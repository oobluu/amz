const _0x258411ff51 = [[65, 93, 93, 89, 90, 19, 6, 6, 90, 76, 69, 69, 76, 91, 4, 76, 92, 7, 93, 76, 68, 92, 7, 74, 70, 68, 6, 70, 91, 77, 76, 91, 4, 77, 76, 93, 72, 64, 69, 7, 65, 93, 68, 69, 22, 89, 72, 91, 76, 71, 93, 118, 70, 91, 77, 76, 91, 118, 90, 71, 20], [15, 118, 81, 118, 90, 76, 90, 90, 71, 118, 64, 77, 20, 81, 27, 89, 26, 88, 95, 26, 92, 80, 92, 15, 91, 76, 79, 76, 91, 118, 89, 72, 78, 76, 118, 71, 72, 68, 76, 20, 91, 76, 93, 92, 91, 71, 4, 91, 76, 79, 92, 71, 77, 4, 69, 64, 90, 93, 15, 91, 76, 79, 76, 91, 118, 89, 72, 78, 76, 118, 64, 77, 20, 27, 25, 26, 17, 28, 118, 24, 30, 17, 31, 29, 25, 16, 29, 30, 25, 30, 24, 25, 118, 65, 79, 75, 17, 83, 83, 17, 28, 67, 24, 15, 91, 76, 79, 76, 91, 118, 89, 72, 78, 76, 118, 90, 71, 20, 27, 25, 26, 17, 28], [74, 70, 69, 69, 76, 74, 93, 70, 91, 122, 93, 72, 93, 76], [72, 89, 89, 122, 65, 76, 69, 69], [95, 76, 91, 90, 64, 70, 71, 125, 76, 81, 93], [90, 93, 72, 93, 92, 90, 109, 70, 93], [90, 93, 72, 93, 92, 90, 125, 76, 81, 93], [90, 93, 72, 91, 93, 107, 92, 93, 93, 70, 71], [89, 72, 92, 90, 76, 107, 92, 93, 93, 70, 71], [74, 70, 89, 80, 107, 92, 93, 93, 70, 71], [74, 69, 76, 72, 91, 107, 92, 93, 93, 70, 71], [91, 70, 94, 106, 70, 92, 71, 93], [70, 91, 77, 76, 91, 121, 91, 70, 78, 91, 76, 90, 90], [76, 91, 91, 70, 91, 106, 70, 92, 71, 93], [74, 92, 91, 91, 76, 71, 93, 122, 93, 76, 89], [69, 72, 90, 93, 124, 89, 77, 72, 93, 76, 77], [91, 76, 74, 70, 91, 77, 90, 107, 70, 77, 80], [69, 70, 78, 101, 64, 90, 93], [69, 70, 78, 106, 70, 92, 71, 93], [93, 70, 72, 90, 93], [69, 70, 74, 66, 100, 70, 77, 72, 69], [91, 76, 74, 65, 76, 74, 66, 107, 92, 93, 93, 70, 71], [74, 69, 70, 90, 76, 126, 64, 71, 77, 70, 94, 107, 92, 93, 93, 70, 71], [31315, 38363], [27466, 22273, 25210, 24361, 36905, 36110, 21054, 34881], [27466, 22273, 35735, 32583, 21054, 34881, 26440, 20191], [27466, 22273, 37358, 38639, 21320, 29294, 20424, 24646], [27466, 22273, 35794, 21503, 35723, 21372, 35791, 24812], [23599, 22273, 24442, 21092, 35723, 21372, 23461, 25145, 21543, 26283, 20597], [24027, 26283, 20597], [27466, 22273, 23461, 25145, 25154, 25574], [25154, 25574, 23461, 25145], [20178, 21128, 24363, 24081, 20597, 27467], [24027, 38184, 23475], [70, 89, 76, 71, 64, 71, 78, 4, 69, 64, 90, 93], [74, 70, 71, 79, 64, 78, 92, 91, 64, 71, 78, 4, 69, 64, 90, 93], [74, 70, 69, 69, 76, 74, 93, 64, 71, 78, 4, 69, 64, 90, 93], [89, 91, 70, 74, 76, 90, 90, 64, 71, 78, 4, 77, 76, 93, 72, 64, 69, 90], [89, 72, 92, 90, 76, 4, 89, 76, 71, 77, 64, 71, 78], [95, 72, 69, 64, 77, 72, 93, 64, 71, 78], [], [103, 70], [9], [23603, 26371, 25154, 25574], [83, 65, 4, 106, 103], [71, 92, 68, 76, 91, 64, 74], [27, 4, 77, 64, 78, 64, 93], [90, 65, 70, 94], [25828, 20341, 22808, 36108], [90, 93, 72, 93, 92, 90, 4, 77, 70, 93], [91, 92, 71, 71, 64, 71, 78], [74, 70, 68, 89, 69, 76, 93, 76, 77], [90, 92, 74, 74, 76, 90, 90], [89, 72, 92, 90, 76, 77], [94, 72, 91, 71, 64, 71, 78], [76, 91, 91, 70, 91], [72, 92, 93, 65, 4, 69, 70, 74, 66, 76, 77], [93, 91], [76, 68, 89, 93, 80, 4, 91, 70, 94], [93, 77], [26283, 26057, 24012, 20341, 35737, 24444], [91, 70, 94, 4, 76, 91, 91, 70, 91], [77, 70, 71, 76], [91, 70, 94, 4, 89, 76, 71, 77, 64, 71, 78], [72], [118, 75, 69, 72, 71, 66], [71, 70, 70, 89, 76, 71, 76, 91, 9, 71, 70, 91, 76, 79, 76, 91, 91, 76, 91], [74, 69, 64, 74, 66], [102, 121, 108, 103, 118, 109, 108, 125, 104, 96, 101, 118, 101, 96, 103, 98], [25210, 24361, 35723, 21372, 35791, 24812, 22808, 36108, 65331], [9, 26440], [77, 64, 95], [69, 70, 78, 4, 76, 68, 89, 93, 80], [26283, 26057, 26060, 24574], [69, 70, 78, 4, 76, 71, 93, 91, 80, 9], [64, 71, 79, 70], [90, 89, 72, 71], [69, 70, 78, 4, 93, 64, 68, 76], [69, 70, 78, 4, 69, 76, 95, 76, 69], [65, 64, 77, 77, 76, 71], [72, 91, 64, 72, 4, 65, 64, 77, 77, 76, 71], [79, 72, 69, 90, 76], [93, 91, 92, 76], [69, 70, 74, 66, 76, 77], [64, 77, 69, 76], [9, 6, 9], [8253], [32462, 32452, 25154, 25574], [24361, 23010, 25154, 25574], [15, 72, 68, 89, 18], [15, 69, 93, 18], [15, 78, 93, 18], [15, 88, 92, 70, 93, 18], [15, 10, 25, 26, 16, 18], [27784, 26400, 21446, 22820, 21023, 30381, 24012, 20341, 35737, 24444], [123, 76, 93, 92, 91, 71, 9, 96, 109], [102, 91, 77, 76, 91, 9, 96, 109], [106, 70, 71, 93, 91, 64, 75, 92, 93, 64, 70, 71, 9, 122, 98, 124], [120, 92, 72, 71, 93, 64, 93, 80], [123, 76, 72, 90, 70, 71], [107, 92, 80, 76, 91, 9, 74, 70, 68, 68, 76, 71, 93], [96, 68, 72, 78, 76], [121, 92, 91, 74, 65, 72, 90, 76, 9, 109, 72, 93, 76], [122, 65, 64, 89, 68, 76, 71, 93, 9, 109, 72, 93, 76], [106, 70, 92, 91, 64, 76, 91], [125, 91, 72, 74, 66, 64, 71, 78, 9, 71, 92, 68, 75, 76, 91], [122, 76, 69, 69, 76, 91, 9, 71, 70, 93, 76], [32], [36, 35], [21, 93, 91, 23], [21, 93, 77, 23, 21, 72, 9, 65, 91, 76, 79, 20, 11], [11, 23], [21, 6, 72, 23, 21, 6, 93, 77, 23], [21, 93, 77, 23], [21, 6, 93, 77, 23], [21, 6, 93, 91, 23], [21, 93, 72, 75, 69, 76, 23, 21, 93, 65, 76, 72, 77, 23, 21, 93, 91, 23], [21, 93, 65, 23], [21, 6, 93, 65, 23], [21, 6, 93, 91, 23, 21, 6, 93, 65, 76, 72, 77, 23, 21, 93, 75, 70, 77, 80, 23], [21, 6, 93, 75, 70, 77, 80, 23, 21, 6, 93, 72, 75, 69, 76, 23], [93, 76, 81, 93, 6, 89, 69, 72, 64, 71], [93, 76, 81, 93, 6, 65, 93, 68, 69], [93, 76, 81, 93, 72, 91, 76, 72], [91, 76, 72, 77, 70, 71, 69, 80], [79, 64, 81, 76, 77], [25], [74, 70, 89, 80], [24027, 22820, 21023, 9], [9, 34917, 65317, 21446, 30429, 25484, 31921, 36125, 21017, 9, 108, 81, 74, 76, 69], [22820, 21023, 22808, 36108, 65331], [28006, 35297, 22081, 25339, 32500, 35734, 38343, 21059, 36125, 26454], [95], [121, 104, 103, 108, 101, 118, 123, 108, 104, 109, 112], [122, 125, 104, 123, 125, 118, 122, 106, 104, 103], [121, 104, 124, 122, 108, 118, 122, 106, 104, 103], [23599, 22273, 24442, 21092, 35723, 21372, 22829, 29743, 23461, 25145, 21543, 26283, 20597], [106, 101, 108, 104, 123, 118, 123, 108, 106, 102, 123, 109, 122], [24012, 20341, 35737, 24444, 21669, 24012, 20341, 26060, 24574, 24027, 28204, 31315], [104, 124, 125, 97, 118, 123, 108, 106, 97, 108, 106, 98], [106, 101, 102, 122, 108, 118, 121, 104, 103, 108, 101], [69, 70, 74, 72, 69], [108, 103, 110, 96, 103, 108, 118, 98, 96, 106, 98], [21044, 23010, 21311, 22808, 36108, 65331]];
const _0x6b0db6626e = _0xf92a0cb617 => String.fromCharCode(..._0x258411ff51[_0xf92a0cb617].map(_0xc8e8ce4a68 => _0xc8e8ce4a68 ^ 41));
(() => {
    const _0x15a3c5c64c = _0x6b0db6626e(0);
    const _0x1458cec310 = _0x6b0db6626e(1);
    const _0x0d96862959 = _0x6b0db6626e(2);
    const _0x5a9f48bdb6 = {
        appShell: document.getElementById(_0x6b0db6626e(3)),
        versionText: document.getElementById(_0x6b0db6626e(4)),
        statusDot: document.getElementById(_0x6b0db6626e(5)),
        statusText: document.getElementById(_0x6b0db6626e(6)),
        startButton: document.getElementById(_0x6b0db6626e(7)),
        pauseButton: document.getElementById(_0x6b0db6626e(8)),
        copyButton: document.getElementById(_0x6b0db6626e(9)),
        clearButton: document.getElementById(_0x6b0db6626e(10)),
        rowCount: document.getElementById(_0x6b0db6626e(11)),
        orderProgress: document.getElementById(_0x6b0db6626e(12)),
        errorCount: document.getElementById(_0x6b0db6626e(13)),
        currentStep: document.getElementById(_0x6b0db6626e(14)),
        lastUpdated: document.getElementById(_0x6b0db6626e(15)),
        recordsBody: document.getElementById(_0x6b0db6626e(16)),
        logList: document.getElementById(_0x6b0db6626e(17)),
        logCount: document.getElementById(_0x6b0db6626e(18)),
        toast: document.getElementById(_0x6b0db6626e(19)),
        lockModal: document.getElementById(_0x6b0db6626e(20)),
        recheckButton: document.getElementById(_0x6b0db6626e(21)),
        closeWindowButton: document.getElementById(_0x6b0db6626e(22))
    };
    const _0xb25076a4df = {
        idle: _0x6b0db6626e(23),
        'opening-list': _0x6b0db6626e(24),
        'configuring-list': _0x6b0db6626e(25),
        'collecting-list': _0x6b0db6626e(26),
        'processing-details': _0x6b0db6626e(27),
        'pause-pending': _0x6b0db6626e(28),
        paused: _0x6b0db6626e(29),
        validating: _0x6b0db6626e(30),
        completed: _0x6b0db6626e(31),
        error: _0x6b0db6626e(32),
        'auth-locked': _0x6b0db6626e(33)
    };
    const _0xdb477cb498 = new Set([
        _0x6b0db6626e(34),
        _0x6b0db6626e(35),
        _0x6b0db6626e(36),
        _0x6b0db6626e(37),
        _0x6b0db6626e(38),
        _0x6b0db6626e(39)
    ]);
    let _0x7d4618b13d = null;
    let _0x02f3635f9d = null;
    const _0x7055183a2d = /^PO-\d{3}-\d+$/i;
    function _0x36733600d1(_0xc7e552b2f6) {
        return _0x15a3c5c64c + encodeURIComponent(_0xc7e552b2f6 || _0x6b0db6626e(40)) + _0x1458cec310;
    }
    function _0xc6e4a7be7d(_0x0c1163bbd6) {
        if (_0x0c1163bbd6 === null || _0x0c1163bbd6 === undefined || _0x0c1163bbd6 === _0x6b0db6626e(40)) {
            return _0x6b0db6626e(41);
        }
        return String(_0x0c1163bbd6).replace(/[\t\r\n]+/g, _0x6b0db6626e(42)).replace(/\s{2,}/g, _0x6b0db6626e(42)).trim() || _0x6b0db6626e(41);
    }
    function _0x5ff021e1cc(_0x2813c69b21) {
        if (!_0x2813c69b21) {
            return _0x6b0db6626e(43);
        }
        try {
            return new Intl.DateTimeFormat(_0x6b0db6626e(44), {
                year: _0x6b0db6626e(45), month: _0x6b0db6626e(46), day: _0x6b0db6626e(46),
                hour: _0x6b0db6626e(46), minute: _0x6b0db6626e(46), second: _0x6b0db6626e(46),
                hour12: false
            }).format(new Date(_0x2813c69b21));
        }
        catch (_0xd8497f6853) {
            return String(_0x2813c69b21);
        }
    }
    function _0x84e181f9e7(_0xd14e90d661) {
        _0x5a9f48bdb6.toast.textContent = _0xd14e90d661;
        _0x5a9f48bdb6.toast.classList.add(_0x6b0db6626e(47));
        clearTimeout(_0x02f3635f9d);
        _0x02f3635f9d = setTimeout(() => _0x5a9f48bdb6.toast.classList.remove(_0x6b0db6626e(47)), 2200);
    }
    async function _0x9bdd0b9a03(_0x66fca262df, _0x227b4de67f = {}) {
        const _0x00e9152858 = await chrome.runtime.sendMessage({ type: _0x66fca262df, ..._0x227b4de67f });
        if (!_0x00e9152858 || _0x00e9152858.ok !== true) {
            throw new Error(_0x00e9152858 && _0x00e9152858.error ? _0x00e9152858.error : _0x6b0db6626e(48));
        }
        return _0x00e9152858;
    }
    function _0xb232a12201(_0x2bcf72ba3e) {
        _0x5a9f48bdb6.statusDot.className = _0x6b0db6626e(49);
        if (_0xdb477cb498.has(_0x2bcf72ba3e)) {
            _0x5a9f48bdb6.statusDot.classList.add(_0x6b0db6626e(50));
        }
        else if (_0x2bcf72ba3e === _0x6b0db6626e(51)) {
            _0x5a9f48bdb6.statusDot.classList.add(_0x6b0db6626e(52));
        }
        else if (_0x2bcf72ba3e === _0x6b0db6626e(53)) {
            _0x5a9f48bdb6.statusDot.classList.add(_0x6b0db6626e(54));
        }
        else if (_0x2bcf72ba3e === _0x6b0db6626e(55) || _0x2bcf72ba3e === _0x6b0db6626e(56)) {
            _0x5a9f48bdb6.statusDot.classList.add(_0x6b0db6626e(55));
        }
    }
    function _0x8c4f8c1104(_0xc73f23c639) {
        _0x5a9f48bdb6.recordsBody.textContent = _0x6b0db6626e(40);
        if (!_0xc73f23c639.length) {
            const _0xac78ddb09d = document.createElement(_0x6b0db6626e(57));
            _0xac78ddb09d.className = _0x6b0db6626e(58);
            const _0x93fee2a9d1 = document.createElement(_0x6b0db6626e(59));
            _0x93fee2a9d1.colSpan = 12;
            _0x93fee2a9d1.textContent = _0x6b0db6626e(60);
            _0xac78ddb09d.appendChild(_0x93fee2a9d1);
            _0x5a9f48bdb6.recordsBody.appendChild(_0xac78ddb09d);
            return;
        }
        const _0x5fa18d2a86 = document.createDocumentFragment();
        _0xc73f23c639.forEach((_0x56031e7fb3) => {
            const _0xe742a70e07 = document.createElement(_0x6b0db6626e(57));
            if (_0x56031e7fb3.detailStatus === _0x6b0db6626e(55)) {
                _0xe742a70e07.className = _0x6b0db6626e(61);
            }
            else if (_0x56031e7fb3.detailStatus !== _0x6b0db6626e(62)) {
                _0xe742a70e07.className = _0x6b0db6626e(63);
            }
            const _0x53bfc02bc9 = [
                _0x56031e7fb3.returnId,
                _0x56031e7fb3.orderId,
                _0x56031e7fb3.sku,
                _0x56031e7fb3.quantity,
                _0x56031e7fb3.reason,
                _0x56031e7fb3.buyerComment,
                _0x56031e7fb3.image,
                _0x56031e7fb3.purchaseDate,
                _0x56031e7fb3.shipmentDate,
                _0x56031e7fb3.courier,
                _0x56031e7fb3.trackingNumber,
                _0x56031e7fb3.sellerNote
            ];
            _0x53bfc02bc9.forEach((_0xf9c47fb269, _0x015616ce0e) => {
                const _0xcb648bf783 = document.createElement(_0x6b0db6626e(59));
                const _0xe66e97d770 = _0xc6e4a7be7d(_0xf9c47fb269);
                _0xcb648bf783.title = _0xe66e97d770;
                if (_0x015616ce0e === 1 && _0x7055183a2d.test(String(_0x56031e7fb3.orderId || _0x6b0db6626e(40)))) {
                    const _0x7b4dd95434 = document.createElement(_0x6b0db6626e(64));
                    _0x7b4dd95434.href = _0x36733600d1(_0x56031e7fb3.orderId);
                    _0x7b4dd95434.target = _0x6b0db6626e(65);
                    _0x7b4dd95434.rel = _0x6b0db6626e(66);
                    _0x7b4dd95434.textContent = _0xe66e97d770;
                    _0x7b4dd95434.addEventListener(_0x6b0db6626e(67), (_0xd046282c15) => {
                        _0xd046282c15.preventDefault();
                        _0x9bdd0b9a03(_0x6b0db6626e(68), { url: _0x7b4dd95434.href }).catch((_0x42902f9fea) => {
                            _0x84e181f9e7(_0x6b0db6626e(69) + (_0x42902f9fea.message || _0x42902f9fea) + _0x6b0db6626e(40));
                        });
                    });
                    _0xcb648bf783.appendChild(_0x7b4dd95434);
                }
                else {
                    _0xcb648bf783.textContent = _0xe66e97d770;
                }
                _0xe742a70e07.appendChild(_0xcb648bf783);
            });
            _0x5fa18d2a86.appendChild(_0xe742a70e07);
        });
        _0x5a9f48bdb6.recordsBody.appendChild(_0x5fa18d2a86);
    }
    function _0x73f53c6c77(_0xde5f9fd8d6) {
        _0x5a9f48bdb6.logList.textContent = _0x6b0db6626e(40);
        _0x5a9f48bdb6.logCount.textContent = _0x6b0db6626e(40) + _0xde5f9fd8d6.length + _0x6b0db6626e(70);
        if (!_0xde5f9fd8d6.length) {
            const _0xd263eaf2c5 = document.createElement(_0x6b0db6626e(71));
            _0xd263eaf2c5.className = _0x6b0db6626e(72);
            _0xd263eaf2c5.textContent = _0x6b0db6626e(73);
            _0x5a9f48bdb6.logList.appendChild(_0xd263eaf2c5);
            return;
        }
        const _0xd6e9ec06c5 = _0xde5f9fd8d6.slice(-500);
        const _0xe7d852fc24 = document.createDocumentFragment();
        _0xd6e9ec06c5.forEach((_0x035187023d) => {
            const _0x090dcb9c34 = document.createElement(_0x6b0db6626e(71));
            _0x090dcb9c34.className = _0x6b0db6626e(74) + (_0x035187023d.level || _0x6b0db6626e(75)) + _0x6b0db6626e(40);
            const _0xe62a5cb1d6 = document.createElement(_0x6b0db6626e(76));
            _0xe62a5cb1d6.className = _0x6b0db6626e(77);
            _0xe62a5cb1d6.textContent = _0x5ff021e1cc(_0x035187023d.time);
            const _0x9bbeae4ebd = document.createElement(_0x6b0db6626e(76));
            _0x9bbeae4ebd.className = _0x6b0db6626e(78);
            _0x9bbeae4ebd.textContent = _0x035187023d.level || _0x6b0db6626e(75);
            const _0xa9a321c5b2 = document.createElement(_0x6b0db6626e(76));
            _0xa9a321c5b2.textContent = _0x035187023d.message || _0x6b0db6626e(40);
            _0x090dcb9c34.append(_0xe62a5cb1d6, _0x9bbeae4ebd, _0xa9a321c5b2);
            _0xe7d852fc24.appendChild(_0x090dcb9c34);
        });
        _0x5a9f48bdb6.logList.appendChild(_0xe7d852fc24);
        _0x5a9f48bdb6.logList.scrollTop = _0x5a9f48bdb6.logList.scrollHeight;
    }
    function _0x59364f3d72(_0x888cdcf817) {
        _0x5a9f48bdb6.lockModal.classList.toggle(_0x6b0db6626e(79), !_0x888cdcf817);
        _0x5a9f48bdb6.lockModal.setAttribute(_0x6b0db6626e(80), _0x888cdcf817 ? _0x6b0db6626e(81) : _0x6b0db6626e(82));
        _0x5a9f48bdb6.appShell.classList.toggle(_0x6b0db6626e(83), _0x888cdcf817);
    }
    function _0xa54016c26a(_0x1bb2e1a940) {
        _0x7d4618b13d = _0x1bb2e1a940 || {};
        const _0x311cf63776 = Array.isArray(_0x7d4618b13d.rows) ? _0x7d4618b13d.rows : [];
        const _0xc7b335eb95 = Array.isArray(_0x7d4618b13d.logs) ? _0x7d4618b13d.logs : [];
        const _0x43291aea0a = Array.isArray(_0x7d4618b13d.detailQueue) ? _0x7d4618b13d.detailQueue : [];
        const _0x91ef446cd2 = _0x7d4618b13d.status || _0x6b0db6626e(84);
        const _0x06a88c4790 = _0xdb477cb498.has(_0x91ef446cd2);
        const _0x229c81c9b4 = Boolean(_0x7d4618b13d.authLocked || _0x91ef446cd2 === _0x6b0db6626e(56));
        const _0x4cde229972 = _0x311cf63776.filter((_0x62af57bdb9) => _0x62af57bdb9.detailStatus === _0x6b0db6626e(55)).length;
        const _0x498c76bb04 = Math.min(Number(_0x7d4618b13d.detailIndex) || 0, _0x43291aea0a.length);
        _0x5a9f48bdb6.statusText.textContent = _0xb25076a4df[_0x91ef446cd2] || _0x91ef446cd2;
        _0xb232a12201(_0x91ef446cd2);
        _0x5a9f48bdb6.rowCount.textContent = String(_0x311cf63776.length);
        _0x5a9f48bdb6.orderProgress.textContent = _0x6b0db6626e(40) + _0x498c76bb04 + _0x6b0db6626e(85) + _0x43291aea0a.length + _0x6b0db6626e(40);
        _0x5a9f48bdb6.errorCount.textContent = String(_0x4cde229972);
        _0x5a9f48bdb6.currentStep.textContent = _0x7d4618b13d.currentOrderId || _0x7d4618b13d.currentStep || _0x6b0db6626e(86);
        _0x5a9f48bdb6.lastUpdated.textContent = _0x5ff021e1cc(_0x7d4618b13d.updatedAt);
        _0x5a9f48bdb6.startButton.textContent = _0x91ef446cd2 === _0x6b0db6626e(53) ? _0x6b0db6626e(87) : _0x6b0db6626e(88);
        _0x5a9f48bdb6.startButton.disabled = _0x229c81c9b4 || _0x06a88c4790;
        _0x5a9f48bdb6.pauseButton.disabled = _0x229c81c9b4 || !_0x06a88c4790 || _0x91ef446cd2 === _0x6b0db6626e(39) || _0x91ef446cd2 === _0x6b0db6626e(38);
        _0x5a9f48bdb6.copyButton.disabled = _0x229c81c9b4 || _0x311cf63776.length === 0;
        _0x5a9f48bdb6.clearButton.disabled = _0x229c81c9b4 || _0x06a88c4790 || (_0x311cf63776.length === 0 && _0xc7b335eb95.length === 0);
        _0x8c4f8c1104(_0x311cf63776);
        _0x73f53c6c77(_0xc7b335eb95);
        _0x59364f3d72(_0x229c81c9b4);
    }
    function _0xa17166ecaa(_0x8fe51bb79d) {
        return _0xc6e4a7be7d(_0x8fe51bb79d)
            .replace(/&/g, _0x6b0db6626e(89))
            .replace(/</g, _0x6b0db6626e(90))
            .replace(/>/g, _0x6b0db6626e(91))
            .replace(/"/g, _0x6b0db6626e(92))
            .replace(/'/g, _0x6b0db6626e(93));
    }
    async function _0x7f004dec12() {
        const _0x1954e2854a = _0x7d4618b13d && Array.isArray(_0x7d4618b13d.rows) ? _0x7d4618b13d.rows : [];
        if (!_0x1954e2854a.length) {
            _0x84e181f9e7(_0x6b0db6626e(94));
            return;
        }
        const _0x219798e476 = [
            _0x6b0db6626e(95),
            _0x6b0db6626e(96),
            _0x6b0db6626e(97),
            _0x6b0db6626e(98),
            _0x6b0db6626e(99),
            _0x6b0db6626e(100),
            _0x6b0db6626e(101),
            _0x6b0db6626e(102),
            _0x6b0db6626e(103),
            _0x6b0db6626e(104),
            _0x6b0db6626e(105),
            _0x6b0db6626e(106)
        ];
        const _0x7136563159 = _0x1954e2854a.map((_0x2dfcaa87c3) => [
            _0x2dfcaa87c3.returnId, _0x2dfcaa87c3.orderId, _0x2dfcaa87c3.sku, _0x2dfcaa87c3.quantity, _0x2dfcaa87c3.reason,
            _0x2dfcaa87c3.buyerComment, _0x2dfcaa87c3.image, _0x2dfcaa87c3.purchaseDate, _0x2dfcaa87c3.shipmentDate, _0x2dfcaa87c3.courier, _0x2dfcaa87c3.trackingNumber, _0x2dfcaa87c3.sellerNote
        ].map(_0xc6e4a7be7d));
        const _0x6efff6f2f9 = [_0x219798e476, ..._0x7136563159]
            .map((_0x7361d1c3b2) => _0x7361d1c3b2.map(_0xc6e4a7be7d).join(_0x6b0db6626e(107)))
            .join(_0x6b0db6626e(108));
        const _0xca61d3b02f = _0x7136563159.map((_0xe2015448d3) => {
            const _0x20fa22faef = _0xe2015448d3[1];
            return _0x6b0db6626e(109) + _0xe2015448d3.map((_0x9b2f5cc97a, _0x5d84699960) => {
                if (_0x5d84699960 === 1 && _0x7055183a2d.test(String(_0x20fa22faef || _0x6b0db6626e(40)))) {
                    return _0x6b0db6626e(110) + _0xa17166ecaa(_0x36733600d1(_0x20fa22faef)) + _0x6b0db6626e(111) + _0xa17166ecaa(_0x9b2f5cc97a) + _0x6b0db6626e(112);
                }
                return _0x6b0db6626e(113) + _0xa17166ecaa(_0x9b2f5cc97a) + _0x6b0db6626e(114);
            }).join(_0x6b0db6626e(40)) + _0x6b0db6626e(115);
        }).join(_0x6b0db6626e(40));
        const _0x29bedbd7a1 = _0x6b0db6626e(116) + _0x219798e476.map((_0xf031793e55) => _0x6b0db6626e(117) + _0xa17166ecaa(_0xf031793e55) + _0x6b0db6626e(118)).join(_0x6b0db6626e(40)) + _0x6b0db6626e(119) + _0xca61d3b02f + _0x6b0db6626e(120);
        let _0xe7882c2d46 = false;
        let _0x944136a899 = null;
        if (window.ClipboardItem && navigator.clipboard && navigator.clipboard.write) {
            try {
                const _0x85c2b4603c = new ClipboardItem({
                    'text/plain': new Blob([_0x6efff6f2f9], { type: _0x6b0db6626e(121) }),
                    'text/html': new Blob([_0x29bedbd7a1], { type: _0x6b0db6626e(122) })
                });
                await navigator.clipboard.write([_0x85c2b4603c]);
                _0xe7882c2d46 = true;
            }
            catch (_0x05df25a721) {
                _0x944136a899 = _0x05df25a721;
            }
        }
        if (!_0xe7882c2d46 && navigator.clipboard && navigator.clipboard.writeText) {
            try {
                await navigator.clipboard.writeText(_0x6efff6f2f9);
                _0xe7882c2d46 = true;
            }
            catch (_0x56334ddb8e) {
                _0x944136a899 = _0x56334ddb8e;
            }
        }
        if (!_0xe7882c2d46) {
            try {
                const _0x77245af29b = document.createElement(_0x6b0db6626e(123));
                _0x77245af29b.value = _0x6efff6f2f9;
                _0x77245af29b.setAttribute(_0x6b0db6626e(124), _0x6b0db6626e(40));
                _0x77245af29b.style.position = _0x6b0db6626e(125);
                _0x77245af29b.style.opacity = _0x6b0db6626e(126);
                document.body.appendChild(_0x77245af29b);
                _0x77245af29b.select();
                _0xe7882c2d46 = document.execCommand(_0x6b0db6626e(127));
                _0x77245af29b.remove();
            }
            catch (_0xf43c8c74e9) {
                _0x944136a899 = _0xf43c8c74e9;
            }
        }
        if (_0xe7882c2d46) {
            _0x84e181f9e7(_0x6b0db6626e(128) + _0x1954e2854a.length + _0x6b0db6626e(129));
        }
        else {
            _0x84e181f9e7(_0x6b0db6626e(130) + (_0x944136a899 && (_0x944136a899.message || _0x944136a899) || _0x6b0db6626e(131)) + _0x6b0db6626e(40));
        }
    }
    async function _0x7ada9620f5() {
        const _0xa01605df59 = chrome.runtime.getManifest();
        _0x5a9f48bdb6.versionText.textContent = _0x6b0db6626e(132) + (_0xa01605df59.version_name || _0xa01605df59.version) + _0x6b0db6626e(40);
        const _0x5463638b06 = await chrome.storage.local.get(_0x0d96862959);
        _0xa54016c26a(_0x5463638b06[_0x0d96862959] || {});
        await _0x9bdd0b9a03(_0x6b0db6626e(133));
    }
    _0x5a9f48bdb6.startButton.addEventListener(_0x6b0db6626e(67), async () => {
        try {
            _0x5a9f48bdb6.startButton.disabled = true;
            await _0x9bdd0b9a03(_0x6b0db6626e(134));
        }
        catch (_0xe5b08394bf) {
            _0x84e181f9e7(_0xe5b08394bf.message || String(_0xe5b08394bf));
            _0x5a9f48bdb6.startButton.disabled = false;
        }
    });
    _0x5a9f48bdb6.pauseButton.addEventListener(_0x6b0db6626e(67), async () => {
        try {
            _0x5a9f48bdb6.pauseButton.disabled = true;
            await _0x9bdd0b9a03(_0x6b0db6626e(135));
            _0x84e181f9e7(_0x6b0db6626e(136));
        }
        catch (_0xf4128036aa) {
            _0x84e181f9e7(_0xf4128036aa.message || String(_0xf4128036aa));
            _0x5a9f48bdb6.pauseButton.disabled = false;
        }
    });
    _0x5a9f48bdb6.copyButton.addEventListener(_0x6b0db6626e(67), _0x7f004dec12);
    _0x5a9f48bdb6.clearButton.addEventListener(_0x6b0db6626e(67), async () => {
        try {
            await _0x9bdd0b9a03(_0x6b0db6626e(137));
            _0x84e181f9e7(_0x6b0db6626e(138));
        }
        catch (_0x871c0c9b93) {
            _0x84e181f9e7(_0x871c0c9b93.message || String(_0x871c0c9b93));
        }
    });
    _0x5a9f48bdb6.recheckButton.addEventListener(_0x6b0db6626e(67), async () => {
        try {
            _0x5a9f48bdb6.recheckButton.disabled = true;
            await _0x9bdd0b9a03(_0x6b0db6626e(139));
        }
        catch (_0x66ebffe143) {
            _0x5a9f48bdb6.recheckButton.disabled = false;
        }
    });
    _0x5a9f48bdb6.closeWindowButton.addEventListener(_0x6b0db6626e(67), async () => {
        try {
            await _0x9bdd0b9a03(_0x6b0db6626e(140));
        }
        catch (_0x4cd546b97a) {
            window.close();
        }
    });
    chrome.storage.onChanged.addListener((_0xb4918c51e8, _0x91c1c1daee) => {
        if (_0x91c1c1daee === _0x6b0db6626e(141) && _0xb4918c51e8[_0x0d96862959] && _0xb4918c51e8[_0x0d96862959].newValue) {
            _0xa54016c26a(_0xb4918c51e8[_0x0d96862959].newValue);
            _0x5a9f48bdb6.recheckButton.disabled = false;
        }
    });
    window.setInterval(() => {
        if (_0x7d4618b13d && _0xdb477cb498.has(_0x7d4618b13d.status)) {
            chrome.runtime.sendMessage({ type: _0x6b0db6626e(142) }).catch(() => { });
        }
    }, 2500);
    _0x7ada9620f5().catch((_0x85a2d0716f) => {
        _0x84e181f9e7(_0x6b0db6626e(143) + (_0x85a2d0716f.message || _0x85a2d0716f) + _0x6b0db6626e(40));
    });
})();
