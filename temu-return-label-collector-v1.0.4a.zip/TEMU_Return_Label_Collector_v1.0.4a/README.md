# TEMU Return Label Collector

## 安装

1. 解压 ZIP 文件。
2. 在 Chrome 地址栏打开 `chrome://extensions/`。
3. 开启右上角的“开发者模式”。
4. 点击“加载已解压的扩展程序”。
5. 选择解压后的插件目录。

## 使用方法

1. 点击浏览器工具栏中的插件图标，打开独立工具窗口。
2. 点击“开始扫描”。
3. 插件会在当前普通浏览器窗口打开并自动切换到 TEMU 退货列表，设置目标筛选条件、排序方式和每页 100 条。列表卡片采集完成后，会关闭列表页并返回工具窗口。
4. 插件先采集第一页全部退货卡片，再逐个读取对应订单详情。
5. 扫描过程中可以点击“暂停扫描”。插件会完成当前订单后暂停并关闭详情工作标签页。
6. 暂停后点击“继续扫描”，插件会从下一条未完成订单继续。
7. 点击“复制到 Excel”，可将当前 12 列记录直接粘贴到 Excel。
8. 点击“一键清空”，可同时清除当前工作记录和工作日志。

## 工作记录列

- Return ID
- Order ID
- Contribution SKU
- Quantity
- Reason
- Buyer comment
- Image
- Purchase Date
- Shipment Date
- Courier
- Tracking number
- Seller note

Order ID 在工具窗口中为可点击链接。

## 数据规则

- 同一退货请求包含多个 Contribution SKU 时，每个 SKU 单独生成一行。
- 同一 Order ID 只打开一次详情页，详情数据会回填到该订单对应的全部行。
- 买家存在图片或视频证据时，Image 记录为 `Yes`，否则为 `No`。
- Purchase Date 读取订单详情页 `Order summary` 模块中 `Purchase date` 后显示的日期。
- Shipment Date 读取订单详情页物流模块中 `Shipment confirmed at` 后显示的日期；同一订单存在多个物流模块时，按页面顺序使用 ` | ` 合并。
- Seller note 只记录包含 GLS、DHL 或 DPD 的内容；多个匹配内容使用 ` | ` 分隔。
- 页面明确没有字段时记录 `No`；页面加载或提取失败时记录 `ERROR`，并继续下一条。
- 本版本只处理设置为每页 100 条后的第一页。

## 异常样本

插件遇到未提供过的页面结构时，会把对应 HTML 样本保存为 TXT 文件。同一种异常类型只保存一次。已确认可正常处理的多商品卡片，以及每页 100 条选择控件的常见首次切换失败，不再保存异常样本。

保存位置：

`下载/TEMU_Return_Label_Collector/Anomaly_Samples/`

文件名中包含异常类型和记录时间，便于后续补充页面适配。

## 注意事项

- 使用前请确保已经登录 TEMU Seller Center。
- 列表设置和卡片采集期间，插件会保持退货列表标签页处于前台；订单详情仍在后台逐个处理。
- 关闭独立工具窗口后，插件会完成当前订单并暂停，不会继续不可见扫描。
- 浏览器启用了“每次下载前询问保存位置”时，异常样本保存可能弹出文件选择窗口。


## v1.0.3

- 修正每页 100 条切换后因 React 重建分页 DOM 而误判失败的问题。
- 列表页短暂不稳定时优先在当前页面重新验证，不再直接刷新重做。
- 增强列表异常诊断信息，记录当前筛选、排序、页数及分页组件。


## v1.0.4

- 工作记录新增 Purchase Date。
- 原 Date 字段更名为 Shipment Date。
- Purchase Date 从订单详情页 Order summary 模块提取。
