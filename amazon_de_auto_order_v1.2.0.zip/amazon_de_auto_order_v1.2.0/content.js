'use strict';

(() => {
  if (window.top !== window || window.__AMZ_DE_AUTO_ORDER_CONTENT__) {
    return;
  }
  window.__AMZ_DE_AUTO_ORDER_CONTENT__ = true;

  const RUN_STATE_KEY = 'amzOrderRunState';
  const ABORTED = Symbol('ABORTED');

  let executing = false;
  let rerunRequested = false;
  let scheduledTimer = null;
  let abortGeneration = 0;
  let activeRunId = null;
  let activeRowIndex = null;

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function scheduleRun(delay = 250) {
    if (scheduledTimer !== null) {
      clearTimeout(scheduledTimer);
    }
    scheduledTimer = setTimeout(() => {
      scheduledTimer = null;
      runAutomation().catch(() => undefined);
    }, delay);
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === 'WAKE_AUTOMATION') {
      scheduleRun(50);
    }
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local' || !changes[RUN_STATE_KEY]) {
      return;
    }

    const nextState = changes[RUN_STATE_KEY].newValue;
    if (
      !nextState ||
      nextState.mode !== 'running' ||
      nextState.runId !== activeRunId ||
      nextState.currentIndex !== activeRowIndex
    ) {
      abortGeneration += 1;
    }
    scheduleRun(100);
  });

  async function send(message) {
    try {
      return await chrome.runtime.sendMessage(message);
    } catch (error) {
      return { ok: false, error: error.message || String(error) };
    }
  }

  function normalizeWhitespace(value) {
    return String(value ?? '')
      .normalize('NFKC')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function normalizeNameForComparison(value) {
    return normalizeWhitespace(value).toLocaleLowerCase('de-DE');
  }

  function namesMatch(left, right) {
    return normalizeNameForComparison(left) === normalizeNameForComparison(right);
  }

  function isVisible(element) {
    if (!(element instanceof Element)) {
      return false;
    }
    const style = window.getComputedStyle(element);
    if (style.display === 'none' || style.visibility === 'hidden') {
      return false;
    }
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function isEnabled(element) {
    return Boolean(
      element &&
      !element.disabled &&
      element.getAttribute('aria-disabled') !== 'true' &&
      !element.closest('.a-button-disabled')
    );
  }

  function findVisible(selector, root = document) {
    return [...root.querySelectorAll(selector)].find((element) => isVisible(element)) || null;
  }

  async function waitFor(check, timeoutMs, intervalMs = 250, epoch = abortGeneration) {
    const startedAt = Date.now();
    while (Date.now() - startedAt < timeoutMs) {
      if (epoch !== abortGeneration) {
        return ABORTED;
      }
      try {
        const result = check();
        if (result) {
          return result;
        }
      } catch {
        // DOM can change during Amazon page rendering. Retry until timeout.
      }
      await sleep(intervalMs);
    }
    return null;
  }

  function detectBlockingPage() {
    if (document.querySelector('#captchacharacters') || /robot check/i.test(document.title)) {
      return 'Amazon 出现验证码或 Robot Check。';
    }
    if (
      document.querySelector('#ap_email') ||
      document.querySelector('form[name="signIn"]') ||
      document.querySelector('#authportal-main-section')
    ) {
      return 'Amazon 当前要求登录或身份验证。';
    }
    const bodyText = normalizeWhitespace(document.body?.innerText || '');
    if (/sorry, we just need to make sure you['’]?re not a robot/i.test(bodyText)) {
      return 'Amazon 出现机器人验证页面。';
    }
    return '';
  }

  function detectProductNotFoundPage() {
    const bodyText = normalizeWhitespace(document.body?.innerText || '');
    return Boolean(
      document.querySelector('a[href="/ref=cs_404_logo"]') ||
      document.querySelector('a[href="/ref=cs_404_link"]') ||
      document.querySelector('img[src*="kailey-kitty"]') ||
      (/Looking\s+for\s+something\?/i.test(bodyText) &&
        /not\s+a\s+functioning\s+page\s+on\s+our\s+site/i.test(bodyText))
    );
  }

  function extractAsinFromCurrentPage() {
    const candidates = [location.href, document.querySelector('link[rel="canonical"]')?.href || ''];
    const patterns = [
      /\/(?:dp|gp\/product|gp\/aw\/d)\/([A-Z0-9]{10})(?:[/?]|$)/i,
      /[?&](?:asin|ASIN)=([A-Z0-9]{10})(?:&|$)/i
    ];
    for (const candidate of candidates) {
      for (const pattern of patterns) {
        const match = String(candidate).match(pattern);
        if (match) {
          return match[1].toUpperCase();
        }
      }
    }
    return null;
  }

  function setInputValue(element, value) {
    const expected = String(value ?? '');
    element.focus();

    const prototype = element instanceof HTMLTextAreaElement
      ? HTMLTextAreaElement.prototype
      : HTMLInputElement.prototype;
    const valueSetter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set;
    if (valueSetter) {
      valueSetter.call(element, expected);
    } else {
      element.value = expected;
    }

    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    element.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  function valuesMatch(actual, expected) {
    return normalizeWhitespace(actual) === normalizeWhitespace(expected);
  }

  function findAddressFields() {
    const fullName = document.querySelector('#address-ui-widgets-enterAddressFullName');
    const phone = document.querySelector('#address-ui-widgets-enterAddressPhoneNumber');
    const line1 = document.querySelector('#address-ui-widgets-enterAddressLine1');
    const line2 = document.querySelector('#address-ui-widgets-enterAddressLine2');
    const postal = document.querySelector('#address-ui-widgets-enterAddressPostalCode');
    const city = document.querySelector('#address-ui-widgets-enterAddressCity');
    const country = document.querySelector('#address-ui-widgets-countryCode-dropdown-nativeId');

    const required = [fullName, phone, line1, line2, postal, city];
    if (!required.every((element) => element && isVisible(element))) {
      return null;
    }

    const line1LooksLikeStreet = /street name|street and number/i.test(line1.placeholder || '');
    const line2LooksLikeStreet = /street name|street and number/i.test(line2.placeholder || '');
    const street = line2LooksLikeStreet || !line1LooksLikeStreet ? line2 : line1;
    const extra = street === line2 ? line1 : line2;

    return { fullName, phone, street, extra, postal, city, country };
  }

  function getVisibleUseAddressButton() {
    const candidates = [
      ...document.querySelectorAll('input[data-testid="bottom-continue-button"]'),
      ...document.querySelectorAll('#checkout-primary-continue-button-id input.a-button-input')
    ];
    return candidates.find((element) => isVisible(element) && isEnabled(element)) || null;
  }

  function getVisibleOriginalAddressRadio() {
    const radios = [
      ...document.querySelectorAll('#address-ui-widgets-original-address-block_id-input'),
      ...document.querySelectorAll('input[name="address-ui-widgets-suggested-address-selection"][value^="original-address-"]')
    ];
    return radios.find((radio) => {
      const container = radio.closest('.a-popover, .a-box, label') || radio;
      return isVisible(container);
    }) || null;
  }

  function getVisibleAddressError() {
    const selectors = [
      '.a-alert-error:not(.aok-hidden)',
      '.a-alert-inline-error:not(.aok-hidden)',
      '[role="alert"]:not(.aok-hidden)'
    ];
    for (const selector of selectors) {
      const element = [...document.querySelectorAll(selector)].find(
        (candidate) => isVisible(candidate) && normalizeWhitespace(candidate.textContent)
      );
      if (element) {
        return normalizeWhitespace(element.textContent);
      }
    }
    return '';
  }

  function getPaymentRecipientName() {
    const heading = document.querySelector('#deliver-to-customer-text');
    if (!heading || !isVisible(heading)) {
      return null;
    }
    return normalizeWhitespace(heading.textContent).replace(/^Delivering\s+to\s+/i, '').trim();
  }

  function parseMoney(text) {
    let raw = String(text ?? '').replace(/\s/g, '').replace(/[^\d,.-]/g, '');
    if (!raw) {
      return Number.NaN;
    }

    const comma = raw.lastIndexOf(',');
    const dot = raw.lastIndexOf('.');
    if (comma >= 0 && dot >= 0) {
      const decimalIndex = Math.max(comma, dot);
      const integerPart = raw.slice(0, decimalIndex).replace(/[.,]/g, '');
      const decimalPart = raw.slice(decimalIndex + 1).replace(/[.,]/g, '');
      raw = `${integerPart}.${decimalPart}`;
    } else if (comma >= 0) {
      const decimalDigits = raw.length - comma - 1;
      raw = decimalDigits === 2 ? raw.replace(/\./g, '').replace(',', '.') : raw.replace(/,/g, '');
    } else if (dot >= 0) {
      const decimalDigits = raw.length - dot - 1;
      if (decimalDigits !== 2) {
        raw = raw.replace(/\./g, '');
      }
    }
    return Number(raw);
  }

  function getOrderTotal() {
    const grids = [...document.querySelectorAll('.order-summary-grid')];
    for (const grid of grids) {
      const term = normalizeWhitespace(grid.querySelector('.order-summary-line-term')?.textContent || '');
      if (!/^Order\s*Total\s*:/i.test(term)) {
        continue;
      }
      const amountElement = grid.querySelector(
        '.order-summary-line-definition [data-shimmer-target="ordertotals-amount"], .order-summary-line-definition'
      );
      const text = normalizeWhitespace(amountElement?.textContent || '');
      const value = parseMoney(text);
      return { value, text };
    }
    return null;
  }

  function getPlaceOrderButtons() {
    const selectors = [
      'input[data-testid="SPC_selectPlaceOrder"][data-client-component="PlaceYourOrder"]',
      'input[data-csa-c-slot-id="checkout-place-your-order-button"]',
      'input.place-your-order-button[type="submit"]',
      'input[id="placeOrder"][type="submit"]'
    ];
    const buttons = [];
    const seen = new Set();

    for (const selector of selectors) {
      for (const element of document.querySelectorAll(selector)) {
        if (!(element instanceof HTMLInputElement) || seen.has(element) || !element.isConnected) {
          continue;
        }
        seen.add(element);
        buttons.push(element);
      }
    }
    return buttons;
  }

  function getPlaceOrderButtonSet() {
    const all = getPlaceOrderButtons();
    const usable = all.filter((button) => isVisible(button) && isEnabled(button));
    const top =
      usable.find((button) => button.getAttribute('aria-labelledby') === 'submitOrderButtonId-announce') ||
      usable.find((button) => button.closest('#submitOrderButtonId')) ||
      null;
    const bottom =
      usable.find((button) => button.getAttribute('aria-labelledby') === 'bottomSubmitOrderButtonId-announce') ||
      null;
    const primary = top || usable[0] || null;
    const fallback =
      (bottom && bottom !== primary ? bottom : null) ||
      usable.find((button) => button !== primary) ||
      null;
    return { all, usable, top, bottom, primary, fallback };
  }

  function selectFallbackPlaceOrderButton(buttonSet, previousButton) {
    if (!buttonSet) {
      return null;
    }
    return (
      (buttonSet.bottom && buttonSet.bottom !== previousButton ? buttonSet.bottom : null) ||
      buttonSet.usable.find((button) => button !== previousButton) ||
      null
    );
  }

  function describePlaceOrderButton(button) {
    if (!button) {
      return '未知按钮';
    }
    const labelledBy = button.getAttribute('aria-labelledby') || '';
    if (labelledBy === 'submitOrderButtonId-announce' || button.closest('#submitOrderButtonId')) {
      return '顶部 Buy now';
    }
    if (labelledBy === 'bottomSubmitOrderButtonId-announce') {
      return '底部 Buy now';
    }
    return `Buy now（aria-labelledby=${labelledBy || '空'}）`;
  }

  function getVisibleSubmissionSpinnerCount() {
    const processingSelectors = [
      '.a-spinner-wrapper:not(.aok-hidden)',
      '.checkout-page-spinner:not(.aok-hidden)',
      '[data-testid*="spinner"]:not(.aok-hidden)',
      '[aria-busy="true"]'
    ];
    const seen = new Set();
    for (const selector of processingSelectors) {
      for (const element of document.querySelectorAll(selector)) {
        if (isVisible(element)) {
          seen.add(element);
        }
      }
    }
    return seen.size;
  }

  function hasOrderProcessingText() {
    const bodyText = normalizeWhitespace(document.body?.innerText || '');
    return /placing\s+your\s+order|processing\s+your\s+order|order\s+is\s+being\s+processed/i.test(bodyText);
  }

  function captureSubmissionSnapshot() {
    const buttonSet = getPlaceOrderButtonSet();
    return {
      url: location.href,
      allButtonCount: buttonSet.all.length,
      usableButtonCount: buttonSet.usable.length,
      spinnerCount: getVisibleSubmissionSpinnerCount(),
      hasProcessingText: hasOrderProcessingText()
    };
  }

  function getSubmissionEvidence(snapshot) {
    if (location.href !== snapshot.url) {
      return '页面 URL 已变化';
    }
    if (getReviewOrdersLink()) {
      return '已出现下单成功页面入口';
    }
    if (getFirstOrderCard()) {
      return '已进入订单记录页面';
    }

    if (!snapshot.hasProcessingText && hasOrderProcessingText()) {
      return '页面显示订单提交处理中';
    }

    const spinnerCount = getVisibleSubmissionSpinnerCount();
    if (spinnerCount > snapshot.spinnerCount) {
      return '页面出现新的提交处理中状态';
    }

    const current = getPlaceOrderButtonSet();
    if (snapshot.allButtonCount > 0 && current.all.length === 0) {
      return '付款按钮已从页面移除';
    }
    if (snapshot.usableButtonCount > 0 && current.usable.length < snapshot.usableButtonCount) {
      return '可用付款按钮数量已减少';
    }
    if (current.all.length > 0 && current.all.every((button) => !isVisible(button) || !isEnabled(button))) {
      return '付款按钮已全部隐藏或禁用';
    }
    return '';
  }

  async function nativeClickAndObserve(button, epoch, observeMs = 12000) {
    if (!button || !button.isConnected || !isVisible(button) || !isEnabled(button)) {
      return { clicked: false, evidence: '', error: '按钮在点击前已失效或不可用' };
    }

    const snapshot = captureSubmissionSnapshot();
    let unloading = false;
    const onBeforeUnload = () => {
      unloading = true;
    };
    window.addEventListener('beforeunload', onBeforeUnload, { once: true });
    window.addEventListener('pagehide', onBeforeUnload, { once: true });

    try {
      button.scrollIntoView({ block: 'center', inline: 'center', behavior: 'auto' });
      button.focus({ preventScroll: true });
      await sleep(160);

      if (!button.isConnected || !isVisible(button) || !isEnabled(button)) {
        return { clicked: false, evidence: '', error: 'Amazon 重绘页面后按钮引用已失效' };
      }

      HTMLInputElement.prototype.click.call(button);
      const evidence = await waitFor(
        () => (unloading ? '页面已开始跳转' : getSubmissionEvidence(snapshot)),
        observeMs,
        250,
        epoch
      );
      if (evidence === ABORTED) {
        return { clicked: true, evidence: ABORTED, error: '' };
      }
      return { clicked: true, evidence: evidence || '', error: '' };
    } catch (error) {
      return { clicked: false, evidence: '', error: error.message || String(error) };
    } finally {
      window.removeEventListener('beforeunload', onBeforeUnload);
      window.removeEventListener('pagehide', onBeforeUnload);
    }
  }

  function getReviewOrdersLink() {
    const links = [
      ...document.querySelectorAll('#widget-accountLevelActions a'),
      ...document.querySelectorAll('a.a-link-emphasis')
    ];
    return links.find((link) => /Review\s+or\s+edit\s+your\s+recent\s+orders/i.test(link.textContent || '')) || null;
  }

  function getFirstOrderCard() {
    return (
      document.querySelector('#yourOrderHistorySection [id="orderCard"]') ||
      document.querySelector('#yourOrderInfoSection [id="orderCard"]')
    );
  }

  function getOrderCardRecipientName(card) {
    if (!card) {
      return null;
    }
    const full = card.querySelector('.shipToTriggerTextTruncate .a-truncate-full');
    if (full) {
      return normalizeWhitespace(full.textContent);
    }
    const fallback = card.querySelector('.shipToTriggerTextTruncate');
    return fallback ? normalizeWhitespace(fallback.textContent) : null;
  }

  function getOrderCardOrderId(card) {
    if (!card) {
      return null;
    }
    const orderIdField = card.querySelector('#orderIdField') || card;
    return normalizeWhitespace(orderIdField.textContent).match(/\b\d{3}-\d{7}-\d{7}\b/)?.[0] || null;
  }

  async function transition(context, nextPhase, status, logMessage, level = 'info') {
    return send({
      type: 'SET_PHASE',
      runId: context.state.runId,
      expectedPhase: context.state.phase,
      nextPhase,
      status,
      logMessage,
      level
    });
  }

  async function pause(context, reason) {
    return send({
      type: 'PAUSE_ERROR',
      runId: context.state.runId,
      expectedPhase: context.state.phase,
      reason
    });
  }

  async function pauseAtPhase(context, expectedPhase, reason) {
    return send({
      type: 'PAUSE_ERROR',
      runId: context.state.runId,
      expectedPhase,
      reason
    });
  }

  async function skip(context, reason, observedOrderTotal = null) {
    return send({
      type: 'SKIP_ROW',
      runId: context.state.runId,
      expectedPhase: context.state.phase,
      reason,
      observedOrderTotal
    });
  }

  async function pageLog(context, message, level = 'info') {
    return send({
      type: 'PAGE_LOG',
      runId: context.state.runId,
      message,
      level
    });
  }

  async function handleProductPage(context, epoch) {
    const blocker = detectBlockingPage();
    if (blocker) {
      await pause(context, blocker);
      return;
    }

    if (detectProductNotFoundPage()) {
      await skip(context, '未找到商品，跳过');
      return;
    }

    const currentAsin = extractAsinFromCurrentPage();
    if (currentAsin && currentAsin !== context.row.asin) {
      await pause(context, `当前商品 ASIN 为 ${currentAsin}，与目标 ${context.row.asin} 不一致。`);
      return;
    }

    const productResult = await waitFor(
      () => {
        if (detectProductNotFoundPage()) {
          return { type: 'not-found' };
        }
        const button = document.querySelector('#buy-now-button');
        return button && isVisible(button) && isEnabled(button)
          ? { type: 'buy-now', button }
          : null;
      },
      30000,
      300,
      epoch
    );

    if (productResult === ABORTED) {
      return;
    }
    if (productResult?.type === 'not-found' || detectProductNotFoundPage()) {
      await skip(context, '未找到商品，跳过');
      return;
    }
    if (!productResult?.button) {
      await pause(context, detectBlockingPage() || '商品页面未找到可用的 Buy Now 按钮。');
      return;
    }
    const buyNowButton = productResult.button;

    const response = await transition(
      context,
      'WAIT_CHECKOUT',
      '已点击商品页 Buy Now，等待下单页面',
      '已找到并点击商品页面 Buy Now。'
    );
    if (!response?.ok) {
      return;
    }

    buyNowButton.click();
    scheduleRun(600);
  }

  async function handleCheckoutPage(context, epoch) {
    const blocker = detectBlockingPage();
    if (blocker) {
      await pause(context, blocker);
      return;
    }

    const addAddressLink = await waitFor(
      () => {
        const link = document.querySelector('#add-new-address-popover-link');
        return link && isVisible(link) ? link : null;
      },
      35000,
      300,
      epoch
    );

    if (addAddressLink === ABORTED) {
      return;
    }
    if (!addAddressLink) {
      await pause(context, '下单页面未找到 Add a new delivery address。');
      return;
    }

    const response = await transition(
      context,
      'WAIT_ADDRESS_FORM',
      '正在打开新建地址窗口',
      '已找到并点击 Add a new delivery address。'
    );
    if (!response?.ok) {
      return;
    }

    addAddressLink.click();
    scheduleRun(450);
  }

  async function handleAddressForm(context, epoch) {
    const fields = await waitFor(findAddressFields, 25000, 250, epoch);
    if (fields === ABORTED) {
      return;
    }
    if (!fields) {
      await pause(context, getVisibleAddressError() || '未出现完整的新建地址表单。');
      return;
    }

    if (fields.country && fields.country.value !== 'DE') {
      await pause(context, `地址国家不是 Germany（当前值：${fields.country.value || '空'}）。`);
      return;
    }

    for (let attempt = 1; attempt <= 2; attempt += 1) {
      setInputValue(fields.fullName, context.row.normalizedName);
      setInputValue(fields.phone, context.row.phoneNumber);
      setInputValue(fields.street, context.row.shipAddress);
      setInputValue(fields.extra, '');
      setInputValue(fields.postal, context.row.shipPostalCode);
      await sleep(500);
      setInputValue(fields.city, context.row.shipCity);
      await sleep(350);

      const valid =
        valuesMatch(fields.fullName.value, context.row.normalizedName) &&
        String(fields.phone.value).trim() === String(context.row.phoneNumber).trim() &&
        valuesMatch(fields.street.value, context.row.shipAddress) &&
        valuesMatch(fields.postal.value, context.row.shipPostalCode) &&
        valuesMatch(fields.city.value, context.row.shipCity);

      if (valid) {
        break;
      }

      if (attempt === 2) {
        await pause(context, '地址表单回读结果与输入数据不一致。');
        return;
      }
    }

    const useAddressButton = getVisibleUseAddressButton();
    if (!useAddressButton) {
      await pause(context, '新建地址窗口未找到可用的 Use this address 按钮。');
      return;
    }

    const response = await transition(
      context,
      'WAIT_ADDRESS_RESULT',
      '地址已填写并验证，等待地址处理结果',
      '姓名、电话、地址、邮编和城市已填写并回读验证，点击 Use this address。'
    );
    if (!response?.ok) {
      return;
    }

    useAddressButton.click();
    scheduleRun(700);
  }

  async function handleAddressResult(context, epoch) {
    const result = await waitFor(
      () => {
        const originalRadio = getVisibleOriginalAddressRadio();
        if (originalRadio) {
          return { type: 'suggestion', originalRadio };
        }
        if (getPaymentRecipientName() && getPlaceOrderButtonSet().usable.length > 0) {
          return { type: 'payment' };
        }
        const error = getVisibleAddressError();
        if (error) {
          return { type: 'error', error };
        }
        return null;
      },
      18000,
      300,
      epoch
    );

    if (result === ABORTED) {
      return;
    }
    if (!result) {
      await pause(context, '点击 Use this address 后，未出现推荐地址窗口或付款页面。');
      return;
    }
    if (result.type === 'error') {
      await pause(context, `Amazon 地址验证错误：${result.error}`);
      return;
    }
    if (result.type === 'payment') {
      const response = await transition(
        context,
        'VERIFY_PAYMENT',
        '正在检查付款页面',
        '未出现推荐地址窗口，已进入付款页面。'
      );
      if (response?.ok) {
        scheduleRun(100);
      }
      return;
    }

    const radio = result.originalRadio;
    radio.click();
    radio.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(250);
    if (!radio.checked) {
      const label = document.querySelector(`label[for="${CSS.escape(radio.id)}"]`);
      label?.click();
      await sleep(200);
    }
    if (!radio.checked) {
      await pause(context, '推荐地址窗口中无法选中 Original address。');
      return;
    }

    const useAddressButton = getVisibleUseAddressButton();
    if (!useAddressButton) {
      await pause(context, '推荐地址窗口未找到可用的 Use this address 按钮。');
      return;
    }

    const response = await transition(
      context,
      'WAIT_PAYMENT',
      '已选择 Original address，等待付款页面',
      '推荐地址窗口已选择 Original address，并点击 Use this address。'
    );
    if (!response?.ok) {
      return;
    }

    useAddressButton.click();
    scheduleRun(700);
  }

  async function handleWaitPayment(context, epoch) {
    const paymentReady = await waitFor(
      () => getPaymentRecipientName() && getPlaceOrderButtonSet().usable.length > 0,
      45000,
      350,
      epoch
    );
    if (paymentReady === ABORTED) {
      return;
    }
    if (!paymentReady) {
      await pause(context, detectBlockingPage() || '未进入可识别的付款页面。');
      return;
    }

    const response = await transition(
      context,
      'VERIFY_PAYMENT',
      '正在检查付款页面',
      '付款页面已加载。'
    );
    if (response?.ok) {
      scheduleRun(100);
    }
  }

  async function handleVerifyPayment(context, epoch) {
    const paymentData = await waitFor(
      () => {
        const recipientName = getPaymentRecipientName();
        const total = getOrderTotal();
        const buttonSet = getPlaceOrderButtonSet();
        if (recipientName && total && buttonSet.usable.length > 0) {
          return { recipientName, total, buttonCount: buttonSet.usable.length };
        }
        return null;
      },
      30000,
      300,
      epoch
    );

    if (paymentData === ABORTED) {
      return;
    }
    if (!paymentData) {
      await pause(context, '付款页面未找到收件人、Order Total 或可用的最终 Buy now 按钮。');
      return;
    }

    if (!namesMatch(paymentData.recipientName, context.row.normalizedName)) {
      await pause(
        context,
        `付款页面收件人姓名不一致：页面为“${paymentData.recipientName}”，目标为“${context.row.normalizedName}”。`
      );
      return;
    }

    if (!Number.isFinite(paymentData.total.value)) {
      await pause(context, `无法解析 Order Total：${paymentData.total.text || '空'}`);
      return;
    }

    if (Math.abs(paymentData.total.value - 2) > 0.0001) {
      await skip(context, '金额不为2，跳过', paymentData.total.value);
      return;
    }

    const prepared = await send({
      type: 'BEFORE_FINAL_SUBMIT',
      runId: context.state.runId,
      observedOrderTotal: paymentData.total.value,
      observedRecipientName: paymentData.recipientName
    });
    if (!prepared?.ok) {
      return;
    }

    const finalContext = await send({ type: 'GET_CONTEXT' });
    if (
      !finalContext?.ok ||
      !finalContext.isWorkTab ||
      finalContext.state?.runId !== context.state.runId ||
      finalContext.state?.mode !== 'running' ||
      finalContext.state?.phase !== 'WAIT_ORDER_SUCCESS'
    ) {
      return;
    }

    let buttonSet = getPlaceOrderButtonSet();
    if (!buttonSet.primary) {
      await pauseAtPhase(context, 'WAIT_ORDER_SUCCESS', '进入最终提交阶段后重新定位最终 Buy now 失败；未执行付款点击。');
      return;
    }

    await pageLog(
      context,
      `付款页面共识别到 ${buttonSet.all.length} 个 Buy now 元素、${buttonSet.usable.length} 个可用按钮；先尝试${describePlaceOrderButton(buttonSet.primary)}。`
    );

    // The log/storage round trip can give Amazon time to repaint the checkout widget.
    // Re-query immediately before clicking so that a detached DOM reference is never used.
    buttonSet = getPlaceOrderButtonSet();
    const primaryButton = buttonSet.primary;
    if (!primaryButton) {
      await pauseAtPhase(context, 'WAIT_ORDER_SUCCESS', '最终点击前 Amazon 重绘了付款模块，重新定位顶部 Buy now 失败。');
      return;
    }

    const primaryDescription = describePlaceOrderButton(primaryButton);
    const primaryResult = await nativeClickAndObserve(primaryButton, epoch, 12000);
    if (primaryResult.evidence === ABORTED) {
      return;
    }
    if (primaryResult.evidence) {
      await pageLog(context, `${primaryDescription}已点击，检测到提交迹象：${primaryResult.evidence}。`, 'success');
      scheduleRun(500);
      return;
    }

    await pageLog(
      context,
      primaryResult.clicked
        ? `${primaryDescription}点击后 12 秒内未检测到跳转或处理状态，准备使用第二个 Buy now 兜底。`
        : `${primaryDescription}未能执行点击（${primaryResult.error || '未知原因'}），准备使用第二个 Buy now 兜底。`,
      'warning'
    );

    buttonSet = getPlaceOrderButtonSet();
    const fallbackButton = selectFallbackPlaceOrderButton(buttonSet, primaryButton);
    if (!fallbackButton) {
      await pageLog(context, '未找到独立的第二个可用 Buy now 按钮，将继续等待页面结果。', 'warning');
      scheduleRun(500);
      return;
    }

    const fallbackDescription = describePlaceOrderButton(fallbackButton);
    await pageLog(context, `尝试兜底按钮：${fallbackDescription}。`, 'warning');

    // Re-query one final time after logging. Prefer the bottom button explicitly,
    // including the case where the top clone was removed and the bottom became the only button.
    buttonSet = getPlaceOrderButtonSet();
    const freshFallback = selectFallbackPlaceOrderButton(buttonSet, primaryButton);
    if (!freshFallback) {
      await pageLog(context, '记录兜底步骤后按钮被 Amazon 重绘，未再次点击；继续等待页面结果。', 'warning');
      scheduleRun(500);
      return;
    }

    const fallbackResult = await nativeClickAndObserve(freshFallback, epoch, 15000);
    if (fallbackResult.evidence === ABORTED) {
      return;
    }
    if (fallbackResult.evidence) {
      await pageLog(
        context,
        `${describePlaceOrderButton(freshFallback)}已点击，检测到提交迹象：${fallbackResult.evidence}。`,
        'success'
      );
    } else {
      await pageLog(
        context,
        fallbackResult.clicked
          ? '第二个 Buy now 已执行点击，但 15 秒内仍未检测到跳转；继续等待下单成功页面。'
          : `第二个 Buy now 点击失败：${fallbackResult.error || '未知原因'}；继续等待页面结果。`,
        'warning'
      );
    }
    scheduleRun(500);
  }

  async function handleWaitOrderSuccess(context, epoch) {
    const result = await waitFor(
      () => {
        const firstCard = getFirstOrderCard();
        if (firstCard) {
          return { type: 'orders' };
        }
        const reviewLink = getReviewOrdersLink();
        if (reviewLink && isVisible(reviewLink)) {
          return { type: 'success', reviewLink };
        }
        return null;
      },
      90000,
      500,
      epoch
    );

    if (result === ABORTED) {
      return;
    }
    if (!result) {
      await pause(context, '点击最终 Buy now 后未找到下单成功页面，订单结果未确认。');
      return;
    }

    const response = await transition(
      context,
      'WAIT_ORDER_HISTORY',
      '正在核对最新订单',
      result.type === 'success'
        ? '下单成功页面已出现，点击 Review or edit your recent orders。'
        : '当前已在所有订单页面，开始核对第一张订单卡片。'
    );
    if (!response?.ok) {
      return;
    }

    if (result.type === 'success') {
      result.reviewLink.click();
    }
    scheduleRun(700);
  }

  async function handleOrderHistory(context, epoch) {
    const card = await waitFor(getFirstOrderCard, 45000, 350, epoch);
    if (card === ABORTED) {
      return;
    }
    if (!card) {
      await pause(context, '所有订单页面未找到第一张订单卡片。');
      return;
    }

    const recipientName = getOrderCardRecipientName(card);
    if (!recipientName) {
      await pause(context, '第一张订单卡片未读取到 Dispatch to 姓名。');
      return;
    }
    if (!namesMatch(recipientName, context.row.normalizedName)) {
      await pause(
        context,
        `第一张订单卡片收件人不一致：卡片为“${recipientName}”，目标为“${context.row.normalizedName}”。`
      );
      return;
    }

    const orderId = getOrderCardOrderId(card);
    if (!orderId) {
      await pause(context, '第一张订单卡片未读取到有效 Order ID。');
      return;
    }

    await send({
      type: 'ORDER_SUCCESS',
      runId: context.state.runId,
      orderId,
      observedRecipientName: recipientName
    });
  }

  async function runAutomation() {
    if (executing) {
      rerunRequested = true;
      return;
    }

    executing = true;
    rerunRequested = false;

    try {
      const context = await send({ type: 'GET_CONTEXT' });
      if (!context?.ok || !context.isWorkTab || !context.state || !context.row) {
        return;
      }
      if (context.state.mode !== 'running') {
        return;
      }

      activeRunId = context.state.runId;
      activeRowIndex = context.state.currentIndex;
      const epoch = abortGeneration;

      switch (context.state.phase) {
        case 'WAIT_PRODUCT':
          await handleProductPage(context, epoch);
          break;
        case 'WAIT_CHECKOUT':
          await handleCheckoutPage(context, epoch);
          break;
        case 'WAIT_ADDRESS_FORM':
          await handleAddressForm(context, epoch);
          break;
        case 'WAIT_ADDRESS_RESULT':
          await handleAddressResult(context, epoch);
          break;
        case 'WAIT_PAYMENT':
          await handleWaitPayment(context, epoch);
          break;
        case 'VERIFY_PAYMENT':
          await handleVerifyPayment(context, epoch);
          break;
        case 'WAIT_ORDER_SUCCESS':
          await handleWaitOrderSuccess(context, epoch);
          break;
        case 'WAIT_ORDER_HISTORY':
          await handleOrderHistory(context, epoch);
          break;
        default:
          break;
      }
    } finally {
      executing = false;
      if (rerunRequested) {
        scheduleRun(100);
      }
    }
  }

  scheduleRun(300);
})();
