# Amazon DE 自动下单助手 v1.2.0

Chrome Manifest V3 插件。插件在独立控制窗口中接收从 Excel 复制的八列数据，在 Amazon.de 英文界面逐行执行下单，并保存工作记录和详细工作日志。

> 插件会自动点击最终 **Buy now**，会产生真实 Amazon 订单。首次测试新版本时，只放入一条新 Temu Order ID，并全程观察 Amazon 工作标签页。

## v1.2.0 修改内容

### 1. 工作记录改为七列

页面表格、“复制工作记录”和 CSV 均只保留：

```text
Temu Order ID
ASIN
recipient name
address
city
postal code
工作结果
```

- `recipient name` 显示原始输入姓名。
- 成功获取 Amazon Order ID 时，“工作结果”直接显示 Order ID，例如 `302-2658264-7813966`。
- 其他情况继续显示原有结果，例如 `数量不为1，跳过`、`未找到商品，跳过`、`金额不为2，跳过` 或等待人工检查原因。
- “复制所有 Order ID”只复制工作结果中真实成功取得的 Amazon Order ID。

### 2. 每单间隔

控制栏增加：

```text
每单间隔 [30] 秒
```

规则：

- 默认值为 30 秒。
- 可设置为 `0–3600` 的整数。
- 设置保存在本地，下次打开控制面板继续使用。
- 只有当前订单成功获取 Amazon Order ID 后，才开始等待。
- 等待结束后才打开下一条有效订单的 Amazon 商品链接。
- 数量错误、重复 Temu Order ID、无效链接、404、金额错误以及人工跳过等行不等待。
- 最后一个成功订单后没有下一条有效数据时，不再等待。
- 等待期间可以暂停；继续后按剩余秒数恢复。

### 3. Temu Order ID 仅做当天防重复

“当天”按 `Europe/Berlin` 自然日计算。

- 当前批次中第二次出现相同 Temu Order ID：`Temu Order ID重复，跳过`。
- 同一 Temu Order ID 今天已经成功取得 Amazon Order ID：`Temu Order ID当天已下过单，跳过`。
- 昨天或更早成功的同一 Temu Order ID，不会阻止今天再次下单。
- Temu Order ID 比较前会去除空白并转换为大写。

### 4. 只有成功获取 Order ID 才计入当天下单记录

以下结果不会写入当天防重复索引：

```text
Temu Order ID为空，跳过
数量不为1，跳过
AMZ link无效，跳过
信息不完整，跳过
Temu Order ID重复，跳过
未找到商品，跳过
金额不为2，跳过
人工跳过
订单结果未确认
```

只有从 Amazon 订单卡片取得符合以下格式的 Order ID 后才写入：

```text
000-0000000-0000000
```

#### 重要风险

按已确认规则，本版本不创建“已点击 Buy now、但尚未取得 Order ID”的防重复锁。因此可能出现：

1. Amazon 已经创建订单；
2. 成功页面或订单页面加载失败；
3. 插件没有取得 Order ID；
4. 该 Temu Order ID 没有写入当天记录；
5. 再次运行相同 Temu Order ID 时可能重复下单。

在 `WAIT_ORDER_SUCCESS` 或 `WAIT_ORDER_HISTORY` 阶段停止、跳过或发生异常后，应先人工检查 Amazon 最近订单，再决定是否重新运行。

### 5. 清空当天下单记录

控制栏增加：

```text
清空当天下单记录
```

按钮只删除德国当天已成功取得 Order ID 的 Temu Order ID 防重复索引：

- 不清除输入数据；
- 不清除工作记录；
- 不清除工作日志；
- 清除后，这些 Temu Order ID 当天可以再次下单；
- 任务运行、暂停或切换过程中不能执行清空。

## 输入列顺序

从 Excel 复制时必须按以下八列排列，不要复制表头：

```text
Temu Order ID
AMZ link
quantity to ship
recipient name
phone number
ship address
ship city
ship postal code
```

可一次粘贴多行。八列数据必须逐行对应。

## 姓名处理

- 工作记录显示原始输入姓名。
- 实际填写 Amazon 时保留 Unicode 字母、空格、连字符 `-` 和撇号。
- 其他字符转换为空格，并压缩连续空格。
- 付款页面仍按处理后的实际填写姓名核对。

## 最终 Buy now 点击逻辑

付款页面核对收件人姓名和 `Order Total = €2.00` 后：

1. 扫描全部最终 Buy now 控件，不依赖唯一的 `id="placeOrder"`。
2. 优先选择顶部按钮：

```css
input[aria-labelledby="submitOrderButtonId-announce"]
```

3. 点击前重新查询 DOM，避免 Amazon 动态重绘造成旧元素引用失效。
4. 点击后观察 URL、按钮状态、处理提示和成功页面入口。
5. 顶部按钮 12 秒内没有提交迹象时，重新扫描并尝试底部按钮：

```css
input[aria-labelledby="bottomSubmitOrderButtonId-announce"]
```

6. 若仍未找到成功页面，暂停并记录“订单结果未确认”；不会写入当天防重复记录。

## 无效商品页面

出现以下元素或对应文本时，该行记录为 `未找到商品，跳过`，并直接进入下一条有效数据：

```css
a[href="/ref=cs_404_logo"]
a[href="/ref=cs_404_link"]
img[src*="kailey-kitty"]
```

文本组合：

```text
Looking for something?
not a functioning page on our site
```

## 工作记录功能

### 复制所有 Order ID

- 只复制成功行的有效 Amazon Order ID；
- 每行一个；
- 按工作记录顺序排列；
- 自动去重。

### 导出工作记录 CSV

导出 UTF-8 BOM、分号分隔的 CSV，便于德国区域设置的 Excel 直接分列打开。

文件名：

```text
amazon_order_work_records_YYYY-MM-DD_HH-MM-SS.csv
```

CSV 仅包含上述七列。

## 安装或更新

1. 先停止旧版本任务。
2. 解压 ZIP。
3. 打开：

```text
chrome://extensions/
```

4. 开启“开发者模式”。
5. 删除或禁用旧版本，避免两个版本同时控制 Amazon 页面。
6. 点击“加载已解压的扩展程序”。
7. 选择目录：

```text
amazon_de_auto_order_v1.2.0
```

8. 点击插件图标打开独立控制窗口。

升级时，v1.1.0 中没有有效 Amazon Order ID 的旧未确认防重复锁会被清除。只有有效 `ORDERED + Order ID` 记录会保留，并按其德国日期参与当天判断。

## 使用条件

- 仅支持 `https://www.amazon.de/*` 和 `https://amazon.de/*`。
- 仅支持 Amazon.de 英文界面。
- 必须提前登录正确的 Amazon 账号。
- `quantity to ship` 必须严格为 `1`。
- 付款页面只按已确认规则核对收件人姓名。
- `Order Total` 必须为 `€2.00`；其他金额跳过。
- 地址建议窗口始终选择 `Original address`。
- 电话号码按输入内容原样填写，只去除首尾空格。
- 下单后仍检查订单页面第一张卡片的 `Dispatch to` 姓名并读取 Order ID。

## 文件结构

```text
amazon_de_auto_order_v1.2.0/
├── manifest.json
├── background.js
├── content.js
├── panel.html
├── panel.css
├── panel.js
└── README.md
```

## 测试说明

代码已进行 JavaScript 语法、Manifest、七列记录、当天索引、清空当天记录、成功单间隔、404 页面和最终 Buy now 选择器测试。未在您的 Amazon 账号上执行真实付款。Amazon 页面可能进行 A/B 更新；异常时应保存完整工作日志和相关页面 HTML。
