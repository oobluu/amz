'use strict';

const STORAGE_KEYS = Object.freeze({
  RUN_STATE: 'amzOrderRunState',
  HISTORY: 'amzOrderHistory',
  LOGS: 'amzOrderLogs',
  DRAFT_ROWS: 'amzOrderDraftRows',
  SETTINGS: 'amzOrderSettings'
});

const FIELD_DEFINITIONS = Object.freeze([
  { key: 'temuOrderId', label: 'Temu Order ID' },
  { key: 'amzLink', label: 'AMZ link' },
  { key: 'quantityToShip', label: 'quantity to ship' },
  { key: 'recipientName', label: 'recipient name' },
  { key: 'phoneNumber', label: 'phone number' },
  { key: 'shipAddress', label: 'ship address' },
  { key: 'shipCity', label: 'ship city' },
  { key: 'shipPostalCode', label: 'ship postal code' }
]);

const ACTIVE_MODES = new Set(['running', 'paused', 'transitioning']);
const PHASE_LABELS = Object.freeze({
  WAIT_PRODUCT: '打开商品页并查找 Buy Now',
  WAIT_CHECKOUT: '等待下单页面',
  WAIT_ADDRESS_FORM: '等待新建地址窗口',
  WAIT_ADDRESS_RESULT: '等待地址验证结果',
  WAIT_PAYMENT: '等待付款页面',
  VERIFY_PAYMENT: '核对收件人和 Order Total',
  WAIT_ORDER_SUCCESS: '等待下单成功页面',
  WAIT_ORDER_HISTORY: '核对第一张订单卡片',
  TRANSITIONING: '切换到下一条数据',
  WAIT_INTERVAL: '等待下一单下单间隔',
  COMPLETED: '任务完成',
  STOPPED: '任务已停止'
});

const MODE_LABELS = Object.freeze({
  running: '运行中',
  paused: '已暂停',
  transitioning: '切换中',
  completed: '已完成',
  stopped: '已停止'
});

let draftRows = [];
let runState = null;
let logs = [];
let settings = { orderIntervalSeconds: 30 };
let saveDraftTimer = null;
let toastTimer = null;

const elements = {
  runMode: document.querySelector('#runMode'),
  currentRow: document.querySelector('#currentRow'),
  currentPhase: document.querySelector('#currentPhase'),
  pauseReason: document.querySelector('#pauseReason'),
  startBtn: document.querySelector('#startBtn'),
  pauseBtn: document.querySelector('#pauseBtn'),
  continueBtn: document.querySelector('#continueBtn'),
  skipBtn: document.querySelector('#skipBtn'),
  stopBtn: document.querySelector('#stopBtn'),
  openTabBtn: document.querySelector('#openTabBtn'),
  orderIntervalSeconds: document.querySelector('#orderIntervalSeconds'),
  clearTodayOrdersBtn: document.querySelector('#clearTodayOrdersBtn'),
  addRowsBtn: document.querySelector('#addRowsBtn'),
  removeBlankBtn: document.querySelector('#removeBlankBtn'),
  clearInputBtn: document.querySelector('#clearInputBtn'),
  copyOrderIdsBtn: document.querySelector('#copyOrderIdsBtn'),
  exportRecordsCsvBtn: document.querySelector('#exportRecordsCsvBtn'),
  copyRecordsBtn: document.querySelector('#copyRecordsBtn'),
  copyLogBtn: document.querySelector('#copyLogBtn'),
  clearLogBtn: document.querySelector('#clearLogBtn'),
  inputTableBody: document.querySelector('#inputTableBody'),
  recordsTableBody: document.querySelector('#recordsTableBody'),
  logContainer: document.querySelector('#logContainer'),
  toast: document.querySelector('#toast')
};

function createBlankRow() {
  return Object.fromEntries(FIELD_DEFINITIONS.map(({ key }) => [key, '']));
}

function normalizeDraftRow(row) {
  const source = row && typeof row === 'object' ? row : {};
  return Object.fromEntries(
    FIELD_DEFINITIONS.map(({ key }) => [key, String(source[key] ?? '')])
  );
}

function ensureMinimumRows(rows, minimum = 12) {
  const next = rows.map(normalizeDraftRow);
  while (next.length < minimum) {
    next.push(createBlankRow());
  }
  return next;
}

function isBlankDraftRow(row) {
  return FIELD_DEFINITIONS.every(({ key }) => String(row?.[key] ?? '').trim() === '');
}

function showToast(message, isError = false) {
  clearTimeout(toastTimer);
  elements.toast.textContent = message;
  elements.toast.classList.toggle('error', isError);
  elements.toast.classList.remove('hidden');
  toastTimer = setTimeout(() => elements.toast.classList.add('hidden'), 4000);
}

async function send(type, payload = {}) {
  try {
    const response = await chrome.runtime.sendMessage({ type, ...payload });
    if (!response?.ok && response?.error) {
      showToast(response.error, true);
    }
    return response;
  } catch (error) {
    showToast(error.message || String(error), true);
    return { ok: false, error: error.message || String(error) };
  }
}

function renderInputTable() {
  elements.inputTableBody.replaceChildren();
  const fragment = document.createDocumentFragment();

  draftRows.forEach((row, rowIndex) => {
    const tr = document.createElement('tr');

    const numberCell = document.createElement('td');
    numberCell.className = 'input-row-number';
    numberCell.textContent = String(rowIndex + 1);
    tr.appendChild(numberCell);

    FIELD_DEFINITIONS.forEach(({ key, label }, columnIndex) => {
      const td = document.createElement('td');
      const input = document.createElement('input');
      input.type = 'text';
      input.value = String(row[key] ?? '');
      input.autocomplete = 'off';
      input.spellcheck = false;
      input.setAttribute('aria-label', `${label}，第 ${rowIndex + 1} 行`);
      input.dataset.rowIndex = String(rowIndex);
      input.dataset.columnIndex = String(columnIndex);
      input.dataset.field = key;

      input.addEventListener('input', () => {
        draftRows[rowIndex][key] = input.value;
        scheduleDraftSave();
      });

      input.addEventListener('paste', (event) => {
        const text = event.clipboardData?.getData('text/plain') || '';
        if (!text.includes('\t') && !/[\r\n]/.test(text)) {
          return;
        }
        event.preventDefault();
        pasteTableData(rowIndex, columnIndex, text);
      });

      td.appendChild(input);
      tr.appendChild(td);
    });

    fragment.appendChild(tr);
  });

  elements.inputTableBody.appendChild(fragment);
  updateControlStates();
}

function parseTsv(text) {
  const rows = [];
  let row = [];
  let cell = '';
  let inQuotes = false;

  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    const next = text[index + 1];

    if (char === '"') {
      if (inQuotes && next === '"') {
        cell += '"';
        index += 1;
      } else {
        inQuotes = !inQuotes;
      }
      continue;
    }

    if (!inQuotes && char === '\t') {
      row.push(cell);
      cell = '';
      continue;
    }

    if (!inQuotes && (char === '\n' || char === '\r')) {
      if (char === '\r' && next === '\n') {
        index += 1;
      }
      row.push(cell);
      rows.push(row);
      row = [];
      cell = '';
      continue;
    }

    cell += char;
  }

  row.push(cell);
  rows.push(row);

  while (rows.length > 1 && rows[rows.length - 1].every((value) => value === '')) {
    rows.pop();
  }
  return rows;
}

function pasteTableData(startRow, startColumn, text) {
  const pastedRows = parseTsv(text);
  const requiredLength = startRow + pastedRows.length;
  while (draftRows.length < requiredLength) {
    draftRows.push(createBlankRow());
  }

  pastedRows.forEach((cells, rowOffset) => {
    cells.forEach((value, columnOffset) => {
      const targetColumn = startColumn + columnOffset;
      if (targetColumn >= FIELD_DEFINITIONS.length) {
        return;
      }
      const key = FIELD_DEFINITIONS[targetColumn].key;
      draftRows[startRow + rowOffset][key] = value;
    });
  });

  draftRows = ensureMinimumRows(draftRows);
  renderInputTable();
  scheduleDraftSave(0);
  showToast(`已粘贴 ${pastedRows.length} 行数据。`);
}

function collectRowsFromInputs() {
  const inputs = [...elements.inputTableBody.querySelectorAll('input[data-field]')];
  inputs.forEach((input) => {
    const rowIndex = Number(input.dataset.rowIndex);
    const key = input.dataset.field;
    if (draftRows[rowIndex] && key) {
      draftRows[rowIndex][key] = input.value;
    }
  });
  return draftRows.map(normalizeDraftRow);
}

function scheduleDraftSave(delay = 450) {
  clearTimeout(saveDraftTimer);
  saveDraftTimer = setTimeout(async () => {
    saveDraftTimer = null;
    if (runState && ACTIVE_MODES.has(runState.mode)) {
      return;
    }
    collectRowsFromInputs();
    await send('SAVE_DRAFT_ROWS', { rows: draftRows });
  }, delay);
}

function formatCell(value) {
  return String(value ?? '').replace(/[\t\r\n]+/g, ' ').trim();
}

function setTextCell(tr, value, className = '') {
  const td = document.createElement('td');
  td.textContent = String(value ?? '');
  td.title = String(value ?? '');
  if (className) {
    td.className = className;
  }
  tr.appendChild(td);
}

function getRecordStatusClass(row) {
  if (row.result === 'success') {
    return 'record-success';
  }
  if (row.result === 'blocked') {
    return 'record-error';
  }
  if (row.result === 'skipped') {
    return 'record-warning';
  }
  return '';
}

function getWorkResult(row) {
  if (row?.result === 'success' && /^\d{3}-\d{7}-\d{7}$/.test(String(row?.orderId || '').trim())) {
    return String(row.orderId).trim();
  }
  return String(row?.status || '');
}

function renderWorkRecords() {
  elements.recordsTableBody.replaceChildren();
  const rows = Array.isArray(runState?.rows) ? runState.rows : [];

  if (rows.length === 0) {
    const tr = document.createElement('tr');
    const td = document.createElement('td');
    td.colSpan = 7;
    td.className = 'empty-cell';
    td.textContent = '暂无工作记录';
    tr.appendChild(td);
    elements.recordsTableBody.appendChild(tr);
    return;
  }

  const fragment = document.createDocumentFragment();
  rows.forEach((row) => {
    const tr = document.createElement('tr');
    setTextCell(tr, row.temuOrderId || '');
    setTextCell(tr, row.asin || '');
    setTextCell(tr, row.recipientName || '');
    setTextCell(tr, row.shipAddress || '');
    setTextCell(tr, row.shipCity || '');
    setTextCell(tr, row.shipPostalCode || '');
    setTextCell(tr, getWorkResult(row), getRecordStatusClass(row));
    fragment.appendChild(tr);
  });
  elements.recordsTableBody.appendChild(fragment);
}

function renderLogs() {
  elements.logContainer.replaceChildren();
  if (!Array.isArray(logs) || logs.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'log-empty';
    empty.textContent = '暂无日志';
    elements.logContainer.appendChild(empty);
    return;
  }

  const fragment = document.createDocumentFragment();
  logs.forEach((entry) => {
    const row = document.createElement('div');
    row.className = 'log-row';
    row.dataset.level = entry.level || 'info';

    const time = document.createElement('span');
    time.className = 'log-time';
    time.textContent = entry.time || '';

    const level = document.createElement('span');
    level.className = 'log-level';
    level.textContent = entry.level || 'info';

    const rowNumber = document.createElement('span');
    rowNumber.className = 'log-row-number';
    rowNumber.textContent = entry.rowNumber ? `第${entry.rowNumber}行` : '—';

    const message = document.createElement('span');
    message.className = 'log-message';
    message.textContent = entry.message || '';

    row.append(time, level, rowNumber, message);
    fragment.appendChild(row);
  });

  elements.logContainer.appendChild(fragment);
  elements.logContainer.scrollTop = elements.logContainer.scrollHeight;
}

function updateStatusHeader() {
  if (!runState) {
    elements.runMode.textContent = '未开始';
    elements.currentRow.textContent = '—';
    elements.currentPhase.textContent = '—';
    elements.pauseReason.classList.add('hidden');
    elements.pauseReason.textContent = '';
    return;
  }

  elements.runMode.textContent = MODE_LABELS[runState.mode] || runState.mode || '未知';
  const current = Number.isInteger(runState.currentIndex) ? runState.rows?.[runState.currentIndex] : null;
  elements.currentRow.textContent = current
    ? `第 ${current.rowNumber} 行 / 共 ${runState.rows.length} 条`
    : `共 ${runState.rows?.length || 0} 条`;

  if (runState.phase === 'WAIT_INTERVAL') {
    const endTime = Date.parse(String(runState.intervalEndsAt || ''));
    const remainingSeconds = runState.mode === 'paused'
      ? Math.max(0, Number(runState.intervalRemainingSeconds || 0))
      : Math.max(0, Math.ceil((Number.isFinite(endTime) ? endTime - Date.now() : 0) / 1000));
    elements.currentPhase.textContent = `等待下一单，剩余约 ${remainingSeconds} 秒`;
  } else {
    elements.currentPhase.textContent = PHASE_LABELS[runState.phase] || runState.phase || '—';
  }

  if (runState.pauseReason) {
    elements.pauseReason.textContent = `暂停原因：${runState.pauseReason}`;
    elements.pauseReason.classList.remove('hidden');
  } else {
    elements.pauseReason.classList.add('hidden');
    elements.pauseReason.textContent = '';
  }
}

function updateControlStates() {
  const mode = runState?.mode || '';
  const active = ACTIVE_MODES.has(mode);
  const running = mode === 'running' || mode === 'transitioning';
  const paused = mode === 'paused';

  elements.startBtn.disabled = active;
  elements.pauseBtn.disabled = !running;
  elements.continueBtn.disabled = !paused;
  elements.skipBtn.disabled = !paused;
  elements.stopBtn.disabled = !active;
  elements.openTabBtn.disabled = !Number.isInteger(runState?.workTabId);
  elements.orderIntervalSeconds.disabled = active;
  elements.clearTodayOrdersBtn.disabled = active;
  elements.addRowsBtn.disabled = active;
  elements.removeBlankBtn.disabled = active;
  elements.clearInputBtn.disabled = active;

  const recordRows = Array.isArray(runState?.rows) ? runState.rows : [];
  const hasOrderIds = recordRows.some((row) => row?.result === 'success' && /^\d{3}-\d{7}-\d{7}$/.test(String(row?.orderId || '').trim()));
  elements.copyOrderIdsBtn.disabled = !hasOrderIds;
  elements.exportRecordsCsvBtn.disabled = recordRows.length === 0;
  elements.copyRecordsBtn.disabled = recordRows.length === 0;

  elements.inputTableBody.querySelectorAll('input').forEach((input) => {
    input.disabled = active;
  });
}

function renderState() {
  updateStatusHeader();
  renderWorkRecords();
  updateControlStates();
}

async function copyText(text, successMessage) {
  try {
    await navigator.clipboard.writeText(text);
    showToast(successMessage);
  } catch (error) {
    showToast(`复制失败：${error.message || String(error)}`, true);
  }
}

function buildRecordsTsv() {
  const headers = [
    'Temu Order ID',
    'ASIN',
    'recipient name',
    'address',
    'city',
    'postal code',
    '工作结果'
  ];
  const rows = Array.isArray(runState?.rows) ? runState.rows : [];
  const lines = rows.map((row) => [
    row.temuOrderId,
    row.asin,
    row.recipientName,
    row.shipAddress,
    row.shipCity,
    row.shipPostalCode,
    getWorkResult(row)
  ].map(formatCell).join('\t'));
  return [headers.join('\t'), ...lines].join('\n');
}

function getAllOrderIds() {
  const rows = Array.isArray(runState?.rows) ? runState.rows : [];
  const ids = [];
  const seen = new Set();
  for (const row of rows) {
    const orderId = row?.result === 'success' ? String(row?.orderId || '').trim() : '';
    if (!/^\d{3}-\d{7}-\d{7}$/.test(orderId) || seen.has(orderId)) {
      continue;
    }
    seen.add(orderId);
    ids.push(orderId);
  }
  return ids;
}

function escapeCsvCell(value) {
  const text = String(value ?? '').replace(/\r?\n/g, ' ').trim();
  return `"${text.replace(/"/g, '""')}"`;
}

function buildRecordsCsv() {
  const headers = [
    'Temu Order ID',
    'ASIN',
    'recipient name',
    'address',
    'city',
    'postal code',
    '工作结果'
  ];
  const rows = Array.isArray(runState?.rows) ? runState.rows : [];
  const lines = rows.map((row) => [
    row.temuOrderId,
    row.asin,
    row.recipientName,
    row.shipAddress,
    row.shipCity,
    row.shipPostalCode,
    getWorkResult(row)
  ].map(escapeCsvCell).join(';'));
  return [headers.map(escapeCsvCell).join(';'), ...lines].join('\r\n');
}

function getBerlinFileTimestamp(date = new Date()) {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/Berlin',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23'
  }).formatToParts(date);
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}_${values.hour}-${values.minute}-${values.second}`;
}

function downloadCsvFile() {
  const csv = `\uFEFF${buildRecordsCsv()}`;
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `amazon_order_work_records_${getBerlinFileTimestamp()}.csv`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function buildLogsText() {
  return (Array.isArray(logs) ? logs : [])
    .map((entry) => [
      entry.time || '',
      String(entry.level || 'info').toUpperCase(),
      entry.rowNumber ? `第${entry.rowNumber}行` : '',
      formatCell(entry.message)
    ].join('\t'))
    .join('\n');
}

elements.startBtn.addEventListener('click', async () => {
  collectRowsFromInputs();
  const nonBlank = draftRows.filter((row) => !isBlankDraftRow(row));
  if (nonBlank.length === 0) {
    showToast('没有可处理的数据行。', true);
    return;
  }

  const intervalSeconds = Number(elements.orderIntervalSeconds.value);
  if (!Number.isInteger(intervalSeconds) || intervalSeconds < 0 || intervalSeconds > 3600) {
    showToast('每单下单时间间隔必须是 0–3600 的整数秒。', true);
    elements.orderIntervalSeconds.focus();
    return;
  }

  const saved = await send('SAVE_SETTINGS', {
    settings: { orderIntervalSeconds: intervalSeconds }
  });
  if (!saved?.ok) {
    return;
  }
  settings = saved.settings || { orderIntervalSeconds: intervalSeconds };

  const response = await send('START_RUN', {
    rows: draftRows,
    orderIntervalSeconds: intervalSeconds
  });
  if (response?.ok) {
    showToast('任务已开始。');
  }
});

elements.pauseBtn.addEventListener('click', async () => {
  const response = await send('PAUSE_RUN');
  if (response?.ok) {
    showToast('任务已暂停。');
  }
});

elements.continueBtn.addEventListener('click', async () => {
  const response = await send('CONTINUE_RUN');
  if (response?.ok) {
    showToast('任务继续执行。');
  }
});

elements.skipBtn.addEventListener('click', async () => {
  const risky = ['WAIT_ORDER_SUCCESS', 'WAIT_ORDER_HISTORY'].includes(runState?.phase);
  if (risky) {
    const accepted = window.confirm(
      '当前订单可能已经提交但尚未取得 Order ID。跳过后不会写入当天下单记录，重新运行相同 Temu Order ID 可能造成重复下单。确定跳过当前行吗？'
    );
    if (!accepted) {
      return;
    }
  }

  const response = await send('SKIP_CURRENT_MANUAL');
  if (response?.ok) {
    showToast('当前行已跳过。');
  }
});

elements.stopBtn.addEventListener('click', async () => {
  const risky = ['WAIT_ORDER_SUCCESS', 'WAIT_ORDER_HISTORY'].includes(runState?.phase);
  if (risky) {
    const accepted = window.confirm(
      '当前订单可能已经提交但尚未取得 Order ID。停止后不会写入当天下单记录，重新运行可能造成重复下单。确定停止全部任务吗？'
    );
    if (!accepted) {
      return;
    }
  }

  const response = await send('STOP_RUN');
  if (response?.ok) {
    showToast('任务已停止。');
  }
});

elements.openTabBtn.addEventListener('click', () => send('OPEN_WORK_TAB'));

elements.addRowsBtn.addEventListener('click', () => {
  collectRowsFromInputs();
  for (let index = 0; index < 10; index += 1) {
    draftRows.push(createBlankRow());
  }
  renderInputTable();
  scheduleDraftSave(0);
});

elements.removeBlankBtn.addEventListener('click', () => {
  collectRowsFromInputs();
  draftRows = ensureMinimumRows(draftRows.filter((row) => !isBlankDraftRow(row)));
  renderInputTable();
  scheduleDraftSave(0);
});

elements.clearInputBtn.addEventListener('click', async () => {
  const accepted = window.confirm('确定清空输入表格和当前已结束任务的工作记录吗？当天成功下单防重复记录不会被删除。');
  if (!accepted) {
    return;
  }
  const response = await send('CLEAR_DRAFT_ROWS');
  if (response?.ok) {
    draftRows = ensureMinimumRows([]);
    runState = null;
    renderInputTable();
    renderState();
    showToast('输入数据已清空；当天成功下单防重复记录仍保留。');
  }
});

elements.orderIntervalSeconds.addEventListener('change', async () => {
  const intervalSeconds = Number(elements.orderIntervalSeconds.value);
  if (!Number.isInteger(intervalSeconds) || intervalSeconds < 0 || intervalSeconds > 3600) {
    elements.orderIntervalSeconds.value = String(settings.orderIntervalSeconds ?? 30);
    showToast('每单下单时间间隔必须是 0–3600 的整数秒。', true);
    return;
  }
  const response = await send('SAVE_SETTINGS', {
    settings: { orderIntervalSeconds: intervalSeconds }
  });
  if (response?.ok) {
    settings = response.settings || { orderIntervalSeconds: intervalSeconds };
    showToast(`每单下单时间间隔已保存为 ${intervalSeconds} 秒。`);
  }
});

elements.clearTodayOrdersBtn.addEventListener('click', async () => {
  const accepted = window.confirm(
    '确定清空今天已成功获取 Order ID 的 Temu Order ID 防重复记录吗？\n\n清空后，这些 Temu Order ID 今天可以再次下单。工作记录、输入数据和工作日志不会被清除。'
  );
  if (!accepted) {
    return;
  }
  const response = await send('CLEAR_TODAY_ORDER_RECORDS');
  if (response?.ok) {
    showToast(`已清空 ${response.clearedCount || 0} 条 ${response.dateKey || '今天'} 的成功下单记录。`);
  }
});

elements.copyOrderIdsBtn.addEventListener('click', () => {
  const orderIds = getAllOrderIds();
  if (orderIds.length === 0) {
    showToast('工作记录中没有可复制的 Order ID。', true);
    return;
  }
  copyText(orderIds.join('\n'), `已复制 ${orderIds.length} 个 Order ID。`);
});

elements.exportRecordsCsvBtn.addEventListener('click', () => {
  const rows = Array.isArray(runState?.rows) ? runState.rows : [];
  if (rows.length === 0) {
    showToast('没有可导出的工作记录。', true);
    return;
  }
  downloadCsvFile();
  showToast(`已导出 ${rows.length} 条工作记录。`);
});

elements.copyRecordsBtn.addEventListener('click', () => {
  copyText(buildRecordsTsv(), '工作记录已复制。');
});

elements.copyLogBtn.addEventListener('click', () => {
  copyText(buildLogsText(), '工作日志已复制。');
});

elements.clearLogBtn.addEventListener('click', async () => {
  const accepted = window.confirm('确定清空工作日志吗？工作记录和当天成功下单防重复记录不会被删除。');
  if (!accepted) {
    return;
  }
  const response = await send('CLEAR_LOGS');
  if (response?.ok) {
    logs = [];
    renderLogs();
    showToast('工作日志已清空。');
  }
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== 'local') {
    return;
  }
  if (changes[STORAGE_KEYS.RUN_STATE]) {
    runState = changes[STORAGE_KEYS.RUN_STATE].newValue || null;
    renderState();
  }
  if (changes[STORAGE_KEYS.LOGS]) {
    logs = Array.isArray(changes[STORAGE_KEYS.LOGS].newValue)
      ? changes[STORAGE_KEYS.LOGS].newValue
      : [];
    renderLogs();
  }
  if (changes[STORAGE_KEYS.SETTINGS]) {
    settings = changes[STORAGE_KEYS.SETTINGS].newValue || { orderIntervalSeconds: 30 };
    if (!(runState && ACTIVE_MODES.has(runState.mode))) {
      elements.orderIntervalSeconds.value = String(settings.orderIntervalSeconds ?? 30);
    }
  }
});

async function initialize() {
  const response = await send('GET_ALL_DATA');
  const data = response?.data || {};
  runState = data[STORAGE_KEYS.RUN_STATE] || null;
  logs = Array.isArray(data[STORAGE_KEYS.LOGS]) ? data[STORAGE_KEYS.LOGS] : [];
  settings = data[STORAGE_KEYS.SETTINGS] && typeof data[STORAGE_KEYS.SETTINGS] === 'object'
    ? data[STORAGE_KEYS.SETTINGS]
    : { orderIntervalSeconds: 30 };
  elements.orderIntervalSeconds.value = String(settings.orderIntervalSeconds ?? 30);
  draftRows = ensureMinimumRows(
    Array.isArray(data[STORAGE_KEYS.DRAFT_ROWS]) ? data[STORAGE_KEYS.DRAFT_ROWS] : []
  );

  renderInputTable();
  renderState();
  renderLogs();
}

setInterval(() => {
  if (runState?.phase === 'WAIT_INTERVAL') {
    updateStatusHeader();
  }
}, 1000);

initialize().catch((error) => showToast(error.message || String(error), true));
