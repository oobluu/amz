const $ = (id) => document.querySelector(`#${id}`);
const fields = ['orderId', 'fullName', 'street', 'houseNumber', 'postcode', 'town', 'country'];
const clean = (value) => value.replace(/^[\s:：,;-]+|[\s,;]+$/g, '').trim();
const getLabelValue = (line, keys) => {
  const escaped = keys.map((key) => key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
  const hit = line.match(new RegExp(`^(?:${escaped})\\s*[:：-]\\s*(.+)$`, 'i'));
  return hit ? clean(hit[1]) : '';
};

function parseAddress(source) {
  const lines = source.split(/\r?\n/).map(clean).filter(Boolean);
  const data = { orderId: '', fullName: '', street: '', houseNumber: '', postcode: '', town: '', country: 'Germany' };
  const aliases = {
    orderId: ['order id', 'order number', 'shipment reference', 'customer reference', '订单号'],
    fullName: ['name', 'recipient', 'consignee', '姓名', '收件人'],
    street: ['street', 'address', 'straße', 'strasse', '街道', '地址'],
    houseNumber: ['no.', 'number', 'house number', 'hausnummer', '门牌号'],
    postcode: ['postcode', 'postal code', 'zip', 'plz', '邮编'],
    town: ['town', 'city', 'ort', '城市'],
    country: ['country', '国家']
  };
  for (const line of lines) for (const [field, keys] of Object.entries(aliases)) if (!data[field] || field === 'country') {
    const value = getLabelValue(line, keys);
    if (value) data[field] = value;
  }
  const order = source.match(/\b\d{3}-\d{7}-\d{7}\b/);
  if (!data.orderId && order) data.orderId = order[0];
  const postcodeLine = lines.find((line) => /^\d{4,5}$/.test(line) || /\b\d{5}\b/.test(line));
  if (postcodeLine) {
    const postcode = postcodeLine.match(/\b(\d{4,5})\b/);
    if (!data.postcode && postcode) data.postcode = postcode[1];
    if (!data.town && postcode) data.town = clean(postcodeLine.replace(postcode[0], ''));
  }
  const ignored = /^(?:order|shipment|customer|name|recipient|consignee|street|address|postcode|postal|zip|plz|town|city|country|订单|姓名|收件|地址|邮编|城市|国家)\b/i;
  const candidates = lines.filter((line) => !ignored.test(line) && !/\b\d{3}-\d{7}-\d{7}\b/.test(line) && line !== postcodeLine && !/^(germany|deutschland|austria|österreich|osterreich)$/i.test(line));
  if (!data.fullName && candidates.length) data.fullName = candidates[0];
  const address = data.street || candidates.slice(1).find((line) => /\d/.test(line)) || '';
  if (address) {
    const hit = address.match(/^(.*?)[,\s]+(\d+[\w\/-]*)$/u);
    data.street = data.street || clean(hit ? hit[1] : address);
    if (!data.houseNumber && hit) data.houseNumber = hit[2];
  }
  if (!data.town) data.town = candidates.find((line) => line !== data.fullName && line !== address && !/\d/.test(line)) || '';
  data.country = 'Germany';
  return data;
}

function status(message, error = false) { $('status').textContent = message; $('status').classList.toggle('error', error); }
function renderParsed(source, showMessage = true) {
  if (!source.trim()) { $('result').hidden = true; return; }
  const data = parseAddress(source);
  fields.forEach((field) => { $(field).value = data[field]; });
  $('result').hidden = false;
  if (showMessage) status(data.orderId ? '已自动解析，确认后可直接填入 DHL。' : '未识别订单号，请手动补充。', !data.orderId);
}

chrome.storage.local.get({ dhlEmail: '', dhlDraft: '' }, ({ dhlEmail, dhlDraft }) => {
  $('email').value = dhlEmail;
  if (dhlDraft) { $('source').value = dhlDraft; renderParsed(dhlDraft); }
});
$('email').addEventListener('change', () => chrome.storage.local.set({ dhlEmail: $('email').value.trim() }));
$('source').addEventListener('input', () => {
  const source = $('source').value;
  chrome.storage.local.set({ dhlDraft: source });
  renderParsed(source, false);
});

$('copyAmazon').addEventListener('click', async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const [{ result: amazon }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: readAmazonOrder });
    if (!amazon?.orderId || !amazon?.address) return status('未找到订单号或收件地址；请打开 Seller Central 的订单详情页。', true);
    const text = `${amazon.orderId}\n${amazon.address}`;
    await navigator.clipboard.writeText(text);
    $('source').value = text;
    chrome.storage.local.set({ dhlDraft: text });
    renderParsed(text, false);
    status('已复制并保存。切到 DHL 后重新打开扩展，内容会自动恢复。');
  } catch { status('复制失败；请确认当前页面是可访问的 Seller Central 订单详情。', true); }
});

$('fill').addEventListener('click', async () => {
  const data = Object.fromEntries(fields.map((field) => [field, $(field).value.trim()]));
  data.email = $('email').value.trim();
  if (!data.orderId || !data.fullName || !data.postcode || !data.town || !data.street || !data.houseNumber) return status('请补全订单号、姓名、街道、门牌号、邮编和城市。', true);
  chrome.storage.local.set({ dhlEmail: data.email });
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const reports = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: fillDhl, args: [data] });
    const filled = reports.reduce((total, frame) => total + (frame.result?.filled || 0), 0);
    status(filled ? `已精确填入 ${filled} 个 DHL 字段。` : '未找到 DHL 表单。请停留在填写地址的实际页面后再试。', !filled);
  } catch { status('无法在此页面填充；请先打开 DHL 的可编辑表单。', true); }
});

function readAmazonOrder() {
  const orderId = document.querySelector('[data-test-id="order-id-value"]')?.innerText.trim() || '';
  const address = [...document.querySelectorAll('[data-test-id="shipping-section-buyer-address"] span')].map((el) => el.innerText.trim()).filter(Boolean).join('\n');
  return { orderId, address };
}

function fillDhl(data) {
  const setValue = (input, value) => {
    const proto = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(input, value);
    input.dispatchEvent(new Event('input', { bubbles: true })); input.dispatchEvent(new Event('change', { bubbles: true })); input.dispatchEvent(new Event('blur', { bubbles: true }));
  };
  const targets = {
    fullName: 'input[name="address.sender.name1"]',
    postcode: '#address\\.sender\\.plz, input[name="address.sender.plz"]',
    town: '#address\\.sender\\.city, input[name="address.sender.city"]',
    houseNumber: 'input[name="address.sender.streetNumber"]',
    street: '#address\\.sender\\.street, input[name="address.sender.street"]',
    orderId: 'input[name="shipmentReference"], input[name="customerReference"]',
    email: 'input[name*="email" i], input[type="email"]'
  };
  let filled = 0;
  for (const [field, selector] of Object.entries(targets)) {
    const value = data[field];
    if (!value) continue;
    for (const input of document.querySelectorAll(selector)) { if (!input.disabled && !input.readOnly) { setValue(input, value); filled += 1; } }
  }
  return { filled };
}
