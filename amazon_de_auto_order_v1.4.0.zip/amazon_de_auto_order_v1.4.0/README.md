# Amazon DE 自动下单助手 v1.4.0

Chrome Manifest V3 扩展，用于在 **Amazon.de 英文界面** 按表格数据逐行执行下单流程。控制面板使用独立浏览器窗口，任务只控制一个 Amazon 工作标签页。

## 1. 安装

1. 解压 ZIP。
2. 在 Chrome 地址栏打开 `chrome://extensions/`。
3. 开启右上角“开发者模式”。
4. 点击“加载已解压的扩展程序”。
5. 选择目录 `amazon_de_auto_order_v1.4.0`。
6. 登录 Amazon.de，并保持账号可正常使用 Buy Now。
7. 点击扩展图标打开独立控制面板。

升级时应先禁用或删除旧版本，避免两个版本同时控制 Amazon 页面。

## 2. 输入格式

输入表格固定为以下 **九列**，顺序不能改变：

| 顺序 | 列名 | 用途 |
|---:|---|---|
| 1 | Temu Order ID | 当天防重复依据 |
| 2 | AMZ link | Amazon 商品链接 |
| 3 | quantity to ship | 需要购买的精准数量 |
| 4 | recipient name | 收件人姓名 |
| 5 | phone number | 电话号码 |
| 6 | ship address | 街道和门牌号 |
| 7 | address2 | 补充地址，可为空 |
| 8 | ship city | 城市 |
| 9 | ship postal code | 邮编 |

### Excel 粘贴规则

- 从 Excel 复制完整数据时，每一行必须正好九列。
- `address2` 为空时，该空单元格仍必须保留在 `ship address` 与 `ship city` 之间。
- 八列旧格式会被拒绝，防止城市被误填进 `address2`。
- 不要复制表头。
- 可以在单个文本框中手工编辑内容。

## 3. 地址字段映射

Amazon DE 新建地址窗口的两个 Address 文本框命名与视觉顺序相反，本扩展按下列固定映射填写：

| 插件字段 | Amazon 页面位置 | DOM ID |
|---|---|---|
| ship address | 第一个 Address 文本框 | `address-ui-widgets-enterAddressLine2` |
| address2 | 第二个 Address 文本框 | `address-ui-widgets-enterAddressLine1` |

规则：

- `address2` 有内容时，填入第二个 Address 文本框。
- `address2` 为空时，明确清空第二个 Address 文本框。
- 点击 `Use this address` 前，插件回读并核对姓名、电话、ship address、address2、邮编和城市六项数据。
- 任一字段回读不一致时，任务暂停并等待人工检查。

## 4. 主工作流程

1. 预检查 Temu Order ID、链接、数量、姓名、电话和地址数据。
2. 当前批次中，处理后姓名重复的所有对应行均记录为“有重复姓名，跳过”。
3. 打开商品链接并识别当前可用的 Buy Box。
4. 检查当前下单模块的含税单价是否为 €2.00。
5. 按 `quantity to ship` 选择精准数字数量。
6. 回读数量；只有页面数量与目标数量完全一致时才点击商品页 Buy Now。
7. 进入下单页面，按正常地址流程或特殊银行卡分支处理。
8. 填写并核对新地址。
9. 推荐地址窗口出现时，由用户人工选择地址并点击 `Use this address`；窗口关闭并进入付款页后，插件自动恢复。
10. 付款页只核对处理后的收件人姓名，不再检查付款页金额。
11. 点击最终 Buy now。顶部按钮无响应时，尝试底部第二个 Buy now。
12. 在下单成功页点击 `Review or edit your recent orders`。
13. 核对订单列表第一张卡片的 `Dispatch to` 姓名。
14. 获取有效 Amazon Order ID，并写入工作结果。
15. 成功订单等待设定的每单间隔后处理下一条；跳过行不等待。

## 5. 商品价格与数量规则

### 商品含税单价

插件从当前有效 Buy Box 读取含税单价，优先使用当前模块中的稳定隐藏字段及可见 `incl. VAT` 金额。

- 等于 €2.00：继续。
- 不等于 €2.00：记录“金额不为2，跳过”。
- 完全无法读取或多个可靠来源互相冲突：暂停全部任务，等待人工检查。
- 付款页面不再检查金额。

### 精准数量

- `quantity to ship` 必须是标准正整数。
- `1`、`2`、`3`、`4` 等数字选项可精准匹配。
- `4+`、`5+` 等选项不视为数字 4 或 5。
- 没有目标精准数字选项时，记录“限购，跳过”。
- 选择后页面回读数量不一致时，暂停全部任务。

## 6. 下单页面的两种地址入口

### 正常分支

如果页面存在可见的 `Add a new delivery address`：

1. 直接点击该入口。
2. 不修改银行卡。
3. 按原地址流程继续。

### 特殊银行卡分支

只有在以下条件同时成立时才进入此分支：

- 页面没有可见的 `Add a new delivery address`；
- 页面存在 `Your credit cards` 银行卡模块；
- 地址模块存在 `Change delivery address`。

处理顺序：

1. 在 `.pmts-credit-card-row` 中精准定位 `American Express ending in 1009`。
2. 若目标卡未选中，则点击目标卡。
3. 重新读取运行时状态；只有目标卡同时满足 `radio.checked === true`，且它是唯一带有 `pmts-selected` 的可见银行卡行，才视为切换成功。
4. 不使用 `hasAttribute('checked')` 或粘贴 HTML 中残留的 `checked=""` 判断当前状态。
5. 点击 `#checkout-deliveryAddressPanel` 中的 `Change`。
6. 等待地址选择页加载 `Add a new delivery address`。
7. 进入原地址填写流程。

该分支的限制：

- 只在点击 `Change` 前确认一次 American Express ending in 1009。
- 添加地址并返回最终付款页后，不再复查或重新切换银行卡。
- 不勾选、不取消，也不修改 American Express Rewards Points。
- 找不到目标卡、目标卡不可用、无法确认选中、找不到 Change 或点击后未加载地址入口时，暂停全部任务。

## 7. 推荐地址窗口

出现 `Verify your address` 窗口时：

- 插件不自动选择 Original address。
- 插件不自动选择 Suggested address。
- 插件不自动点击该窗口中的 `Use this address`。
- 用户人工完成选择后，插件在进入付款页时自动继续。

## 8. 姓名处理

填写 Amazon 前：

- 保留 Unicode 字母、空格、连字符 `-` 和撇号 `'`。
- 其他符号及数字转换为空格。
- 连续空格压缩为一个空格。
- 去除首尾空格。

当前批次重复姓名比较使用处理后的姓名，忽略大小写和多余空格。

## 9. Temu Order ID 当天防重复

- 防重复只按 Temu Order ID 判断。
- 比较时去除空白并转换为大写。
- 仅成功获取有效 Amazon Order ID 的订单计入当天记录。
- 普通跳过、页面错误和未取得 Order ID 的订单不计入当天记录。
- “清空当天下单记录”只清除隐藏的当天成功防重复数据，不清除输入表格、工作记录或日志。
- 日期按 `Europe/Berlin` 自然日计算。

## 10. 工作记录

工作记录与导出的 CSV 固定保留七列：

1. Temu Order ID
2. ASIN
3. recipient name
4. address
5. city
6. postal code
7. 工作结果

`address2` 只用于输入和 Amazon 地址填写，不加入工作记录和 CSV。

成功下单时，“工作结果”直接显示 Amazon Order ID；其他情况显示原有结果，例如：

- 有重复姓名，跳过
- 金额不为2，跳过
- 限购，跳过
- 未找到商品，跳过
- 等待人工检查：……

面板提供：

- 复制所有 Order ID
- 导出工作记录 CSV
- 复制工作记录
- 复制工作日志

## 11. 每单间隔

- 默认 30 秒。
- 可设置 0–3600 的整数。
- 只在成功取得 Order ID 后开始计时。
- 跳过行直接进入下一条。
- 最后一条成功后没有下一条有效数据时，任务直接完成。

## 12. 页面异常处理

下列情况会暂停全部任务并等待人工检查：

- Amazon 登录、验证码或 Robot Check；
- 商品页面无法识别当前 Buy Box；
- 商品价格读取失败或来源冲突；
- 数量回读不一致；
- 地址六项回读不一致；
- 特殊银行卡分支任何关键步骤失败；
- 付款页收件人姓名不一致；
- 最终 Buy now 后无法确认下单结果；
- 第一张订单卡片收件人姓名不一致；
- 无法获取有效 Order ID。

## 13. 重要风险

本版本按既定规则，不为“已经点击最终 Buy now，但尚未取得 Order ID”的订单保存未确认安全锁。

因此，如果 Amazon 实际已创建订单，但插件因为网络、跳转或订单页加载问题未取得 Order ID，再次运行相同 Temu Order ID 可能重复下单。遇到最终付款后的任何异常，应先人工检查 Amazon 最近订单。

## 14. 文件结构

```text
amazon_de_auto_order_v1.4.0/
├── manifest.json
├── background.js
├── content.js
├── panel.html
├── panel.css
├── panel.js
└── README.md
```

## 15. 建议首次测试

1. 禁用旧版本。
2. 只输入一条新的 Temu Order ID。
3. `address2` 为空时保留第七列空单元格。
4. 先测试正常 Add-new 分支。
5. 再单独测试特殊银行卡分支。
6. 在最终付款后异常停止时，先检查 Amazon 最近订单再决定是否重试。

本扩展未在当前生成环境中执行真实 Amazon 付款测试。
