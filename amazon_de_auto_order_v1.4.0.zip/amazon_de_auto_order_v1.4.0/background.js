'use strict';

const STORAGE_KEYS = Object.freeze({
  RUN_STATE: 'amzOrderRunState',
  HISTORY: 'amzOrderHistory',
  ORDER_INDEX: 'amzTemuOrderIndex',
  LOGS: 'amzOrderLogs',
  DRAFT_ROWS: 'amzOrderDraftRows',
  SETTINGS: 'amzOrderSettings'
});

const DEFAULT_SETTINGS = Object.freeze({
  orderIntervalSeconds: 30
});
const MAX_LOG_ENTRIES = 2500;
const MAX_HISTORY_ENTRIES = 2000;
const ACTIVE_MODES = new Set(['running', 'paused', 'transitioning']);
const POST_SUBMIT_PHASES = new Set(['WAIT_ORDER_SUCCESS', 'WAIT_ORDER_HISTORY']);
const INTERVAL_ALARM_PREFIX = 'amz-order-interval:';
const ORDER_ID_PATTERN = /^\d{3}-\d{7}-\d{7}$/;
const START_PASSWORD = '963852';

let mutationQueue = Promise.resolve();
const intervalTimers = new Map();

function enqueueMutation(task) {
  const next = mutationQueue.then(task, task);
  mutationQueue = next.catch(() => undefined);
  return next;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function normalizeIntervalSeconds(value, fallback = DEFAULT_SETTINGS.orderIntervalSeconds) {
  const number = Number(value);
  if (!Number.isInteger(number) || number < 0 || number > 3600) {
    return fallback;
  }
  return number;
}

function normalizeSettings(value) {
  const source = value && typeof value === 'object' ? value : {};
  return {
    orderIntervalSeconds: normalizeIntervalSeconds(
      source.orderIntervalSeconds,
      DEFAULT_SETTINGS.orderIntervalSeconds
    )
  };
}

function isValidOrderId(value) {
  return ORDER_ID_PATTERN.test(String(value ?? '').trim());
}

function parseRequestedQuantity(value) {
  const text = String(value ?? '').trim();
  if (!/^[1-9]\d*$/.test(text)) {
    return null;
  }
  const number = Number(text);
  return Number.isSafeInteger(number) ? number : null;
}

function getIntervalAlarmName(runId) {
  return `${INTERVAL_ALARM_PREFIX}${String(runId || '')}`;
}

function clearIntervalTimer(runId) {
  const timer = intervalTimers.get(runId);
  if (timer !== undefined) {
    clearTimeout(timer);
    intervalTimers.delete(runId);
  }
}

async function clearIntervalAlarm(runId) {
  if (!runId) {
    return false;
  }
  return chrome.alarms.clear(getIntervalAlarmName(runId));
}

async function cancelIntervalWait(runId) {
  clearIntervalTimer(runId);
  try {
    await clearIntervalAlarm(runId);
  } catch {
    // The alarm may already be absent.
  }
}

function getIntervalRemainingMs(state) {
  const endsAt = Date.parse(String(state?.intervalEndsAt || ''));
  if (Number.isFinite(endsAt)) {
    return Math.max(0, endsAt - Date.now());
  }
  const seconds = Number(state?.intervalRemainingSeconds || 0);
  return Math.max(0, seconds * 1000);
}

async function scheduleIntervalWake(state, delayMs) {
  const runId = state?.runId;
  if (!runId) {
    throw new Error('无法安排下单间隔：任务 ID 不存在。');
  }

  const safeDelayMs = Math.max(0, Number(delayMs) || 0);
  const wakeAt = Date.now() + safeDelayMs;
  await cancelIntervalWait(runId);
  await chrome.alarms.create(getIntervalAlarmName(runId), { when: wakeAt });

  // A short timer makes settings below one minute responsive. The alarm is
  // retained as a recovery path if the Manifest V3 service worker is suspended.
  if (safeDelayMs <= 60000) {
    const timer = setTimeout(() => {
      intervalTimers.delete(runId);
      enqueueMutation(() => resumeIntervalRun(runId)).catch((error) => console.error(error));
    }, safeDelayMs);
    intervalTimers.set(runId, timer);
  }
}

function getBerlinDateKey(date = new Date()) {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/Berlin',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).formatToParts(date);
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
}

function getBerlinTimestamp(date = new Date()) {
  return new Intl.DateTimeFormat('zh-CN', {
    timeZone: 'Europe/Berlin',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23'
  }).format(date);
}

function normalizeWhitespace(value) {
  return String(value ?? '')
    .normalize('NFKC')
    .replace(/\s+/g, ' ')
    .trim();
}

function sanitizeRecipientName(value) {
  return String(value ?? '')
    .normalize('NFKC')
    .replace(/[^\p{L}\p{M}\s\-'’]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function normalizeKeyPart(value) {
  return normalizeWhitespace(value).toLocaleLowerCase('de-DE');
}

function normalizeTemuOrderId(value) {
  return String(value ?? '')
    .normalize('NFKC')
    .replace(/\s+/g, '')
    .trim()
    .toUpperCase();
}

function extractAsin(link) {
  const raw = String(link ?? '').trim();
  if (!raw) {
    return null;
  }

  let url;
  try {
    url = new URL(raw);
  } catch {
    return null;
  }

  const host = url.hostname.toLowerCase();
  if (host !== 'amazon.de' && !host.endsWith('.amazon.de')) {
    return null;
  }

  const pathPatterns = [
    /\/(?:dp|gp\/product|gp\/aw\/d)\/([A-Z0-9]{10})(?:[/?]|$)/i,
    /\/product\/([A-Z0-9]{10})(?:[/?]|$)/i
  ];

  for (const pattern of pathPatterns) {
    const match = url.pathname.match(pattern);
    if (match) {
      return match[1].toUpperCase();
    }
  }

  const queryAsin = url.searchParams.get('asin') || url.searchParams.get('ASIN');
  if (queryAsin && /^[A-Z0-9]{10}$/i.test(queryAsin)) {
    return queryAsin.toUpperCase();
  }

  return null;
}

function buildDedupeKey({ temuOrderId }) {
  return normalizeTemuOrderId(temuOrderId);
}

function getOrderIndexStorageKey(value) {
  const normalized = normalizeTemuOrderId(value);
  return normalized ? `temu:${normalized}` : '';
}

function resolveRecordDateKey(dateKey, timestamp) {
  const direct = String(dateKey || '').trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(direct)) {
    return direct;
  }
  const date = new Date(timestamp || '');
  return Number.isNaN(date.getTime()) ? '' : getBerlinDateKey(date);
}

function sanitizeHistory(rawHistory) {
  const cleaned = [];
  for (const record of Array.isArray(rawHistory) ? rawHistory : []) {
    const temuOrderId = normalizeTemuOrderId(record?.temuOrderIdKey || record?.temuOrderId || '');
    const orderId = String(record?.orderId || '').trim();
    if (!temuOrderId || record?.status !== 'ORDERED' || !isValidOrderId(orderId)) {
      continue;
    }
    cleaned.push({
      ...record,
      temuOrderId,
      temuOrderIdKey: temuOrderId,
      status: 'ORDERED',
      orderId,
      dateKey: resolveRecordDateKey(record?.dateKey, record?.updatedAt || record?.createdAt),
      updatedAt: record?.updatedAt || record?.createdAt || new Date().toISOString()
    });
  }
  return cleaned;
}

function buildOrderIndex(rawIndex, history = []) {
  const index = {};
  const candidates = [];

  if (rawIndex && typeof rawIndex === 'object' && !Array.isArray(rawIndex)) {
    for (const value of Object.values(rawIndex)) {
      const temuOrderId = normalizeTemuOrderId(value?.temuOrderId || '');
      const orderId = String(value?.orderId || '').trim();
      if (!temuOrderId || value?.status !== 'ORDERED' || !isValidOrderId(orderId)) {
        continue;
      }
      candidates.push({
        temuOrderId,
        status: 'ORDERED',
        orderId,
        dateKey: resolveRecordDateKey(value?.dateKey, value?.updatedAt),
        updatedAt: value?.updatedAt || new Date().toISOString()
      });
    }
  }

  for (const record of sanitizeHistory(history)) {
    candidates.push({
      temuOrderId: record.temuOrderIdKey,
      status: 'ORDERED',
      orderId: record.orderId,
      dateKey: record.dateKey,
      updatedAt: record.updatedAt
    });
  }

  for (const candidate of candidates) {
    const storageKey = getOrderIndexStorageKey(candidate.temuOrderId);
    if (!storageKey) {
      continue;
    }
    const existing = index[storageKey];
    if (!existing || String(candidate.updatedAt) >= String(existing.updatedAt || '')) {
      index[storageKey] = candidate;
    }
  }

  return index;
}

function makeLog(level, message, rowNumber = null) {
  return {
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    time: getBerlinTimestamp(),
    isoTime: new Date().toISOString(),
    level,
    rowNumber,
    message
  };
}

function appendLog(logs, level, message, rowNumber = null) {
  const nextLogs = Array.isArray(logs) ? logs : [];
  nextLogs.push(makeLog(level, message, rowNumber));
  if (nextLogs.length > MAX_LOG_ENTRIES) {
    nextLogs.splice(0, nextLogs.length - MAX_LOG_ENTRIES);
  }
  return nextLogs;
}

function createRowRecord(rawRow, sourceIndex) {
  const raw = rawRow && typeof rawRow === 'object' ? rawRow : {};
  const temuOrderId = normalizeWhitespace(raw.temuOrderId);
  const normalizedTemuOrderId = normalizeTemuOrderId(temuOrderId);
  const amzLink = String(raw.amzLink ?? '').trim();
  const quantityToShip = String(raw.quantityToShip ?? '').trim();
  const recipientName = String(raw.recipientName ?? '').trim();
  const phoneNumber = String(raw.phoneNumber ?? '').trim();
  const shipAddress = normalizeWhitespace(raw.shipAddress);
  const address2 = normalizeWhitespace(raw.address2);
  const shipCity = normalizeWhitespace(raw.shipCity);
  const shipPostalCode = normalizeWhitespace(raw.shipPostalCode);
  const normalizedName = sanitizeRecipientName(recipientName);
  const normalizedNameKey = normalizeKeyPart(normalizedName);
  const requestedQuantity = parseRequestedQuantity(quantityToShip);
  const asin = extractAsin(amzLink);

  return {
    id: crypto.randomUUID(),
    sourceIndex,
    rowNumber: sourceIndex + 1,
    temuOrderId,
    normalizedTemuOrderId,
    amzLink,
    quantityToShip,
    recipientName,
    normalizedName,
    normalizedNameKey,
    requestedQuantity,
    phoneNumber,
    shipAddress,
    address2,
    shipCity,
    shipPostalCode,
    asin,
    dedupeKey: null,
    status: '待处理',
    result: 'pending',
    orderId: '',
    observedUnitPrice: '',
    selectedQuantity: '',
    updatedAt: new Date().toISOString()
  };
}

function isCompletelyBlankRow(row) {
  return [
    row.temuOrderId,
    row.amzLink,
    row.quantityToShip,
    row.recipientName,
    row.phoneNumber,
    row.shipAddress,
    row.address2,
    row.shipCity,
    row.shipPostalCode
  ].every((value) => String(value ?? '').trim() === '');
}

function markRow(row, status, result) {
  row.status = status;
  row.result = result;
  row.updatedAt = new Date().toISOString();
}

function prepareRows(rawRows, history, rawOrderIndex) {
  const seenTemuOrderIds = new Set();
  const orderIndex = buildOrderIndex(rawOrderIndex, history);
  const today = getBerlinDateKey();
  const nonBlankRows = (Array.isArray(rawRows) ? rawRows : [])
    .map((rawRow, sourceIndex) => createRowRecord(rawRow, sourceIndex))
    .filter((row) => !isCompletelyBlankRow(row));

  // Duplicate recipient names are evaluated across the entire non-empty batch.
  // Every row belonging to a duplicated normalized name is skipped.
  const recipientNameCounts = new Map();
  for (const row of nonBlankRows) {
    if (!row.normalizedNameKey) {
      continue;
    }
    recipientNameCounts.set(
      row.normalizedNameKey,
      (recipientNameCounts.get(row.normalizedNameKey) || 0) + 1
    );
  }

  const preparedRows = [];
  for (const row of nonBlankRows) {
    if (row.normalizedNameKey && (recipientNameCounts.get(row.normalizedNameKey) || 0) > 1) {
      markRow(row, '有重复姓名，跳过', 'skipped');
      preparedRows.push(row);
      continue;
    }

    if (!row.normalizedTemuOrderId) {
      markRow(row, 'Temu Order ID为空，跳过', 'skipped');
      preparedRows.push(row);
      continue;
    }

    if (row.requestedQuantity === null) {
      markRow(row, '数量格式错误，跳过', 'skipped');
      preparedRows.push(row);
      continue;
    }

    if (!row.asin) {
      markRow(row, 'AMZ link无效，跳过', 'skipped');
      preparedRows.push(row);
      continue;
    }

    if (!row.normalizedName || !row.phoneNumber || !row.shipAddress || !row.shipCity || !row.shipPostalCode) {
      markRow(row, '信息不完整，跳过', 'skipped');
      preparedRows.push(row);
      continue;
    }

    row.dedupeKey = buildDedupeKey(row);

    if (seenTemuOrderIds.has(row.dedupeKey)) {
      markRow(row, 'Temu Order ID重复，跳过', 'skipped');
      preparedRows.push(row);
      continue;
    }
    seenTemuOrderIds.add(row.dedupeKey);

    const existing = orderIndex[getOrderIndexStorageKey(row.dedupeKey)];
    if (
      existing?.status === 'ORDERED' &&
      existing.dateKey === today &&
      isValidOrderId(existing.orderId)
    ) {
      markRow(row, 'Temu Order ID当天已下过单，跳过', 'skipped');
      preparedRows.push(row);
      continue;
    }

    markRow(row, '待处理', 'ready');
    preparedRows.push(row);
  }

  return { preparedRows, orderIndex };
}

function findNextReadyIndex(rows, afterIndex = -1) {
  for (let index = afterIndex + 1; index < rows.length; index += 1) {
    if (rows[index]?.result === 'ready') {
      return index;
    }
  }
  return -1;
}

function getCurrentRow(state) {
  if (!state || !Array.isArray(state.rows) || !Number.isInteger(state.currentIndex)) {
    return null;
  }
  return state.rows[state.currentIndex] || null;
}

async function getStoredData() {
  return chrome.storage.local.get([
    STORAGE_KEYS.RUN_STATE,
    STORAGE_KEYS.HISTORY,
    STORAGE_KEYS.ORDER_INDEX,
    STORAGE_KEYS.LOGS,
    STORAGE_KEYS.DRAFT_ROWS,
    STORAGE_KEYS.SETTINGS
  ]);
}

async function openOrFocusPanel() {
  const panelUrl = chrome.runtime.getURL('panel.html');
  const windows = await chrome.windows.getAll({ populate: true });

  for (const windowInfo of windows) {
    const panelTab = windowInfo.tabs?.find((tab) => tab.url === panelUrl);
    if (panelTab) {
      await chrome.windows.update(windowInfo.id, { focused: true });
      await chrome.tabs.update(panelTab.id, { active: true });
      return;
    }
  }

  await chrome.windows.create({
    url: panelUrl,
    type: 'popup',
    width: 1400,
    height: 900,
    focused: true
  });
}

async function acquireWorkTab(previousTabId = null) {
  if (Number.isInteger(previousTabId)) {
    try {
      const existingTab = await chrome.tabs.get(previousTabId);
      await chrome.tabs.update(existingTab.id, { url: 'about:blank', active: true });
      await chrome.windows.update(existingTab.windowId, { focused: true });
      await sleep(120);
      return existingTab.id;
    } catch {
      // Create a replacement tab below.
    }
  }

  const normalWindows = await chrome.windows.getAll({ windowTypes: ['normal'] });
  const targetWindow = normalWindows.find((item) => item.focused) || normalWindows[0];

  if (targetWindow) {
    const tab = await chrome.tabs.create({
      windowId: targetWindow.id,
      url: 'about:blank',
      active: true
    });
    await chrome.windows.update(targetWindow.id, { focused: true });
    return tab.id;
  }

  const createdWindow = await chrome.windows.create({
    type: 'normal',
    url: 'about:blank',
    focused: true
  });
  const tabId = createdWindow.tabs?.[0]?.id;
  if (!Number.isInteger(tabId)) {
    throw new Error('无法创建 Amazon 工作标签页。');
  }
  return tabId;
}

async function focusWorkTab(tabId) {
  if (!Number.isInteger(tabId)) {
    throw new Error('工作标签页不存在。');
  }
  const tab = await chrome.tabs.get(tabId);
  await chrome.tabs.update(tabId, { active: true });
  await chrome.windows.update(tab.windowId, { focused: true });
}

async function wakeWorkTab(tabId) {
  if (!Number.isInteger(tabId)) {
    return;
  }
  try {
    await chrome.tabs.sendMessage(tabId, { type: 'WAKE_AUTOMATION' });
  } catch {
    // The content script will start automatically after the next Amazon page load.
  }
}

async function navigateWorkTab(tabId, url) {
  if (!Number.isInteger(tabId)) {
    throw new Error('工作标签页不存在。');
  }
  await chrome.tabs.update(tabId, { url, active: true });
  await focusWorkTab(tabId);
}

async function saveStateAndLogs(state, logs, extra = {}) {
  await chrome.storage.local.set({
    [STORAGE_KEYS.RUN_STATE]: state,
    [STORAGE_KEYS.LOGS]: logs,
    ...extra
  });
}

async function startRun(rawRows, requestedIntervalSeconds, startPassword) {
  const data = await getStoredData();
  const logs = Array.isArray(data[STORAGE_KEYS.LOGS]) ? data[STORAGE_KEYS.LOGS] : [];

  if (String(startPassword ?? '') !== START_PASSWORD) {
    appendLog(logs, 'warning', '开始密码错误，任务未启动。');
    await chrome.storage.local.set({ [STORAGE_KEYS.LOGS]: logs });
    return { ok: false, error: '开始密码错误。' };
  }

  const existingState = data[STORAGE_KEYS.RUN_STATE];
  if (existingState && ACTIVE_MODES.has(existingState.mode) && existingState.phase !== 'PRECHECK_PENDING') {
    return {
      ok: false,
      error: '已有未结束任务。请使用继续、跳过当前行或停止按钮处理现有任务。'
    };
  }

  if (existingState?.runId) {
    await cancelIntervalWait(existingState.runId);
  }

  const storedSettings = normalizeSettings(data[STORAGE_KEYS.SETTINGS]);
  const rawInterval = requestedIntervalSeconds ?? storedSettings.orderIntervalSeconds;
  const numericInterval = Number(rawInterval);
  if (!Number.isInteger(numericInterval) || numericInterval < 0 || numericInterval > 3600) {
    return { ok: false, error: '每单间隔必须是 0–3600 的整数。' };
  }
  const orderIntervalSeconds = numericInterval;
  const settings = { orderIntervalSeconds };

  const history = sanitizeHistory(data[STORAGE_KEYS.HISTORY]);
  const orderIndex = buildOrderIndex(data[STORAGE_KEYS.ORDER_INDEX], history);
  const { preparedRows } = prepareRows(rawRows, history, orderIndex);

  if (preparedRows.length === 0) {
    return { ok: false, error: '没有可处理的数据行。' };
  }

  appendLog(logs, 'info', `开始密码验证通过。任务预检查开始：共 ${preparedRows.length} 条非空数据。`);

  const duplicateNameCount = preparedRows.filter((row) => row.status === '有重复姓名，跳过').length;
  if (duplicateNameCount > 0) {
    appendLog(logs, 'warning', `发现 ${duplicateNameCount} 条重复收件人姓名数据；所有对应行均已跳过。`);
  }

  const readyCount = preparedRows.filter((row) => row.result === 'ready').length;
  const skippedCount = preparedRows.filter((row) => row.result === 'skipped').length;
  appendLog(logs, 'info', `预检查完成：待处理 ${readyCount} 条，预先跳过 ${skippedCount} 条。`);
  appendLog(
    logs,
    'info',
    '商品页先核对含税单价 €2.00，再按 quantity to ship 精准选择数量；带“+”的数量选项不作为精准匹配。'
  );
  appendLog(
    logs,
    'info',
    '地址表单使用 ship address 填写第一个 Address 文本框，address2 填写第二个文本框；address2 为空时明确清空并回读验证。'
  );
  appendLog(
    logs,
    'info',
    '若下单入口没有 Add a new delivery address 但出现银行卡模块，则先选择 American Express ending in 1009，再点击地址模块 Change；不处理 Rewards Points，返回付款页后不再次核对银行卡。'
  );
  appendLog(
    logs,
    'info',
    `每个成功订单获取 Order ID 后，下一单额外等待 ${orderIntervalSeconds} 秒；跳过行不等待。`
  );

  const firstReadyIndex = findNextReadyIndex(preparedRows);
  if (firstReadyIndex === -1) {
    const state = {
      version: 5,
      runId: crypto.randomUUID(),
      mode: 'completed',
      phase: 'COMPLETED',
      pauseReason: '',
      currentIndex: null,
      rows: preparedRows,
      workTabId: null,
      orderIntervalSeconds,
      intervalEndsAt: null,
      intervalRemainingSeconds: 0,
      startedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    appendLog(logs, 'success', '没有需要下单的有效数据，任务结束。');
    await saveStateAndLogs(state, logs, {
      [STORAGE_KEYS.DRAFT_ROWS]: Array.isArray(rawRows) ? rawRows : [],
      [STORAGE_KEYS.HISTORY]: history,
      [STORAGE_KEYS.ORDER_INDEX]: orderIndex,
      [STORAGE_KEYS.SETTINGS]: settings
    });
    return { ok: true, state };
  }

  const previousTabId = Number.isInteger(existingState?.workTabId) ? existingState.workTabId : null;
  let workTabId;
  try {
    workTabId = await acquireWorkTab(previousTabId);
  } catch (error) {
    return { ok: false, error: error.message || String(error) };
  }

  const currentRow = preparedRows[firstReadyIndex];
  markRow(currentRow, '正在打开商品页面', 'processing');

  const state = {
    version: 5,
    runId: crypto.randomUUID(),
    mode: 'running',
    phase: 'WAIT_PRODUCT',
    pauseReason: '',
    currentIndex: firstReadyIndex,
    rows: preparedRows,
    workTabId,
    orderIntervalSeconds,
    intervalEndsAt: null,
    intervalRemainingSeconds: 0,
    startedAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  appendLog(
    logs,
    'info',
    `第 ${currentRow.rowNumber} 行：开始处理 Temu Order ID ${currentRow.temuOrderId}，ASIN ${currentRow.asin}，目标数量 ${currentRow.requestedQuantity}。`,
    currentRow.rowNumber
  );
  await saveStateAndLogs(state, logs, {
    [STORAGE_KEYS.DRAFT_ROWS]: Array.isArray(rawRows) ? rawRows : [],
    [STORAGE_KEYS.HISTORY]: history,
    [STORAGE_KEYS.ORDER_INDEX]: orderIndex,
    [STORAGE_KEYS.SETTINGS]: settings
  });

  try {
    await navigateWorkTab(workTabId, currentRow.amzLink);
  } catch (error) {
    state.mode = 'paused';
    state.pauseReason = `无法打开商品页面：${error.message || String(error)}`;
    markRow(currentRow, `等待人工检查：${state.pauseReason}`, 'blocked');
    appendLog(logs, 'error', state.pauseReason, currentRow.rowNumber);
    await saveStateAndLogs(state, logs);
  }

  return { ok: true, state };
}

async function transitionPhase(message, sender) {
  const data = await getStoredData();
  const state = data[STORAGE_KEYS.RUN_STATE];
  const logs = Array.isArray(data[STORAGE_KEYS.LOGS]) ? data[STORAGE_KEYS.LOGS] : [];

  if (!state || sender.tab?.id !== state.workTabId) {
    return { ok: false, error: '消息不是来自当前工作标签页。' };
  }
  if (state.runId !== message.runId) {
    return { ok: false, error: '任务版本已经变化。' };
  }
  if (message.expectedPhase && state.phase !== message.expectedPhase) {
    return { ok: false, stale: true, error: `当前阶段已变为 ${state.phase}。` };
  }
  if (state.mode !== 'running') {
    return { ok: false, paused: true, error: '任务当前未运行。' };
  }

  const row = getCurrentRow(state);
  state.phase = message.nextPhase;
  state.updatedAt = new Date().toISOString();
  if (row && Number.isFinite(Number(message.observedUnitPrice))) {
    row.observedUnitPrice = Number(message.observedUnitPrice).toFixed(2);
  }
  if (row && Number.isSafeInteger(Number(message.selectedQuantity)) && Number(message.selectedQuantity) > 0) {
    row.selectedQuantity = Number(message.selectedQuantity);
  }
  if (row && message.status) {
    markRow(row, message.status, 'processing');
  }
  if (message.logMessage) {
    appendLog(logs, message.level || 'info', message.logMessage, row?.rowNumber ?? null);
  }

  await saveStateAndLogs(state, logs);
  return { ok: true, state };
}

async function pauseForError(message, sender) {
  const data = await getStoredData();
  const state = data[STORAGE_KEYS.RUN_STATE];
  const logs = Array.isArray(data[STORAGE_KEYS.LOGS]) ? data[STORAGE_KEYS.LOGS] : [];

  if (!state || sender.tab?.id !== state.workTabId || state.runId !== message.runId) {
    return { ok: false, stale: true };
  }
  if (message.expectedPhase && state.phase !== message.expectedPhase) {
    return { ok: false, stale: true };
  }

  const row = getCurrentRow(state);
  state.mode = 'paused';
  state.pauseReason = message.reason || '页面状态异常。';
  state.updatedAt = new Date().toISOString();
  if (row) {
    markRow(row, `等待人工检查：${state.pauseReason}`, 'blocked');
  }
  appendLog(logs, 'error', state.pauseReason, row?.rowNumber ?? null);
  await saveStateAndLogs(state, logs);
  return { ok: true, state };
}

async function prepareFinalSubmission(message, sender) {
  const data = await getStoredData();
  const state = data[STORAGE_KEYS.RUN_STATE];
  const logs = Array.isArray(data[STORAGE_KEYS.LOGS]) ? data[STORAGE_KEYS.LOGS] : [];
  const history = sanitizeHistory(data[STORAGE_KEYS.HISTORY]);
  const orderIndex = buildOrderIndex(data[STORAGE_KEYS.ORDER_INDEX], history);

  if (!state || sender.tab?.id !== state.workTabId || state.runId !== message.runId) {
    return { ok: false, stale: true, error: '任务状态已经变化。' };
  }
  if (state.mode !== 'running' || state.phase !== 'VERIFY_PAYMENT_NAME') {
    return { ok: false, stale: true, error: `当前阶段不是付款页姓名验证阶段：${state.phase}` };
  }

  const row = getCurrentRow(state);
  if (!row) {
    return { ok: false, error: '找不到当前数据行。' };
  }

  const observedRecipientName = normalizeWhitespace(message.observedRecipientName);
  if (!observedRecipientName || normalizeKeyPart(observedRecipientName) !== normalizeKeyPart(row.normalizedName)) {
    return { ok: false, error: '最终提交前的收件人姓名与当前数据行不一致。' };
  }

  const verifiedUnitPrice = Number(row.observedUnitPrice);
  if (!Number.isFinite(verifiedUnitPrice) || Math.abs(verifiedUnitPrice - 2) > 0.0001) {
    return { ok: false, error: '最终提交前没有有效的商品含税单价 €2.00 校验记录。' };
  }

  const verifiedQuantity = Number(row.selectedQuantity);
  if (
    !Number.isSafeInteger(verifiedQuantity) ||
    verifiedQuantity <= 0 ||
    verifiedQuantity !== row.requestedQuantity
  ) {
    return { ok: false, error: '最终提交前没有有效的精准数量校验记录。' };
  }

  const today = getBerlinDateKey();
  const existingIndexRecord = orderIndex[getOrderIndexStorageKey(row.dedupeKey)];
  if (
    existingIndexRecord?.status === 'ORDERED' &&
    existingIndexRecord.dateKey === today &&
    isValidOrderId(existingIndexRecord.orderId)
  ) {
    state.mode = 'paused';
    state.pauseReason = '最终付款前发现该 Temu Order ID 今天已有成功订单，已停止以避免重复下单。';
    markRow(row, `等待人工检查：${state.pauseReason}`, 'blocked');
    appendLog(logs, 'error', state.pauseReason, row.rowNumber);
    await saveStateAndLogs(state, logs, {
      [STORAGE_KEYS.HISTORY]: history,
      [STORAGE_KEYS.ORDER_INDEX]: orderIndex
    });
    return { ok: false, error: state.pauseReason };
  }

  markRow(row, '正在提交订单（等待获取 Order ID）', 'processing');
  state.phase = 'WAIT_ORDER_SUCCESS';
  state.updatedAt = new Date().toISOString();
  appendLog(
    logs,
    'warning',
    `商品含税单价 €2.00、精准数量 ${verifiedQuantity} 和付款页收件人姓名均已核对通过；付款页面不再检查金额。只有成功获取 Order ID 后才计入当天下单记录。`,
    row.rowNumber
  );

  await chrome.storage.local.set({
    [STORAGE_KEYS.RUN_STATE]: state,
    [STORAGE_KEYS.HISTORY]: history,
    [STORAGE_KEYS.ORDER_INDEX]: orderIndex,
    [STORAGE_KEYS.LOGS]: logs
  });

  return { ok: true, state };
}

async function openCurrentRowInWorkTab(state, logs) {
  const row = getCurrentRow(state);
  if (!row) {
    return { completed: false, error: '找不到准备处理的数据行。' };
  }

  state.mode = 'transitioning';
  state.phase = 'TRANSITIONING';
  state.pauseReason = '';
  state.intervalEndsAt = null;
  state.intervalRemainingSeconds = 0;
  markRow(row, '准备打开下一条商品页面', 'processing');
  state.updatedAt = new Date().toISOString();
  appendLog(
    logs,
    'info',
    `第 ${row.rowNumber} 行：准备处理 Temu Order ID ${row.temuOrderId}，ASIN ${row.asin}，目标数量 ${row.requestedQuantity}。`,
    row.rowNumber
  );
  await saveStateAndLogs(state, logs);

  try {
    let tabExists = false;
    if (Number.isInteger(state.workTabId)) {
      try {
        await chrome.tabs.get(state.workTabId);
        tabExists = true;
      } catch {
        tabExists = false;
      }
    }

    if (tabExists) {
      await chrome.tabs.update(state.workTabId, { url: 'about:blank', active: true });
      await sleep(120);
    } else {
      state.workTabId = await acquireWorkTab(null);
      await saveStateAndLogs(state, logs);
    }

    state.mode = 'running';
    state.phase = 'WAIT_PRODUCT';
    state.pauseReason = '';
    markRow(row, '正在打开商品页面', 'processing');
    state.updatedAt = new Date().toISOString();
    await saveStateAndLogs(state, logs);
    await navigateWorkTab(state.workTabId, row.amzLink);
    return { completed: false };
  } catch (error) {
    state.mode = 'paused';
    state.pauseReason = `无法打开下一条商品页面：${error.message || String(error)}`;
    markRow(row, `等待人工检查：${state.pauseReason}`, 'blocked');
    appendLog(logs, 'error', state.pauseReason, row.rowNumber);
    await saveStateAndLogs(state, logs);
    return { completed: false, error: state.pauseReason };
  }
}

async function transitionToNextReady(state, logs, completedMessage, delaySeconds = 0) {
  const currentIndex = state.currentIndex;
  const nextIndex = findNextReadyIndex(state.rows, Number.isInteger(currentIndex) ? currentIndex : -1);

  if (nextIndex === -1) {
    await cancelIntervalWait(state.runId);
    state.mode = 'completed';
    state.phase = 'COMPLETED';
    state.pauseReason = '';
    state.currentIndex = null;
    state.intervalEndsAt = null;
    state.intervalRemainingSeconds = 0;
    state.updatedAt = new Date().toISOString();
    appendLog(logs, 'success', completedMessage || '所有有效数据行处理完成。');
    await saveStateAndLogs(state, logs);
    return { completed: true };
  }

  state.currentIndex = nextIndex;
  const nextRow = state.rows[nextIndex];
  const intervalSeconds = normalizeIntervalSeconds(delaySeconds, 0);

  if (intervalSeconds > 0) {
    state.mode = 'transitioning';
    state.phase = 'WAIT_INTERVAL';
    state.pauseReason = '';
    state.intervalEndsAt = new Date(Date.now() + intervalSeconds * 1000).toISOString();
    state.intervalRemainingSeconds = intervalSeconds;
    markRow(nextRow, `等待下单间隔（${intervalSeconds}秒）`, 'processing');
    state.updatedAt = new Date().toISOString();
    appendLog(
      logs,
      'info',
      `距离下一单还有 ${intervalSeconds} 秒；等待结束后处理第 ${nextRow.rowNumber} 行。`,
      nextRow.rowNumber
    );
    await saveStateAndLogs(state, logs);

    try {
      await scheduleIntervalWake(state, intervalSeconds * 1000);
      return { completed: false, waiting: true };
    } catch (error) {
      state.mode = 'paused';
      state.pauseReason = `无法安排下一单间隔：${error.message || String(error)}`;
      markRow(nextRow, `等待人工检查：${state.pauseReason}`, 'blocked');
      appendLog(logs, 'error', state.pauseReason, nextRow.rowNumber);
      await saveStateAndLogs(state, logs);
      return { completed: false, error: state.pauseReason };
    }
  }

  return openCurrentRowInWorkTab(state, logs);
}

async function resumeIntervalRun(runId) {
  const data = await getStoredData();
  const state = data[STORAGE_KEYS.RUN_STATE];
  const logs = Array.isArray(data[STORAGE_KEYS.LOGS]) ? data[STORAGE_KEYS.LOGS] : [];

  if (
    !state ||
    state.runId !== runId ||
    state.mode !== 'transitioning' ||
    state.phase !== 'WAIT_INTERVAL'
  ) {
    await cancelIntervalWait(runId);
    return { ok: false, stale: true };
  }

  const remainingMs = getIntervalRemainingMs(state);
  if (remainingMs > 500) {
    state.intervalRemainingSeconds = Math.ceil(remainingMs / 1000);
    await saveStateAndLogs(state, logs);
    await scheduleIntervalWake(state, remainingMs);
    return { ok: true, waiting: true };
  }

  await cancelIntervalWait(runId);
  state.intervalEndsAt = null;
  state.intervalRemainingSeconds = 0;
  const row = getCurrentRow(state);
  appendLog(logs, 'info', '下单间隔结束，开始处理下一单。', row?.rowNumber ?? null);
  await saveStateAndLogs(state, logs);
  await openCurrentRowInWorkTab(state, logs);
  return { ok: true };
}

async function skipCurrentRow(message, sender = null, manual = false) {
  const data = await getStoredData();
  const state = data[STORAGE_KEYS.RUN_STATE];
  const logs = Array.isArray(data[STORAGE_KEYS.LOGS]) ? data[STORAGE_KEYS.LOGS] : [];

  if (!state) {
    return { ok: false, error: '当前没有任务。' };
  }
  if (sender?.tab && sender.tab.id !== state.workTabId) {
    return { ok: false, stale: true };
  }
  if (message.runId && state.runId !== message.runId) {
    return { ok: false, stale: true };
  }
  if (message.expectedPhase && state.phase !== message.expectedPhase) {
    return { ok: false, stale: true };
  }

  const row = getCurrentRow(state);
  if (!row) {
    return { ok: false, error: '找不到当前数据行。' };
  }

  if (state.phase === 'WAIT_INTERVAL') {
    await cancelIntervalWait(state.runId);
    state.intervalEndsAt = null;
    state.intervalRemainingSeconds = 0;
  }

  const reason = message.reason || (manual ? '人工跳过' : '跳过');
  if (Number.isFinite(Number(message.observedUnitPrice))) {
    row.observedUnitPrice = Number(message.observedUnitPrice).toFixed(2);
  }
  if (Number.isSafeInteger(Number(message.selectedQuantity)) && Number(message.selectedQuantity) > 0) {
    row.selectedQuantity = Number(message.selectedQuantity);
  }

  const unresolved = POST_SUBMIT_PHASES.has(state.phase);
  const status = manual && unresolved ? `${reason}（订单结果未确认）` : reason;
  markRow(row, status, 'skipped');
  appendLog(logs, 'warning', status, row.rowNumber);

  await saveStateAndLogs(state, logs);
  await transitionToNextReady(state, logs, '所有有效数据行处理完成。', 0);
  return { ok: true };
}

async function recordOrderSuccess(message, sender) {
  const data = await getStoredData();
  const state = data[STORAGE_KEYS.RUN_STATE];
  const logs = Array.isArray(data[STORAGE_KEYS.LOGS]) ? data[STORAGE_KEYS.LOGS] : [];
  const history = sanitizeHistory(data[STORAGE_KEYS.HISTORY]);
  const orderIndex = buildOrderIndex(data[STORAGE_KEYS.ORDER_INDEX], history);

  if (!state || sender.tab?.id !== state.workTabId || state.runId !== message.runId) {
    return { ok: false, stale: true };
  }
  if (state.phase !== 'WAIT_ORDER_HISTORY') {
    return { ok: false, stale: true, error: `当前阶段不是订单核对阶段：${state.phase}` };
  }

  const row = getCurrentRow(state);
  if (!row) {
    return { ok: false, error: '找不到当前数据行。' };
  }

  const orderId = String(message.orderId ?? '').trim();
  if (!isValidOrderId(orderId)) {
    return { ok: false, error: 'Order ID 格式无效。' };
  }

  const now = new Date().toISOString();
  const dateKey = getBerlinDateKey();
  history.push({
    id: crypto.randomUUID(),
    runId: state.runId,
    rowNumber: row.rowNumber,
    dateKey,
    dedupeKey: row.dedupeKey,
    temuOrderId: row.temuOrderId,
    temuOrderIdKey: row.dedupeKey,
    asin: row.asin,
    normalizedName: row.normalizedName,
    shipAddress: row.shipAddress,
    address2: row.address2,
    shipCity: row.shipCity,
    shipPostalCode: row.shipPostalCode,
    phoneNumber: row.phoneNumber,
    status: 'ORDERED',
    orderId,
    observedUnitPrice: row.observedUnitPrice || '2.00',
    requestedQuantity: row.requestedQuantity,
    selectedQuantity: row.selectedQuantity || row.requestedQuantity,
    createdAt: now,
    updatedAt: now
  });
  if (history.length > MAX_HISTORY_ENTRIES) {
    history.splice(0, history.length - MAX_HISTORY_ENTRIES);
  }

  orderIndex[getOrderIndexStorageKey(row.dedupeKey)] = {
    temuOrderId: row.dedupeKey,
    status: 'ORDERED',
    orderId,
    dateKey,
    updatedAt: now
  };

  row.orderId = orderId;
  markRow(row, '下单成功', 'success');
  appendLog(logs, 'success', `下单成功，Order ID：${orderId}`, row.rowNumber);
  state.updatedAt = now;

  await chrome.storage.local.set({
    [STORAGE_KEYS.RUN_STATE]: state,
    [STORAGE_KEYS.HISTORY]: history,
    [STORAGE_KEYS.ORDER_INDEX]: orderIndex,
    [STORAGE_KEYS.LOGS]: logs
  });

  await transitionToNextReady(
    state,
    logs,
    '所有有效数据行处理完成。',
    normalizeIntervalSeconds(state.orderIntervalSeconds, DEFAULT_SETTINGS.orderIntervalSeconds)
  );
  return { ok: true, orderId };
}

async function pauseRunManually() {
  const data = await getStoredData();
  const state = data[STORAGE_KEYS.RUN_STATE];
  const logs = Array.isArray(data[STORAGE_KEYS.LOGS]) ? data[STORAGE_KEYS.LOGS] : [];

  if (!state || !ACTIVE_MODES.has(state.mode) || state.mode === 'paused') {
    return { ok: false, error: '当前任务不处于可暂停状态。' };
  }

  const row = getCurrentRow(state);
  if (state.phase === 'WAIT_INTERVAL') {
    const remainingMs = getIntervalRemainingMs(state);
    await cancelIntervalWait(state.runId);
    state.intervalEndsAt = null;
    state.intervalRemainingSeconds = Math.ceil(remainingMs / 1000);
  }

  state.mode = 'paused';
  state.pauseReason = '人工暂停';
  state.updatedAt = new Date().toISOString();
  if (row) {
    const intervalSuffix = state.phase === 'WAIT_INTERVAL'
      ? `（间隔剩余约 ${state.intervalRemainingSeconds} 秒）`
      : '';
    markRow(row, `已暂停：人工暂停${intervalSuffix}`, 'blocked');
  }
  appendLog(logs, 'warning', '任务已人工暂停。', row?.rowNumber ?? null);
  await saveStateAndLogs(state, logs);
  return { ok: true };
}

async function continueRun() {
  const data = await getStoredData();
  const state = data[STORAGE_KEYS.RUN_STATE];
  const logs = Array.isArray(data[STORAGE_KEYS.LOGS]) ? data[STORAGE_KEYS.LOGS] : [];

  if (!state || state.mode !== 'paused') {
    return { ok: false, error: '当前没有已暂停任务。' };
  }

  const row = getCurrentRow(state);

  if (state.phase === 'WAIT_INTERVAL') {
    const remainingMs = Math.max(0, Number(state.intervalRemainingSeconds || 0) * 1000);
    state.mode = 'transitioning';
    state.pauseReason = '';
    state.intervalEndsAt = new Date(Date.now() + remainingMs).toISOString();
    state.intervalRemainingSeconds = Math.ceil(remainingMs / 1000);
    state.updatedAt = new Date().toISOString();
    if (row) {
      markRow(row, `等待下单间隔（${state.intervalRemainingSeconds}秒）`, 'processing');
    }
    appendLog(logs, 'info', '任务继续执行，下单间隔计时恢复。', row?.rowNumber ?? null);
    await saveStateAndLogs(state, logs);

    if (remainingMs <= 0) {
      await resumeIntervalRun(state.runId);
    } else {
      await scheduleIntervalWake(state, remainingMs);
    }
    return { ok: true };
  }

  let tabExists = false;
  if (Number.isInteger(state.workTabId)) {
    try {
      await chrome.tabs.get(state.workTabId);
      tabExists = true;
    } catch {
      tabExists = false;
    }
  }

  if (!tabExists) {
    if (state.phase !== 'WAIT_PRODUCT' || !row?.amzLink) {
      return {
        ok: false,
        error: 'Amazon 工作标签页已关闭，当前阶段不能安全自动恢复。请人工检查后跳过当前行或停止任务。'
      };
    }
    state.workTabId = await acquireWorkTab(null);
  }

  state.mode = 'running';
  state.pauseReason = '';
  state.updatedAt = new Date().toISOString();
  if (row) {
    markRow(row, '继续执行当前步骤', 'processing');
  }
  appendLog(logs, 'info', '任务继续执行。', row?.rowNumber ?? null);
  await saveStateAndLogs(state, logs);

  if (!tabExists && state.phase === 'WAIT_PRODUCT' && row?.amzLink) {
    await navigateWorkTab(state.workTabId, row.amzLink);
  } else {
    await wakeWorkTab(state.workTabId);
  }
  return { ok: true };
}

async function stopRun() {
  const data = await getStoredData();
  const state = data[STORAGE_KEYS.RUN_STATE];
  const logs = Array.isArray(data[STORAGE_KEYS.LOGS]) ? data[STORAGE_KEYS.LOGS] : [];

  if (!state || !ACTIVE_MODES.has(state.mode)) {
    return { ok: false, error: '当前没有可停止的任务。' };
  }

  const row = getCurrentRow(state);
  const previousPhase = state.phase;
  if (previousPhase === 'WAIT_INTERVAL') {
    await cancelIntervalWait(state.runId);
  }

  state.mode = 'stopped';
  state.phase = 'STOPPED';
  state.pauseReason = '';
  state.intervalEndsAt = null;
  state.intervalRemainingSeconds = 0;
  state.updatedAt = new Date().toISOString();
  if (row && (row.result === 'processing' || row.result === 'blocked')) {
    markRow(row, POST_SUBMIT_PHASES.has(previousPhase) ? '已停止（订单结果未确认）' : '已停止', 'blocked');
  }
  appendLog(
    logs,
    'warning',
    POST_SUBMIT_PHASES.has(previousPhase)
      ? '任务已停止；当前订单结果仍未确认，且不会写入当天防重复记录。'
      : '任务已停止。',
    row?.rowNumber ?? null
  );
  await saveStateAndLogs(state, logs);
  return { ok: true };
}

async function appendPageLog(message, sender) {
  const data = await getStoredData();
  const state = data[STORAGE_KEYS.RUN_STATE];
  const logs = Array.isArray(data[STORAGE_KEYS.LOGS]) ? data[STORAGE_KEYS.LOGS] : [];

  if (!state || sender.tab?.id !== state.workTabId || state.runId !== message.runId) {
    return { ok: false, stale: true };
  }

  const row = getCurrentRow(state);
  appendLog(logs, message.level || 'info', String(message.message || ''), row?.rowNumber ?? null);
  await chrome.storage.local.set({ [STORAGE_KEYS.LOGS]: logs });
  return { ok: true };
}

async function saveDraftRows(rows) {
  const data = await chrome.storage.local.get(STORAGE_KEYS.RUN_STATE);
  const state = data[STORAGE_KEYS.RUN_STATE];
  if (state && ACTIVE_MODES.has(state.mode)) {
    return { ok: false, error: '任务运行期间不能修改输入数据。' };
  }
  await chrome.storage.local.set({
    [STORAGE_KEYS.DRAFT_ROWS]: Array.isArray(rows) ? rows : []
  });
  return { ok: true };
}

async function clearDraftRows() {
  const data = await chrome.storage.local.get(STORAGE_KEYS.RUN_STATE);
  const state = data[STORAGE_KEYS.RUN_STATE];
  if (state && ACTIVE_MODES.has(state.mode)) {
    return { ok: false, error: '任务运行期间不能清空输入数据。' };
  }
  await chrome.storage.local.set({
    [STORAGE_KEYS.DRAFT_ROWS]: [],
    [STORAGE_KEYS.RUN_STATE]: null
  });
  return { ok: true };
}

async function clearLogs() {
  await chrome.storage.local.set({ [STORAGE_KEYS.LOGS]: [] });
  return { ok: true };
}

async function saveSettings(rawSettings) {
  const data = await chrome.storage.local.get([STORAGE_KEYS.RUN_STATE, STORAGE_KEYS.SETTINGS]);
  const state = data[STORAGE_KEYS.RUN_STATE];
  if (state && ACTIVE_MODES.has(state.mode)) {
    return { ok: false, error: '任务运行期间不能修改每单间隔。' };
  }

  const rawInterval = rawSettings?.orderIntervalSeconds;
  const numericInterval = Number(rawInterval);
  if (!Number.isInteger(numericInterval) || numericInterval < 0 || numericInterval > 3600) {
    return { ok: false, error: '每单间隔必须是 0–3600 的整数。' };
  }

  const settings = { orderIntervalSeconds: numericInterval };
  await chrome.storage.local.set({ [STORAGE_KEYS.SETTINGS]: settings });
  return { ok: true, settings };
}

async function clearTodayOrderRecords() {
  const data = await getStoredData();
  const state = data[STORAGE_KEYS.RUN_STATE];
  if (state && ACTIVE_MODES.has(state.mode)) {
    return { ok: false, error: '任务运行期间不能清空当天下单记录。' };
  }

  const today = getBerlinDateKey();
  const logs = Array.isArray(data[STORAGE_KEYS.LOGS]) ? data[STORAGE_KEYS.LOGS] : [];
  const history = sanitizeHistory(data[STORAGE_KEYS.HISTORY]);
  const orderIndex = buildOrderIndex(data[STORAGE_KEYS.ORDER_INDEX], history);
  const removedTemuIds = new Set();

  for (const [key, record] of Object.entries(orderIndex)) {
    if (record?.status === 'ORDERED' && record.dateKey === today && isValidOrderId(record.orderId)) {
      removedTemuIds.add(normalizeTemuOrderId(record.temuOrderId));
      delete orderIndex[key];
    }
  }

  const remainingHistory = history.filter((record) => {
    const shouldRemove =
      record.status === 'ORDERED' &&
      record.dateKey === today &&
      isValidOrderId(record.orderId);
    if (shouldRemove) {
      removedTemuIds.add(normalizeTemuOrderId(record.temuOrderIdKey || record.temuOrderId));
    }
    return !shouldRemove;
  });

  appendLog(logs, 'warning', `已清空 ${removedTemuIds.size} 条 ${today} 的成功下单防重复记录。`);
  await chrome.storage.local.set({
    [STORAGE_KEYS.HISTORY]: remainingHistory,
    [STORAGE_KEYS.ORDER_INDEX]: orderIndex,
    [STORAGE_KEYS.LOGS]: logs
  });
  return { ok: true, clearedCount: removedTemuIds.size, dateKey: today };
}

async function recoverIntervalState() {
  const data = await getStoredData();
  const state = data[STORAGE_KEYS.RUN_STATE];
  if (!state || state.mode !== 'transitioning' || state.phase !== 'WAIT_INTERVAL' || !state.runId) {
    return { ok: false, stale: true };
  }

  const remainingMs = getIntervalRemainingMs(state);
  if (remainingMs <= 0) {
    return resumeIntervalRun(state.runId);
  }
  await scheduleIntervalWake(state, remainingMs);
  return { ok: true, waiting: true };
}

async function handleGetContext(sender) {
  const data = await chrome.storage.local.get(STORAGE_KEYS.RUN_STATE);
  const state = data[STORAGE_KEYS.RUN_STATE] || null;
  const isWorkTab = Boolean(state && sender.tab?.id === state.workTabId);
  return {
    ok: true,
    isWorkTab,
    state,
    row: isWorkTab ? getCurrentRow(state) : null
  };
}

chrome.action.onClicked.addListener(() => {
  openOrFocusPanel().catch((error) => console.error('Unable to open panel:', error));
});

chrome.runtime.onInstalled.addListener(() => {
  enqueueMutation(async () => {
    const data = await getStoredData();
    const history = sanitizeHistory(data[STORAGE_KEYS.HISTORY]);
    const orderIndex = buildOrderIndex(data[STORAGE_KEYS.ORDER_INDEX], history);
    const logs = Array.isArray(data[STORAGE_KEYS.LOGS]) ? data[STORAGE_KEYS.LOGS] : [];
    const settings = normalizeSettings(data[STORAGE_KEYS.SETTINGS]);
    let draftRows = Array.isArray(data[STORAGE_KEYS.DRAFT_ROWS])
      ? data[STORAGE_KEYS.DRAFT_ROWS]
      : [];
    let state = data[STORAGE_KEYS.RUN_STATE] || null;

    const hasLegacyEightColumnDraft = draftRows.some((row) => {
      if (!row || typeof row !== 'object' || Object.prototype.hasOwnProperty.call(row, 'address2')) {
        return false;
      }
      return Object.values(row).some((value) => String(value ?? '').trim() !== '');
    });
    if (hasLegacyEightColumnDraft) {
      draftRows = [];
      appendLog(
        logs,
        'warning',
        '升级到 v1.4.0 后已清空旧版八列输入草稿；请按九列格式重新粘贴，address2 为空时也必须保留空列。'
      );
    }

    // Do not continue an active task created by an older workflow. v1.4.0 adds
    // the address2 field and a conditional payment-card/address-change branch.
    if (state && ACTIVE_MODES.has(state.mode) && Number(state.version || 0) < 5) {
      const row = getCurrentRow(state);
      if (row) {
        markRow(row, '升级后任务已停止，请人工检查当前 Amazon 页面', 'blocked');
      }
      state = {
        ...state,
        version: 5,
        mode: 'stopped',
        phase: 'STOPPED',
        pauseReason: '',
        intervalEndsAt: null,
        intervalRemainingSeconds: 0,
        updatedAt: new Date().toISOString()
      };
      appendLog(logs, 'warning', '升级到 v1.4.0 后已停止旧版未结束任务，请人工确认是否已产生订单。');
    }

    // v1.1 could pause before a run because of a SUBMITTING safety record.
    // Later versions intentionally remove that lock when no Amazon Order ID exists.
    if (state?.phase === 'PRECHECK_PENDING') {
      const row = getCurrentRow(state);
      if (row) {
        markRow(row, '旧版未确认记录已清除，任务已停止', 'skipped');
      }
      state = {
        ...state,
        version: 5,
        mode: 'stopped',
        phase: 'STOPPED',
        pauseReason: '',
        intervalEndsAt: null,
        intervalRemainingSeconds: 0,
        updatedAt: new Date().toISOString()
      };
      appendLog(logs, 'warning', '升级后已清除旧版未确认下单锁。');
    }

    await chrome.storage.local.set({
      [STORAGE_KEYS.RUN_STATE]: state,
      [STORAGE_KEYS.HISTORY]: history,
      [STORAGE_KEYS.ORDER_INDEX]: orderIndex,
      [STORAGE_KEYS.LOGS]: logs,
      [STORAGE_KEYS.DRAFT_ROWS]: draftRows,
      [STORAGE_KEYS.SETTINGS]: settings
    });

    if (state?.mode === 'transitioning' && state.phase === 'WAIT_INTERVAL') {
      await recoverIntervalState();
    }
  }).catch((error) => console.error(error));
});

chrome.runtime.onStartup.addListener(() => {
  enqueueMutation(recoverIntervalState).catch((error) => console.error(error));
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (!alarm?.name?.startsWith(INTERVAL_ALARM_PREFIX)) {
    return;
  }
  const runId = alarm.name.slice(INTERVAL_ALARM_PREFIX.length);
  enqueueMutation(() => resumeIntervalRun(runId)).catch((error) => console.error(error));
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const respond = (promise) => {
    promise
      .then((result) => sendResponse(result))
      .catch((error) => {
        console.error(error);
        sendResponse({ ok: false, error: error.message || String(error) });
      });
  };

  switch (message?.type) {
    case 'GET_CONTEXT':
      respond(handleGetContext(sender));
      return true;
    case 'GET_ALL_DATA':
      respond(getStoredData().then((data) => ({ ok: true, data })));
      return true;
    case 'START_RUN':
      respond(enqueueMutation(() => startRun(message.rows, message.orderIntervalSeconds, message.startPassword)));
      return true;
    case 'SAVE_DRAFT_ROWS':
      respond(enqueueMutation(() => saveDraftRows(message.rows)));
      return true;
    case 'CLEAR_DRAFT_ROWS':
      respond(enqueueMutation(clearDraftRows));
      return true;
    case 'CLEAR_LOGS':
      respond(enqueueMutation(clearLogs));
      return true;
    case 'SAVE_SETTINGS':
      respond(enqueueMutation(() => saveSettings(message.settings)));
      return true;
    case 'CLEAR_TODAY_ORDER_RECORDS':
      respond(enqueueMutation(clearTodayOrderRecords));
      return true;
    case 'SET_PHASE':
      respond(enqueueMutation(() => transitionPhase(message, sender)));
      return true;
    case 'PAUSE_ERROR':
      respond(enqueueMutation(() => pauseForError(message, sender)));
      return true;
    case 'BEFORE_FINAL_SUBMIT':
      respond(enqueueMutation(() => prepareFinalSubmission(message, sender)));
      return true;
    case 'PAGE_LOG':
      respond(enqueueMutation(() => appendPageLog(message, sender)));
      return true;
    case 'SKIP_ROW':
      respond(enqueueMutation(() => skipCurrentRow(message, sender, false)));
      return true;
    case 'ORDER_SUCCESS':
      respond(enqueueMutation(() => recordOrderSuccess(message, sender)));
      return true;
    case 'PAUSE_RUN':
      respond(enqueueMutation(pauseRunManually));
      return true;
    case 'CONTINUE_RUN':
      respond(enqueueMutation(continueRun));
      return true;
    case 'STOP_RUN':
      respond(enqueueMutation(stopRun));
      return true;
    case 'SKIP_CURRENT_MANUAL':
      respond(enqueueMutation(() => skipCurrentRow({ reason: '人工跳过' }, null, true)));
      return true;
    case 'OPEN_WORK_TAB':
      respond(
        chrome.storage.local
          .get(STORAGE_KEYS.RUN_STATE)
          .then((data) => focusWorkTab(data[STORAGE_KEYS.RUN_STATE]?.workTabId))
          .then(() => ({ ok: true }))
      );
      return true;
    default:
      return false;
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  enqueueMutation(async () => {
    const data = await getStoredData();
    const state = data[STORAGE_KEYS.RUN_STATE];
    if (!state || tabId !== state.workTabId || !ACTIVE_MODES.has(state.mode)) {
      return;
    }

    const logs = Array.isArray(data[STORAGE_KEYS.LOGS]) ? data[STORAGE_KEYS.LOGS] : [];
    const row = getCurrentRow(state);
    state.workTabId = null;
    state.updatedAt = new Date().toISOString();

    if (state.phase === 'WAIT_INTERVAL' && state.mode === 'transitioning') {
      appendLog(logs, 'warning', '等待间隔期间 Amazon 工作标签页被关闭；间隔结束后将自动创建新标签页。', row?.rowNumber ?? null);
      await saveStateAndLogs(state, logs);
      return;
    }

    state.mode = 'paused';
    state.pauseReason = 'Amazon 工作标签页已被关闭。';
    if (row) {
      markRow(row, `等待人工检查：${state.pauseReason}`, 'blocked');
    }
    appendLog(logs, 'error', state.pauseReason, row?.rowNumber ?? null);
    await saveStateAndLogs(state, logs);
  }).catch((error) => console.error(error));
});
