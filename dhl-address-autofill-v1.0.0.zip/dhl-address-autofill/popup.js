const $ = (id) => document.querySelector(`#${id}`);
const fields = ['orderId', 'fullName', 'street', 'houseNumber', 'postcode', 'town', 'country'];
const labels = {
  orderId: ['shipment reference', 'customer reference', 'print on label', 'order id', 'order number', '订单号', '参考号'],
  fullName: ['first and family name', 'full name', 'recipient', 'consignee', 'name', '姓名', '收件人'],
  street: ['street', 'street name', 'straße', 'strasse', '街道'],
  houseNumber: ['no.', 'number', 'house number', 'hausnummer', '门牌号', '号码'],
  postcode: ['postcode', 'postal code', 'zip code', 'plz', '邮编'],
  town: ['town', 'city', 'locality', 'ort', '城市'],
  email: ["customer's email", 'customer email', 'email', 'e-mail', '邮箱']
};

const clean = (value) => value.replace(/^[\s:：,;-]+|[\s,;]+$/g, '').trim();
const normalize = (value) => (value || '').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
const getLabelValue = (line, keys) => {
  const escaped = keys.map((key) => key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
  const hit = line.match(new RegExp(`^(?:${escaped})\\s*[:：-]\\s*(.+)$`, 'i'));
  return hit ? clean(hit[1]) : '';
};

function parseAddress(source) {
  const lines = source.split(/\r?\n/).map(clean).filter(Boolean);
  const data = { orderId: '', fullName: '', street: '', houseNumber: '', postcode: '', town: '', country: 'Germany' };
  const aliases = {
    orderId: ['order id', 'order number', 'shipment reference', 'customer reference', '订单号'],
    fullName: ['name', 'recipient', 'consignee', '姓名', '收件人'],
    street: ['street', 'address', 'straße', 'strasse', '街道', '地址'],
    houseNumber: ['no.', 'number', 'house number', 'hausnummer', '门牌号'],
    postcode: ['postcode', 'postal code', 'zip', 'plz', '邮编'],
    town: ['town', 'city', 'ort', '城市'],
    country: ['country', '国家']
  };
  for (const line of lines) for (const [field, keys] of Object.entries(aliases)) if (!data[field] || field === 'country') {
    const value = getLabelValue(line, keys);
    if (value) data[field] = value;
  }
  const order = source.match(/\b\d{3}-\d{7}-\d{7}\b/);
  if (!data.orderId && order) data.orderId = order[0];
  if (/\b(austria|österreich|osterreich|at)\b/i.test(source)) data.country = 'Austria';
  if (/\b(germany|deutschland|de)\b/i.test(source)) data.country = 'Germany';
  const postcodeLine = lines.find((line) => /\b(?:AT-?)?\d{4,5}\b/.test(line));
  if (postcodeLine) {
    const postcode = postcodeLine.match(/\b(?:AT-?)?(\d{4,5})\b/i);
    if (!data.postcode && postcode) data.postcode = postcode[1];
    if (!data.town && postcode) data.town = clean(postcodeLine.replace(postcode[0], ''));
  }
  const ignored = /^(?:order|shipment|customer|name|recipient|consignee|street|address|postcode|postal|zip|plz|town|city|country|订单|姓名|收件|地址|邮编|城市|国家)\b/i;
  const candidates = lines.filter((line) => !ignored.test(line) && !/\b\d{3}-\d{7}-\d{7}\b/.test(line) && line !== postcodeLine && !/^(germany|deutschland|austria|österreich|osterreich)$/i.test(line));
  if (!data.fullName && candidates.length) data.fullName = candidates[0];
  const address = data.street || candidates.slice(1).find((line) => /\d/.test(line)) || '';
  if (address) {
    const hit = address.match(/^(.*?)[,\s]+(\d+[\w\/-]*)$/u);
    data.street = data.street || clean(hit ? hit[1] : address);
    if (!data.houseNumber && hit) data.houseNumber = hit[2];
  }
  data.country = /austria|österreich|osterreich/i.test(data.country) ? 'Austria' : 'Germany';
  return data;
}

function status(message, error = false) { $('status').textContent = message; $('status').classList.toggle('error', error); }
chrome.storage.local.get({ dhlEmail: '' }, ({ dhlEmail }) => { $('email').value = dhlEmail; });
$('email').addEventListener('change', () => chrome.storage.local.set({ dhlEmail: $('email').value.trim() }));

$('parse').addEventListener('click', () => {
  if (!$('source').value.trim()) return status('请先粘贴订单与地址信息。', true);
  const data = parseAddress($('source').value);
  fields.forEach((field) => { $(field).value = data[field]; });
  $('result').hidden = false;
  status(data.orderId ? '请核对解析结果后填入页面。' : '未识别订单号；请手动补充后填入。', !data.orderId);
});

$('fill').addEventListener('click', async () => {
  const data = Object.fromEntries(fields.map((field) => [field, $(field).value.trim()]));
  data.email = $('email').value.trim();
  if (!data.orderId || !data.fullName || !data.postcode || !data.town || !data.street || !data.houseNumber) return status('请补全订单号、姓名、街道、门牌号、邮编和城市。', true);
  chrome.storage.local.set({ dhlEmail: data.email });
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const [{ result: report }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: fillDhl, args: [data, labels] });
    status(report.filled ? `已填入 ${report.filled} 个字段${report.country ? '，并选择国家。' : '。'}` : '未找到 DHL 表单字段。', !report.filled);
  } catch { status('无法在此页面填充；请先打开 DHL 的可编辑表单。', true); }
});

async function fillDhl(data, fieldLabels) {
  const normalize = (value) => (value || '').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
  const descriptor = (el) => normalize([el.name, el.id, el.autocomplete, el.placeholder, el.getAttribute('aria-label'), el.labels?.[0]?.innerText, el.closest('label')?.innerText, el.parentElement?.innerText].join(' '));
  const setValue = (input, value) => {
    const proto = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(input, value);
    input.dispatchEvent(new Event('input', { bubbles: true })); input.dispatchEvent(new Event('change', { bubbles: true }));
  };
  let country = false;
  const wanted = data.country === 'Austria' ? ['austria', 'österreich', 'osterreich', 'at'] : ['germany', 'deutschland', 'de'];
  const countryControls = [...document.querySelectorAll('input[type="checkbox"], input[type="radio"], select')];
  for (const control of countryControls) {
    const text = normalize([descriptor(control), control.value, control.closest('label')?.innerText].join(' '));
    if (control.tagName === 'SELECT' && /country|land|国家/.test(text)) {
      const option = [...control.options].find((o) => wanted.some((word) => normalize([o.text, o.value].join(' ')).includes(word)));
      if (option) { control.value = option.value; control.dispatchEvent(new Event('change', { bubbles: true })); country = true; break; }
    }
    if (wanted.some((word) => text.includes(word))) { if (!control.checked) control.click(); country = true; break; }
  }
  if (country) await new Promise((resolve) => setTimeout(resolve, 250));
  const inputs = [...document.querySelectorAll('input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="submit"]), textarea')].filter((el) => !el.disabled && !el.readOnly);
  let filled = 0;
  for (const [field, value] of Object.entries(data)) {
    if (!value || field === 'country') continue;
    const targets = field === 'orderId'
      ? inputs.filter((input) => fieldLabels.orderId.some((word) => descriptor(input).includes(normalize(word))))
      : inputs.filter((input) => fieldLabels[field].some((word) => descriptor(input).includes(normalize(word)))).slice(0, 1);
    for (const input of targets) { setValue(input, value); filled += 1; }
  }
  return { filled, country };
}
