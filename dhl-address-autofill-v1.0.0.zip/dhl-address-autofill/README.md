# DHL 地址自动填充 Chrome 扩展

本扩展在本机解析粘贴的订单和地址信息，再填写当前 DHL 表单；不请求网络权限，也不上传信息。

## 安装

1. 在 Chrome 打开 `chrome://extensions`，开启“开发者模式”。
2. 选择“加载已解压的扩展程序”。
3. 选择本文件夹 `dhl-address-autofill`。

## 使用

1. 打开 DHL 创建运单的页面。
2. 点击扩展，首次在“固定收件邮箱”填写你的邮箱（只保存于此浏览器）。
3. 粘贴订单号和地址，点击“解析信息”，确认字段。
4. 点击“填入当前 DHL 页面”。

支持 `303-0450381-4649911` 格式的亚马逊订单号。它会同时填入 **SHIPMENT REFERENCE** 与 **CUSTOMER REFERENCE / PRINT ON LABEL**。未包含国家时默认 Germany；文本出现 Austria、Österreich 或 Österreich 时会选 Austria，再填写因国家切换而显示的字段。
