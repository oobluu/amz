const _0x2c471f5f8a=[[241,253,254,254,247,241,230,253,224,193,230,243,230,247],[250,230,230,226,225,168,189,189,225,247,254,254,247,224,191,247,231,188,230,247,255,231,188,241,253,255,189,224,247,230,231,224,252,191,224,247,244,231,252,246,191,254,251,225,230,188,250,230,255,254,173,205,234,205,225,247,225,225,252,205,251,246,175,234,160,226,161,227,228,161,231,235,231,180,224,247,244,247,224,205,226,243,245,247,205,252,243,255,247,175,192,247,230,231,224,252,183,160,162,224,247,226,253,224,230,225,180,224,247,244,247,224,205,226,243,245,247,205,251,246,175,160,160,160,163,167,205,163,165,170,161,164,164,166,165,171,161,163,163,166,205,249,228,243,227,227,162,254,232,254,226,180,224,247,244,247,224,205,226,243,245,247,205,225,252,175,160,160,160,163,167,180,226,243,245,247,220,231,255,240,247,224,175,163,180,226,243,245,247,193,251,232,247,175,163,162,180,224,247,243,225,253,252,209,253,246,247,222,251,225,230,175,162,180,245,224,253,231,226,193,247,243,224,241,250,198,235,226,247,175,163,162,162,162,162,163,180,230,251,255,247,193,247,243,224,241,250,198,235,226,247,175,163,162,162,163,162,162,180,225,247,243,224,241,250,198,247,234,230,198,235,226,247,175,163,180,225,247,243,224,241,250,198,247,234,230,175,180,241,253,255,226,254,247,230,247,246,193,247,243,224,241,250,198,235,226,247,175,163,162,162,166,162,160,180,226,224,253,230,247,241,230,247,246,208,235,194,254,243,230,244,253,224,255,193,247,243,224,241,250,198,235,226,247,175,163,162,162,165,162,163],[250,230,230,226,225,168,189,189,225,247,254,254,247,224,191,247,231,188,230,247,255,231,188,241,253,255,189,253,224,246,247,224,191,246,247,230,243,251,254,188,250,230,255,254,173,226,243,224,247,252,230,205,253,224,246,247,224,205,225,252,175],[180,205,234,205,225,247,225,225,252,205,251,246,175,234,160,226,161,227,228,161,231,235,231,180,224,247,244,247,224,205,226,243,245,247,205,252,243,255,247,175,224,247,230,231,224,252,191,224,247,244,231,252,246,191,254,251,225,230,180,224,247,244,247,224,205,226,243,245,247,205,251,246,175,160,162,161,170,167,205,163,165,170,164,166,162,171,166,165,162,165,163,162,205,250,244,240,170,232,232,170,167,248,163,180,224,247,244,247,224,205,226,243,245,247,205,225,252,175,160,162,161,170,167],[250,230,230,226,225,168,189,189,243,252,243,252,191,163,160,167,171,162,171,167,170,170,161,188,241,253,225,188,247,231,191,244,224,243,252,249,244,231,224,230,188,255,235,227,241,254,253,231,246,188,241,253,255,189,163,189,254,243,240,247,254,188,250,230,255,254],[253,226,247,252,251,252,245,191,254,251,225,230],[241,253,252,244,251,245,231,224,251,252,245,191,254,251,225,230],[241,253,254,254,247,241,230,251,252,245,191,254,251,225,230],[226,224,253,241,247,225,225,251,252,245,191,246,247,230,243,251,254,225],[226,243,231,225,247,191,226,247,252,246,251,252,245],[228,243,254,251,246,243,230,251,252,245],[251,246,254,247],[8326],[246,243,230,247],[226,247,252,246,251,252,245],[194,247,252,246,251,252,245],[220,253],[253,240,248,247,241,230],[251,252,244,253],[],[252,253,224,255,243,254],[226,253,226,231,226],[23904,22458,30332,26773,28125,35162,22266,31237,21361,28498,28073,178,198,215,223,199,178,37010,36277,21125,35066,26773,31724,39143,12432],[229,243,224,252,251,252,245],[250,230,230,226,225,168,189,189,225,247,254,254,247,224,191,247,231,188,230,247,255,231,188,241,253,255,189,253,224,246,247,224,191,246,247,230,243,251,254,188,250,230,255,254,173],[25970,26074,30230,35632,21447,35700,24663,37996,25399],[30332,26773,26773,31724,39143,20127,23498,22458],[241,253,255,226,254,247,230,247],[30332,26773,26773,31724,39143,22458,21042,36847,36693,31385,20159,34873,20961,38271],[39143,38896,21042,36847,36119,25956],[226,243,252,247,254,188,250,230,255,254],[205],[223,199,222,198,219,205,193,217,199,205,209,211,192,214],[222,219,193,198,205,194,211,213,215,205,193,215,198,199,194,205,221,192,205,209,221,222,222,215,209,198,219,221,220,205,212,211,219,222,215,214],[199,220,217,220,221,197,220,205,211,220,221,223,211,222,203],[225,243,228,247,246],[191],[218,198,223,222,178,193,211,223,194,222,215,168],[186,220,253,178,218,198,223,222,178,229,243,225,178,243,228,243,251,254,243,240,254,247,188,187],[159,152],[231,252,251,227,231,251,244,235],[247,224,224,253,224],[24513,21215,30174,38896,23904,38291,23304],[25337,25437,20073,21043,27633,22458,36674,35038],[226,243,231,225,247,246],[35689,21316,35632,21447,35700,24663],[32373,32383,25337,25437,26552,23326,25218,30230,35632,21447,35700,24663,12432],[27633,22458,23326,25218,25337,25437],[35632,21447,35700,24663,23904,20986,36986,22934,29844,65438,32373,32383,23326,25218,25337,25437,12432],[25281,24466,37010,36277,21125,35066],[24466,22873,25890,30230,25337,25437,20073,21043,12432],[23904,25281,24466,24292,21141,25584,21154,178,198,215,223,199,178,37010,36277,21125,35066,39143,38896,12432],[24513,21215,27699,26523,21373,26128,20686,30230,25337,25437,20073,21043],[23326,25218,21125,35066,37205,38484,21660,26128,20686],[23326,25218,24513,21215,27639,39478,21660,26128,20686],[23904,26020,21154,26128,20686,35685,27856,65438,23700,22458,24513,21215,21125,35066,37205,38484,23326,25218,21660,26128,20686,12432],[23904,26020,21154,26128,20686,35685,27856,65438,23700,22458,24513,21215,35632,21447,22934,29844,23326,25218,21660,26128,20686,12432],[25337,25437,36674,35038,26509,38246,20127,32879,28311,31464,35618,24519],[243,231,230,250,191,254,253,241,249,247,246],[20073,21043,24464,24234,20686,27632],[37215,25890,25281,24466,37010,36277,21125,35066],[37010,36277,21125,35066,26773,31724,39143,20127,23498,22458,65438,23904,37215,25890,25281,24466,12432],[250,230,230,226,225,168,189,189,225,247,254,254,247,224,191,247,231,188,230,247,255,231,188,241,253,255,189,224,247,230,231,224,252,191,224,247,244,231,252,246,191,254,251,225,230,188,250,230,255,254],[35628,32764,31689,37019,12435,25344,24093,21534,27485,39143,26082,37213],[222,219,193,198,205,193,209,192,219,194,198,205,220,221,205,219,220,216,215,209,198,219,221,220,205,192,215,193,199,222,198],[225,230,253,226],[21125,35066,39143,27770,20983,20847,26082,27699,26523,36678,22092,178,219,252,248,247,241,230,251,253,252,192,247,225,231,254,230,65438,20073,21043,23904,20686,27632,20087,37101,20959,25970,24989,20187,21157,25890,12432],[241,250,224,253,255,247,188,225,241,224,251,226,230,251,252,245,188,247,234,247,241,231,230,247,193,241,224,251,226,230,178,26552,36678,22092,20073,20423,178,219,252,248,247,241,230,251,253,252,192,247,225,231,254,230,12432],[254,253,243,246,251,252,245],[222,219,193,198,205,194,211,213,215,205,220,211,196,219,213,211,198,215,214,205,214,199,192,219,220,213,205,193,215,198,199,194],[225,243,255,247,191,226,243,245,247],[21125,35066,39143,22458,26214,25890,35628,32764,25956,21315,30093,39143,38896,23406,33464,65438,23700,31707,24343,24513,21215,39143,38896,23326,25218,21660,32373,32383,65438,20127,20137,21050,21157,25890,12432],[222,219,193,198,205,193,209,192,219,194,198,205,220,221,205,192,215,198,199,192,220,205,196,211,222,199,215],[21125,35066,39143,27770,20983,20847,26082,26552,36678,22092,32321,26382,65438,21373,32879,21315,30093,39143,38896,33160,26558,36674,35038,24464,24234,65417,20073,21043,23904,20686,27632,65438,20127,20767,21157,25890,37215,35655,12432],[27770,20983,20847,26082,36678,22092,20654,20136,31464,65438,20102,26552,26706,28121,21154,39143,38896,23406,33464,12432,24234,35155,21261,22130,21399,25214,36674,35038,25956,24464,24234,25220,20847,26082,23498,22458,22916,36986,20239,36292,12432],[222,219,193,198,205,194,211,213,215,205,211,194,194,205,220,221,198,205,192,215,211,214,203],[222,219,193,198,205,193,209,192,219,194,198,205,219,220,216,215,209,198,219,221,220,205,212,211,219,222,215,214],[224,247,254,253,243,246],[21125,35066,33160,26558,26552,36678,22092,21373,35668,21177,32321,26382],[39143,38896,24070,30138,26552,27633,24234,21042,36847,65438,23700,21157,25890,21660,37215,35655],[23700,22458,24513,21215,39143,38896,37215,25890,26487,35696,23308,25956,178,214,221,223,178,24292,37215,35655,65438,20127,21157,25890,39143,38896],[21125,35066,37205,38484,22947,36279],[215,192,192,221,192],[211,254,254,178,226,247,252,246,251,252,245,178,243,241,230,251,253,252,178,23904,30972,35638,65416,197,243,251,230,251,252,245,178,230,253,178,231,226,254,253,243,246,178,224,247,230,231,224,252,178,254,243,240,247,254,12432],[25344,24093,25899,24477,23904,30972,35638,65416,193,253,224,230,178,240,235,178,225,250,253,224,230,247,225,230,178,224,247,255,243,251,252,251,252,245,178,226,224,253,241,247,225,225,251,252,245,178,230,251,255,247,178,186,224,247,227,231,247,225,230,225,178,229,251,230,250,178,224,247,255,243,251,252,251,252,245,178,226,224,253,241,247,225,225,251,252,245,178,230,251,255,247,178,253,252,254,235,187,12432],[27485,39143,26284,31144,26082,37213,23904,30972,35638,65416,163,162,162,12432],[225,231,241,241,247,225,225],[23904,26128,20686],[23904,22458,35632,21447,35700,24663,38564,27431,24466,22873,21215,26128,20686,12432],[21125,35066,21491,29397,37205,38484,23326,25218,65438,23904,20961,38271,21125,35066,39143,24292,36678,22092,25408,20068,31237,21361,12432],[21125,35066,21491,29397,37205,38484,23326,25218,65438,23904,20961,38271,21125,35066,39143,12432],[25337,25437,23904,26128,20686,12432],[25298,26523,35632,21447,35700,24663,23904,35689,21316,23326,25218,12432],[214,215,198,211,219,222,205,193,209,192,219,194,198,205,221,192,205,222,221,211,214,205,212,211,219,222,215,214],[26552,30583,38283,35709],[178,238,178],[246,253,252,247],[24513,21215,35632,21447,23904,22934,29844,23326,25218,65438,25337,25437,29474,23904,26128,20686,12432],[213,215,198],[252,253,191,225,230,253,224,247],[244,253,254,254,253,229],[253,255,251,230],[241,253,255,226,254,247,230,247,246],[25337,25437,23326,25218],[25337,25437,20073,21043,23904,23326,25218,12432],[23904,38291,23304],[194,211,220,215,222,205,192,215,211,214,203],[193,198,211,192,198,205,193,209,211,220],[194,211,199,193,215,205,193,209,211,220],[209,222,215,211,192,205,192,215,209,221,192,214,193],[215,220,213,219,220,215,205,217,219,209,217],[211,199,198,218,205,192,215,209,218,215,209,217],[209,222,221,193,215,205,194,211,220,215,222],[221,194,215,220,205,214,215,198,211,219,222,205,222,219,220,217],[26552,30583,25695,20430],[37010,36277,21125,35066,26773,31724,39143,34873,20961,38271,65438,23700,33144,21050,37215,25890,25281,24466,12432],[35632,21447,35700,24663,26773,31724,39143,34873,20961,38271,65438,23700,33144,21050,37215,25890,25281,24466,24513,21215,35632,21447,12432],[23927,20965,31237,21361,23904,20961,38271,65438,23700,22458,21125,35066,37205,38484,23326,25218,21660,26128,20686,12432],[23927,20965,31237,21361,23904,20961,38271,65438,23700,22458,24513,21215,35632,21447,22934,29844,23326,25218,21660,26128,20686,12432]];const _0x9f515ee8ec=(_0xb57557df)=>String.fromCharCode(..._0x2c471f5f8a[_0xb57557df].map((_0x0e258ede)=>_0x0e258ede^146));const _0xd4b2b9cc69 = _0x9f515ee8ec(0);
const _0x56d2a35a7c = _0x9f515ee8ec(1);
const _0xcf2ab61221 = _0x9f515ee8ec(2);
const _0x34fcb35bd1 = _0x9f515ee8ec(3);
const _0x659e6e0974 = _0x9f515ee8ec(4);
const _0x9f31c16ffa = 8 * 60 * 60 * 1000;
const _0x514f16fddf = 10 * 1000;
const _0x91aee3b5c7 = 1200;
const _0x7921e04efc = 160000;
const _0x2b73cce789 = new Set([
    _0x9f515ee8ec(5),
    _0x9f515ee8ec(6),
    _0x9f515ee8ec(7),
    _0x9f515ee8ec(8),
    _0x9f515ee8ec(9),
    _0x9f515ee8ec(10)
]);
let _0xdaacf787b6 = Promise.resolve();
let _0xc3bc946c63 = false;
let _0x02614f1d06 = false;
let _0xfe9ea732aa = false;
const _0xa0b5739dfe = 3;
function _0x660128c054() {
    return {
        schemaVersion: 3,
        panelWindowId: null,
        sourceWindowId: null,
        listWindowId: null,
        status: _0x9f515ee8ec(11),
        currentStep: _0x9f515ee8ec(12),
        scanId: null,
        rows: [],
        detailQueue: [],
        detailIndex: 0,
        currentOrderId: null,
        detailAttempts: 0,
        listAttempts: 0,
        listTabId: null,
        detailTabId: null,
        pauseRequested: false,
        closePanelRequested: false,
        logs: [],
        authLocked: false,
        authCacheUntil: 0,
        anomalyTypes: {},
        lastError: null,
        startedAt: null,
        completedAt: null,
        updatedAt: Date.now()
    };
}
function _0x74abf99c27(_0x5afb777951) {
    const _0xe99f3a0f05 = { ..._0x660128c054(), ...(_0x5afb777951 || {}) };
    _0xe99f3a0f05.rows = Array.isArray(_0xe99f3a0f05.rows) ? _0xe99f3a0f05.rows.map((_0x3a1328c84e) => ({
        ...(_0x3a1328c84e || {}),
        date: _0x3a1328c84e && Object.prototype.hasOwnProperty.call(_0x3a1328c84e, _0x9f515ee8ec(13))
            ? _0x3a1328c84e.date
            : (_0x3a1328c84e && _0x3a1328c84e.detailStatus === _0x9f515ee8ec(14) ? _0x9f515ee8ec(15) : _0x9f515ee8ec(16))
    })) : [];
    _0xe99f3a0f05.detailQueue = Array.isArray(_0xe99f3a0f05.detailQueue) ? _0xe99f3a0f05.detailQueue : [];
    _0xe99f3a0f05.logs = Array.isArray(_0xe99f3a0f05.logs) ? _0xe99f3a0f05.logs : [];
    _0xe99f3a0f05.anomalyTypes = _0xe99f3a0f05.anomalyTypes && typeof _0xe99f3a0f05.anomalyTypes === _0x9f515ee8ec(17) ? _0xe99f3a0f05.anomalyTypes : {};
    _0xe99f3a0f05.schemaVersion = 3;
    return _0xe99f3a0f05;
}
async function _0x8f9ffeab74() {
    const _0x9e6c88c9c1 = await chrome.storage.local.get(_0xd4b2b9cc69);
    return _0x74abf99c27(_0x9e6c88c9c1[_0xd4b2b9cc69]);
}
function _0x156b76cd4c(_0xac72338f94) {
    const _0x60cb12db0a = _0xdaacf787b6.then(async () => {
        const _0x71a59b58b4 = await chrome.storage.local.get(_0xd4b2b9cc69);
        const _0x1d7f18c91c = _0x74abf99c27(_0x71a59b58b4[_0xd4b2b9cc69]);
        const _0x31a8714851 = await _0xac72338f94(_0x1d7f18c91c);
        _0x1d7f18c91c.updatedAt = Date.now();
        await chrome.storage.local.set({ [_0xd4b2b9cc69]: _0x1d7f18c91c });
        return _0x31a8714851 === undefined ? _0x1d7f18c91c : _0x31a8714851;
    });
    _0xdaacf787b6 = _0x60cb12db0a.catch(() => { });
    return _0x60cb12db0a;
}
async function _0x548b514436(_0x6a4ca3d7f1) {
    return _0x156b76cd4c((_0xfd9d3e307f) => {
        Object.assign(_0xfd9d3e307f, _0x6a4ca3d7f1);
    });
}
async function _0x8ba21f0e52(_0xbe4f73c175, _0x1d29e4ebbc) {
    return _0x156b76cd4c((_0xd8e3885299) => {
        _0xd8e3885299.logs.push({
            time: Date.now(),
            level: _0xbe4f73c175 || _0x9f515ee8ec(18),
            message: String(_0x1d29e4ebbc || _0x9f515ee8ec(19))
        });
        if (_0xd8e3885299.logs.length > _0x91aee3b5c7) {
            _0xd8e3885299.logs.splice(0, _0xd8e3885299.logs.length - _0x91aee3b5c7);
        }
    });
}
function _0xde13b58bf4(_0xd2ac8ed890) {
    return _0xcf2ab61221 + encodeURIComponent(_0xd2ac8ed890) + _0x34fcb35bd1;
}
function _0x0f4e0c8848(_0x7751e9c6e1) {
    return new Promise((_0xde8736f1e7) => setTimeout(_0xde8736f1e7, _0x7751e9c6e1));
}
async function _0x8ffb916747(_0xeb07719e36) {
    if (!Number.isInteger(_0xeb07719e36)) {
        return null;
    }
    try {
        return await chrome.tabs.get(_0xeb07719e36);
    }
    catch (_0xd0b2011dbd) {
        return null;
    }
}
async function _0x20a987ddd8(_0x9cfe73ff4f) {
    if (!Number.isInteger(_0x9cfe73ff4f)) {
        return;
    }
    try {
        await chrome.tabs.remove(_0x9cfe73ff4f);
    }
    catch (_0xdc7d3ff198) {
    }
}
async function _0xf50e17f2a6(_0xe6dc3202af) {
    if (!Number.isInteger(_0xe6dc3202af)) {
        return null;
    }
    try {
        return await chrome.windows.get(_0xe6dc3202af);
    }
    catch (_0x004411a0b2) {
        return null;
    }
}
async function _0xc7f0eeb030(_0xaf4ca39842) {
    const _0xad548358a0 = await _0xf50e17f2a6(_0xaf4ca39842);
    if (_0xad548358a0 && _0xad548358a0.type === _0x9f515ee8ec(20)) {
        return _0xad548358a0.id;
    }
    const _0x8c75d64a22 = await _0x8f9ffeab74();
    const _0xe32c4b1f6f = await _0xf50e17f2a6(_0x8c75d64a22.sourceWindowId);
    if (_0xe32c4b1f6f && _0xe32c4b1f6f.type === _0x9f515ee8ec(20)) {
        return _0xe32c4b1f6f.id;
    }
    const _0x913ede743e = await chrome.windows.getAll({ windowTypes: [_0x9f515ee8ec(20)] });
    const _0x1d05675fcb = _0x913ede743e.find((_0x0e4e736fc2) => _0x0e4e736fc2.focused && Number.isInteger(_0x0e4e736fc2.id));
    if (_0x1d05675fcb) {
        return _0x1d05675fcb.id;
    }
    const _0xb2c29fa319 = _0x913ede743e.find((_0x0bfc551d62) => Number.isInteger(_0x0bfc551d62.id));
    if (_0xb2c29fa319) {
        return _0xb2c29fa319.id;
    }
    const _0x6fc4a7e829 = await chrome.windows.create({ type: _0x9f515ee8ec(20), focused: false });
    return _0x6fc4a7e829 && Number.isInteger(_0x6fc4a7e829.id) ? _0x6fc4a7e829.id : undefined;
}
async function _0x8f3959d23b(_0x63bd9c6143, _0x69ddc4bc0b = {}) {
    const _0x926194bc38 = await _0xc7f0eeb030(_0x69ddc4bc0b.windowId);
    return chrome.tabs.create({
        windowId: _0x926194bc38,
        url: _0x63bd9c6143,
        active: Boolean(_0x69ddc4bc0b.active)
    });
}
async function _0x2a7d5e53a1() {
    const _0x41e64dbf10 = await _0x8f9ffeab74();
    if (!Number.isInteger(_0x41e64dbf10.panelWindowId)) {
        return false;
    }
    try {
        const _0xe5d3189e9a = await chrome.windows.get(_0x41e64dbf10.panelWindowId);
        if (!_0xe5d3189e9a || _0xe5d3189e9a.type !== _0x9f515ee8ec(21)) {
            return false;
        }
        await chrome.windows.update(_0x41e64dbf10.panelWindowId, { focused: true });
        return true;
    }
    catch (_0x2bab944212) {
        await _0x548b514436({ panelWindowId: null });
        return false;
    }
}
async function _0x56d70f3dd8(_0x18210106de, _0x9b729586d0 = false) {
    if (_0xfe9ea732aa) {
        return false;
    }
    _0xfe9ea732aa = true;
    try {
        const _0x37e67a96ef = await _0x8f9ffeab74();
        if (![_0x9f515ee8ec(5), _0x9f515ee8ec(6), _0x9f515ee8ec(7)].includes(_0x37e67a96ef.status)) {
            return false;
        }
        const _0x5caf56343b = await _0x8ffb916747(_0x37e67a96ef.listTabId);
        if (!_0x5caf56343b || !Number.isInteger(_0x5caf56343b.id) || !Number.isInteger(_0x5caf56343b.windowId)) {
            return false;
        }
        await chrome.tabs.update(_0x5caf56343b.id, { active: true });
        await chrome.windows.update(_0x5caf56343b.windowId, { focused: true });
        await _0x548b514436({
            sourceWindowId: _0x5caf56343b.windowId,
            listWindowId: _0x5caf56343b.windowId
        });
        if (_0x9b729586d0) {
            await _0x8ba21f0e52(_0x9f515ee8ec(18), _0x18210106de || _0x9f515ee8ec(22));
        }
        return true;
    }
    catch (_0xd66dca9b4d) {
        if (_0x9b729586d0) {
            await _0x8ba21f0e52(_0x9f515ee8ec(23), `无法将退货列表切换到前台 — ${_0xd66dca9b4d.message || _0xd66dca9b4d}`);
        }
        return false;
    }
    finally {
        _0xfe9ea732aa = false;
    }
}
async function _0x2fc653af46(_0x13a524e487) {
    const _0xa58f675f7c = String(_0x13a524e487 || _0x9f515ee8ec(19));
    if (!_0xa58f675f7c.startsWith(_0x9f515ee8ec(24))) {
        throw new Error(_0x9f515ee8ec(25));
    }
    const _0xd944c86f27 = await _0xc7f0eeb030();
    const _0x4278339d8c = await chrome.tabs.create({
        windowId: _0xd944c86f27,
        url: _0xa58f675f7c,
        active: true
    });
    if (Number.isInteger(_0xd944c86f27)) {
        await chrome.windows.update(_0xd944c86f27, { focused: true }).catch(() => { });
    }
    return _0x4278339d8c;
}
async function _0xf8bb828ebe(_0xbf5909e48c, _0x816d523e34 = 30000) {
    const _0x4d542a6324 = await _0x8ffb916747(_0xbf5909e48c);
    if (!_0x4d542a6324) {
        throw new Error(_0x9f515ee8ec(26));
    }
    if (_0x4d542a6324.status === _0x9f515ee8ec(27)) {
        return _0x4d542a6324;
    }
    return new Promise((_0x8ad1dc35a8, _0xdb6c2d15b5) => {
        let _0x882b3d1a2e = false;
        const _0x386f7b161c = (_0x000fcf6f7f, _0xaa20f2cadc) => {
            if (_0x882b3d1a2e) {
                return;
            }
            _0x882b3d1a2e = true;
            clearTimeout(_0xdfbe455b71);
            chrome.tabs.onUpdated.removeListener(_0x465980b510);
            chrome.tabs.onRemoved.removeListener(_0xcdcc17be51);
            if (_0x000fcf6f7f) {
                _0xdb6c2d15b5(_0x000fcf6f7f);
            }
            else {
                _0x8ad1dc35a8(_0xaa20f2cadc);
            }
        };
        const _0x465980b510 = (_0x385c6e911d, _0x09203da7a5, _0xc3a7e09cec) => {
            if (_0x385c6e911d === _0xbf5909e48c && _0x09203da7a5.status === _0x9f515ee8ec(27)) {
                _0x386f7b161c(null, _0xc3a7e09cec);
            }
        };
        const _0xcdcc17be51 = (_0x50f5bc88c1) => {
            if (_0x50f5bc88c1 === _0xbf5909e48c) {
                _0x386f7b161c(new Error(_0x9f515ee8ec(28)));
            }
        };
        const _0xdfbe455b71 = setTimeout(() => _0x386f7b161c(new Error(_0x9f515ee8ec(29))), _0x816d523e34);
        chrome.tabs.onUpdated.addListener(_0x465980b510);
        chrome.tabs.onRemoved.addListener(_0xcdcc17be51);
        _0x8ffb916747(_0xbf5909e48c).then((_0x1c09dfc280) => {
            if (!_0x1c09dfc280) {
                _0x386f7b161c(new Error(_0x9f515ee8ec(28)));
            }
            else if (_0x1c09dfc280.status === _0x9f515ee8ec(27)) {
                _0x386f7b161c(null, _0x1c09dfc280);
            }
        }).catch(() => { });
    });
}
async function _0x5a9bcbb65e(_0x874ba55190) {
    const _0xad3f5e3c79 = await _0xc7f0eeb030(_0x874ba55190 && _0x874ba55190.windowId);
    if (Number.isInteger(_0xad3f5e3c79)) {
        await _0x548b514436({ sourceWindowId: _0xad3f5e3c79 });
    }
    const _0x3b5284face = await _0x8f9ffeab74();
    if (Number.isInteger(_0x3b5284face.panelWindowId)) {
        try {
            await chrome.windows.get(_0x3b5284face.panelWindowId);
            await chrome.windows.update(_0x3b5284face.panelWindowId, { focused: true });
            return;
        }
        catch (_0x8e0b232f51) {
            await _0x548b514436({ panelWindowId: null });
        }
    }
    const _0x0b23a6e7b0 = await chrome.windows.create({
        url: chrome.runtime.getURL(_0x9f515ee8ec(30)),
        type: _0x9f515ee8ec(21),
        width: 1500,
        height: 900,
        focused: true
    });
    if (_0x0b23a6e7b0 && Number.isInteger(_0x0b23a6e7b0.id)) {
        await _0x548b514436({ panelWindowId: _0x0b23a6e7b0.id });
    }
}
async function _0xc34abfb535() {
    const _0x8f1a54c550 = await _0x8f9ffeab74();
    if (!Number.isInteger(_0x8f1a54c550.panelWindowId)) {
        return;
    }
    try {
        await chrome.windows.remove(_0x8f1a54c550.panelWindowId);
    }
    catch (_0xcfcdd60482) {
        await _0x548b514436({ panelWindowId: null });
    }
}
function _0x27a445fd28(_0x064e1af00f, _0xc605a062e4) {
    const _0x3ecc55487a = String(_0x064e1af00f || _0x9f515ee8ec(19)).toUpperCase().replace(/[^A-Z0-9_-]+/g, _0x9f515ee8ec(31));
    if (_0x3ecc55487a === _0x9f515ee8ec(32)) {
        return true;
    }
    if (_0x3ecc55487a !== _0x9f515ee8ec(33)) {
        return false;
    }
    const _0x1ecdfc0629 = String((_0xc605a062e4 && _0xc605a062e4.message) || _0x9f515ee8ec(19));
    if (/\bPAGE_SIZE_(?:CONTROL_NOT_FOUND|100_OPTION_NOT_FOUND|VERIFY_TIMEOUT)\b/i.test(_0x1ecdfc0629)) {
        return true;
    }
    return /(未找到每页显示数量栏|每页显示数量未能切换为\s*100|每页数量(?:下拉)?栏.*(?:100|当前值)|(?:未出现|未找到).*?(?:100|一百)选项|(?:100|一百)选项.*(?:未出现|未找到)|已点击\s*100.*(?:仍|还是|显示)\s*10|(?:page\s*size|items\s*per\s*page).*(?:100|not found|failed))/i.test(_0x1ecdfc0629);
}
async function _0x128c80cdd2(_0x1c1676da36, _0xbe17c63eb2) {
    if (_0x27a445fd28(_0x1c1676da36, _0xbe17c63eb2)) {
        return;
    }
    const _0x722a83823c = String(_0x1c1676da36 || _0x9f515ee8ec(34)).toUpperCase().replace(/[^A-Z0-9_-]+/g, _0x9f515ee8ec(31)).slice(0, 80);
    const _0x4b0a652cda = Date.now();
    const _0x716eb79be7 = await _0x156b76cd4c((_0xb2fb8e2886) => {
        const _0x908f6d39e4 = _0xb2fb8e2886.anomalyTypes[_0x722a83823c];
        if (_0x908f6d39e4 && _0x908f6d39e4.status === _0x9f515ee8ec(35)) {
            return false;
        }
        if (_0x908f6d39e4 && _0x908f6d39e4.status === _0x9f515ee8ec(14) && _0x4b0a652cda - Number(_0x908f6d39e4.time || 0) < 5 * 60 * 1000) {
            return false;
        }
        _0xb2fb8e2886.anomalyTypes[_0x722a83823c] = { status: _0x9f515ee8ec(14), time: _0x4b0a652cda };
        return true;
    });
    if (!_0x716eb79be7) {
        return;
    }
    const _0x743be2de92 = new Date(_0x4b0a652cda).toISOString().replace(/[:.]/g, _0x9f515ee8ec(36));
    const _0x25700d5b56 = String((_0xbe17c63eb2 && _0xbe17c63eb2.html) || _0x9f515ee8ec(19)).slice(0, _0x7921e04efc);
    const _0x628452879d = [
        `ANOMALY TYPE: ${_0x722a83823c}`,
        `RECORDED AT: ${new Date(_0x4b0a652cda).toISOString()}`,
        `PAGE URL: ${(_0xbe17c63eb2 && _0xbe17c63eb2.url) || _0x9f515ee8ec(19)}`,
        `ORDER ID: ${(_0xbe17c63eb2 && _0xbe17c63eb2.orderId) || _0x9f515ee8ec(19)}`,
        `MESSAGE: ${(_0xbe17c63eb2 && _0xbe17c63eb2.message) || _0x9f515ee8ec(19)}`,
        _0x9f515ee8ec(19),
        _0x9f515ee8ec(37),
        _0x25700d5b56 || _0x9f515ee8ec(38)
    ].join(_0x9f515ee8ec(39));
    const _0x8a23211e08 = `TEMU_Return_Label_Collector/Anomaly_Samples/${_0x722a83823c}_${_0x743be2de92}.txt`;
    try {
        const _0x6912a503ee = await chrome.downloads.download({
            url: `data:text/plain;charset=utf-8,${encodeURIComponent(_0x628452879d)}`,
            filename: _0x8a23211e08,
            conflictAction: _0x9f515ee8ec(40),
            saveAs: false
        });
        await _0x156b76cd4c((_0x8e89ea93a1) => {
            _0x8e89ea93a1.anomalyTypes[_0x722a83823c] = {
                status: _0x9f515ee8ec(35),
                time: _0x4b0a652cda,
                filename: _0x8a23211e08,
                downloadId: _0x6912a503ee
            };
            _0x8e89ea93a1.logs.push({
                time: Date.now(),
                level: _0x9f515ee8ec(23),
                message: `已记录异常样本：${_0x722a83823c}`
            });
            if (_0x8e89ea93a1.logs.length > _0x91aee3b5c7) {
                _0x8e89ea93a1.logs.splice(0, _0x8e89ea93a1.logs.length - _0x91aee3b5c7);
            }
        });
    }
    catch (_0x7020173487) {
        await _0x156b76cd4c((_0x37de0d3c67) => {
            delete _0x37de0d3c67.anomalyTypes[_0x722a83823c];
            _0x37de0d3c67.logs.push({
                time: Date.now(),
                level: _0x9f515ee8ec(41),
                message: `异常样本保存失败：${_0x722a83823c} — ${_0x7020173487.message || _0x7020173487}`
            });
            if (_0x37de0d3c67.logs.length > _0x91aee3b5c7) {
                _0x37de0d3c67.logs.splice(0, _0x37de0d3c67.logs.length - _0x91aee3b5c7);
            }
        });
    }
}
async function _0x4e05b88314() {
    const _0x0e9915bfec = await _0x8f9ffeab74();
    await _0x548b514436({ listTabId: null, listWindowId: null, detailTabId: null, currentOrderId: null });
    await Promise.all([
        _0x20a987ddd8(_0x0e9915bfec.listTabId),
        _0x20a987ddd8(_0x0e9915bfec.detailTabId)
    ]);
}
async function _0xd189e33656() {
    const _0x15956b99fe = await _0x8f9ffeab74();
    if (_0x15956b99fe.authLocked) {
        throw new Error(_0x9f515ee8ec(42));
    }
    if (_0x2b73cce789.has(_0x15956b99fe.status)) {
        throw new Error(_0x9f515ee8ec(43));
    }
    if (_0x15956b99fe.status === _0x9f515ee8ec(44)) {
        if (_0x15956b99fe.detailQueue.length > _0x15956b99fe.detailIndex) {
            await _0x156b76cd4c((_0x02425ba252) => {
                _0x02425ba252.status = _0x9f515ee8ec(8);
                _0x02425ba252.pauseRequested = false;
                _0x02425ba252.closePanelRequested = false;
                _0x02425ba252.currentStep = _0x02425ba252.detailQueue[_0x02425ba252.detailIndex] || _0x9f515ee8ec(45);
                _0x02425ba252.logs.push({ time: Date.now(), level: _0x9f515ee8ec(18), message: _0x9f515ee8ec(46) });
                if (_0x02425ba252.logs.length > _0x91aee3b5c7) {
                    _0x02425ba252.logs.splice(0, _0x02425ba252.logs.length - _0x91aee3b5c7);
                }
            });
            _0x7cdfcc76d4();
            return;
        }
        if (_0x15956b99fe.scanId && _0x15956b99fe.startedAt) {
            await _0x156b76cd4c((_0x93e8c0dfd0) => {
                _0x93e8c0dfd0.status = _0x9f515ee8ec(10);
                _0x93e8c0dfd0.pauseRequested = false;
                _0x93e8c0dfd0.closePanelRequested = false;
                _0x93e8c0dfd0.currentStep = _0x9f515ee8ec(47);
                _0x93e8c0dfd0.logs.push({ time: Date.now(), level: _0x9f515ee8ec(18), message: _0x9f515ee8ec(48) });
                if (_0x93e8c0dfd0.logs.length > _0x91aee3b5c7) {
                    _0x93e8c0dfd0.logs.splice(0, _0x93e8c0dfd0.logs.length - _0x91aee3b5c7);
                }
            });
            _0x7cdfcc76d4();
            return;
        }
    }
    await _0x4e05b88314();
    const _0xb059a77713 = `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
    await _0x156b76cd4c((_0x08451f91c0) => {
        _0x08451f91c0.status = _0x9f515ee8ec(5);
        _0x08451f91c0.currentStep = _0x9f515ee8ec(49);
        _0x08451f91c0.scanId = _0xb059a77713;
        _0x08451f91c0.rows = [];
        _0x08451f91c0.detailQueue = [];
        _0x08451f91c0.detailIndex = 0;
        _0x08451f91c0.currentOrderId = null;
        _0x08451f91c0.detailAttempts = 0;
        _0x08451f91c0.listAttempts = 0;
        _0x08451f91c0.pauseRequested = false;
        _0x08451f91c0.closePanelRequested = false;
        _0x08451f91c0.lastError = null;
        _0x08451f91c0.startedAt = Date.now();
        _0x08451f91c0.completedAt = null;
        _0x08451f91c0.logs.push({ time: Date.now(), level: _0x9f515ee8ec(18), message: _0x9f515ee8ec(50) });
        if (_0x08451f91c0.logs.length > _0x91aee3b5c7) {
            _0x08451f91c0.logs.splice(0, _0x08451f91c0.logs.length - _0x91aee3b5c7);
        }
    });
    const _0xc699d3d4d2 = await _0xc7f0eeb030(_0x15956b99fe.sourceWindowId);
    const _0x268f9eca32 = await _0x8f3959d23b(_0x56d2a35a7c, { windowId: _0xc699d3d4d2, active: true });
    await _0x548b514436({
        listTabId: _0x268f9eca32.id,
        listWindowId: _0x268f9eca32.windowId,
        sourceWindowId: _0x268f9eca32.windowId
    });
    await _0x56d70f3dd8(_0x9f515ee8ec(22), false);
    await _0x8ba21f0e52(_0x9f515ee8ec(18), _0x9f515ee8ec(51));
    _0x7cdfcc76d4();
}
async function _0x46cc719cad() {
    const _0xd2b85ebe04 = await _0x8f9ffeab74();
    if (!_0x2b73cce789.has(_0xd2b85ebe04.status) || _0xd2b85ebe04.status === _0x9f515ee8ec(10)) {
        throw new Error(_0x9f515ee8ec(52));
    }
    await _0x156b76cd4c((_0xbdc5d2e588) => {
        _0xbdc5d2e588.pauseRequested = true;
        const _0x564fed7eea = [_0x9f515ee8ec(5), _0x9f515ee8ec(6), _0x9f515ee8ec(7)].includes(_0xbdc5d2e588.status);
        if (!_0x564fed7eea) {
            _0xbdc5d2e588.status = _0x9f515ee8ec(9);
        }
        _0xbdc5d2e588.currentStep = _0xbdc5d2e588.currentOrderId || (_0x564fed7eea ? _0x9f515ee8ec(53) : _0x9f515ee8ec(54));
        _0xbdc5d2e588.logs.push({
            time: Date.now(),
            level: _0x9f515ee8ec(18),
            message: _0x564fed7eea ? _0x9f515ee8ec(55) : _0x9f515ee8ec(56)
        });
        if (_0xbdc5d2e588.logs.length > _0x91aee3b5c7) {
            _0xbdc5d2e588.logs.splice(0, _0xbdc5d2e588.logs.length - _0x91aee3b5c7);
        }
    });
    _0x7cdfcc76d4();
}
async function _0xbcc3a4e67a() {
    const _0xb626503f70 = await _0x8f9ffeab74();
    if (_0x2b73cce789.has(_0xb626503f70.status)) {
        throw new Error(_0x9f515ee8ec(57));
    }
    await _0x4e05b88314();
    await _0x156b76cd4c((_0x7d2ab1786e) => {
        _0x7d2ab1786e.status = _0x7d2ab1786e.authLocked ? _0x9f515ee8ec(58) : _0x9f515ee8ec(11);
        _0x7d2ab1786e.currentStep = _0x9f515ee8ec(12);
        _0x7d2ab1786e.rows = [];
        _0x7d2ab1786e.detailQueue = [];
        _0x7d2ab1786e.detailIndex = 0;
        _0x7d2ab1786e.currentOrderId = null;
        _0x7d2ab1786e.detailAttempts = 0;
        _0x7d2ab1786e.listAttempts = 0;
        _0x7d2ab1786e.pauseRequested = false;
        _0x7d2ab1786e.closePanelRequested = false;
        _0x7d2ab1786e.lastError = null;
        _0x7d2ab1786e.startedAt = null;
        _0x7d2ab1786e.completedAt = null;
        _0x7d2ab1786e.logs = [];
    });
}
function _0x7cdfcc76d4() {
    if (_0xc3bc946c63) {
        _0x02614f1d06 = true;
        return;
    }
    queueMicrotask(() => {
        _0x8f2e5cfaec().catch(() => { });
    });
}
async function _0x8f2e5cfaec() {
    if (_0xc3bc946c63) {
        _0x02614f1d06 = true;
        return;
    }
    _0xc3bc946c63 = true;
    try {
        const _0x5554c40ec9 = await _0x8f9ffeab74();
        if (_0x5554c40ec9.authLocked && _0x5554c40ec9.status !== _0x9f515ee8ec(58)) {
            await _0x548b514436({ status: _0x9f515ee8ec(58) });
            return;
        }
        if ([_0x9f515ee8ec(5), _0x9f515ee8ec(6), _0x9f515ee8ec(7)].includes(_0x5554c40ec9.status)) {
            await _0x963e93d15e(_0x5554c40ec9);
        }
        else if ([_0x9f515ee8ec(8), _0x9f515ee8ec(9)].includes(_0x5554c40ec9.status)) {
            await _0xac18a82b4b(_0x5554c40ec9);
        }
        else if (_0x5554c40ec9.status === _0x9f515ee8ec(10)) {
            await _0xfa270f35b1(false);
        }
    }
    catch (_0xa949d51eaa) {
        await _0x156b76cd4c((_0x0cd927adbe) => {
            _0x0cd927adbe.status = _0x0cd927adbe.authLocked ? _0x9f515ee8ec(58) : _0x9f515ee8ec(41);
            _0x0cd927adbe.lastError = _0xa949d51eaa.message || String(_0xa949d51eaa);
            _0x0cd927adbe.currentStep = _0x9f515ee8ec(59);
            _0x0cd927adbe.logs.push({
                time: Date.now(),
                level: _0x9f515ee8ec(41),
                message: `任务异常停止 — ${_0xa949d51eaa.message || _0xa949d51eaa}`
            });
            if (_0x0cd927adbe.logs.length > _0x91aee3b5c7) {
                _0x0cd927adbe.logs.splice(0, _0x0cd927adbe.logs.length - _0x91aee3b5c7);
            }
        });
    }
    finally {
        _0xc3bc946c63 = false;
        if (_0x02614f1d06) {
            _0x02614f1d06 = false;
            _0x7cdfcc76d4();
        }
    }
}
async function _0x963e93d15e(_0xb2324ce54d) {
    let _0xf682dd1bbf = await _0x8ffb916747(_0xb2324ce54d.listTabId);
    if (!_0xf682dd1bbf) {
        const _0x7ae8caaf8d = await _0xc7f0eeb030(_0xb2324ce54d.sourceWindowId);
        _0xf682dd1bbf = await _0x8f3959d23b(_0x56d2a35a7c, { windowId: _0x7ae8caaf8d, active: true });
        await _0x548b514436({
            listTabId: _0xf682dd1bbf.id,
            listWindowId: _0xf682dd1bbf.windowId,
            sourceWindowId: _0xf682dd1bbf.windowId,
            status: _0x9f515ee8ec(5),
            currentStep: _0x9f515ee8ec(60)
        });
        await _0x8ba21f0e52(_0x9f515ee8ec(23), _0x9f515ee8ec(61));
    }
    else if (!String(_0xf682dd1bbf.url || _0xf682dd1bbf.pendingUrl || _0x9f515ee8ec(19)).startsWith(_0x9f515ee8ec(62))) {
        _0xf682dd1bbf = await chrome.tabs.update(_0xf682dd1bbf.id, { url: _0x56d2a35a7c, active: true });
        await _0x548b514436({ status: _0x9f515ee8ec(5), currentStep: _0x9f515ee8ec(60) });
    }
    const _0x3dd31cf707 = Number(_0xb2324ce54d.listAttempts || 0) + 1;
    await _0x56d70f3dd8(_0x3dd31cf707 > 1
        ? `列表采集重试前已重新激活列表标签页（${_0x3dd31cf707}/${_0xa0b5739dfe}）。`
        : _0x9f515ee8ec(22), true);
    let _0x091b614fe7 = null;
    try {
        await _0xf8bb828ebe(_0xf682dd1bbf.id, 35000);
        await _0x56d70f3dd8(_0x9f515ee8ec(19), false);
        await _0x548b514436({ status: _0x9f515ee8ec(6), currentStep: _0x9f515ee8ec(63) });
        const _0x3a864b4383 = await chrome.scripting.executeScript({
            target: { tabId: _0xf682dd1bbf.id },
            func: prepareAndCollectListPage
        });
        if (!Array.isArray(_0x3a864b4383) || _0x3a864b4383.length === 0) {
            _0x091b614fe7 = {
                ok: false,
                errorCode: _0x9f515ee8ec(64),
                retryAction: _0x9f515ee8ec(65),
                error: _0x9f515ee8ec(66),
                anomaly: {
                    type: _0x9f515ee8ec(64),
                    message: _0x9f515ee8ec(67),
                    url: _0xf682dd1bbf.url || _0x56d2a35a7c,
                    html: _0x9f515ee8ec(19)
                }
            };
        }
        else if (_0x3a864b4383[0].result == null) {
            const _0xf5e5d28b0a = await _0x8ffb916747(_0xf682dd1bbf.id);
            const _0x61448132b7 = String((_0xf5e5d28b0a && (_0xf5e5d28b0a.pendingUrl || _0xf5e5d28b0a.url)) || _0xf682dd1bbf.url || _0x9f515ee8ec(19));
            const _0xaa11489d71 = Boolean(_0xf5e5d28b0a && _0xf5e5d28b0a.status === _0x9f515ee8ec(68) ||
                /[?&]pageSize=100(?:&|$)/i.test(_0x61448132b7));
            _0x091b614fe7 = _0xaa11489d71 ? {
                ok: false,
                errorCode: _0x9f515ee8ec(69),
                retryAction: _0x9f515ee8ec(70),
                error: _0x9f515ee8ec(71),
                anomaly: null
            } : {
                ok: false,
                errorCode: _0x9f515ee8ec(72),
                retryAction: _0x9f515ee8ec(65),
                error: _0x9f515ee8ec(73),
                anomaly: {
                    type: _0x9f515ee8ec(72),
                    message: _0x9f515ee8ec(74),
                    url: _0x61448132b7 || _0x56d2a35a7c,
                    html: _0x9f515ee8ec(19)
                }
            };
        }
        else {
            _0x091b614fe7 = _0x3a864b4383[0].result;
        }
    }
    catch (_0x5e5b1f5279) {
        const _0x0a1e187c1e = _0x5e5b1f5279.message || String(_0x5e5b1f5279);
        const _0x2c44e1f382 = await _0x8ffb916747(_0xf682dd1bbf.id);
        const _0x31031520ae = String((_0x2c44e1f382 && (_0x2c44e1f382.pendingUrl || _0x2c44e1f382.url)) || _0xf682dd1bbf.url || _0x9f515ee8ec(19));
        const _0x1ecdec0a60 = Boolean(_0x2c44e1f382 && _0x2c44e1f382.status === _0x9f515ee8ec(68) ||
            /[?&]pageSize=100(?:&|$)/i.test(_0x31031520ae) && /(frame|navigation|context|destroyed|access contents)/i.test(_0x0a1e187c1e));
        const _0xc4a527ca2d = /(页面加载超时|在加载过程中被关闭|目标标签页不存在|ERR_|network|timeout)/i.test(_0x0a1e187c1e);
        _0x091b614fe7 = _0x1ecdec0a60 ? {
            ok: false,
            errorCode: _0x9f515ee8ec(69),
            retryAction: _0x9f515ee8ec(70),
            error: _0x9f515ee8ec(71),
            anomaly: null
        } : {
            ok: false,
            errorCode: _0xc4a527ca2d ? _0x9f515ee8ec(75) : _0x9f515ee8ec(76),
            retryAction: _0xc4a527ca2d ? _0x9f515ee8ec(77) : _0x9f515ee8ec(65),
            error: _0xc4a527ca2d ? `退货列表页面应用未正常加载：${_0x0a1e187c1e}`
                : `无法执行列表页采集脚本：${_0x0a1e187c1e}`,
            anomaly: {
                type: _0xc4a527ca2d ? _0x9f515ee8ec(75) : _0x9f515ee8ec(76),
                message: _0x0a1e187c1e,
                url: _0x31031520ae || _0x56d2a35a7c,
                html: _0x9f515ee8ec(19)
            }
        };
    }
    if (!_0x091b614fe7 || _0x091b614fe7.ok !== true) {
        const _0xa8e1acb462 = _0x091b614fe7 && _0x091b614fe7.anomaly;
        if (_0xa8e1acb462) {
            await _0x128c80cdd2(_0xa8e1acb462.type, _0xa8e1acb462);
        }
        const _0xf4478673de = Number(_0xb2324ce54d.listAttempts || 0) + 1;
        const _0xb7bd8eac80 = String((_0x091b614fe7 && _0x091b614fe7.retryAction) || _0x9f515ee8ec(70));
        const _0xadcc45f156 = (_0x091b614fe7 && _0x091b614fe7.error) || _0x9f515ee8ec(78);
        const _0x04e8314fe6 = _0xb7bd8eac80 !== _0x9f515ee8ec(65) && _0xf4478673de < _0xa0b5739dfe;
        if (_0x04e8314fe6) {
            const _0xb5d6ff3a6d = _0xb7bd8eac80 === _0x9f515ee8ec(77)
                ? _0x9f515ee8ec(79) : _0x9f515ee8ec(80);
            await _0x156b76cd4c((_0x81b4c8d782) => {
                _0x81b4c8d782.listAttempts = _0xf4478673de;
                _0x81b4c8d782.status = _0x9f515ee8ec(5);
                _0x81b4c8d782.currentStep = `重试列表采集（${_0xf4478673de + 1}/${_0xa0b5739dfe}）`;
                _0x81b4c8d782.logs.push({
                    time: Date.now(),
                    level: _0x9f515ee8ec(23),
                    message: `列表采集失败（${_0xf4478673de}/${_0xa0b5739dfe}）— ${_0xadcc45f156}；${_0xb5d6ff3a6d}。`
                });
                if (_0x81b4c8d782.logs.length > _0x91aee3b5c7) {
                    _0x81b4c8d782.logs.splice(0, _0x81b4c8d782.logs.length - _0x91aee3b5c7);
                }
            });
            try {
                await _0x56d70f3dd8(_0x9f515ee8ec(19), false);
                if (_0xb7bd8eac80 === _0x9f515ee8ec(77)) {
                    await chrome.tabs.reload(_0xf682dd1bbf.id);
                }
                else {
                    await _0x0f4e0c8848(700);
                }
            }
            catch (_0x28c9f27b3f) {
                await _0x548b514436({ listTabId: null, listWindowId: null });
            }
            _0x7cdfcc76d4();
            return;
        }
        await _0x156b76cd4c((_0xacc255bd63) => {
            _0xacc255bd63.status = _0x9f515ee8ec(41);
            _0xacc255bd63.currentStep = _0x9f515ee8ec(81);
            _0xacc255bd63.lastError = _0xadcc45f156;
            _0xacc255bd63.logs.push({
                time: Date.now(),
                level: _0x9f515ee8ec(41),
                message: _0xb7bd8eac80 === _0x9f515ee8ec(65)
                    ? `列表采集发生确定性错误，任务已停止且未刷新页面 — ${_0xadcc45f156}`
                    : `列表采集连续失败，任务停止 — ${_0xadcc45f156}`
            });
            if (_0xacc255bd63.logs.length > _0x91aee3b5c7) {
                _0xacc255bd63.logs.splice(0, _0xacc255bd63.logs.length - _0x91aee3b5c7);
            }
        });
        return;
    }
    const _0x5f201fcd6e = Array.isArray(_0x091b614fe7.anomalies) ? _0x091b614fe7.anomalies : [];
    for (const _0xb3d291fcfe of _0x5f201fcd6e) {
        await _0x128c80cdd2(_0xb3d291fcfe.type, _0xb3d291fcfe);
    }
    const _0xa3401f2a04 = Array.isArray(_0x091b614fe7.rows) ? _0x091b614fe7.rows : [];
    const _0x010ac034c1 = /^PO-\d{3}-\d+$/i;
    const _0xd2b74ff874 = _0xa3401f2a04.map((_0xb2346caca5) => _0x010ac034c1.test(String(_0xb2346caca5.orderId || _0x9f515ee8ec(19))) ? _0xb2346caca5 : {
        ..._0xb2346caca5,
        date: _0x9f515ee8ec(82),
        courier: _0x9f515ee8ec(82),
        trackingNumber: _0x9f515ee8ec(82),
        sellerNote: _0x9f515ee8ec(82),
        detailStatus: _0x9f515ee8ec(41)
    });
    const _0xd18f0e0551 = [];
    const _0x83a1f4052c = new Set();
    for (const _0xcb42bdd44b of _0xd2b74ff874) {
        if (_0x010ac034c1.test(String(_0xcb42bdd44b.orderId || _0x9f515ee8ec(19))) && !_0x83a1f4052c.has(_0xcb42bdd44b.orderId)) {
            _0x83a1f4052c.add(_0xcb42bdd44b.orderId);
            _0xd18f0e0551.push(_0xcb42bdd44b.orderId);
        }
    }
    await _0x156b76cd4c((_0xd60c02a38e) => {
        _0xd60c02a38e.rows = _0xd2b74ff874;
        _0xd60c02a38e.detailQueue = _0xd18f0e0551;
        _0xd60c02a38e.detailIndex = 0;
        _0xd60c02a38e.currentOrderId = null;
        _0xd60c02a38e.detailAttempts = 0;
        _0xd60c02a38e.listAttempts = 0;
        _0xd60c02a38e.listTabId = null;
        _0xd60c02a38e.listWindowId = null;
        _0xd60c02a38e.logs.push({
            time: Date.now(),
            level: _0x9f515ee8ec(18),
            message: _0x9f515ee8ec(83)
        });
        _0xd60c02a38e.logs.push({
            time: Date.now(),
            level: _0x9f515ee8ec(18),
            message: _0x9f515ee8ec(84)
        });
        _0xd60c02a38e.logs.push({
            time: Date.now(),
            level: _0x9f515ee8ec(18),
            message: _0x9f515ee8ec(85)
        });
        if (Number.isFinite(Number(_0x091b614fe7.totalCount))) {
            const _0xab96219c9e = Math.min(Number(_0x091b614fe7.totalCount), 100);
            _0xd60c02a38e.logs.push({
                time: Date.now(),
                level: _0x9f515ee8ec(86),
                message: `页面显示 ${Number(_0x091b614fe7.totalCount)} 个请求，当前页应采集 ${_0xab96219c9e} 个，已稳定采集 ${_0x091b614fe7.cardCount} 个 Return ID。`
            });
        }
        else {
            _0xd60c02a38e.logs.push({
                time: Date.now(),
                level: _0x9f515ee8ec(86),
                message: `已稳定采集 ${_0x091b614fe7.cardCount} 个 Return ID。`
            });
        }
        _0xd60c02a38e.logs.push({
            time: Date.now(),
            level: _0x9f515ee8ec(86),
            message: `卡片采集完成：${_0x091b614fe7.cardCount} 个退货请求，生成 ${_0xd2b74ff874.length} 行，需读取 ${_0xd18f0e0551.length} 个唯一订单详情。`
        });
        if (_0xd60c02a38e.pauseRequested || _0xd60c02a38e.closePanelRequested) {
            _0xd60c02a38e.status = _0x9f515ee8ec(44);
            _0xd60c02a38e.currentStep = _0x9f515ee8ec(87);
            _0xd60c02a38e.logs.push({ time: Date.now(), level: _0x9f515ee8ec(23), message: _0x9f515ee8ec(88) });
        }
        else if (_0xd18f0e0551.length === 0) {
            _0xd60c02a38e.status = _0x9f515ee8ec(10);
            _0xd60c02a38e.currentStep = _0x9f515ee8ec(47);
        }
        else {
            _0xd60c02a38e.status = _0x9f515ee8ec(8);
            _0xd60c02a38e.currentStep = _0xd18f0e0551[0];
        }
        if (_0xd60c02a38e.logs.length > _0x91aee3b5c7) {
            _0xd60c02a38e.logs.splice(0, _0xd60c02a38e.logs.length - _0x91aee3b5c7);
        }
    });
    await _0x20a987ddd8(_0xf682dd1bbf.id);
    const _0x69f0ce86c7 = await _0x2a7d5e53a1();
    await _0x8ba21f0e52(_0x9f515ee8ec(18), _0x69f0ce86c7 ? _0x9f515ee8ec(89) : _0x9f515ee8ec(90));
    _0x7cdfcc76d4();
}
async function _0xac18a82b4b(_0xa05eea8b0f) {
    if (_0xa05eea8b0f.pauseRequested && !_0xa05eea8b0f.currentOrderId) {
        const _0xe7610412b4 = _0xa05eea8b0f.detailTabId;
        await _0x156b76cd4c((_0x47331b36ca) => {
            _0x47331b36ca.status = _0x9f515ee8ec(44);
            _0x47331b36ca.currentStep = _0x9f515ee8ec(87);
            _0x47331b36ca.detailTabId = null;
            _0x47331b36ca.logs.push({ time: Date.now(), level: _0x9f515ee8ec(23), message: _0x9f515ee8ec(91) });
            if (_0x47331b36ca.logs.length > _0x91aee3b5c7) {
                _0x47331b36ca.logs.splice(0, _0x47331b36ca.logs.length - _0x91aee3b5c7);
            }
        });
        await _0x20a987ddd8(_0xe7610412b4);
        return;
    }
    if (_0xa05eea8b0f.detailIndex >= _0xa05eea8b0f.detailQueue.length) {
        const _0xe38734850f = _0xa05eea8b0f.detailTabId;
        await _0x156b76cd4c((_0xf8a9951cd8) => {
            _0xf8a9951cd8.status = _0x9f515ee8ec(10);
            _0xf8a9951cd8.currentStep = _0x9f515ee8ec(47);
            _0xf8a9951cd8.currentOrderId = null;
            _0xf8a9951cd8.detailTabId = null;
            _0xf8a9951cd8.logs.push({ time: Date.now(), level: _0x9f515ee8ec(86), message: _0x9f515ee8ec(92) });
            if (_0xf8a9951cd8.logs.length > _0x91aee3b5c7) {
                _0xf8a9951cd8.logs.splice(0, _0xf8a9951cd8.logs.length - _0x91aee3b5c7);
            }
        });
        await _0x20a987ddd8(_0xe38734850f);
        _0x7cdfcc76d4();
        return;
    }
    const _0x35590415a7 = _0xa05eea8b0f.currentOrderId || _0xa05eea8b0f.detailQueue[_0xa05eea8b0f.detailIndex];
    await _0x548b514436({
        status: _0xa05eea8b0f.pauseRequested ? _0x9f515ee8ec(9) : _0x9f515ee8ec(8),
        currentOrderId: _0x35590415a7,
        currentStep: _0x35590415a7
    });
    if (!_0xa05eea8b0f.currentOrderId) {
        await _0x8ba21f0e52(_0x9f515ee8ec(18), `读取订单详情 ${_0xa05eea8b0f.detailIndex + 1}/${_0xa05eea8b0f.detailQueue.length}：${_0x35590415a7}`);
    }
    let _0xe5fa1b93e2 = await _0x8ffb916747(_0xa05eea8b0f.detailTabId);
    const _0x0d3bd9df7c = _0xde13b58bf4(_0x35590415a7);
    if (!_0xe5fa1b93e2) {
        _0xe5fa1b93e2 = await _0x8f3959d23b(_0x0d3bd9df7c, { windowId: _0xa05eea8b0f.sourceWindowId, active: false });
        await _0x548b514436({ detailTabId: _0xe5fa1b93e2.id });
    }
    else {
        const _0x40b769e656 = String(_0xe5fa1b93e2.url || _0xe5fa1b93e2.pendingUrl || _0x9f515ee8ec(19));
        if (!_0x40b769e656.includes(encodeURIComponent(_0x35590415a7)) && !_0x40b769e656.includes(_0x35590415a7)) {
            _0xe5fa1b93e2 = await chrome.tabs.update(_0xe5fa1b93e2.id, { url: _0x0d3bd9df7c });
        }
    }
    let _0xea96c0f19c;
    try {
        await _0xf8bb828ebe(_0xe5fa1b93e2.id, 30000);
        const _0x5c74a0771b = await chrome.scripting.executeScript({
            target: { tabId: _0xe5fa1b93e2.id },
            func: extractOrderDetailPage,
            args: [_0x35590415a7]
        });
        _0xea96c0f19c = _0x5c74a0771b && _0x5c74a0771b[0] ? _0x5c74a0771b[0].result : null;
    }
    catch (_0x20610f5bc3) {
        _0xea96c0f19c = {
            ok: false,
            error: _0x20610f5bc3.message || String(_0x20610f5bc3),
            anomalies: [{
                    type: _0x9f515ee8ec(93),
                    orderId: _0x35590415a7,
                    message: _0x20610f5bc3.message || String(_0x20610f5bc3),
                    url: _0x0d3bd9df7c,
                    html: _0x9f515ee8ec(19)
                }]
        };
    }
    const _0x2a2a528a94 = _0xea96c0f19c && Array.isArray(_0xea96c0f19c.anomalies) ? _0xea96c0f19c.anomalies : [];
    for (const _0x6377cd723d of _0x2a2a528a94) {
        await _0x128c80cdd2(_0x6377cd723d.type, _0x6377cd723d);
    }
    if (!_0xea96c0f19c || _0xea96c0f19c.ok !== true) {
        const _0xd9f0598d02 = Number(_0xa05eea8b0f.detailAttempts || 0) + 1;
        if (_0xd9f0598d02 < 2) {
            await _0x156b76cd4c((_0x3df11ea527) => {
                _0x3df11ea527.detailAttempts = _0xd9f0598d02;
                _0x3df11ea527.logs.push({
                    time: Date.now(),
                    level: _0x9f515ee8ec(23),
                    message: `订单 ${_0x35590415a7} 详情读取失败，准备重试 — ${(_0xea96c0f19c && _0xea96c0f19c.error) || _0x9f515ee8ec(94)}`
                });
                if (_0x3df11ea527.logs.length > _0x91aee3b5c7) {
                    _0x3df11ea527.logs.splice(0, _0x3df11ea527.logs.length - _0x91aee3b5c7);
                }
            });
            try {
                await chrome.tabs.reload(_0xe5fa1b93e2.id);
            }
            catch (_0xa5c37b23cf) {
                await _0x548b514436({ detailTabId: null });
            }
            _0x7cdfcc76d4();
            return;
        }
        await _0x156b76cd4c((_0x44c3dd4502) => {
            _0x44c3dd4502.rows = _0x44c3dd4502.rows.map((_0x8c8aa4ce91) => _0x8c8aa4ce91.orderId === _0x35590415a7 ? {
                ..._0x8c8aa4ce91,
                date: _0x9f515ee8ec(82),
                courier: _0x9f515ee8ec(82),
                trackingNumber: _0x9f515ee8ec(82),
                sellerNote: _0x9f515ee8ec(82),
                detailStatus: _0x9f515ee8ec(41)
            } : _0x8c8aa4ce91);
            _0x44c3dd4502.detailIndex += 1;
            _0x44c3dd4502.currentOrderId = null;
            _0x44c3dd4502.detailAttempts = 0;
            _0x44c3dd4502.logs.push({
                time: Date.now(),
                level: _0x9f515ee8ec(41),
                message: `订单 ${_0x35590415a7} 详情读取失败，已记录 ERROR 并继续下一条。`
            });
            if (_0x44c3dd4502.logs.length > _0x91aee3b5c7) {
                _0x44c3dd4502.logs.splice(0, _0x44c3dd4502.logs.length - _0x91aee3b5c7);
            }
        });
    }
    else {
        const _0x33297e7702 = _0xea96c0f19c.date || _0x9f515ee8ec(16);
        const _0xb534bd5b43 = _0xea96c0f19c.courier || _0x9f515ee8ec(16);
        const _0x0712962eca = _0xea96c0f19c.trackingNumber || _0x9f515ee8ec(16);
        const _0xa0e5cc560f = _0xea96c0f19c.sellerNote || _0x9f515ee8ec(16);
        const _0xcd446fd036 = [_0x33297e7702, _0xb534bd5b43, _0x0712962eca, _0xa0e5cc560f].some((_0xd8a134ebf7) => String(_0xd8a134ebf7 || _0x9f515ee8ec(19)).split(_0x9f515ee8ec(95)).includes(_0x9f515ee8ec(82)));
        await _0x156b76cd4c((_0x15620adb8e) => {
            _0x15620adb8e.rows = _0x15620adb8e.rows.map((_0x768e8c13cf) => _0x768e8c13cf.orderId === _0x35590415a7 ? {
                ..._0x768e8c13cf,
                date: _0x33297e7702,
                courier: _0xb534bd5b43,
                trackingNumber: _0x0712962eca,
                sellerNote: _0xa0e5cc560f,
                detailStatus: _0xcd446fd036 ? _0x9f515ee8ec(41) : _0x9f515ee8ec(96)
            } : _0x768e8c13cf);
            _0x15620adb8e.detailIndex += 1;
            _0x15620adb8e.currentOrderId = null;
            _0x15620adb8e.detailAttempts = 0;
            _0x15620adb8e.logs.push({
                time: Date.now(),
                level: _0xcd446fd036 ? _0x9f515ee8ec(23) : _0x9f515ee8ec(86),
                message: _0xcd446fd036 ? `订单 ${_0x35590415a7} 详情读取完成，但存在无法识别的字段，已记录 ERROR。`
                    : `订单 ${_0x35590415a7} 详情读取完成。`
            });
            if (_0x15620adb8e.logs.length > _0x91aee3b5c7) {
                _0x15620adb8e.logs.splice(0, _0x15620adb8e.logs.length - _0x91aee3b5c7);
            }
        });
    }
    const _0xaeca8aa6db = await _0x8f9ffeab74();
    if (_0xaeca8aa6db.pauseRequested || _0xaeca8aa6db.closePanelRequested) {
        const _0xeb9768bb27 = _0xaeca8aa6db.detailTabId;
        await _0x156b76cd4c((_0xc9f6747608) => {
            _0xc9f6747608.status = _0x9f515ee8ec(44);
            _0xc9f6747608.currentStep = _0x9f515ee8ec(87);
            _0xc9f6747608.detailTabId = null;
            _0xc9f6747608.logs.push({ time: Date.now(), level: _0x9f515ee8ec(23), message: _0x9f515ee8ec(97) });
            if (_0xc9f6747608.logs.length > _0x91aee3b5c7) {
                _0xc9f6747608.logs.splice(0, _0xc9f6747608.logs.length - _0x91aee3b5c7);
            }
        });
        await _0x20a987ddd8(_0xeb9768bb27);
        return;
    }
    await _0x548b514436({
        status: _0x9f515ee8ec(8),
        currentStep: _0xaeca8aa6db.detailQueue[_0xaeca8aa6db.detailIndex] || _0x9f515ee8ec(47)
    });
    _0x7cdfcc76d4();
}
async function _0xc7ee51d962(_0x1c09af6e94) {
    const _0xf3e1e231ab = await _0x8f9ffeab74();
    const _0x76e0c58674 = Date.now();
    if (!_0x1c09af6e94 && !_0xf3e1e231ab.authLocked && Number(_0xf3e1e231ab.authCacheUntil || 0) > _0x76e0c58674) {
        return true;
    }
    const _0x5c67b5dba5 = new AbortController();
    const _0x3add5d9d16 = setTimeout(() => _0x5c67b5dba5.abort(), _0x514f16fddf);
    try {
        const _0xf706dee09c = await fetch(_0x659e6e0974, {
            method: _0x9f515ee8ec(98),
            cache: _0x9f515ee8ec(99),
            redirect: _0x9f515ee8ec(100),
            credentials: _0x9f515ee8ec(101),
            signal: _0x5c67b5dba5.signal
        });
        if (_0xf706dee09c.status !== 200) {
            return false;
        }
        await _0x548b514436({
            authLocked: false,
            authCacheUntil: _0x76e0c58674 + _0x9f31c16ffa
        });
        return true;
    }
    catch (_0x0a5c873bf3) {
        return false;
    }
    finally {
        clearTimeout(_0x3add5d9d16);
    }
}
async function _0xfa270f35b1(_0xb1d44cf15c) {
    const _0x48def2ac47 = await _0xc7ee51d962(_0xb1d44cf15c);
    if (_0x48def2ac47) {
        await _0x156b76cd4c((_0x7354d1d865) => {
            _0x7354d1d865.authLocked = false;
            _0x7354d1d865.status = _0x9f515ee8ec(102);
            _0x7354d1d865.currentStep = _0x9f515ee8ec(103);
            _0x7354d1d865.completedAt = Date.now();
            if (!_0x7354d1d865.logs.length || _0x7354d1d865.logs[_0x7354d1d865.logs.length - 1].message !== _0x9f515ee8ec(104)) {
                _0x7354d1d865.logs.push({ time: Date.now(), level: _0x9f515ee8ec(86), message: _0x9f515ee8ec(104) });
            }
            if (_0x7354d1d865.logs.length > _0x91aee3b5c7) {
                _0x7354d1d865.logs.splice(0, _0x7354d1d865.logs.length - _0x91aee3b5c7);
            }
        });
    }
    else {
        await _0x156b76cd4c((_0xb88a4a57ed) => {
            _0xb88a4a57ed.authLocked = true;
            _0xb88a4a57ed.status = _0x9f515ee8ec(58);
            _0xb88a4a57ed.currentStep = _0x9f515ee8ec(105);
        });
    }
}
async function prepareAndCollectListPage() {const _0x03aa531128=[[143,185,177,172,177,182,191,248,172,183,248,173,168,180,183,185,188,248,170,189,172,173,170,182,248,180,185,186,189,180],[143,185,177,172,177,182,191,248,172,183,248,173,168,180,183,185,188,248,172,176,189,248,170,189,172,173,170,182,248,180,185,186,189,180],[139,183,170,172,248,186,161,248,171,176,183,170,172,189,171,172,248,170,189,181,185,177,182,177,182,191,248,168,170,183,187,189,171,171,177,182,191,248,172,177,181,189,248,240,170,189,169,173,189,171,172,171,248,175,177,172,176,248,170,189,181,185,177,182,177,182,191,248,168,170,183,187,189,171,171,177,182,191,248,172,177,181,189,248,183,182,180,161,241],[],[248],[182,183,182,189],[176,177,188,188,189,182],[31633,24413,39085,38842,20891,32248,36189,25902],[187,189,182,172,189,170],[168,183,177,182,172,189,170,188,183,175,182],[181,183,173,171,189,188,183,175,182],[168,183,177,182,172,189,170,173,168],[181,183,173,171,189,173,168],[131,188,185,172,185,245,172,189,171,172,177,188,229,250,186,189,185,171,172,245,187,183,170,189,245,171,189,180,189,187,172,245,176,189,185,188,189,170,250,133],[131,170,183,180,189,229,250,183,168,172,177,183,182,250,133],[143,153,145,140,135,136,153,159,157,135,153,136,136],[171,185,181,189,245,168,185,191,189],[131,188,185,172,185,245,172,189,171,172,177,188,229,250,186,189,185,171,172,245,187,183,170,189,245,168,185,191,177,182,185,172,177,183,182,250,133],[177,182,168,173,172,131,188,185,172,185,245,172,189,171,172,177,188,229,250,186,189,185,171,172,245,187,183,170,189,245,171,189,180,189,187,172,245,176,172,181,180,145,182,168,173,172,250,133],[251,181,185,177,182],[153,180,180,248,168,189,182,188,177,182,191,248,185,187,172,177,183,182,171],[139,183,170,172,248,186,161,248,183,180,188,189,171,172,248,190,177,170,171,172],[139,183,170,172,248,186,161,248,182,189,175,189,171,172,248,190,177,170,171,172],[142,145,139,145,154,148,157,248,139,157,148,157,155,140,248,144,157,153,156,157,138,139,226],[210],[240,182,183,182,189,241],[136,153,159,145,150,153,140,145,151,150,248,144,140,149,148,226],[240,182,183,172,248,190,183,173,182,188,241],[154,151,156,129,248,142,145,139,145,154,148,157,248,140,157,128,140,226],[240,189,181,168,172,161,241],[154,151,156,129,248,144,140,149,148,226],[136,153,159,157,135,139,145,130,157,135,155,151,150,140,138,151,148,135,150,151,140,135,158,151,141,150,156],[26610,25254,21224,27415,39085,26342,31202,26024,37143,26839],[233,232,232],[136,153,159,157,135,139,145,130,157,135,233,232,232,135,151,136,140,145,151,150,135,150,151,140,135,158,151,141,150,156],[27415,39085,26024,37143,20179,25105,26839,20213,26610,25254,21224,233,232,232,37073,39073],[136,153,159,157,135,139,145,130,157,135,142,157,138,145,158,129,135,140,145,149,157,151,141,140],[27415,39085,26342,31202,26024,37143,26610,32805,21215,25530,20194,233,232,232],[153,180,180,248,168,189,182,188,177,182,191,248,185,187,172,177,183,182],[136,157,150,156,145,150,159,135,158,145,148,140,157,138,135,142,157,138,145,158,129,135,158,153,145,148,157,156],[25418,24151],[139,151,138,140,135,142,157,138,145,158,129,135,158,153,145,148,157,156],[158,145,150,153,148,135,139,157,140,141,136,135,142,157,138,145,158,129,135,158,153,145,148,157,156],[31619,37073,12505,25418,24151,25294,27415,39085,233,232,232,26553,30300,26584,32272,32908,21712,39508,35609,26610,37058,36639],[171,168,185,182,244,188,177,174],[171,174,191,244,171,172,161,180,189,244,171,187,170,177,168,172,244,186,173,172,172,183,182,244,131,170,183,180,189,229,250,186,173,172,172,183,182,250,133],[132,252,254],[177,191],[138,189,172,173,170,182,248,145,156,226],[151,170,188,189,170,248,145,156,226],[155,183,182,172,170,177,186,173,172,177,183,182,248,139,147,141,226],[138,189,172,173,170,182,248,169,173,185,182,172,177,172,161,226],[142,177,189,175,248,170,189,172,173,170,182,248,188,189,172,185,177,180,171],[141,168,180,183,185,188,248,170,189,172,173,170,182,248,180,185,186,189,180],[138,189,185,171,183,182,248,190,183,170,248,170,189,169,173,189,171,172,226],[154,173,161,189,170,248,187,183,181,181,189,182,172,226],[129,189,171],[150,183],[173,182,179,182,183,175,182],[157,138,138,151,138],[136,189,182,188,177,182,191],[168,189,182,188,177,182,191],[143,153,145,140,135,136,157,150,156,145,150,159,135,144,157,153,156,157,138],[139,157,140,135,136,157,150,156,145,150,159,135,158,145,148,140,157,138],[136,157,150,156,145,150,159,135,158,145,148,140,157,138,135,139,157,140,135,158,153,145,148,157,156],[143,153,145,140,135,139,151,138,140,135,144,157,153,156,157,138],[139,157,140,135,139,151,138,140],[139,151,138,140,135,139,157,140,135,158,153,145,148,157,156],[139,157,140,135,136,153,159,157,135,139,145,130,157,135,233,232,232],[158,145,150,153,148,135,139,157,140,141,136,135,142,157,138,145,158,129],[143,153,145,140,135,148,145,139,140,135,155,153,138,156,139],[139,157,140,140,148,157,135,148,145,139,140,135,153,158,140,157,138,135,139,157,140,141,136],[164],[155,151,148,148,157,155,140,135,148,145,139,140,135,155,153,138,156,139],[155,153,138,156,135,155,151,138,157,135,158,145,157,148,156,135,141,150,138,157,155,151,159,150,145,130,157,156],[37080,36351,21433,29343,26610,32805,31467,23362,35614,21235,248,138,189,172,173,170,182,248,145,156,248,25294,248,151,170,188,189,170,248,145,156,12506],[148,145,139,140,135,155,153,138,156,135,155,151,141,150,140,135,149,145,139,149,153,140,155,144],[39085,38842,23424,22512,37080,36351,35631,27802,65492,20382,26610,37151,38430,21224,20003,20365,21433,29343,26024,25526],[148,145,139,140,135,136,153,159,157,135,141,150,147,150,151,143,150,135,157,138,138,151,138],[170,189,180,183,185,188],[148,145,139,140,135,136,153,159,157,135,139,157,140,141,136,135,151,138,135,155,151,148,148,157,155,140,145,151,150,135,158,153,145,148,157,156]];const _0x8fba554725=(_0xc84339fd)=>String.fromCharCode(..._0x03aa531128[_0xc84339fd].map((_0x20d6afd3)=>_0x20d6afd3^216));
    const _0x7db2b2451e = [
        _0x8fba554725(0),
        _0x8fba554725(1)
    ];
    const _0xf046e72ab3 = _0x8fba554725(2);
    const _0x1ff7df57d8 = (_0x45556cce0c) => new Promise((_0xe5d438973a) => setTimeout(_0xe5d438973a, _0x45556cce0c));
    const _0x9ba6c8e573 = (_0xf3147d8cd4) => String(_0xf3147d8cd4 || _0x8fba554725(3)).replace(/\s+/g, _0x8fba554725(4)).trim();
    const _0x6bc61a463d = (_0x855f4ba0b5) => _0x9ba6c8e573(_0x855f4ba0b5).toLowerCase().replace(/\bthe\b/g, _0x8fba554725(3)).replace(/\s+/g, _0x8fba554725(4)).trim();
    const _0xb6c92ad023 = (_0x798f3d0657) => {
        if (!_0x798f3d0657 || !_0x798f3d0657.isConnected) {
            return false;
        }
        const _0x3ffb9a930a = getComputedStyle(_0x798f3d0657);
        const _0x0c057601cf = _0x798f3d0657.getBoundingClientRect();
        return _0x3ffb9a930a.display !== _0x8fba554725(5) && _0x3ffb9a930a.visibility !== _0x8fba554725(6) && _0x0c057601cf.width > 0 && _0x0c057601cf.height > 0;
    };
    const _0x2c51689a3d = async (_0xab78db754e, _0x2e05a47073 = 12000, _0xd85d81cde5 = 150) => {
        const _0x5a4c68fa59 = Date.now();
        let _0x27ecc8dbc9 = null;
        while (Date.now() - _0x5a4c68fa59 < _0x2e05a47073) {
            try {
                const _0xdff8a3976d = _0xab78db754e();
                if (_0xdff8a3976d) {
                    return _0xdff8a3976d;
                }
            }
            catch (_0x8a6a13aa72) {
                _0x27ecc8dbc9 = _0x8a6a13aa72;
            }
            await _0x1ff7df57d8(_0xd85d81cde5);
        }
        if (_0x27ecc8dbc9) {
            throw _0x27ecc8dbc9;
        }
        throw new Error(_0x8fba554725(7));
    };
    const _0xdda1b2bdd6 = (_0x8564c65d30) => {
        _0x8564c65d30.scrollIntoView({ block: _0x8fba554725(8), inline: _0x8fba554725(8) });
        try {
            _0x8564c65d30.focus({ preventScroll: true });
        }
        catch (_0x0a65dac156) {
            _0x8564c65d30.focus();
        }
        const _0xbd13174602 = { bubbles: true, cancelable: true, view: window };
        _0x8564c65d30.dispatchEvent(new PointerEvent(_0x8fba554725(9), _0xbd13174602));
        _0x8564c65d30.dispatchEvent(new MouseEvent(_0x8fba554725(10), _0xbd13174602));
        _0x8564c65d30.dispatchEvent(new PointerEvent(_0x8fba554725(11), _0xbd13174602));
        _0x8564c65d30.dispatchEvent(new MouseEvent(_0x8fba554725(12), _0xbd13174602));
        _0x8564c65d30.click();
    };
    const _0x433412e715 = () => Array.from(document.querySelectorAll(_0x8fba554725(13))).filter(_0xb6c92ad023);
    const _0x214456df8d = (_0xbdf26f8391) => {
        const _0xa0b862ed59 = _0xbdf26f8391.map(_0x6bc61a463d);
        const _0xdcb5bf4004 = _0x433412e715().map((_0x2a3f2f80ca) => ({
            element: _0x2a3f2f80ca,
            text: _0x6bc61a463d(_0x2a3f2f80ca.innerText || _0x2a3f2f80ca.textContent)
        }));
        const _0x0a1faafe7e = _0xdcb5bf4004.find((_0x0a6c1ea9e1) => _0xa0b862ed59.includes(_0x0a6c1ea9e1.text));
        if (_0x0a1faafe7e) {
            return _0x0a1faafe7e.element;
        }
        const _0x01a800e3a8 = _0xdcb5bf4004.find((_0xbaa0aabff6) => _0xa0b862ed59.some((_0x88d6083b53) => _0xbaa0aabff6.text.includes(_0x88d6083b53) || _0x88d6083b53.includes(_0xbaa0aabff6.text)));
        return _0x01a800e3a8 ? _0x01a800e3a8.element : null;
    };
    const _0xaf36633882 = (_0xf7d94fd1de) => {
        const _0x9c875a5c80 = _0xf7d94fd1de.map(_0x6bc61a463d);
        return Array.from(document.querySelectorAll(_0x8fba554725(14)))
            .filter(_0xb6c92ad023)
            .find((_0xffb4954dbb) => _0x9c875a5c80.includes(_0x6bc61a463d(_0xffb4954dbb.innerText || _0xffb4954dbb.textContent))) || null;
    };
    let _0xc6c1920191 = _0x8fba554725(15);
    const _0xd9101d00c0 = (_0xa3dab00043, _0xed038ffff1, _0xb37e741e08 = _0x8fba554725(16)) => {
        const _0x36c799611f = new Error(_0xed038ffff1);
        _0x36c799611f.code = _0xa3dab00043;
        _0x36c799611f.retryAction = _0xb37e741e08;
        return _0x36c799611f;
    };
    const _0x05d853d74f = () => {
        const _0x750483a2af = document.querySelector(_0x8fba554725(17));
        return _0x750483a2af && _0x750483a2af.isConnected ? _0x750483a2af : null;
    };
    const _0xd3ee444211 = () => {
        const _0x7959929a88 = _0x05d853d74f();
        if (!_0x7959929a88) {
            return null;
        }
        const _0xbda8186fbb = Array.from(_0x7959929a88.querySelectorAll(_0x8fba554725(13))).filter(_0xb6c92ad023);
        return _0xbda8186fbb.find((_0xd9a3a39cbc) => {
            const _0x6c3074812d = _0xd9a3a39cbc.querySelector(_0x8fba554725(18));
            const _0x068cf7b9d0 = _0x9ba6c8e573((_0x6c3074812d && _0x6c3074812d.value) || _0xd9a3a39cbc.innerText || _0xd9a3a39cbc.textContent);
            return /^\d+$/.test(_0x068cf7b9d0);
        }) || _0xbda8186fbb[0] || null;
    };
    const _0x009d3a6046 = () => {
        const _0x09e91d336f = _0xd3ee444211();
        if (!_0x09e91d336f) {
            return _0x8fba554725(3);
        }
        const _0x01004b9b4d = _0x09e91d336f.querySelector(_0x8fba554725(18));
        const _0x7f1db606dd = _0x9ba6c8e573((_0x01004b9b4d && _0x01004b9b4d.value) || _0x09e91d336f.innerText || _0x09e91d336f.textContent);
        const _0xeb8150f39b = _0x7f1db606dd.match(/\d+/);
        return _0xeb8150f39b ? _0xeb8150f39b[0] : _0x8fba554725(3);
    };
    const _0xa0c521cdb5 = (_0xb7095b3e88) => {
        const _0x77faa35f42 = _0x214456df8d(_0xb7095b3e88);
        return _0x77faa35f42 ? _0x9ba6c8e573(_0x77faa35f42.innerText || _0x77faa35f42.textContent) : _0x8fba554725(3);
    };
    const _0x539e45b40e = (_0xbfbafbb470, _0x54481e7d83) => {
        try {
            const _0x7375e213d6 = _0x05d853d74f();
            const _0x1f1d1349c2 = _0x433412e715().map((_0x7c091e719c, _0xe6002266ca) => {
                const _0xb4f2e92bd3 = _0x7c091e719c.querySelector(_0x8fba554725(18));
                return `${_0xe6002266ca + 1}. input=${_0x9ba6c8e573(_0xb4f2e92bd3 && _0xb4f2e92bd3.value)} | text=${_0x9ba6c8e573(_0x7c091e719c.innerText || _0x7c091e719c.textContent)}`;
            });
            const _0x6c91ad4aeb = document.querySelector(_0x8fba554725(19));
            const _0x6049b9fba7 = _0x9ba6c8e573(document.body && document.body.innerText).slice(0, 12000);
            const _0xc0bd7f8dd1 = String((document.body && document.body.outerHTML) || _0x8fba554725(3)).slice(0, 120000);
            return [
                `STAGE: ${_0xbfbafbb470 || _0x8fba554725(3)}`,
                `MESSAGE: ${_0x54481e7d83 || _0x8fba554725(3)}`,
                `DOCUMENT READY STATE: ${document.readyState}`,
                `LOCATION: ${location.href}`,
                `MAIN ROOT PRESENT: ${Boolean(_0x6c91ad4aeb)}`,
                `VISIBLE SELECT HEADER COUNT: ${_0x1f1d1349c2.length}`,
                `CURRENT PENDING VALUE: ${_0xa0c521cdb5([_0x8fba554725(20), ..._0x7db2b2451e])}`,
                `CURRENT SORT VALUE: ${_0xa0c521cdb5([_0x8fba554725(21), _0x8fba554725(22), _0xf046e72ab3])}`,
                `CURRENT PAGE SIZE: ${_0x009d3a6046()}`,
                _0x8fba554725(3),
                _0x8fba554725(23),
                _0x1f1d1349c2.join(_0x8fba554725(24)) || _0x8fba554725(25),
                _0x8fba554725(3),
                _0x8fba554725(26),
                _0x7375e213d6 ? _0x7375e213d6.outerHTML.slice(0, 30000) : _0x8fba554725(27),
                _0x8fba554725(3),
                _0x8fba554725(28),
                _0x6049b9fba7 || _0x8fba554725(29),
                _0x8fba554725(3),
                _0x8fba554725(30),
                _0xc0bd7f8dd1 || _0x8fba554725(29)
            ].join(_0x8fba554725(24));
        }
        catch (_0xea9d1a4b90) {
            return [
                `STAGE: ${_0xbfbafbb470 || _0x8fba554725(3)}`,
                `MESSAGE: ${_0x54481e7d83 || _0x8fba554725(3)}`,
                `DIAGNOSTIC SNAPSHOT FAILED: ${_0xea9d1a4b90.message || _0xea9d1a4b90}`,
                `DOCUMENT READY STATE: ${document.readyState}`,
                `LOCATION: ${location.href}`
            ].join(_0x8fba554725(24));
        }
    };
    const _0x7e3acf8361 = async (_0xc9e670e878, _0xa0e46fe230, _0x2e174b87d8, _0x709f2dc7a2) => {
        const _0x6bcd607272 = _0xa0e46fe230.map(_0x6bc61a463d);
        for (let _0xd25a1817d3 = 0; _0xd25a1817d3 < 3; _0xd25a1817d3 += 1) {
            const _0x5439911ec1 = _0x214456df8d([..._0xc9e670e878, ..._0xa0e46fe230]);
            if (!_0x5439911ec1) {
                if (_0xd25a1817d3 < 2) {
                    await _0x1ff7df57d8(300);
                    continue;
                }
                throw _0xd9101d00c0(_0x709f2dc7a2, `未找到${_0x2e174b87d8}选择栏`);
            }
            if (_0x6bcd607272.includes(_0x6bc61a463d(_0x5439911ec1.innerText || _0x5439911ec1.textContent))) {
                return;
            }
            _0xdda1b2bdd6(_0x5439911ec1);
            const _0x9faa797fd7 = await _0x2c51689a3d(() => _0xaf36633882(_0xa0e46fe230), 3000, 100).catch(() => null);
            if (_0x9faa797fd7) {
                _0xdda1b2bdd6(_0x9faa797fd7);
                const _0xfcc5b54045 = await _0x2c51689a3d(() => {
                    const _0x5b9285547c = _0x214456df8d(_0xa0e46fe230);
                    return _0x5b9285547c && _0x6bcd607272.includes(_0x6bc61a463d(_0x5b9285547c.innerText || _0x5b9285547c.textContent));
                }, 6000, 150).catch(() => null);
                if (_0xfcc5b54045) {
                    await _0x1ff7df57d8(350);
                    return;
                }
            }
            await _0x1ff7df57d8(350);
        }
        throw _0xd9101d00c0(_0x709f2dc7a2, `${_0x2e174b87d8}未能切换到目标值`);
    };
    const _0x1908bf8312 = async () => {
        for (let _0xc7fdabe049 = 0; _0xc7fdabe049 < 3; _0xc7fdabe049 += 1) {
            const _0xc428feb8cc = await _0x2c51689a3d(() => _0xd3ee444211(), 5000, 150).catch(() => null);
            if (!_0xc428feb8cc) {
                if (_0xc7fdabe049 < 2) {
                    await _0x1ff7df57d8(350);
                    continue;
                }
                throw _0xd9101d00c0(_0x8fba554725(31), _0x8fba554725(32));
            }
            if (_0x009d3a6046() === _0x8fba554725(33)) {
                return;
            }
            _0xdda1b2bdd6(_0xc428feb8cc);
            const _0x9bd4bfa764 = await _0x2c51689a3d(() => _0xaf36633882([_0x8fba554725(33)]), 3000, 100).catch(() => null);
            if (!_0x9bd4bfa764) {
                if (_0xc7fdabe049 < 2) {
                    await _0x1ff7df57d8(350);
                    continue;
                }
                throw _0xd9101d00c0(_0x8fba554725(34), _0x8fba554725(35));
            }
            _0xdda1b2bdd6(_0x9bd4bfa764);
            const _0xcd1a2909ab = await _0x2c51689a3d(() => _0x009d3a6046() === _0x8fba554725(33), 9000, 150).catch(() => null);
            if (_0xcd1a2909ab) {
                await _0x1ff7df57d8(700);
                return;
            }
            await _0x1ff7df57d8(350);
        }
        throw _0xd9101d00c0(_0x8fba554725(36), _0x8fba554725(37));
    };
    const _0x6dce0b659a = async () => {
        for (let _0xe10af89b24 = 0; _0xe10af89b24 < 2; _0xe10af89b24 += 1) {
            const _0x6662ae489c = _0x6bc61a463d(_0xa0c521cdb5([_0x8fba554725(20), ..._0x7db2b2451e]));
            const _0x708be3de2b = _0x6bc61a463d(_0xa0c521cdb5([_0x8fba554725(21), _0x8fba554725(22), _0xf046e72ab3]));
            const _0xb999da0e34 = _0x009d3a6046();
            const _0x7248b54ebf = _0x7db2b2451e.map(_0x6bc61a463d).includes(_0x6662ae489c);
            const _0x3765a04a47 = _0x6bc61a463d(_0xf046e72ab3) === _0x708be3de2b;
            const _0x8cab56d43e = _0xb999da0e34 === _0x8fba554725(33);
            if (_0x7248b54ebf && _0x3765a04a47 && _0x8cab56d43e) {
                return;
            }
            if (!_0x7248b54ebf) {
                await _0x7e3acf8361([_0x8fba554725(20), ..._0x7db2b2451e], _0x7db2b2451e, _0x8fba554725(38), _0x8fba554725(39));
            }
            if (!_0x3765a04a47) {
                await _0x7e3acf8361([_0x8fba554725(21), _0x8fba554725(22), _0xf046e72ab3], [_0xf046e72ab3], _0x8fba554725(40), _0x8fba554725(41));
            }
            if (!_0x8cab56d43e) {
                await _0x1908bf8312();
            }
            await _0x1ff7df57d8(450);
        }
        throw _0xd9101d00c0(_0x8fba554725(42), _0x8fba554725(43));
    };
    const _0x01773689f7 = (_0xbfb3a72250, _0xf9cc6b4808) => {
        const _0xb9bac2e450 = _0x6bc61a463d(_0xf9cc6b4808);
        return Array.from(_0xbfb3a72250.querySelectorAll(_0x8fba554725(44))).filter((_0xc491ee0022) => {
            if (_0x6bc61a463d(_0xc491ee0022.textContent) !== _0xb9bac2e450) {
                return false;
            }
            return !Array.from(_0xc491ee0022.children).some((_0xa3db20d495) => _0x6bc61a463d(_0xa3db20d495.textContent) === _0xb9bac2e450);
        });
    };
    const _0xe3427b6088 = (_0xe1f7b21879) => {
        _0xe1f7b21879.querySelectorAll(_0x8fba554725(45)).forEach((_0x833ac1afa6) => _0x833ac1afa6.remove());
    };
    const _0xed657eca7d = (_0x0d34427a2a, _0x0317c71eb6) => {
        const _0x2c82489797 = _0x01773689f7(_0x0d34427a2a, _0x0317c71eb6)[0];
        if (!_0x2c82489797) {
            return _0x8fba554725(3);
        }
        let _0x56fbfa06e1 = _0x2c82489797.parentElement;
        for (let _0x18ae97e52a = 0; _0x56fbfa06e1 && _0x56fbfa06e1 !== _0x0d34427a2a.parentElement && _0x18ae97e52a < 5; _0x18ae97e52a += 1, _0x56fbfa06e1 = _0x56fbfa06e1.parentElement) {
            const _0x4bba770c5e = _0x56fbfa06e1.cloneNode(true);
            _0xe3427b6088(_0x4bba770c5e);
            _0x01773689f7(_0x4bba770c5e, _0x0317c71eb6).forEach((_0x7d64064f2e) => _0x7d64064f2e.remove());
            let _0x42d877d2df = _0x9ba6c8e573(_0x4bba770c5e.textContent).replace(new RegExp(_0x0317c71eb6.replace(/[.*+?^${}()|[\]\\]/g, _0x8fba554725(46)), _0x8fba554725(47)), _0x8fba554725(3)).trim();
            _0x42d877d2df = _0x42d877d2df.replace(/^See more\s*/i, _0x8fba554725(3)).replace(/\s*See more$/i, _0x8fba554725(3)).trim();
            if (_0x42d877d2df && _0x42d877d2df.length <= 2500) {
                return _0x42d877d2df;
            }
        }
        return _0x8fba554725(3);
    };
    const _0x6d706f7714 = (_0x06a96f7565, _0x51e787b2e3) => {
        const _0x3131d95f8d = [];
        for (const _0xf40fbd1648 of _0x01773689f7(_0x06a96f7565, _0x51e787b2e3)) {
            let _0xe04f5566ec = _0xf40fbd1648.parentElement;
            let _0x92a7ee699a = _0x8fba554725(3);
            for (let _0x839caa348a = 0; _0xe04f5566ec && _0xe04f5566ec !== _0x06a96f7565.parentElement && _0x839caa348a < 5; _0x839caa348a += 1, _0xe04f5566ec = _0xe04f5566ec.parentElement) {
                const _0x61264afd98 = _0xe04f5566ec.cloneNode(true);
                _0xe3427b6088(_0x61264afd98);
                _0x01773689f7(_0x61264afd98, _0x51e787b2e3).forEach((_0xe116c8fd33) => _0xe116c8fd33.remove());
                let _0x204af2d5dd = _0x9ba6c8e573(_0x61264afd98.textContent).replace(new RegExp(_0x51e787b2e3.replace(/[.*+?^${}()|[\]\\]/g, _0x8fba554725(46)), _0x8fba554725(47)), _0x8fba554725(3)).trim();
                _0x204af2d5dd = _0x204af2d5dd.replace(/^See more\s*/i, _0x8fba554725(3)).replace(/\s*See more$/i, _0x8fba554725(3)).trim();
                if (_0x204af2d5dd && _0x204af2d5dd.length <= 2500) {
                    _0x92a7ee699a = _0x204af2d5dd;
                    break;
                }
            }
            if (_0x92a7ee699a) {
                _0x3131d95f8d.push(_0x92a7ee699a);
            }
        }
        return _0x3131d95f8d;
    };
    let _0x11d940fd1d = document;
    let _0x6eb1a5afed = _0x8fba554725(3);
    const _0xc96c6a7304 = (_0x675a33e5db) => {
        if (!_0x675a33e5db || !_0x675a33e5db.isConnected) {
            return false;
        }
        const _0x90743c929b = _0x9ba6c8e573(_0x675a33e5db.textContent);
        const _0x8bd0fd8ea1 = _0x90743c929b.includes(_0x8fba554725(48)) && _0x90743c929b.includes(_0x8fba554725(49)) && _0x90743c929b.includes(_0x8fba554725(50))
            && _0x90743c929b.includes(_0x8fba554725(51)) && (_0x90743c929b.includes(_0x8fba554725(52)) || _0x90743c929b.includes(_0x8fba554725(53)));
        if (!_0x8bd0fd8ea1) {
            return false;
        }
        const _0x4e98db8382 = _0x01773689f7(_0x675a33e5db, _0x8fba554725(48)).length;
        if (_0x4e98db8382 !== 1) {
            return false;
        }
        const _0x70f99fec06 = /^(?:Awaiting (?:the )?upload of (?:the )?return label\.?|Waiting to upload (?:the )?return label\.?)$/i;
        return Array.from(_0x675a33e5db.querySelectorAll(_0x8fba554725(44))).some((_0x3d63dcbc65) => {
            const _0xcc966c948c = _0x9ba6c8e573(_0x3d63dcbc65.textContent);
            if (!_0x70f99fec06.test(_0xcc966c948c)) {
                return false;
            }
            return !_0x3d63dcbc65.closest(_0x8fba554725(13));
        });
    };
    const _0xed9adc9c6a = (_0xf1be2b7a23) => {
        if (!_0xf1be2b7a23.length) {
            return null;
        }
        let _0xd9115d6e0f = _0xf1be2b7a23[0].parentElement;
        while (_0xd9115d6e0f && _0xd9115d6e0f !== document.body && !_0xf1be2b7a23.every((_0x19eb96ea86) => _0xd9115d6e0f.contains(_0x19eb96ea86))) {
            _0xd9115d6e0f = _0xd9115d6e0f.parentElement;
        }
        return _0xd9115d6e0f && _0xd9115d6e0f !== document.body ? _0xd9115d6e0f : null;
    };
    const _0x75491b851d = () => {
        if (_0x11d940fd1d !== document && !_0x11d940fd1d.isConnected) {
            _0x11d940fd1d = document;
            _0x6eb1a5afed = _0x8fba554725(3);
        }
        if (_0x6eb1a5afed) {
            const _0x46c2baac3d = Array.from(_0x11d940fd1d.querySelectorAll(_0x6eb1a5afed)).filter(_0xc96c6a7304);
            if (_0x46c2baac3d.length) {
                return _0x46c2baac3d;
            }
        }
        const _0x47c6e039a4 = [];
        const _0xf556131e00 = new Set();
        for (const _0x139c71f1e7 of _0x01773689f7(_0x11d940fd1d, _0x8fba554725(48))) {
            let _0xb5e7043477 = _0x139c71f1e7.parentElement;
            for (let _0xb66c0ede8d = 0; _0xb5e7043477 && _0xb66c0ede8d < 12; _0xb66c0ede8d += 1, _0xb5e7043477 = _0xb5e7043477.parentElement) {
                if (_0xc96c6a7304(_0xb5e7043477)) {
                    if (!_0xf556131e00.has(_0xb5e7043477)) {
                        _0xf556131e00.add(_0xb5e7043477);
                        _0x47c6e039a4.push(_0xb5e7043477);
                    }
                    break;
                }
            }
        }
        if (_0x47c6e039a4.length) {
            const _0x3a6637f1e7 = _0xed9adc9c6a(_0x47c6e039a4);
            if (_0x3a6637f1e7) {
                _0x11d940fd1d = _0x3a6637f1e7;
            }
            const _0xc7d948bb4d = _0x47c6e039a4[0].classList && _0x47c6e039a4[0].classList[0];
            if (_0xc7d948bb4d && _0x47c6e039a4.every((_0xffb83a5893) => _0xffb83a5893.classList.contains(_0xc7d948bb4d))) {
                _0x6eb1a5afed = `.${CSS.escape(_0xc7d948bb4d)}`;
            }
            return _0x47c6e039a4;
        }
        if (_0x11d940fd1d !== document) {
            _0x11d940fd1d = document;
            _0x6eb1a5afed = _0x8fba554725(3);
            return _0x75491b851d();
        }
        return _0x47c6e039a4;
    };
    const _0xda92bcf890 = (_0xb6ad5a9547) => {
        const _0x35dc39adc3 = _0x9ba6c8e573(_0xb6ad5a9547.textContent);
        const _0xc77b01fffe = (_0xed657eca7d(_0xb6ad5a9547, _0x8fba554725(48)).match(/PO-\d{3}-\d+-D\d+/i) || _0x35dc39adc3.match(/PO-\d{3}-\d+-D\d+/i) || [])[0] || _0x8fba554725(3);
        const _0x22d5147897 = (_0xed657eca7d(_0xb6ad5a9547, _0x8fba554725(49)).match(/PO-\d{3}-\d+/i) || _0x35dc39adc3.match(/PO-\d{3}-\d+/i) || [])[0] || _0x8fba554725(3);
        const _0xf67ce96d62 = _0x6d706f7714(_0xb6ad5a9547, _0x8fba554725(50));
        const _0x9c5bd010b5 = _0xf67ce96d62.map((_0x360018e75e) => {
            const _0xb14a202fae = _0x360018e75e.match(/^([^\s]+)/);
            return _0xb14a202fae ? _0xb14a202fae[1] : _0x360018e75e;
        }).filter(Boolean);
        const _0x27d1ab92e9 = _0x6d706f7714(_0xb6ad5a9547, _0x8fba554725(51)).map((_0xee7113e58a) => (_0xee7113e58a.match(/\d+/) || [_0xee7113e58a])[0]);
        const _0x7e924a1e25 = _0x6d706f7714(_0xb6ad5a9547, _0x8fba554725(54));
        const _0xc88eed5da2 = _0x6d706f7714(_0xb6ad5a9547, _0x8fba554725(55)).map((_0x077473da60) => _0x077473da60.replace(/^See more\s*/i, _0x8fba554725(3)).trim());
        const _0x2510b75363 = /^(\d+)\s+(?:image\(s\)(?:\s+and\s+video\(s\))?|video\(s\))$/i;
        const _0xcbf5411acd = Array.from(_0xb6ad5a9547.querySelectorAll(_0x8fba554725(44))).find((_0x27f84d8142) => {
            const _0xeff789ba5b = _0x9ba6c8e573(_0x27f84d8142.textContent);
            if (!_0x2510b75363.test(_0xeff789ba5b)) {
                return false;
            }
            return !Array.from(_0x27f84d8142.children).some((_0x5b1dec35e2) => _0x2510b75363.test(_0x9ba6c8e573(_0x5b1dec35e2.textContent)));
        });
        const _0xf420833d7f = _0x9ba6c8e573(_0xcbf5411acd && _0xcbf5411acd.textContent).match(_0x2510b75363);
        const _0x64c519dbac = _0xf420833d7f && Number(_0xf420833d7f[1]) > 0 ? _0x8fba554725(56) : _0x8fba554725(57);
        const _0xe94f0f055c = [];
        const _0x38f1586012 = _0x9c5bd010b5.length ? _0x9c5bd010b5 : [_0x8fba554725(57)];
        _0x38f1586012.forEach((_0x2df65721fc, _0x4e50da38e5) => {
            _0xe94f0f055c.push({
                key: `${_0xc77b01fffe || _0x22d5147897 || _0x8fba554725(58)}::${_0x2df65721fc}::${_0x4e50da38e5}`,
                returnId: _0xc77b01fffe || _0x8fba554725(59),
                orderId: _0x22d5147897 || _0x8fba554725(59),
                sku: _0x2df65721fc || _0x8fba554725(57),
                quantity: _0x27d1ab92e9[_0x4e50da38e5] || _0x27d1ab92e9[0] || _0x8fba554725(57),
                reason: _0x7e924a1e25[_0x4e50da38e5] || _0x7e924a1e25[0] || _0x8fba554725(57),
                buyerComment: _0xc88eed5da2[_0x4e50da38e5] || _0xc88eed5da2[0] || _0x8fba554725(57),
                image: _0x64c519dbac,
                date: _0x8fba554725(60),
                courier: _0x8fba554725(60),
                trackingNumber: _0x8fba554725(60),
                sellerNote: _0x8fba554725(60),
                detailStatus: _0x8fba554725(61)
            });
        });
        return { returnId: _0xc77b01fffe, orderId: _0x22d5147897, rows: _0xe94f0f055c, skuCount: _0x9c5bd010b5.length, html: _0xb6ad5a9547.outerHTML.slice(0, 160000) };
    };
    const _0x255f1de64a = (_0xe864fd8487) => {
        let _0x578c50c961 = _0xe864fd8487 && _0xe864fd8487.parentElement;
        while (_0x578c50c961 && _0x578c50c961 !== document.body) {
            const _0x513a5dae86 = getComputedStyle(_0x578c50c961);
            if (/(auto|scroll)/.test(_0x513a5dae86.overflowY) && _0x578c50c961.scrollHeight > _0x578c50c961.clientHeight + 20) {
                return _0x578c50c961;
            }
            _0x578c50c961 = _0x578c50c961.parentElement;
        }
        return document.scrollingElement || document.documentElement;
    };
    const _0x41799ebb09 = () => {
        const _0x188b40a34d = document.querySelector(_0x8fba554725(17));
        const _0x7e1515599c = _0x9ba6c8e573(_0x188b40a34d && _0x188b40a34d.textContent);
        const _0x6ba42a6afb = _0x7e1515599c.match(/Total\s+(\d+)\s+items/i);
        if (_0x6ba42a6afb) {
            return Number(_0x6ba42a6afb[1]);
        }
        const _0x76f7569532 = _0x9ba6c8e573(document.body.textContent);
        const _0x76ef7486fb = _0x76f7569532.match(/(\d+)\s+requests/i);
        if (_0x76ef7486fb) {
            return Number(_0x76ef7486fb[1]);
        }
        if (/(?:there (?:aren\x27t|are not) any return or refund requests|there are no return or refund requests|no (?:return |refund )?requests(?: found)?)/i.test(_0x76f7569532)) {
            return 0;
        }
        return null;
    };
    try {
        _0xc6c1920191 = _0x8fba554725(62);
        await _0x2c51689a3d(() => _0x214456df8d([_0x8fba554725(20), ..._0x7db2b2451e]), 18000, 200);
        _0xc6c1920191 = _0x8fba554725(63);
        await _0x7e3acf8361([_0x8fba554725(20), ..._0x7db2b2451e], _0x7db2b2451e, _0x8fba554725(38), _0x8fba554725(64));
        _0xc6c1920191 = _0x8fba554725(65);
        await _0x2c51689a3d(() => _0x214456df8d([_0x8fba554725(21), _0x8fba554725(22), _0xf046e72ab3]), 18000, 200);
        _0xc6c1920191 = _0x8fba554725(66);
        await _0x7e3acf8361([_0x8fba554725(21), _0x8fba554725(22), _0xf046e72ab3], [_0xf046e72ab3], _0x8fba554725(40), _0x8fba554725(67));
        _0xc6c1920191 = _0x8fba554725(68);
        await _0x1908bf8312();
        _0xc6c1920191 = _0x8fba554725(69);
        await _0x6dce0b659a();
        _0xc6c1920191 = _0x8fba554725(70);
        await _0x2c51689a3d(() => _0x75491b851d().length > 0 || _0x41799ebb09() === 0, 18000, 200);
        _0xc6c1920191 = _0x8fba554725(71);
        let _0x1d02e6a15a = _0x8fba554725(3);
        let _0x2bcf2a1dc4 = 0;
        const _0x25ad47b000 = Date.now();
        while (Date.now() - _0x25ad47b000 < 5000) {
            const _0xcccc672d32 = _0x75491b851d().map((_0xf77ff6c26e) => {
                const _0xd3add8e2b2 = _0x9ba6c8e573(_0xf77ff6c26e.textContent);
                return (_0xd3add8e2b2.match(/PO-\d{3}-\d+-D\d+/i) || [_0x8fba554725(3)])[0];
            }).filter(Boolean);
            const _0xb5947842f0 = `${_0x41799ebb09()}:${_0xcccc672d32.join(_0x8fba554725(72))}`;
            if (_0xb5947842f0 === _0x1d02e6a15a) {
                _0x2bcf2a1dc4 += 1;
            }
            else {
                _0x1d02e6a15a = _0xb5947842f0;
                _0x2bcf2a1dc4 = 0;
            }
            if (_0x2bcf2a1dc4 >= 4 && Date.now() - _0x25ad47b000 >= 1400) {
                break;
            }
            await _0x1ff7df57d8(250);
        }
        _0xc6c1920191 = _0x8fba554725(73);
        const _0xd5334ad1d9 = new Map();
        const _0x1bc808f621 = new Set();
        const _0x6ef7f87609 = [];
        const _0x1ead327fbd = new Set();
        const _0xdde53480f3 = (_0x17aa64ccaf, _0x95be7cad7c) => {
            if (_0x1ead327fbd.has(_0x17aa64ccaf)) {
                return;
            }
            _0x1ead327fbd.add(_0x17aa64ccaf);
            _0x6ef7f87609.push(_0x95be7cad7c);
        };
        let _0x254632ed05 = _0x75491b851d();
        const _0xde9736912d = _0x255f1de64a(_0x254632ed05[0]);
        let _0x0aed4841fb = 0;
        let _0xf7168773ff = -1;
        const _0x69d5b799bf = _0x41799ebb09();
        const _0x01bb8f24dc = _0x69d5b799bf === null ? null : Math.min(_0x69d5b799bf, 100);
        const _0x23ed9174a1 = _0x01bb8f24dc === null
            ? 100
            : Math.min(160, Math.max(60, Math.ceil(_0x01bb8f24dc * 1.4)));
        for (let _0x8e274781e5 = 0; _0x8e274781e5 < _0x23ed9174a1; _0x8e274781e5 += 1) {
            _0x254632ed05 = _0x75491b851d();
            for (const _0x3a004fbb1c of _0x254632ed05) {
                const _0x50eceee50a = _0x9ba6c8e573(_0x3a004fbb1c.textContent);
                const _0x7e047fe4e7 = (_0x50eceee50a.match(/PO-\d{3}-\d+-D\d+/i) || [])[0] || _0x8fba554725(3);
                if (_0x7e047fe4e7 && _0x1bc808f621.has(_0x7e047fe4e7)) {
                    continue;
                }
                const _0xccc23f601b = _0xda92bcf890(_0x3a004fbb1c);
                if (_0xccc23f601b.returnId) {
                    _0x1bc808f621.add(_0xccc23f601b.returnId);
                }
                for (const _0xb9cfeaacf0 of _0xccc23f601b.rows) {
                    _0xd5334ad1d9.set(_0xb9cfeaacf0.key, _0xb9cfeaacf0);
                }
                if (!_0xccc23f601b.returnId || !_0xccc23f601b.orderId) {
                    _0xdde53480f3(`CARD_CORE_FIELD_UNRECOGNIZED::${_0xccc23f601b.returnId || _0xccc23f601b.orderId || _0xccc23f601b.html.slice(0, 120)}`, {
                        type: _0x8fba554725(74),
                        message: _0x8fba554725(75),
                        url: location.href,
                        orderId: _0xccc23f601b.orderId,
                        html: _0xccc23f601b.html
                    });
                }
            }
            if (_0x1bc808f621.size === _0xf7168773ff) {
                _0x0aed4841fb += 1;
            }
            else {
                _0x0aed4841fb = 0;
                _0xf7168773ff = _0x1bc808f621.size;
            }
            if (_0x01bb8f24dc !== null && _0x1bc808f621.size >= _0x01bb8f24dc) {
                break;
            }
            const _0xedfa3b6155 = Math.max(0, _0xde9736912d.scrollHeight - _0xde9736912d.clientHeight);
            const _0x1a700668a0 = _0xde9736912d === document.scrollingElement || _0xde9736912d === document.documentElement
                ? window.scrollY
                : _0xde9736912d.scrollTop;
            if (_0x1a700668a0 >= _0xedfa3b6155 - 5) {
                if (_0x0aed4841fb >= 12) {
                    break;
                }
            }
            else {
                const _0xbf12e73811 = Math.min(_0xedfa3b6155, _0x1a700668a0 + Math.max(400, _0xde9736912d.clientHeight * 0.8));
                if (_0xde9736912d === document.scrollingElement || _0xde9736912d === document.documentElement) {
                    window.scrollTo(0, _0xbf12e73811);
                }
                else {
                    _0xde9736912d.scrollTop = _0xbf12e73811;
                }
            }
            await _0x1ff7df57d8(180);
        }
        if (_0xde9736912d === document.scrollingElement || _0xde9736912d === document.documentElement) {
            window.scrollTo(0, 0);
        }
        else {
            _0xde9736912d.scrollTop = 0;
        }
        if (_0x01bb8f24dc !== null && _0x1bc808f621.size < _0x01bb8f24dc) {
            const _0x06f2b48cfa = {
                type: _0x8fba554725(76),
                message: `页面显示 ${_0x01bb8f24dc} 个请求，但只稳定采集到 ${_0x1bc808f621.size} 个 Return ID。为避免产生不完整表格，本轮采集不写入结果。`,
                url: location.href,
                orderId: _0x8fba554725(3),
                html: _0x539e45b40e(_0x8fba554725(76), `expected=${_0x01bb8f24dc}; collected=${_0x1bc808f621.size}`)
            };
            return {
                ok: false,
                error: _0x06f2b48cfa.message,
                errorCode: _0x8fba554725(76),
                retryAction: _0x8fba554725(16),
                anomaly: _0x06f2b48cfa
            };
        }
        const _0x7ef400c2d5 = Array.from(_0xd5334ad1d9.values());
        if (_0x01bb8f24dc !== 0 && _0x7ef400c2d5.length === 0) {
            throw new Error(_0x8fba554725(77));
        }
        return {
            ok: true,
            rows: _0x7ef400c2d5,
            cardCount: _0x1bc808f621.size,
            totalCount: _0x69d5b799bf,
            anomalies: _0x6ef7f87609
        };
    }
    catch (_0xf4d9ac32ad) {
        const _0xdf9f7a69fa = _0xf4d9ac32ad.message || String(_0xf4d9ac32ad);
        const _0x4ebd93624e = Boolean(document.querySelector(_0x8fba554725(19)) ||
            document.querySelector(_0x8fba554725(17)) ||
            _0x433412e715().length > 0 ||
            _0x75491b851d().length > 0);
        const _0xdbaac5c27e = _0xf4d9ac32ad.code || _0xc6c1920191 || _0x8fba554725(78);
        const _0x90c99b0155 = _0xf4d9ac32ad.retryAction || (_0x4ebd93624e ? _0x8fba554725(16) : _0x8fba554725(79));
        return {
            ok: false,
            errorCode: _0xdbaac5c27e,
            retryAction: _0x90c99b0155,
            error: `${_0xdbaac5c27e}: ${_0xdf9f7a69fa}`,
            anomaly: {
                type: _0x8fba554725(80),
                message: `${_0xdbaac5c27e}: ${_0xdf9f7a69fa}`,
                url: location.href,
                orderId: _0x8fba554725(3),
                html: _0x539e45b40e(_0xdbaac5c27e, _0xdf9f7a69fa)
            }
        };
    }
}
async function extractOrderDetailPage(_0x2a885267d9) {const _0xf6dd312cfd=[[],[19],[64,67,82,93,31,87,90,69],[64,69,84,31,64,71,74,95,86,31,64,80,65,90,67,71,31,81,70,71,71,92,93,31,104,65,92,95,86,14,17,81,70,71,71,92,93,17,110],[80,92,70,65,90,86,65],[71,65,82,80,88,90,93,84,19,93,70,94,81,86,65],[64,91,90,67,94,86,93,71,19,80,92,93,85,90,65,94,86,87,19,82,71],[64,91,90,67,67,90,93,84,19,85,65,92,94],[64,91,90,67,67,90,93,84,19,82,87,87,65,86,64,64],[64,86,86,19,94,92,65,86],[82,87,87,19,82,19,93,92,71,86],[67,82,80,88,82,84,86,19,95,92,64,71,19,92,65,19,87,82,94,82,84,86],[85,90,95,86,19,82,19,80,95,82,90,94],[96,91,90,67,94,86,93,71,19,80,92,93,85,90,65,94,86,87,19,82,71],[96,86,95,95,86,65,19,93,92,71,86,64],[112,92,70,65,90,86,65],[103,65,82,80,88,90,93,84,19,93,70,94,81,86,65],[9],[35729,21350,35797,24822,38982,22839,20157,30280,24422,12338,39615,35826,25125,26067,26480,38499,29317,24626],[127,124,116,122,125,108,124,97,108,114,112,112,118,96,96,108,99,114,116,118],[35729,21350,35797,24822,38982,26393,36840,20822,27472,24075,35729,21350,20918,23434,12337],[114,87,87,19,82,19,93,92,71,86],[125,92],[118,97,97,124,97],[19,79,19],[96,118,127,127,118,97,108,125,124,103,118,96,108,126,124,119,102,127,118,108,126,122,96,96,122,125,116],[35729,21350,35797,24822,38982,26393,25165,20995,19,96,86,95,95,86,65,19,93,92,71,86,64,19,27154,22372,65343,26067,27878,30813,35735,26140,26067,20918,23434,36843,26140,38982,38737,32480,26551,21483,21285,65343,23396,27526,25402,19,118,97,97,124,97,19,35715,24422,12337],[96,123,122,99,126,118,125,103,108,119,114,103,118,108,102,125,97,118,112,124,116,125,122,105,118,119],[25165,20995,19,96,91,90,67,94,86,93,71,19,80,92,93,85,90,65,94,86,87,19,82,71,19,26676,31565,65343,20341,26393,31232,23465,35829,21016,23498,24231,26070,26412,12337],[112,124,102,97,122,118,97,108,101,114,127,102,118,108,102,125,97,118,112,124,116,125,122,105,118,119],[25165,20995,19,112,92,70,65,90,86,65,19,26676,31565,65343,20341,26393,31232,23465,35829,21016,29274,28018,21877,12337],[103,97,114,112,120,122,125,116,108,101,114,127,102,118,108,102,125,97,118,112,124,116,125,122,105,118,119],[25165,20995,19,103,65,82,80,88,90,93,84,19,93,70,94,81,86,65,19,26676,31565,65343,20341,26393,31232,23465,35829,21016,36835,21350,21444,12337],[96,123,122,99,126,118,125,103,108,126,124,119,102,127,118,108,96,103,97,102,112,103,102,97,118,108,102,125,97,118,112,124,116,125,122,105,118,119],[38982,38737,23403,22299,19,96,91,90,67,94,86,93,71,19,80,92,93,85,90,65,94,86,87,19,82,71,12338,112,92,70,65,90,86,65,19,25125,19,103,65,82,80,88,90,93,84,19,93,70,94,81,86,65,19,26676,31565,65343,20341,26393,35829,21016,20995,23487,25927,29274,28018,27154,22372,12337],[126,102,127,103,122,108,96,123,122,99,126,118,125,103,108,119,118,103,114,122,127],[57,57],[35729,21350,35797,24822,38982,38737,32480,26551,22299,31610,24502,26053,38343,20918,26393,23554,32473],[119,118,103,114,122,127,108,99,114,116,118,108,102,125,97,118,112,124,116,125,122,105,118,119],[31610,24502,21565,20222,26393,25165,20995,19,96,86,95,95,86,65,19,93,92,71,86,64,12338,96,91,90,67,94,86,93,71,19,80,92,93,85,90,65,94,86,87,19,82,71,12338,112,92,70,65,90,86,65,19,25125,19,103,65,82,80,88,90,93,84,19,93,70,94,81,86,65,12337],[119,118,103,114,122,127,108,124,97,119,118,97,108,122,119,108,125,124,103,108,112,124,125,117,122,97,126,118,119],[35797,24822,38982,19998,26393,30813,35735,20995,30429,26676,19,124,65,87,86,65,19,122,119,65343,20341,20222,25402,24416,21118,38982,38737,25571,21477,32480,26543,12337],[119,118,103,114,122,127,108,118,107,103,97,114,112,103,122,124,125,108,118,107,112,118,99,103,122,124,125]];const _0x95610ede3c=(_0x73be7547)=>String.fromCharCode(..._0xf6dd312cfd[_0x73be7547].map((_0x1afc0a92)=>_0x1afc0a92^51));
    const _0x0699ab6988 = (_0xc6eba447c4) => new Promise((_0xe008b4bf6f) => setTimeout(_0xe008b4bf6f, _0xc6eba447c4));
    const _0x8271b5115e = (_0x629cadc77c) => String(_0x629cadc77c || _0x95610ede3c(0)).replace(/\s+/g, _0x95610ede3c(1)).trim();
    const _0x34fddacdd5 = (_0x07b56048cc) => _0x8271b5115e(_0x07b56048cc).toLowerCase();
    const _0x48ba58e2d7 = (_0x4b7fb8d152, _0xf041168e98) => {
        const _0x4f06f2b822 = _0x34fddacdd5(_0xf041168e98);
        return Array.from(_0x4b7fb8d152.querySelectorAll(_0x95610ede3c(2))).filter((_0x95c29d1141) => {
            if (_0x34fddacdd5(_0x95c29d1141.textContent) !== _0x4f06f2b822) {
                return false;
            }
            return !Array.from(_0x95c29d1141.children).some((_0xb136d496a7) => _0x34fddacdd5(_0xb136d496a7.textContent) === _0x4f06f2b822);
        });
    };
    const _0x0caf902bad = (_0xf52298670b) => {
        _0xf52298670b.querySelectorAll(_0x95610ede3c(3)).forEach((_0xabce5e7f2e) => _0xabce5e7f2e.remove());
    };
    const _0x2468fe9c2b = (_0x11c58f209f, _0x852c938db1) => {
        const _0xc9cf1069be = _0x48ba58e2d7(_0x11c58f209f, _0x852c938db1)[0];
        if (!_0xc9cf1069be) {
            return _0x95610ede3c(0);
        }
        const _0x960637d2c5 = new Set([
            _0x95610ede3c(4),
            _0x95610ede3c(5),
            _0x95610ede3c(6),
            _0x95610ede3c(7),
            _0x95610ede3c(8),
            _0x95610ede3c(9),
            _0x95610ede3c(10),
            _0x95610ede3c(11),
            _0x95610ede3c(12)
        ]);
        let _0x9e6609796f = _0xc9cf1069be.parentElement;
        for (let _0x9d50dad828 = 0; _0x9e6609796f && _0x9e6609796f !== _0x11c58f209f.parentElement && _0x9d50dad828 < 7; _0x9d50dad828 += 1, _0x9e6609796f = _0x9e6609796f.parentElement) {
            const _0xe512e60be8 = [];
            if (_0x9e6609796f.matches && _0x9e6609796f.matches(_0x95610ede3c(2))) {
                _0xe512e60be8.push(_0x9e6609796f);
            }
            _0xe512e60be8.push(..._0x9e6609796f.querySelectorAll(_0x95610ede3c(2)));
            const _0xb4de960dcb = _0xe512e60be8.filter((_0xb978ecaa4e, _0x9ea167e8ed) => {
                if (_0xe512e60be8.indexOf(_0xb978ecaa4e) !== _0x9ea167e8ed) {
                    return false;
                }
                const _0x7acc01f60d = _0x8271b5115e(_0xb978ecaa4e.textContent);
                if (!_0x7acc01f60d) {
                    return false;
                }
                return !Array.from(_0xb978ecaa4e.children).some((_0x882807df78) => _0x8271b5115e(_0x882807df78.textContent));
            });
            let _0x685dd81e1e;
            const _0x21b410617d = _0xb4de960dcb.indexOf(_0xc9cf1069be);
            if (_0x21b410617d >= 0) {
                _0x685dd81e1e = _0xb4de960dcb.slice(_0x21b410617d + 1);
            }
            else {
                _0x685dd81e1e = _0xb4de960dcb.filter((_0x80ed94834a) => Boolean(_0xc9cf1069be.compareDocumentPosition(_0x80ed94834a) & Node.DOCUMENT_POSITION_FOLLOWING));
            }
            const _0x964aad6082 = _0x685dd81e1e.map((_0x9e869d3ba4) => _0x8271b5115e(_0x9e869d3ba4.textContent)).filter((_0x13af8ac9b2) => {
                const _0x09d3476c27 = _0x34fddacdd5(_0x13af8ac9b2);
                return _0x13af8ac9b2 && _0x13af8ac9b2.length <= 300 && !_0x960637d2c5.has(_0x09d3476c27);
            });
            if (_0x34fddacdd5(_0x852c938db1) === _0x95610ede3c(5)) {
                const _0x9e1f6b9846 = _0x964aad6082.find((_0xe35d6c1a79) => /\d{7,}/.test(_0xe35d6c1a79) || (/^[A-Z0-9-]{6,}$/i.test(_0xe35d6c1a79) && /\d/.test(_0xe35d6c1a79)));
                if (_0x9e1f6b9846) {
                    return _0x9e1f6b9846;
                }
            }
            else if (_0x34fddacdd5(_0x852c938db1) === _0x95610ede3c(4)) {
                const _0xd76a83c1e4 = _0x964aad6082.find((_0x74fcb4b0d2) => /[A-Z]/i.test(_0x74fcb4b0d2) && !/^\d+$/.test(_0x74fcb4b0d2) && !/^(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\b/i.test(_0x74fcb4b0d2));
                if (_0xd76a83c1e4) {
                    return _0xd76a83c1e4;
                }
            }
            else if (_0x964aad6082.length) {
                return _0x964aad6082[0];
            }
        }
        return _0x95610ede3c(0);
    };
    const _0x829ad6ccfd = (_0x430b3dc7dc) => {
        const _0xc51fad1c22 = _0x48ba58e2d7(_0x430b3dc7dc, _0x95610ede3c(13))[0];
        if (!_0xc51fad1c22) {
            return _0x95610ede3c(0);
        }
        const _0x5163fba391 = /\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2},\s+\d{4},\s+\d{1,2}:\d{2}(?::\d{2})?\s+(?:am|pm)(?:\s+[A-Z]{2,8}(?:\(UTC[+-]\d{1,2}\))?)?\b/i;
        const _0xcd22fbe795 = _0x8271b5115e(_0x2468fe9c2b(_0x430b3dc7dc, _0x95610ede3c(13)));
        const _0x0c1706b8ee = _0xcd22fbe795.match(_0x5163fba391);
        if (_0x0c1706b8ee) {
            return _0x0c1706b8ee[0];
        }
        const _0xbd5ebd1f05 = Array.from(_0x430b3dc7dc.querySelectorAll(_0x95610ede3c(2)))
            .filter((_0xe668b49467) => Boolean(_0xc51fad1c22.compareDocumentPosition(_0xe668b49467) & Node.DOCUMENT_POSITION_FOLLOWING))
            .map((_0x65d5c26e1b) => _0x8271b5115e(_0x65d5c26e1b.textContent))
            .filter((_0x08021cee0e) => _0x08021cee0e && _0x08021cee0e.length <= 160);
        for (const _0x6f86f48a92 of _0xbd5ebd1f05) {
            const _0x6fa7fe7778 = _0x6f86f48a92.match(_0x5163fba391);
            if (_0x6fa7fe7778) {
                return _0x6fa7fe7778[0];
            }
        }
        return _0x95610ede3c(0);
    };
    const _0xfc60103479 = (_0xc1d2acff39, _0x9b64bd9251, _0x742bee98c9 = 10) => {
        let _0x606a70adf6 = _0xc1d2acff39 && _0xc1d2acff39.parentElement;
        for (let _0x7f2bb3295a = 0; _0x606a70adf6 && _0x7f2bb3295a < _0x742bee98c9; _0x7f2bb3295a += 1, _0x606a70adf6 = _0x606a70adf6.parentElement) {
            if (_0x9b64bd9251(_0x606a70adf6)) {
                return _0x606a70adf6;
            }
        }
        return null;
    };
    const _0xa2391020c5 = async () => {
        const _0xc4c74b55c3 = Date.now();
        let _0x28fe4e1bcb = _0x95610ede3c(0);
        let _0x28b46ac842 = 0;
        while (Date.now() - _0xc4c74b55c3 < 12000) {
            const _0x630c2410e5 = _0x8271b5115e(document.body && document.body.textContent);
            if (/sign in|log in|verification required|access denied/i.test(_0x630c2410e5) && !_0x630c2410e5.includes(_0x95610ede3c(14))) {
                return { accessProblem: true };
            }
            const _0xaeef2b8b8d = _0x48ba58e2d7(document, _0x95610ede3c(14)).length;
            const _0xfdb34379e5 = _0x48ba58e2d7(document, _0x95610ede3c(13)).length;
            const _0x41e2546c8b = _0x48ba58e2d7(document, _0x95610ede3c(15)).length;
            const _0xb04b621c17 = _0x48ba58e2d7(document, _0x95610ede3c(16)).length;
            const _0xbe97f35f64 = [_0xaeef2b8b8d, _0xfdb34379e5, _0x41e2546c8b, _0xb04b621c17, _0x630c2410e5.length].join(_0x95610ede3c(17));
            if (_0xbe97f35f64 === _0x28fe4e1bcb) {
                _0x28b46ac842 += 1;
            }
            else {
                _0x28b46ac842 = 0;
            }
            _0x28fe4e1bcb = _0xbe97f35f64;
            const _0x1481cffc51 = Date.now() - _0xc4c74b55c3;
            const _0x188291cda8 = _0xaeef2b8b8d > 0;
            const _0xaeca34c9f0 = _0xfdb34379e5 > 0 || _0x41e2546c8b > 0 || _0xb04b621c17 > 0;
            if (_0x188291cda8 && _0xaeca34c9f0 && _0x28b46ac842 >= 3 && _0x1481cffc51 >= 900) {
                return { accessProblem: false };
            }
            if ((_0x188291cda8 || _0xaeca34c9f0) && _0x28b46ac842 >= 4 && _0x1481cffc51 >= 4500) {
                return { accessProblem: false, partialSignals: true };
            }
            await _0x0699ab6988(300);
        }
        return { accessProblem: false, timedOut: true };
    };
    try {
        const _0xdefd7a417a = await _0xa2391020c5();
        const _0x7a6a62ddc2 = _0x8271b5115e(document.body && document.body.textContent);
        const _0x41689b0589 = [];
        if (_0xdefd7a417a.accessProblem) {
            return {
                ok: false,
                error: _0x95610ede3c(18),
                anomalies: [{
                        type: _0x95610ede3c(19),
                        message: _0x95610ede3c(20),
                        url: location.href,
                        orderId: _0x2a885267d9,
                        html: document.documentElement.outerHTML.slice(0, 160000)
                    }]
            };
        }
        const _0xdaf92c098d = _0x48ba58e2d7(document, _0x95610ede3c(14))[0];
        let _0x4eca0b5b22 = null;
        if (_0xdaf92c098d) {
            _0x4eca0b5b22 = _0xfc60103479(_0xdaf92c098d, (_0x2f6d3ac970) => {
                const _0xfcfbfcc752 = _0x8271b5115e(_0x2f6d3ac970.textContent);
                return _0xfcfbfcc752.includes(_0x95610ede3c(14)) && _0xfcfbfcc752.includes(_0x95610ede3c(21)) && _0xfcfbfcc752.length < 20000;
            }, 8);
        }
        let _0x1b236f1615 = _0x4eca0b5b22 ? _0x95610ede3c(22) : _0x95610ede3c(23);
        if (_0x4eca0b5b22) {
            const _0xf8d8b26196 = /\b(?:GLS|DHL|DPD)(?=\b|\d)/i;
            const _0x80fa741e88 = Array.from(_0x4eca0b5b22.querySelectorAll(_0x95610ede3c(2))).filter((_0xe49c5faa70) => {
                const _0x15031b6ce2 = _0x8271b5115e(_0xe49c5faa70.textContent);
                if (!_0xf8d8b26196.test(_0x15031b6ce2)) {
                    return false;
                }
                return !Array.from(_0xe49c5faa70.children).some((_0x56ddebf9cf) => _0xf8d8b26196.test(_0x8271b5115e(_0x56ddebf9cf.textContent)));
            });
            const _0x15d29a0846 = [];
            for (const _0x6677ba7804 of _0x80fa741e88) {
                const _0x2c1b721d4e = _0x8271b5115e(_0x6677ba7804.textContent);
                if (_0x2c1b721d4e && !_0x15d29a0846.includes(_0x2c1b721d4e)) {
                    _0x15d29a0846.push(_0x2c1b721d4e);
                }
            }
            if (_0x15d29a0846.length) {
                _0x1b236f1615 = _0x15d29a0846.join(_0x95610ede3c(24));
            }
        }
        else {
            _0x41689b0589.push({
                type: _0x95610ede3c(25),
                message: _0x95610ede3c(26),
                url: location.href,
                orderId: _0x2a885267d9,
                html: document.documentElement.outerHTML.slice(0, 160000)
            });
        }
        const _0x300f611723 = _0x48ba58e2d7(document, _0x95610ede3c(13));
        const _0x6ce1accca9 = _0x48ba58e2d7(document, _0x95610ede3c(15));
        const _0xcf215bac85 = _0x48ba58e2d7(document, _0x95610ede3c(16));
        const _0x2e890fd96d = [];
        const _0x6dbde45b59 = new Set();
        for (const _0x5b234d49dc of [..._0x300f611723, ..._0x6ce1accca9, ..._0xcf215bac85]) {
            const _0xa9c5190a8a = _0xfc60103479(_0x5b234d49dc, (_0x43e0635946) => {
                const _0xc5d708fe20 = _0x8271b5115e(_0x43e0635946.textContent);
                const _0xd4e80ef2ac = [
                    _0xc5d708fe20.includes(_0x95610ede3c(13)),
                    _0xc5d708fe20.includes(_0x95610ede3c(15)),
                    _0xc5d708fe20.includes(_0x95610ede3c(16))
                ].filter(Boolean).length;
                return _0xd4e80ef2ac >= 2 && _0xc5d708fe20.length < 80000;
            }, 9);
            if (_0xa9c5190a8a && !_0x6dbde45b59.has(_0xa9c5190a8a)) {
                _0x6dbde45b59.add(_0xa9c5190a8a);
                _0x2e890fd96d.push(_0xa9c5190a8a);
            }
        }
        const _0x76bf46dcad = [];
        const _0x70e02ae2f5 = [];
        const _0xfedbd6bfaf = [];
        let _0x0402297bae = false;
        let _0x4eb6f74e89 = false;
        let _0xe11a27862b = false;
        for (const _0x422ba5330e of _0x2e890fd96d) {
            const _0xd2fea7e63c = _0x48ba58e2d7(_0x422ba5330e, _0x95610ede3c(13)).length > 0;
            const _0x234756a6c2 = _0x48ba58e2d7(_0x422ba5330e, _0x95610ede3c(15)).length > 0;
            const _0xa8ddd0c1ef = _0x48ba58e2d7(_0x422ba5330e, _0x95610ede3c(16)).length > 0;
            const _0xe4435b8882 = _0xd2fea7e63c ? _0x829ad6ccfd(_0x422ba5330e) : _0x95610ede3c(0);
            let _0x578210e743 = _0x234756a6c2 ? _0x2468fe9c2b(_0x422ba5330e, _0x95610ede3c(15)) : _0x95610ede3c(0);
            let _0x6b4a951d1b = _0xa8ddd0c1ef ? _0x2468fe9c2b(_0x422ba5330e, _0x95610ede3c(16)) : _0x95610ede3c(0);
            if (_0x578210e743) {
                _0x578210e743 = _0x578210e743.replace(/^Courier\s*/i, _0x95610ede3c(0)).trim();
            }
            if (_0x6b4a951d1b) {
                const _0x15e36014e2 = _0x6b4a951d1b.match(/\d{7,}/);
                const _0xb5982e5a82 = _0x6b4a951d1b.match(/[A-Z0-9][A-Z0-9-]{5,}/i);
                _0x6b4a951d1b = _0x15e36014e2 ? _0x15e36014e2[0] : (_0xb5982e5a82 ? _0xb5982e5a82[0] : _0x6b4a951d1b);
            }
            if (_0xe4435b8882 && !_0x76bf46dcad.includes(_0xe4435b8882)) {
                _0x76bf46dcad.push(_0xe4435b8882);
            }
            if (_0x578210e743 && !_0x70e02ae2f5.includes(_0x578210e743)) {
                _0x70e02ae2f5.push(_0x578210e743);
            }
            if (_0x6b4a951d1b && !_0xfedbd6bfaf.includes(_0x6b4a951d1b)) {
                _0xfedbd6bfaf.push(_0x6b4a951d1b);
            }
            if (_0xd2fea7e63c && !_0xe4435b8882) {
                _0x0402297bae = true;
                _0x41689b0589.push({
                    type: _0x95610ede3c(27),
                    message: _0x95610ede3c(28),
                    url: location.href,
                    orderId: _0x2a885267d9,
                    html: _0x422ba5330e.outerHTML.slice(0, 160000)
                });
            }
            if (_0x234756a6c2 && !_0x578210e743) {
                _0x4eb6f74e89 = true;
                _0x41689b0589.push({
                    type: _0x95610ede3c(29),
                    message: _0x95610ede3c(30),
                    url: location.href,
                    orderId: _0x2a885267d9,
                    html: _0x422ba5330e.outerHTML.slice(0, 160000)
                });
            }
            if (_0xa8ddd0c1ef && !_0x6b4a951d1b) {
                _0xe11a27862b = true;
                _0x41689b0589.push({
                    type: _0x95610ede3c(31),
                    message: _0x95610ede3c(32),
                    url: location.href,
                    orderId: _0x2a885267d9,
                    html: _0x422ba5330e.outerHTML.slice(0, 160000)
                });
            }
        }
        if ((_0x300f611723.length || _0x6ce1accca9.length || _0xcf215bac85.length) && _0x2e890fd96d.length === 0) {
            if (_0x300f611723.length) {
                _0x0402297bae = true;
            }
            if (_0x6ce1accca9.length) {
                _0x4eb6f74e89 = true;
            }
            if (_0xcf215bac85.length) {
                _0xe11a27862b = true;
            }
            _0x41689b0589.push({
                type: _0x95610ede3c(33),
                message: _0x95610ede3c(34),
                url: location.href,
                orderId: _0x2a885267d9,
                html: document.documentElement.outerHTML.slice(0, 160000)
            });
        }
        if (_0x2e890fd96d.length > 1) {
            _0x41689b0589.push({
                type: _0x95610ede3c(35),
                message: `订单详情存在 ${_0x2e890fd96d.length} 个物流模块，已按页面顺序合并。`,
                url: location.href,
                orderId: _0x2a885267d9,
                html: _0x2e890fd96d.map((_0xb8b0a5a4b5) => _0xb8b0a5a4b5.outerHTML).join(_0x95610ede3c(36)).slice(0, 160000)
            });
        }
        if (_0xdefd7a417a.timedOut && !_0xdaf92c098d && !_0x300f611723.length && !_0x6ce1accca9.length && !_0xcf215bac85.length) {
            return {
                ok: false,
                error: _0x95610ede3c(37),
                anomalies: [{
                        type: _0x95610ede3c(38),
                        message: _0x95610ede3c(39),
                        url: location.href,
                        orderId: _0x2a885267d9,
                        html: document.documentElement.outerHTML.slice(0, 160000)
                    }]
            };
        }
        const _0x12d8a92be9 = _0x7a6a62ddc2.includes(_0x2a885267d9) || location.href.includes(encodeURIComponent(_0x2a885267d9)) || location.href.includes(_0x2a885267d9);
        if (!_0x12d8a92be9) {
            _0x41689b0589.push({
                type: _0x95610ede3c(40),
                message: _0x95610ede3c(41),
                url: location.href,
                orderId: _0x2a885267d9,
                html: document.documentElement.outerHTML.slice(0, 160000)
            });
        }
        return {
            ok: true,
            date: _0x76bf46dcad.length ? _0x76bf46dcad.join(_0x95610ede3c(24)) : (_0x0402297bae ? _0x95610ede3c(23) : _0x95610ede3c(22)),
            courier: _0x70e02ae2f5.length ? _0x70e02ae2f5.join(_0x95610ede3c(24)) : (_0x4eb6f74e89 ? _0x95610ede3c(23) : _0x95610ede3c(22)),
            trackingNumber: _0xfedbd6bfaf.length ? _0xfedbd6bfaf.join(_0x95610ede3c(24)) : (_0xe11a27862b ? _0x95610ede3c(23) : _0x95610ede3c(22)),
            sellerNote: _0x1b236f1615,
            anomalies: _0x41689b0589
        };
    }
    catch (_0xe21bd21cce) {
        return {
            ok: false,
            error: _0xe21bd21cce.message || String(_0xe21bd21cce),
            anomalies: [{
                    type: _0x95610ede3c(42),
                    message: _0xe21bd21cce.message || String(_0xe21bd21cce),
                    url: location.href,
                    orderId: _0x2a885267d9,
                    html: document.documentElement.outerHTML.slice(0, 160000)
                }]
        };
    }
}
chrome.action.onClicked.addListener((_0x264104ef5d) => {
    _0x5a9bcbb65e(_0x264104ef5d).catch(() => { });
});
chrome.runtime.onInstalled.addListener(() => {
    _0x8f9ffeab74().then((_0x1b79d1eafe) => chrome.storage.local.set({ [_0xd4b2b9cc69]: _0x1b79d1eafe })).catch(() => { });
});
chrome.runtime.onStartup.addListener(() => {
    _0x7cdfcc76d4();
});
chrome.runtime.onMessage.addListener((_0xbc5fc1e9bb, _0xee8e94737b, _0x29ea254e72) => {
    (async () => {
        switch (_0xbc5fc1e9bb && _0xbc5fc1e9bb.type) {
            case _0x9f515ee8ec(106): {
                const _0xa6f608ac04 = _0xee8e94737b && _0xee8e94737b.tab && _0xee8e94737b.tab.windowId;
                if (Number.isInteger(_0xa6f608ac04)) {
                    await _0x548b514436({ panelWindowId: _0xa6f608ac04 });
                }
                _0x7cdfcc76d4();
                return { ok: true };
            }
            case _0x9f515ee8ec(107):
                await _0xd189e33656();
                return { ok: true };
            case _0x9f515ee8ec(108):
                await _0x46cc719cad();
                return { ok: true };
            case _0x9f515ee8ec(109):
                await _0xbcc3a4e67a();
                return { ok: true };
            case _0x9f515ee8ec(110):
                _0x7cdfcc76d4();
                return { ok: true };
            case _0x9f515ee8ec(111):
                await _0xfa270f35b1(true);
                return { ok: true };
            case _0x9f515ee8ec(112):
                await _0xc34abfb535();
                return { ok: true };
            case _0x9f515ee8ec(113):
                await _0x2fc653af46(_0xbc5fc1e9bb.url);
                return { ok: true };
            default:
                return { ok: false, error: _0x9f515ee8ec(114) };
        }
    })().then(_0x29ea254e72).catch((_0xd5c5e1198b) => {
        _0x29ea254e72({ ok: false, error: _0xd5c5e1198b.message || String(_0xd5c5e1198b) });
    });
    return true;
});
chrome.tabs.onActivated.addListener((_0xb21485984f) => {
    _0x8f9ffeab74().then((_0xa72c6eda72) => {
        if (![_0x9f515ee8ec(5), _0x9f515ee8ec(6), _0x9f515ee8ec(7)].includes(_0xa72c6eda72.status)) {
            return;
        }
        if (!Number.isInteger(_0xa72c6eda72.listTabId) || !Number.isInteger(_0xa72c6eda72.listWindowId)) {
            return;
        }
        if (_0xb21485984f.windowId === _0xa72c6eda72.listWindowId && _0xb21485984f.tabId !== _0xa72c6eda72.listTabId) {
            _0x56d70f3dd8(_0x9f515ee8ec(19), false).catch(() => { });
        }
    }).catch(() => { });
});
chrome.tabs.onUpdated.addListener((_0xe273477645, _0x152f056805) => {
    if (_0x152f056805.status !== _0x9f515ee8ec(27)) {
        return;
    }
    _0x8f9ffeab74().then((_0xeffa9696b4) => {
        if (_0xe273477645 === _0xeffa9696b4.listTabId || _0xe273477645 === _0xeffa9696b4.detailTabId) {
            _0x7cdfcc76d4();
        }
    }).catch(() => { });
});
chrome.tabs.onRemoved.addListener((_0xcab0bfffe7) => {
    _0x8f9ffeab74().then(async (_0xd8defd79ca) => {
        if (_0xcab0bfffe7 === _0xd8defd79ca.listTabId) {
            await _0x548b514436({ listTabId: null, listWindowId: null });
            if ([_0x9f515ee8ec(5), _0x9f515ee8ec(6), _0x9f515ee8ec(7)].includes(_0xd8defd79ca.status)) {
                await _0x8ba21f0e52(_0x9f515ee8ec(23), _0x9f515ee8ec(115));
                _0x7cdfcc76d4();
            }
        }
        if (_0xcab0bfffe7 === _0xd8defd79ca.detailTabId) {
            await _0x548b514436({ detailTabId: null });
            if ([_0x9f515ee8ec(8), _0x9f515ee8ec(9)].includes(_0xd8defd79ca.status) && !_0xd8defd79ca.pauseRequested) {
                await _0x8ba21f0e52(_0x9f515ee8ec(23), _0x9f515ee8ec(116));
                _0x7cdfcc76d4();
            }
        }
    }).catch(() => { });
});
chrome.windows.onFocusChanged.addListener((_0x515d310d11) => {
    if (!Number.isInteger(_0x515d310d11) || _0x515d310d11 < 0) {
        return;
    }
    _0x8f9ffeab74().then(async (_0xcf94a60d90) => {
        if ([_0x9f515ee8ec(5), _0x9f515ee8ec(6), _0x9f515ee8ec(7)].includes(_0xcf94a60d90.status)) {
            return;
        }
        const _0xfc27f776bf = await _0xf50e17f2a6(_0x515d310d11);
        if (_0xfc27f776bf && _0xfc27f776bf.type === _0x9f515ee8ec(20) && _0x515d310d11 !== _0xcf94a60d90.sourceWindowId) {
            await _0x548b514436({ sourceWindowId: _0x515d310d11 });
        }
    }).catch(() => { });
});
chrome.windows.onRemoved.addListener((_0x67ac586c27) => {
    _0x8f9ffeab74().then(async (_0xaa3271d75a) => {
        if (_0x67ac586c27 === _0xaa3271d75a.sourceWindowId || _0x67ac586c27 === _0xaa3271d75a.listWindowId) {
            await _0x548b514436({
                sourceWindowId: _0x67ac586c27 === _0xaa3271d75a.sourceWindowId ? null : _0xaa3271d75a.sourceWindowId,
                listWindowId: _0x67ac586c27 === _0xaa3271d75a.listWindowId ? null : _0xaa3271d75a.listWindowId
            });
        }
        if (_0x67ac586c27 !== _0xaa3271d75a.panelWindowId) {
            return;
        }
        await _0x156b76cd4c((_0x0cfaf51fcb) => {
            _0x0cfaf51fcb.panelWindowId = null;
            if (_0x2b73cce789.has(_0x0cfaf51fcb.status) && _0x0cfaf51fcb.status !== _0x9f515ee8ec(10)) {
                _0x0cfaf51fcb.pauseRequested = true;
                _0x0cfaf51fcb.closePanelRequested = true;
                const _0xec63415b04 = [_0x9f515ee8ec(5), _0x9f515ee8ec(6), _0x9f515ee8ec(7)].includes(_0x0cfaf51fcb.status);
                if (!_0xec63415b04) {
                    _0x0cfaf51fcb.status = _0x9f515ee8ec(9);
                }
                _0x0cfaf51fcb.currentStep = _0x0cfaf51fcb.currentOrderId || (_0xec63415b04 ? _0x9f515ee8ec(53) : _0x9f515ee8ec(54));
                _0x0cfaf51fcb.logs.push({
                    time: Date.now(),
                    level: _0x9f515ee8ec(23),
                    message: _0xec63415b04 ? _0x9f515ee8ec(117) : _0x9f515ee8ec(118)
                });
                if (_0x0cfaf51fcb.logs.length > _0x91aee3b5c7) {
                    _0x0cfaf51fcb.logs.splice(0, _0x0cfaf51fcb.logs.length - _0x91aee3b5c7);
                }
            }
        });
        _0x7cdfcc76d4();
    }).catch(() => { });
});
_0x8f9ffeab74().then((_0xbb4f8378fa) => {
    chrome.storage.local.set({ [_0xd4b2b9cc69]: _0xbb4f8378fa }).catch(() => { });
    if (_0x2b73cce789.has(_0xbb4f8378fa.status)) {
        _0x7cdfcc76d4();
    }
}).catch(() => { });
