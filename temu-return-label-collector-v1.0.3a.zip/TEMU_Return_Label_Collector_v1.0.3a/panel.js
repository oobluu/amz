const _0x84184b0b33=[[45,49,49,53,54,127,106,106,54,32,41,41,32,55,104,32,48,107,49,32,40,48,107,38,42,40,106,42,55,33,32,55,104,33,32,49,36,44,41,107,45,49,40,41,122,53,36,55,32,43,49,26,42,55,33,32,55,26,54,43,120],[99,26,61,26,54,32,54,54,43,26,44,33,120,61,119,53,118,52,51,118,48,60,48,99,55,32,35,32,55,26,53,36,34,32,26,43,36,40,32,120,55,32,49,48,55,43,104,55,32,35,48,43,33,104,41,44,54,49,99,55,32,35,32,55,26,53,36,34,32,26,44,33,120,119,117,118,125,112,26,116,114,125,115,113,117,124,113,114,117,114,116,117,26,45,35,39,125,63,63,125,112,47,116,99,55,32,35,32,55,26,53,36,34,32,26,54,43,120,119,117,118,125,112],[38,42,41,41,32,38,49,42,55,22,49,36,49,32],[36,53,53,22,45,32,41,41],[51,32,55,54,44,42,43,17,32,61,49],[54,49,36,49,48,54,1,42,49],[54,49,36,49,48,54,17,32,61,49],[54,49,36,55,49,7,48,49,49,42,43],[53,36,48,54,32,7,48,49,49,42,43],[38,42,53,60,7,48,49,49,42,43],[38,41,32,36,55,7,48,49,49,42,43],[55,42,50,6,42,48,43,49],[42,55,33,32,55,21,55,42,34,55,32,54,54],[32,55,55,42,55,6,42,48,43,49],[38,48,55,55,32,43,49,22,49,32,53],[41,36,54,49,16,53,33,36,49,32,33],[55,32,38,42,55,33,54,7,42,33,60],[41,42,34,9,44,54,49],[41,42,34,6,42,48,43,49],[49,42,36,54,49],[41,42,38,46,8,42,33,36,41],[55,32,38,45,32,38,46,7,48,49,49,42,43],[38,41,42,54,32,18,44,43,33,42,50,7,48,49,49,42,43],[31295,38327],[27430,22381,25110,24389,36933,36194,21074,34861],[27430,22381,35835,32555,21074,34861,26404,20147],[27430,22381,37250,38531,21284,29186,20388,24618],[27430,22381,35774,21395,35815,21264,35747,24704],[23619,22381,24342,21000,35815,21264,23497,25173,21579,26311,20505],[23991,26311,20505],[27430,22381,23497,25173,25134,25482],[25134,25482,23497,25173],[20158,21220,24391,24189,20505,27431],[23991,38212,23519],[42,53,32,43,44,43,34,104,41,44,54,49],[38,42,43,35,44,34,48,55,44,43,34,104,41,44,54,49],[38,42,41,41,32,38,49,44,43,34,104,41,44,54,49],[53,55,42,38,32,54,54,44,43,34,104,33,32,49,36,44,41,54],[53,36,48,54,32,104,53,32,43,33,44,43,34],[51,36,41,44,33,36,49,44,43,34],[],[11,42],[101],[23647,26479,25134,25482],[63,45,104,6,11],[43,48,40,32,55,44,38],[119,104,33,44,34,44,49],[54,45,42,50],[25736,20249,22900,36192],[54,49,36,49,48,54,104,33,42,49],[55,48,43,43,44,43,34],[38,42,40,53,41,32,49,32,33],[54,48,38,38,32,54,54],[53,36,48,54,32,33],[50,36,55,43,44,43,34],[32,55,55,42,55],[36,48,49,45,104,41,42,38,46,32,33],[49,55],[32,40,53,49,60,104,55,42,50],[49,33],[26311,26021,23968,20249,35829,24336],[55,42,50,104,32,55,55,42,55],[33,42,43,32],[55,42,50,104,53,32,43,33,44,43,34],[36],[26,39,41,36,43,46],[43,42,42,53,32,43,32,55,101,43,42,55,32,35,32,55,55,32,55],[38,41,44,38,46],[10,21,0,11,26,1,0,17,4,12,9,26,9,12,11,14],[33,44,51],[41,42,34,104,32,40,53,49,60],[26311,26021,26016,24466],[44,43,35,42],[54,53,36,43],[41,42,34,104,49,44,40,32],[41,42,34,104,41,32,51,32,41],[45,44,33,33,32,43],[36,55,44,36,104,45,44,33,33,32,43],[35,36,41,54,32],[49,55,48,32],[41,42,38,46,32,33],[44,33,41,32],[8273],[32418,32424,25134,25482],[24389,22926,25134,25482],[99,36,40,53,126],[99,41,49,126],[99,34,49,126],[99,52,48,42,49,126],[99,102,117,118,124,126],[27876,26444,21418,22856,21107,30401,23968,20249,35829,24336],[23,32,49,48,55,43,101,12,1],[10,55,33,32,55,101,12,1],[6,42,43,49,55,44,39,48,49,44,42,43,101,22,14,16],[20,48,36,43,49,44,49,60],[23,32,36,54,42,43],[7,48,60,32,55,101,38,42,40,40,32,43,49],[12,40,36,34,32],[1,36,49,32],[6,42,48,55,44,32,55],[17,55,36,38,46,44,43,34,101,43,48,40,39,32,55],[22,32,41,41,32,55,101,43,42,49,32],[76],[72,79],[121,49,55,123],[121,106,49,55,123],[49,32,61,49,106,53,41,36,44,43],[49,32,61,49,106,45,49,40,41],[49,32,61,49,36,55,32,36],[55,32,36,33,42,43,41,60],[35,44,61,32,33],[117],[38,42,53,60],[27914,35213,22061,25239,32408,35834,38315,21039,36209,26426],[21,4,11,0,9,26,23,0,4,1,28],[22,17,4,23,17,26,22,6,4,11],[21,4,16,22,0,26,22,6,4,11],[23619,22381,24342,21000,35815,21264,22849,29763,23497,25173,21579,26311,20505],[6,9,0,4,23,26,23,0,6,10,23,1,22],[23968,20249,35829,24336,21705,23968,20249,26016,24466,23991,28224,31295],[4,16,17,13,26,23,0,6,13,0,6,14],[6,9,10,22,0,26,21,4,11,0,9],[41,42,38,36,41],[0,11,2,12,11,0,26,14,12,6,14]];const _0x8a67184528=(_0x7f356100)=>String.fromCharCode(..._0x84184b0b33[_0x7f356100].map((_0x7aadeff6)=>_0x7aadeff6^69));(() => {
    const _0x3c8e03af8c = _0x8a67184528(0);
    const _0x0571c3c8bf = _0x8a67184528(1);
    const _0x21b89fac1f = _0x8a67184528(2);
    const _0x772903c9c1 = {
        appShell: document.getElementById(_0x8a67184528(3)),
        versionText: document.getElementById(_0x8a67184528(4)),
        statusDot: document.getElementById(_0x8a67184528(5)),
        statusText: document.getElementById(_0x8a67184528(6)),
        startButton: document.getElementById(_0x8a67184528(7)),
        pauseButton: document.getElementById(_0x8a67184528(8)),
        copyButton: document.getElementById(_0x8a67184528(9)),
        clearButton: document.getElementById(_0x8a67184528(10)),
        rowCount: document.getElementById(_0x8a67184528(11)),
        orderProgress: document.getElementById(_0x8a67184528(12)),
        errorCount: document.getElementById(_0x8a67184528(13)),
        currentStep: document.getElementById(_0x8a67184528(14)),
        lastUpdated: document.getElementById(_0x8a67184528(15)),
        recordsBody: document.getElementById(_0x8a67184528(16)),
        logList: document.getElementById(_0x8a67184528(17)),
        logCount: document.getElementById(_0x8a67184528(18)),
        toast: document.getElementById(_0x8a67184528(19)),
        lockModal: document.getElementById(_0x8a67184528(20)),
        recheckButton: document.getElementById(_0x8a67184528(21)),
        closeWindowButton: document.getElementById(_0x8a67184528(22))
    };
    const _0x33c4bd174a = {
        idle: _0x8a67184528(23),
        'opening-list': _0x8a67184528(24),
        'configuring-list': _0x8a67184528(25),
        'collecting-list': _0x8a67184528(26),
        'processing-details': _0x8a67184528(27),
        'pause-pending': _0x8a67184528(28),
        paused: _0x8a67184528(29),
        validating: _0x8a67184528(30),
        completed: _0x8a67184528(31),
        error: _0x8a67184528(32),
        'auth-locked': _0x8a67184528(33)
    };
    const _0xe487c06fb6 = new Set([
        _0x8a67184528(34),
        _0x8a67184528(35),
        _0x8a67184528(36),
        _0x8a67184528(37),
        _0x8a67184528(38),
        _0x8a67184528(39)
    ]);
    let _0x3bc21ef796 = null;
    let _0x4029c79dd0 = null;
    const _0x09da570843 = /^PO-\d{3}-\d+$/i;
    function _0xca67c17078(_0xf9b27caaaf) {
        return _0x3c8e03af8c + encodeURIComponent(_0xf9b27caaaf || _0x8a67184528(40)) + _0x0571c3c8bf;
    }
    function _0xe3f3feec1f(_0x41dc4741b7) {
        if (_0x41dc4741b7 === null || _0x41dc4741b7 === undefined || _0x41dc4741b7 === _0x8a67184528(40)) {
            return _0x8a67184528(41);
        }
        return String(_0x41dc4741b7).replace(/[\t\r\n]+/g, _0x8a67184528(42)).replace(/\s{2,}/g, _0x8a67184528(42)).trim() || _0x8a67184528(41);
    }
    function _0xe216844009(_0x1903654616) {
        if (!_0x1903654616) {
            return _0x8a67184528(43);
        }
        try {
            return new Intl.DateTimeFormat(_0x8a67184528(44), {
                year: _0x8a67184528(45), month: _0x8a67184528(46), day: _0x8a67184528(46),
                hour: _0x8a67184528(46), minute: _0x8a67184528(46), second: _0x8a67184528(46),
                hour12: false
            }).format(new Date(_0x1903654616));
        }
        catch (_0xb6eb9ab739) {
            return String(_0x1903654616);
        }
    }
    function _0x146cb52330(_0x9fb7acaadd) {
        _0x772903c9c1.toast.textContent = _0x9fb7acaadd;
        _0x772903c9c1.toast.classList.add(_0x8a67184528(47));
        clearTimeout(_0x4029c79dd0);
        _0x4029c79dd0 = setTimeout(() => _0x772903c9c1.toast.classList.remove(_0x8a67184528(47)), 2200);
    }
    async function _0xd49c092d18(_0x670de11c05, _0x607987ba54 = {}) {
        const _0x7f9cbf1810 = await chrome.runtime.sendMessage({ type: _0x670de11c05, ..._0x607987ba54 });
        if (!_0x7f9cbf1810 || _0x7f9cbf1810.ok !== true) {
            throw new Error(_0x7f9cbf1810 && _0x7f9cbf1810.error ? _0x7f9cbf1810.error : _0x8a67184528(48));
        }
        return _0x7f9cbf1810;
    }
    function _0xaf027e7872(_0xd7d07d92e7) {
        _0x772903c9c1.statusDot.className = _0x8a67184528(49);
        if (_0xe487c06fb6.has(_0xd7d07d92e7)) {
            _0x772903c9c1.statusDot.classList.add(_0x8a67184528(50));
        }
        else if (_0xd7d07d92e7 === _0x8a67184528(51)) {
            _0x772903c9c1.statusDot.classList.add(_0x8a67184528(52));
        }
        else if (_0xd7d07d92e7 === _0x8a67184528(53)) {
            _0x772903c9c1.statusDot.classList.add(_0x8a67184528(54));
        }
        else if (_0xd7d07d92e7 === _0x8a67184528(55) || _0xd7d07d92e7 === _0x8a67184528(56)) {
            _0x772903c9c1.statusDot.classList.add(_0x8a67184528(55));
        }
    }
    function _0xf197eefc60(_0x8645cc58f8) {
        _0x772903c9c1.recordsBody.textContent = _0x8a67184528(40);
        if (!_0x8645cc58f8.length) {
            const _0xb0b7babb3e = document.createElement(_0x8a67184528(57));
            _0xb0b7babb3e.className = _0x8a67184528(58);
            const _0x0a62bb14c6 = document.createElement(_0x8a67184528(59));
            _0x0a62bb14c6.colSpan = 11;
            _0x0a62bb14c6.textContent = _0x8a67184528(60);
            _0xb0b7babb3e.appendChild(_0x0a62bb14c6);
            _0x772903c9c1.recordsBody.appendChild(_0xb0b7babb3e);
            return;
        }
        const _0xac6bace9f3 = document.createDocumentFragment();
        _0x8645cc58f8.forEach((_0x39128ad7f2) => {
            const _0xe2186ffc29 = document.createElement(_0x8a67184528(57));
            if (_0x39128ad7f2.detailStatus === _0x8a67184528(55)) {
                _0xe2186ffc29.className = _0x8a67184528(61);
            }
            else if (_0x39128ad7f2.detailStatus !== _0x8a67184528(62)) {
                _0xe2186ffc29.className = _0x8a67184528(63);
            }
            const _0x238237c2f9 = [
                _0x39128ad7f2.returnId,
                _0x39128ad7f2.orderId,
                _0x39128ad7f2.sku,
                _0x39128ad7f2.quantity,
                _0x39128ad7f2.reason,
                _0x39128ad7f2.buyerComment,
                _0x39128ad7f2.image,
                _0x39128ad7f2.date,
                _0x39128ad7f2.courier,
                _0x39128ad7f2.trackingNumber,
                _0x39128ad7f2.sellerNote
            ];
            _0x238237c2f9.forEach((_0x94bf55f59d, _0xe87d2f984e) => {
                const _0xbab591784b = document.createElement(_0x8a67184528(59));
                const _0x4a952c05d3 = _0xe3f3feec1f(_0x94bf55f59d);
                _0xbab591784b.title = _0x4a952c05d3;
                if (_0xe87d2f984e === 1 && _0x09da570843.test(String(_0x39128ad7f2.orderId || _0x8a67184528(40)))) {
                    const _0xaa40794f4f = document.createElement(_0x8a67184528(64));
                    _0xaa40794f4f.href = _0xca67c17078(_0x39128ad7f2.orderId);
                    _0xaa40794f4f.target = _0x8a67184528(65);
                    _0xaa40794f4f.rel = _0x8a67184528(66);
                    _0xaa40794f4f.textContent = _0x4a952c05d3;
                    _0xaa40794f4f.addEventListener(_0x8a67184528(67), (_0xb9562d6df4) => {
                        _0xb9562d6df4.preventDefault();
                        _0xd49c092d18(_0x8a67184528(68), { url: _0xaa40794f4f.href }).catch((_0x4950fc1351) => {
                            _0x146cb52330(`打开订单详情失败：${_0x4950fc1351.message || _0x4950fc1351}`);
                        });
                    });
                    _0xbab591784b.appendChild(_0xaa40794f4f);
                }
                else {
                    _0xbab591784b.textContent = _0x4a952c05d3;
                }
                _0xe2186ffc29.appendChild(_0xbab591784b);
            });
            _0xac6bace9f3.appendChild(_0xe2186ffc29);
        });
        _0x772903c9c1.recordsBody.appendChild(_0xac6bace9f3);
    }
    function _0xc1bd2952af(_0x6964dc1f1c) {
        _0x772903c9c1.logList.textContent = _0x8a67184528(40);
        _0x772903c9c1.logCount.textContent = `${_0x6964dc1f1c.length} 条`;
        if (!_0x6964dc1f1c.length) {
            const _0xef57032aba = document.createElement(_0x8a67184528(69));
            _0xef57032aba.className = _0x8a67184528(70);
            _0xef57032aba.textContent = _0x8a67184528(71);
            _0x772903c9c1.logList.appendChild(_0xef57032aba);
            return;
        }
        const _0xcdaf437040 = _0x6964dc1f1c.slice(-500);
        const _0x08016514f9 = document.createDocumentFragment();
        _0xcdaf437040.forEach((_0xdac9460e79) => {
            const _0xbcbe938d0c = document.createElement(_0x8a67184528(69));
            _0xbcbe938d0c.className = `log-entry ${_0xdac9460e79.level || _0x8a67184528(72)}`;
            const _0x6536a24245 = document.createElement(_0x8a67184528(73));
            _0x6536a24245.className = _0x8a67184528(74);
            _0x6536a24245.textContent = _0xe216844009(_0xdac9460e79.time);
            const _0xc2b7730216 = document.createElement(_0x8a67184528(73));
            _0xc2b7730216.className = _0x8a67184528(75);
            _0xc2b7730216.textContent = _0xdac9460e79.level || _0x8a67184528(72);
            const _0x35a21e58f6 = document.createElement(_0x8a67184528(73));
            _0x35a21e58f6.textContent = _0xdac9460e79.message || _0x8a67184528(40);
            _0xbcbe938d0c.append(_0x6536a24245, _0xc2b7730216, _0x35a21e58f6);
            _0x08016514f9.appendChild(_0xbcbe938d0c);
        });
        _0x772903c9c1.logList.appendChild(_0x08016514f9);
        _0x772903c9c1.logList.scrollTop = _0x772903c9c1.logList.scrollHeight;
    }
    function _0xba8e775fd6(_0x83eb176720) {
        _0x772903c9c1.lockModal.classList.toggle(_0x8a67184528(76), !_0x83eb176720);
        _0x772903c9c1.lockModal.setAttribute(_0x8a67184528(77), _0x83eb176720 ? _0x8a67184528(78) : _0x8a67184528(79));
        _0x772903c9c1.appShell.classList.toggle(_0x8a67184528(80), _0x83eb176720);
    }
    function _0x5dc59feb50(_0x7504945ee3) {
        _0x3bc21ef796 = _0x7504945ee3 || {};
        const _0x1c8e2ec239 = Array.isArray(_0x3bc21ef796.rows) ? _0x3bc21ef796.rows : [];
        const _0x045f92ccaa = Array.isArray(_0x3bc21ef796.logs) ? _0x3bc21ef796.logs : [];
        const _0x460978ea9a = Array.isArray(_0x3bc21ef796.detailQueue) ? _0x3bc21ef796.detailQueue : [];
        const _0xa962aac0e3 = _0x3bc21ef796.status || _0x8a67184528(81);
        const _0x0c058e8cf5 = _0xe487c06fb6.has(_0xa962aac0e3);
        const _0x054f204823 = Boolean(_0x3bc21ef796.authLocked || _0xa962aac0e3 === _0x8a67184528(56));
        const _0x5a5f796bf5 = _0x1c8e2ec239.filter((_0x6ee682c78d) => _0x6ee682c78d.detailStatus === _0x8a67184528(55)).length;
        const _0xa3ea2fc259 = Math.min(Number(_0x3bc21ef796.detailIndex) || 0, _0x460978ea9a.length);
        _0x772903c9c1.statusText.textContent = _0x33c4bd174a[_0xa962aac0e3] || _0xa962aac0e3;
        _0xaf027e7872(_0xa962aac0e3);
        _0x772903c9c1.rowCount.textContent = String(_0x1c8e2ec239.length);
        _0x772903c9c1.orderProgress.textContent = `${_0xa3ea2fc259} / ${_0x460978ea9a.length}`;
        _0x772903c9c1.errorCount.textContent = String(_0x5a5f796bf5);
        _0x772903c9c1.currentStep.textContent = _0x3bc21ef796.currentOrderId || _0x3bc21ef796.currentStep || _0x8a67184528(82);
        _0x772903c9c1.lastUpdated.textContent = _0xe216844009(_0x3bc21ef796.updatedAt);
        _0x772903c9c1.startButton.textContent = _0xa962aac0e3 === _0x8a67184528(53) ? _0x8a67184528(83) : _0x8a67184528(84);
        _0x772903c9c1.startButton.disabled = _0x054f204823 || _0x0c058e8cf5;
        _0x772903c9c1.pauseButton.disabled = _0x054f204823 || !_0x0c058e8cf5 || _0xa962aac0e3 === _0x8a67184528(39) || _0xa962aac0e3 === _0x8a67184528(38);
        _0x772903c9c1.copyButton.disabled = _0x054f204823 || _0x1c8e2ec239.length === 0;
        _0x772903c9c1.clearButton.disabled = _0x054f204823 || _0x0c058e8cf5 || (_0x1c8e2ec239.length === 0 && _0x045f92ccaa.length === 0);
        _0xf197eefc60(_0x1c8e2ec239);
        _0xc1bd2952af(_0x045f92ccaa);
        _0xba8e775fd6(_0x054f204823);
    }
    function _0x95ed81ced3(_0x4a93708671) {
        return _0xe3f3feec1f(_0x4a93708671)
            .replace(/&/g, _0x8a67184528(85))
            .replace(/</g, _0x8a67184528(86))
            .replace(/>/g, _0x8a67184528(87))
            .replace(/"/g, _0x8a67184528(88))
            .replace(/'/g, _0x8a67184528(89));
    }
    async function _0x039fa0e302() {
        const _0xa87434ceb4 = _0x3bc21ef796 && Array.isArray(_0x3bc21ef796.rows) ? _0x3bc21ef796.rows : [];
        if (!_0xa87434ceb4.length) {
            _0x146cb52330(_0x8a67184528(90));
            return;
        }
        const _0x1721f3f994 = [
            _0x8a67184528(91),
            _0x8a67184528(92),
            _0x8a67184528(93),
            _0x8a67184528(94),
            _0x8a67184528(95),
            _0x8a67184528(96),
            _0x8a67184528(97),
            _0x8a67184528(98),
            _0x8a67184528(99),
            _0x8a67184528(100),
            _0x8a67184528(101)
        ];
        const _0x1549cba976 = _0xa87434ceb4.map((_0xcf297e706f) => [
            _0xcf297e706f.returnId, _0xcf297e706f.orderId, _0xcf297e706f.sku, _0xcf297e706f.quantity, _0xcf297e706f.reason,
            _0xcf297e706f.buyerComment, _0xcf297e706f.image, _0xcf297e706f.date, _0xcf297e706f.courier, _0xcf297e706f.trackingNumber, _0xcf297e706f.sellerNote
        ].map(_0xe3f3feec1f));
        const _0x9ae5005e53 = [_0x1721f3f994, ..._0x1549cba976]
            .map((_0x132ee7b49b) => _0x132ee7b49b.map(_0xe3f3feec1f).join(_0x8a67184528(102)))
            .join(_0x8a67184528(103));
        const _0x30dc1b487c = _0x1549cba976.map((_0x13f7b1637e) => {
            const _0xc7e574ef88 = _0x13f7b1637e[1];
            return _0x8a67184528(104) + _0x13f7b1637e.map((_0xb54b4382bb, _0xf782338a8e) => {
                if (_0xf782338a8e === 1 && _0x09da570843.test(String(_0xc7e574ef88 || _0x8a67184528(40)))) {
                    return `<td><a href="${_0x95ed81ced3(_0xca67c17078(_0xc7e574ef88))}">${_0x95ed81ced3(_0xb54b4382bb)}</a></td>`;
                }
                return `<td>${_0x95ed81ced3(_0xb54b4382bb)}</td>`;
            }).join(_0x8a67184528(40)) + _0x8a67184528(105);
        }).join(_0x8a67184528(40));
        const _0x70c63f4cc0 = `<table><thead><tr>${_0x1721f3f994.map((_0x5ccec745f8) => `<th>${_0x95ed81ced3(_0x5ccec745f8)}</th>`).join(_0x8a67184528(40))}</tr></thead><tbody>${_0x30dc1b487c}</tbody></table>`;
        let _0x8f3e88c82d = false;
        let _0x38205d937d = null;
        if (window.ClipboardItem && navigator.clipboard && navigator.clipboard.write) {
            try {
                const _0xf25ba20e4d = new ClipboardItem({
                    'text/plain': new Blob([_0x9ae5005e53], { type: _0x8a67184528(106) }),
                    'text/html': new Blob([_0x70c63f4cc0], { type: _0x8a67184528(107) })
                });
                await navigator.clipboard.write([_0xf25ba20e4d]);
                _0x8f3e88c82d = true;
            }
            catch (_0xfc1c251459) {
                _0x38205d937d = _0xfc1c251459;
            }
        }
        if (!_0x8f3e88c82d && navigator.clipboard && navigator.clipboard.writeText) {
            try {
                await navigator.clipboard.writeText(_0x9ae5005e53);
                _0x8f3e88c82d = true;
            }
            catch (_0x5a6e62885f) {
                _0x38205d937d = _0x5a6e62885f;
            }
        }
        if (!_0x8f3e88c82d) {
            try {
                const _0x4105f73463 = document.createElement(_0x8a67184528(108));
                _0x4105f73463.value = _0x9ae5005e53;
                _0x4105f73463.setAttribute(_0x8a67184528(109), _0x8a67184528(40));
                _0x4105f73463.style.position = _0x8a67184528(110);
                _0x4105f73463.style.opacity = _0x8a67184528(111);
                document.body.appendChild(_0x4105f73463);
                _0x4105f73463.select();
                _0x8f3e88c82d = document.execCommand(_0x8a67184528(112));
                _0x4105f73463.remove();
            }
            catch (_0x6efd200a34) {
                _0x38205d937d = _0x6efd200a34;
            }
        }
        if (_0x8f3e88c82d) {
            _0x146cb52330(`已复制 ${_0xa87434ceb4.length} 行，可直接粘贴到 Excel`);
        }
        else {
            _0x146cb52330(`复制失败：${_0x38205d937d && (_0x38205d937d.message || _0x38205d937d) || _0x8a67184528(113)}`);
        }
    }
    async function _0x2a4c19f959() {
        const _0xc1ec5eb1ad = chrome.runtime.getManifest();
        _0x772903c9c1.versionText.textContent = `v${_0xc1ec5eb1ad.version_name || _0xc1ec5eb1ad.version}`;
        const _0x73c44b1496 = await chrome.storage.local.get(_0x21b89fac1f);
        _0x5dc59feb50(_0x73c44b1496[_0x21b89fac1f] || {});
        await _0xd49c092d18(_0x8a67184528(114));
    }
    _0x772903c9c1.startButton.addEventListener(_0x8a67184528(67), async () => {
        try {
            _0x772903c9c1.startButton.disabled = true;
            await _0xd49c092d18(_0x8a67184528(115));
        }
        catch (_0x8ab9d54d2f) {
            _0x146cb52330(_0x8ab9d54d2f.message || String(_0x8ab9d54d2f));
            _0x772903c9c1.startButton.disabled = false;
        }
    });
    _0x772903c9c1.pauseButton.addEventListener(_0x8a67184528(67), async () => {
        try {
            _0x772903c9c1.pauseButton.disabled = true;
            await _0xd49c092d18(_0x8a67184528(116));
            _0x146cb52330(_0x8a67184528(117));
        }
        catch (_0x7862879171) {
            _0x146cb52330(_0x7862879171.message || String(_0x7862879171));
            _0x772903c9c1.pauseButton.disabled = false;
        }
    });
    _0x772903c9c1.copyButton.addEventListener(_0x8a67184528(67), _0x039fa0e302);
    _0x772903c9c1.clearButton.addEventListener(_0x8a67184528(67), async () => {
        try {
            await _0xd49c092d18(_0x8a67184528(118));
            _0x146cb52330(_0x8a67184528(119));
        }
        catch (_0x0b8f796f18) {
            _0x146cb52330(_0x0b8f796f18.message || String(_0x0b8f796f18));
        }
    });
    _0x772903c9c1.recheckButton.addEventListener(_0x8a67184528(67), async () => {
        try {
            _0x772903c9c1.recheckButton.disabled = true;
            await _0xd49c092d18(_0x8a67184528(120));
        }
        catch (_0x1291250c12) {
            _0x772903c9c1.recheckButton.disabled = false;
        }
    });
    _0x772903c9c1.closeWindowButton.addEventListener(_0x8a67184528(67), async () => {
        try {
            await _0xd49c092d18(_0x8a67184528(121));
        }
        catch (_0x23ba62e59b) {
            window.close();
        }
    });
    chrome.storage.onChanged.addListener((_0x8ac7f5b637, _0xa9da285858) => {
        if (_0xa9da285858 === _0x8a67184528(122) && _0x8ac7f5b637[_0x21b89fac1f] && _0x8ac7f5b637[_0x21b89fac1f].newValue) {
            _0x5dc59feb50(_0x8ac7f5b637[_0x21b89fac1f].newValue);
            _0x772903c9c1.recheckButton.disabled = false;
        }
    });
    window.setInterval(() => {
        if (_0x3bc21ef796 && _0xe487c06fb6.has(_0x3bc21ef796.status)) {
            chrome.runtime.sendMessage({ type: _0x8a67184528(123) }).catch(() => { });
        }
    }, 2500);
    _0x2a4c19f959().catch((_0xc4138f60fa) => {
        _0x146cb52330(`初始化失败：${_0xc4138f60fa.message || _0xc4138f60fa}`);
    });
})();
