# GLS 地址自动填充 Chrome 扩展

该扩展在本地解析德国 GLS 退件寄件人信息，并填入当前网页表单。它不请求网络权限，也不会上传数据。

## 安装

1. 打开 Chrome 的 `chrome://extensions`。
2. 打开右上角的“开发者模式”。
3. 点击“加载已解压的扩展程序”。
4. 选择本文件夹 `gls-address-autofill`。

## 使用

1. 打开需要填写地址的网页。
2. 点击浏览器工具栏中的“GLS 地址自动填充”。
3. 粘贴 GLS 标签、订单或邮件中的地址信息，点击“解析信息”。
4. 核对联系人、街道、门牌号、邮编和城市后点击“填入当前页面”。

扩展专门适配 GLS 的 `Sender information for return packages` 页面：

- 联系人会同时填入 `Contact person*` 和 `Name*`。
- `Street* / House number` 会由德国地址的街道和门牌号自动拆分。
- `Postal code* / Location*` 会填入五位德国邮编和对应城市。

例如可直接粘贴：

```text
Sender
Ela Paszewska
Sender address
Friedrichstraße 1, Pleidelsheim, Baden-Württemberg 74385, Germany
```
