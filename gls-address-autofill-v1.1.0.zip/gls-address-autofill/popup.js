const source = document.querySelector('#source');
const result = document.querySelector('#result');
const status = document.querySelector('#status');
const parsedInputs = Object.fromEntries(
  ['contact', 'street', 'houseNumber', 'postcode', 'city'].map((name) => [name, document.querySelector(`#${name}`)])
);

const labels = {
  contact: ['contact person', 'contact', 'consignor contact name', 'consignee', 'recipient', 'name', '联系人', '收件人', '姓名'],
  street: ['street', 'street address', 'consignor street', '地址', '街道'],
  houseNumber: ['house number', 'block no', 'block number', 'consignor block', '门牌号'],
  city: ['city', 'location', 'town', 'locality', '城市'],
  postcode: ['postcode', 'postal code', 'zip code', 'zip', '邮编', '邮政编码']
};

const ignoredLines = new Set(['sender', 'sender address', 'sender information for return packages', 'return sender', 'return address', '寄件人', '寄件人地址', '发件人', '发件人地址', 'germany', 'deutschland']);
const phonePattern = /^(?:\+?49|0)?\s*(?:\d[\s-]*){7,}$/;
const postcodePattern = /\b\d{5}\b/;

function clean(value) {
  return value.replace(/^[\s:：,-]+|[\s,;]+$/g, '').trim();
}

function valueAfterLabel(line, field) {
  const escaped = labels[field].map((label) => label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
  const match = line.match(new RegExp(`^(?:${escaped})\\s*[:：-]\\s*(.+)$`, 'i'));
  return match ? clean(match[1]) : '';
}

function splitGermanStreet(address) {
  const match = clean(address).match(/^(.*?)[\s,]+(\d+\s*[a-z]?(?:\s*[-/]\s*\d+\s*[a-z]?)?)$/i);
  return match ? { street: clean(match[1]), houseNumber: clean(match[2]).replace(/\s+/g, '') } : { street: clean(address), houseNumber: '' };
}

function parseGermanAddress(address) {
  const pieces = address.split(',').map(clean).filter(Boolean);
  const postcodeIndex = pieces.findIndex((piece) => /\b\d{5}\b/.test(piece));
  const postcodePiece = postcodeIndex >= 0 ? pieces[postcodeIndex] : '';
  const postcodeMatch = postcodePiece.match(/\b\d{5}\b/);
  const cityAfterPostcode = postcodePiece ? clean(postcodePiece.replace(/^.*?\b\d{5}\b\s*/, '')) : '';
  const city = cityAfterPostcode || (postcodeIndex > 0 ? pieces[postcodeIndex - 1] : '');
  const streetPiecesEnd = cityAfterPostcode ? postcodeIndex : Math.max(0, postcodeIndex - 1);
  const streetAddress = pieces.slice(0, streetPiecesEnd).join(', ');
  return { ...splitGermanStreet(streetAddress), city, postcode: postcodeMatch?.[0] || '' };
}

function isPhoneNumber(value) {
  return phonePattern.test(value.trim());
}

function parseTabularAddress(text) {
  const rows = text.split(/\r?\n/).map((row) => row.split('\t').map(clean).filter(Boolean)).filter((row) => row.length >= 3);
  const fields = rows.find((row) => row.some((field) => postcodePattern.test(field)));
  if (!fields) return null;

  const postcodeIndex = fields.findIndex((field) => postcodePattern.test(field));
  const postcode = fields[postcodeIndex].match(postcodePattern)?.[0] || '';
  const city = postcodeIndex > 0 ? clean(fields[postcodeIndex - 1]) : '';
  const streetIndex = fields.slice(0, Math.max(0, postcodeIndex - 1)).map((field, index) => ({ field, index }))
    .reverse().find(({ field }) => /\d/.test(field) && !isPhoneNumber(field))?.index;
  const streetAddress = streetIndex === undefined ? '' : fields[streetIndex];
  const contact = fields.slice(0, streetIndex === undefined ? Math.max(0, postcodeIndex - 1) : streetIndex)
    .find((field) => !isPhoneNumber(field) && !ignoredLines.has(field.toLowerCase())) || '';
  return { contact, ...splitGermanStreet(streetAddress), city, postcode };
}

function parseLineAddress(lines) {
  const addressIndex = lines.findIndex((line) => postcodePattern.test(line));
  if (addressIndex < 0) return {};
  const addressLine = lines[addressIndex];
  if (addressLine.includes(',')) return parseGermanAddress(addressLine);

  const postcode = addressLine.match(postcodePattern)?.[0] || '';
  const cityAfterPostcode = clean(addressLine.replace(/^.*?\b\d{5}\b\s*/, ''));
  const city = cityAfterPostcode || clean(lines[addressIndex - 1] || '');
  const street = clean(lines[addressIndex - 2] || '');
  return { ...splitGermanStreet(street), city, postcode };
}

function parseGLS(text) {
  const lines = text.split(/\r?\n/).map(clean).filter(Boolean);
  const data = { contact: '', street: '', houseNumber: '', city: '', postcode: '' };

  for (const line of lines) {
    for (const field of Object.keys(data)) {
      if (!data[field]) data[field] = valueAfterLabel(line, field);
    }
  }

  const structured = parseTabularAddress(text) || parseLineAddress(lines);
  Object.assign(data, Object.fromEntries(Object.entries(structured).map(([field, value]) => [field, data[field] || value])));

  if (data.street && !data.houseNumber) Object.assign(data, { ...data, ...Object.fromEntries(Object.entries(splitGermanStreet(data.street)).filter(([, value]) => value)) });

  const freeLines = lines.filter((line) => !ignoredLines.has(line.toLowerCase()) && !isPhoneNumber(line) && !postcodePattern.test(line) && !Object.values(labels).flat().some((label) => line.toLowerCase().startsWith(label.toLowerCase())));
  if (!data.contact && freeLines.length) data.contact = freeLines[0];
  return data;
}

function showStatus(message, isError = false) {
  status.textContent = message;
  status.classList.toggle('error', isError);
}

function parseSource(automatic = false) {
  if (!source.value.trim()) return showStatus('请先粘贴 GLS 信息。', true);
  const data = parseGLS(source.value);
  Object.entries(data).forEach(([field, value]) => { parsedInputs[field].value = value; });
  result.hidden = false;
  const parsedCount = Object.values(data).filter(Boolean).length;
  showStatus(parsedCount ? `${automatic ? '已自动' : '已'}解析 ${parsedCount} 个字段，请确认后填入页面。` : '未识别到字段，请手动填写解析结果。', !parsedCount);
}

document.querySelector('#parse').addEventListener('click', () => {
  parseSource();
});

let pasteTimer;
source.addEventListener('paste', () => {
  window.clearTimeout(pasteTimer);
  pasteTimer = window.setTimeout(() => parseSource(true), 50);
});

document.querySelector('#fill').addEventListener('click', async () => {
  const data = Object.fromEntries(Object.entries(parsedInputs).map(([field, input]) => [field, input.value.trim()]));
  if (!Object.values(data).some(Boolean)) return showStatus('没有可填入的信息。', true);
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const [{ result: report }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: fillForm, args: [data, labels] });
    showStatus(report.filled ? `已填入 ${report.filled} 个字段${report.isReturnForm ? '（GLS 退件表单）' : ''}。` : '未找到匹配的表单字段。', !report.filled);
  } catch (error) {
    showStatus('无法在此页面填充。请打开可编辑的订单或地址表单。', true);
  }
});

function fillForm(data, fieldLabels) {
  const normalize = (value) => (value || '').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
  const inputs = [...document.querySelectorAll('input:not([type="hidden"]):not([type="submit"]), textarea')]
    .filter((input) => !input.disabled && !input.readOnly);
  const returnFormIds = {
    contact: 'wipp006_addresses_consignor_contact_name_input',
    name: 'wipp006_addresses_consignor_name1_input',
    street: 'wipp006_addresses_consignor_street1_input',
    houseNumber: 'wipp006_addresses_consignor_block_no1_input',
    postcode: 'wipp006_addresses_consignor_postal_code_input',
    city: 'wipp006_addresses_consignor_postal_input_component_input'
  };
  const setValue = (input, value) => {
    if (!input || !value || input.disabled || input.readOnly) return false;
    const prototype = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(prototype, 'value').set.call(input, value);
    input.dataset.glsAutofilled = 'true';
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    input.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  };
  const isReturnForm = Boolean(document.getElementById(returnFormIds.contact));
  if (isReturnForm) {
    const fields = { contact: data.contact, name: data.contact, street: data.street, houseNumber: data.houseNumber, postcode: data.postcode, city: data.city };
    const filled = Object.entries(fields).reduce((total, [field, value]) => total + Number(setValue(document.getElementById(returnFormIds[field]), value)), 0);
    return { filled, isReturnForm };
  }

  let filled = 0;
  for (const [field, value] of Object.entries(data)) {
    if (!value) continue;
    const match = inputs.find((input) => {
      if (input.dataset.glsAutofilled) return false;
      const label = input.labels?.[0]?.innerText || '';
      const descriptor = normalize([input.name, input.id, input.autocomplete, input.placeholder, input.getAttribute('aria-label'), label].join(' '));
      return fieldLabels[field].some((keyword) => descriptor.includes(normalize(keyword)));
    });
    if (!match) continue;
    filled += Number(setValue(match, value));
  }
  return { filled, isReturnForm };
}
