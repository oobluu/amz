'use strict';

(() => {
  if (window.top !== window || window.__AMZ_DE_AUTO_ORDER_CONTENT__) {
    return;
  }
  window.__AMZ_DE_AUTO_ORDER_CONTENT__ = true;

  const RUN_STATE_KEY = 'amzOrderRunState';
  const ABORTED = Symbol('ABORTED');

  let executing = false;
  let rerunRequested = false;
  let scheduledTimer = null;
  let abortGeneration = 0;
  let activeRunId = null;
  let activeRowIndex = null;

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function scheduleRun(delay = 250) {
    if (scheduledTimer !== null) {
      clearTimeout(scheduledTimer);
    }
    scheduledTimer = setTimeout(() => {
      scheduledTimer = null;
      runAutomation().catch(() => undefined);
    }, delay);
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === 'WAKE_AUTOMATION') {
      scheduleRun(50);
    }
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local' || !changes[RUN_STATE_KEY]) {
      return;
    }

    const nextState = changes[RUN_STATE_KEY].newValue;
    if (
      !nextState ||
      nextState.mode !== 'running' ||
      nextState.runId !== activeRunId ||
      nextState.currentIndex !== activeRowIndex
    ) {
      abortGeneration += 1;
    }
    scheduleRun(100);
  });

  async function send(message) {
    try {
      return await chrome.runtime.sendMessage(message);
    } catch (error) {
      return { ok: false, error: error.message || String(error) };
    }
  }

  function normalizeWhitespace(value) {
    return String(value ?? '')
      .normalize('NFKC')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function normalizeNameForComparison(value) {
    return normalizeWhitespace(value).toLocaleLowerCase('de-DE');
  }

  function namesMatch(left, right) {
    return normalizeNameForComparison(left) === normalizeNameForComparison(right);
  }

  function isVisible(element) {
    if (!(element instanceof Element)) {
      return false;
    }
    const style = window.getComputedStyle(element);
    if (style.display === 'none' || style.visibility === 'hidden') {
      return false;
    }
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function isEnabled(element) {
    return Boolean(
      element &&
      !element.disabled &&
      element.getAttribute('aria-disabled') !== 'true' &&
      !element.closest('.a-button-disabled')
    );
  }

  function findVisible(selector, root = document) {
    return [...root.querySelectorAll(selector)].find((element) => isVisible(element)) || null;
  }

  async function waitFor(check, timeoutMs, intervalMs = 250, epoch = abortGeneration) {
    const startedAt = Date.now();
    while (Date.now() - startedAt < timeoutMs) {
      if (epoch !== abortGeneration) {
        return ABORTED;
      }
      try {
        const result = check();
        if (result) {
          return result;
        }
      } catch {
        // DOM can change during Amazon page rendering. Retry until timeout.
      }
      await sleep(intervalMs);
    }
    return null;
  }

  function detectBlockingPage() {
    if (document.querySelector('#captchacharacters') || /robot check/i.test(document.title)) {
      return 'Amazon 出现验证码或 Robot Check。';
    }
    if (
      document.querySelector('#ap_email') ||
      document.querySelector('form[name="signIn"]') ||
      document.querySelector('#authportal-main-section')
    ) {
      return 'Amazon 当前要求登录或身份验证。';
    }
    const bodyText = normalizeWhitespace(document.body?.innerText || '');
    if (/sorry, we just need to make sure you['’]?re not a robot/i.test(bodyText)) {
      return 'Amazon 出现机器人验证页面。';
    }
    return '';
  }

  function detectProductNotFoundPage() {
    const bodyText = normalizeWhitespace(document.body?.innerText || '');
    return Boolean(
      document.querySelector('a[href="/ref=cs_404_logo"]') ||
      document.querySelector('a[href="/ref=cs_404_link"]') ||
      document.querySelector('img[src*="kailey-kitty"]') ||
      (/Looking\s+for\s+something\?/i.test(bodyText) &&
        /not\s+a\s+functioning\s+page\s+on\s+our\s+site/i.test(bodyText))
    );
  }

  function extractAsinFromCurrentPage() {
    const candidates = [location.href, document.querySelector('link[rel="canonical"]')?.href || ''];
    const patterns = [
      /\/(?:dp|gp\/product|gp\/aw\/d)\/([A-Z0-9]{10})(?:[/?]|$)/i,
      /[?&](?:asin|ASIN)=([A-Z0-9]{10})(?:&|$)/i
    ];
    for (const candidate of candidates) {
      for (const pattern of patterns) {
        const match = String(candidate).match(pattern);
        if (match) {
          return match[1].toUpperCase();
        }
      }
    }
    return null;
  }


  function getProductBuyNowButtons() {
    const selectors = [
      'input[id="buy-now-button"][name="submit.buy-now"]',
      'input[id^="buy-now-button"][name="submit.buy-now"]',
      'input[name="submit.buy-now"][formaction*="/checkout/entry/buynow"]'
    ];
    const buttons = [];
    const seen = new Set();

    for (const selector of selectors) {
      for (const element of document.querySelectorAll(selector)) {
        if (
          !(element instanceof HTMLInputElement) ||
          seen.has(element) ||
          !element.isConnected ||
          !isVisible(element) ||
          !isEnabled(element)
        ) {
          continue;
        }
        seen.add(element);
        buttons.push(element);
      }
    }
    return buttons;
  }

  function getActiveProductModule(expectedAsin = '') {
    const normalizedAsin = String(expectedAsin || '').toUpperCase();
    const candidates = getProductBuyNowButtons().map((button, index) => {
      const buyBoxRoot =
        button.closest('#desktop_qualifiedBuyBox') ||
        button.closest('#qualifiedBuybox') ||
        button.closest('[data-feature-name="desktop_qualifiedBuyBox"]') ||
        button.closest('form') ||
        button.parentElement;
      const moduleRoot =
        button.closest('.a-box-group') ||
        button.closest('#buybox') ||
        buyBoxRoot?.parentElement ||
        buyBoxRoot ||
        document;
      const moduleAsin = String(
        buyBoxRoot?.getAttribute?.('data-csa-c-asin') ||
        moduleRoot?.querySelector?.('[data-csa-c-asin]')?.getAttribute?.('data-csa-c-asin') ||
        ''
      ).toUpperCase();
      let score = Math.max(0, 20 - index);
      if (normalizedAsin && moduleAsin === normalizedAsin) {
        score += 100;
      } else if (normalizedAsin && moduleAsin && moduleAsin !== normalizedAsin) {
        score -= 100;
      }
      if (buyBoxRoot?.querySelector?.('input[id="bulk-buying-price-per-item"]')) {
        score += 10;
      }
      if (buyBoxRoot?.querySelector?.('select[id^="edlbpDesktopFfqp_"]')) {
        score += 5;
      }
      return { button, buyBoxRoot, moduleRoot, moduleAsin, score };
    });

    candidates.sort((left, right) => right.score - left.score);
    return candidates[0] || null;
  }

  function collectProductUnitPriceSources(product) {
    if (!product) {
      return [];
    }

    const sources = [];
    const seenElements = new Set();
    const roots = [product.buyBoxRoot, product.moduleRoot].filter(Boolean);

    const addValue = (source, rawValue, element = null) => {
      if (element && seenElements.has(element)) {
        return;
      }
      if (element) {
        seenElements.add(element);
      }
      const value = parseMoney(rawValue);
      if (Number.isFinite(value)) {
        sources.push({ source, rawValue: normalizeWhitespace(rawValue), value });
      }
    };

    for (const root of roots) {
      for (const input of root.querySelectorAll(
        'input[id="bulk-buying-price-per-item"], input[name="bulk-buying-price-per-item"]'
      )) {
        addValue('bulk-buying-price-per-item', input.value, input);
      }
      for (const input of root.querySelectorAll('input[id="twister-plus-price-data-price"]')) {
        addValue('twister-plus-price-data-price', input.value, input);
      }
    }

    const visiblePriceRoots = [];
    for (const root of roots) {
      for (const element of root.querySelectorAll(
        '[id="corePrice_feature_div"], [data-feature-name="corePrice"]'
      )) {
        if (!visiblePriceRoots.includes(element) && isVisible(element)) {
          visiblePriceRoots.push(element);
        }
      }
    }

    for (const priceRoot of visiblePriceRoots) {
      const text = normalizeWhitespace(priceRoot.innerText || priceRoot.textContent || '');
      const match = text.match(/(?:€\s*)?([0-9]+(?:[.,][0-9]{1,2})?)\s*incl\.?\s*VAT/i);
      if (match) {
        addValue('visible-incl-vat', match[1], priceRoot);
      }
    }

    return sources;
  }

  function getProductUnitPrice(product) {
    const sources = collectProductUnitPriceSources(product);
    if (sources.length === 0) {
      return { value: Number.NaN, sources, conflict: false };
    }

    const centValues = new Set(sources.map((entry) => Math.round(entry.value * 100)));
    return {
      value: sources[0].value,
      sources,
      conflict: centValues.size > 1
    };
  }

  function describePriceSources(sources) {
    return (Array.isArray(sources) ? sources : [])
      .map((entry) => `${entry.source}=${Number(entry.value).toFixed(2)}`)
      .join('，');
  }

  function isQuantitySelectUsable(select) {
    if (!(select instanceof HTMLSelectElement) || !select.isConnected || !isEnabled(select)) {
      return false;
    }
    const container = select.closest('.a-dropdown-container') || select.parentElement || select;
    return isVisible(container);
  }

  function findQuantityPicker(product, asin = '') {
    if (!product) {
      return null;
    }
    const roots = [product.buyBoxRoot, product.moduleRoot].filter(Boolean);
    const candidates = [];
    const seen = new Set();
    const selectors = [
      'select[id^="edlbpDesktopFfqp_"][id$="-predefinedQuantitiesDropdown"]',
      'select.a-native-dropdown[data-action="a-dropdown-select"]',
      'select[name="quantity"]',
      'select[id="quantity"]'
    ];

    for (const root of roots) {
      for (const selector of selectors) {
        for (const select of root.querySelectorAll(selector)) {
          if (seen.has(select) || !isQuantitySelectUsable(select)) {
            continue;
          }
          seen.add(select);
          candidates.push(select);
        }
      }
    }

    candidates.sort((left, right) => {
      const leftPreferred = /^edlbpDesktopFfqp_/.test(left.id) ? 2 : 0;
      const rightPreferred = /^edlbpDesktopFfqp_/.test(right.id) ? 2 : 0;
      const leftAsin = asin && left.id.toUpperCase().includes(asin.toUpperCase()) ? 1 : 0;
      const rightAsin = asin && right.id.toUpperCase().includes(asin.toUpperCase()) ? 1 : 0;
      return rightPreferred + rightAsin - (leftPreferred + leftAsin);
    });

    const select = candidates[0] || null;
    if (!select) {
      return null;
    }
    const container = select.closest('.a-dropdown-container') || select.parentElement || select;
    const prompt =
      select.nextElementSibling?.querySelector?.('.a-dropdown-prompt') ||
      container.querySelector('.a-dropdown-prompt') ||
      null;
    return { select, container, prompt };
  }

  function getExactQuantityOptions(select) {
    if (!(select instanceof HTMLSelectElement)) {
      return [];
    }
    return [...select.options]
      .map((option) => ({
        option,
        value: String(option.value || '').trim(),
        text: normalizeWhitespace(option.textContent || '')
      }))
      .filter((entry) => /^[1-9]\d*$/.test(entry.value) && entry.text === entry.value);
  }

  function getHiddenQuantitySummary(product) {
    if (!product) {
      return { values: [], value: null, conflict: false };
    }
    const roots = [product.buyBoxRoot, product.moduleRoot].filter(Boolean);
    const values = [];
    const seenElements = new Set();
    const pushValue = (rawValue, element = null) => {
      if (element && seenElements.has(element)) {
        return;
      }
      if (element) {
        seenElements.add(element);
      }
      const text = String(rawValue ?? '').trim();
      if (!/^[1-9]\d*$/.test(text)) {
        return;
      }
      const number = Number(text);
      if (Number.isSafeInteger(number) && number > 0) {
        values.push(number);
      }
    };

    const selectors = [
      'input[name="items[0.base][quantity]"]',
      'input[id="bulk-buying-total-units-quantity"]',
      'input[id="bulk-buying-subtotal-quantity"]',
      'select[id="quantity"]'
    ];

    for (const root of roots) {
      for (const selector of selectors) {
        for (const element of root.querySelectorAll(selector)) {
          pushValue(element.value, element);
        }
      }

      for (const script of root.querySelectorAll('script[type="a-state"]')) {
        const stateKey = script.getAttribute('data-a-state') || '';
        if (!/turbo-checkout-product-state/i.test(stateKey)) {
          continue;
        }
        try {
          const data = JSON.parse(script.textContent || '{}');
          for (const item of Array.isArray(data.lineItemInputs) ? data.lineItemInputs : []) {
            pushValue(item?.quantity);
          }
        } catch {
          // Ignore malformed Amazon state blocks and use the remaining signals.
        }
      }
    }

    const uniqueValues = [...new Set(values)];
    return {
      values,
      value: uniqueValues.length === 1 ? uniqueValues[0] : null,
      conflict: uniqueValues.length > 1
    };
  }

  function getQuantityReadback(product, targetQuantity, asin = '') {
    const picker = findQuantityPicker(product, asin);
    if (picker) {
      const selectedOption = picker.select.selectedOptions?.[0] || null;
      const selectValue = String(picker.select.value || '').trim();
      const selectedText = normalizeWhitespace(selectedOption?.textContent || '');
      const promptText = normalizeWhitespace(picker.prompt?.textContent || '');
      const expected = String(targetQuantity);
      return {
        exact: selectValue === expected && selectedText === expected && promptText === expected,
        method: 'picker',
        picker,
        selectValue,
        selectedText,
        promptText
      };
    }

    const hidden = getHiddenQuantitySummary(product);
    return {
      exact: targetQuantity === 1 && !hidden.conflict && hidden.value === 1,
      method: 'hidden',
      hidden
    };
  }

  function describeQuantityReadback(readback) {
    if (!readback) {
      return '未读取到数量信息';
    }
    if (readback.method === 'picker') {
      return `select=${readback.selectValue || '空'}，option=${readback.selectedText || '空'}，显示文本=${readback.promptText || '空'}`;
    }
    if (readback.hidden?.conflict) {
      return `隐藏数量信号冲突：${readback.hidden.values.join(', ')}`;
    }
    return readback.hidden?.value
      ? `隐藏数量=${readback.hidden.value}`
      : '未读取到数量选择栏或明确的隐藏数量';
  }

  function getQuantityDropdownTrigger(select) {
    if (!(select instanceof HTMLSelectElement)) {
      return null;
    }
    const container = select.closest('.a-dropdown-container') || select.parentElement;
    const candidates = [
      select.nextElementSibling?.querySelector?.('[data-action="a-dropdown-button"]'),
      container?.querySelector?.('.a-button-dropdown [data-action="a-dropdown-button"]'),
      select.nextElementSibling,
      container?.querySelector?.('.a-button-dropdown')
    ].filter(Boolean);
    return candidates.find((element) => isVisible(element)) || null;
  }

  function getDropdownStringValue(anchor) {
    try {
      const data = JSON.parse(anchor.getAttribute('data-value') || '{}');
      return String(data?.stringVal ?? '');
    } catch {
      return '';
    }
  }

  function findVisibleExactQuantityOption(select, targetQuantity) {
    if (!(select instanceof HTMLSelectElement)) {
      return null;
    }
    const expected = String(targetQuantity);
    return [...document.querySelectorAll('a.a-dropdown-link[data-value]')].find((anchor) => {
      if (!isVisible(anchor)) {
        return false;
      }
      if (select.id && anchor.id && !anchor.id.startsWith(`${select.id}_`)) {
        return false;
      }
      return getDropdownStringValue(anchor) === expected && normalizeWhitespace(anchor.textContent) === expected;
    }) || null;
  }

  async function clickExactQuantityOption(select, targetQuantity, epoch) {
    const trigger = getQuantityDropdownTrigger(select);
    if (!trigger) {
      return { ok: false, error: '数量选择栏未找到可点击的下拉按钮。' };
    }

    trigger.scrollIntoView({ block: 'center', inline: 'center', behavior: 'auto' });
    trigger.focus?.({ preventScroll: true });
    HTMLElement.prototype.click.call(trigger);

    const option = await waitFor(
      () => findVisibleExactQuantityOption(select, targetQuantity),
      6000,
      150,
      epoch
    );
    if (option === ABORTED) {
      return { ok: false, aborted: true };
    }
    if (!option) {
      return { ok: false, error: '点击数量选择栏后未出现可点击的精准数字选项。' };
    }

    option.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'auto' });
    HTMLElement.prototype.click.call(option);
    return { ok: true };
  }

  function getVisibleAddressSuggestionDialog() {
    const radios = [
      ...document.querySelectorAll('input[name="address-ui-widgets-suggested-address-selection"]')
    ];
    for (const radio of radios) {
      const dialog = radio.closest('.a-popover[role="dialog"], .a-popover-modal, .a-popover') || radio.closest('form');
      if (dialog && isVisible(dialog)) {
        return dialog;
      }
    }

    const headings = [...document.querySelectorAll('h1, h2, h4')].filter(
      (element) => isVisible(element) && /Verify\s+your\s+address/i.test(element.textContent || '')
    );
    return headings[0]?.closest('.a-popover[role="dialog"], .a-popover-modal, .a-popover') || null;
  }

  function setInputValue(element, value) {
    const expected = String(value ?? '');
    element.focus();

    const prototype = element instanceof HTMLTextAreaElement
      ? HTMLTextAreaElement.prototype
      : HTMLInputElement.prototype;
    const valueSetter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set;
    if (valueSetter) {
      valueSetter.call(element, expected);
    } else {
      element.value = expected;
    }

    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    element.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  function valuesMatch(actual, expected) {
    return normalizeWhitespace(actual) === normalizeWhitespace(expected);
  }

  function findAddressFields() {
    const fullName = document.querySelector('#address-ui-widgets-enterAddressFullName');
    const phone = document.querySelector('#address-ui-widgets-enterAddressPhoneNumber');
    const line1 = document.querySelector('#address-ui-widgets-enterAddressLine1');
    const line2 = document.querySelector('#address-ui-widgets-enterAddressLine2');
    const postal = document.querySelector('#address-ui-widgets-enterAddressPostalCode');
    const city = document.querySelector('#address-ui-widgets-enterAddressCity');
    const country = document.querySelector('#address-ui-widgets-countryCode-dropdown-nativeId');

    const required = [fullName, phone, line1, line2, postal, city];
    if (!required.every((element) => element && isVisible(element))) {
      return null;
    }

    const line1LooksLikeStreet = /street name|street and number/i.test(line1.placeholder || '');
    const line2LooksLikeStreet = /street name|street and number/i.test(line2.placeholder || '');
    const street = line2LooksLikeStreet || !line1LooksLikeStreet ? line2 : line1;
    const extra = street === line2 ? line1 : line2;

    return { fullName, phone, street, extra, postal, city, country };
  }

  function getVisibleUseAddressButton() {
    const candidates = [
      ...document.querySelectorAll('input[data-testid="bottom-continue-button"]'),
      ...document.querySelectorAll('#checkout-primary-continue-button-id input.a-button-input')
    ];
    return candidates.find((element) => isVisible(element) && isEnabled(element)) || null;
  }


  function getVisibleAddressError() {
    const selectors = [
      '.a-alert-error:not(.aok-hidden)',
      '.a-alert-inline-error:not(.aok-hidden)',
      '[role="alert"]:not(.aok-hidden)'
    ];
    for (const selector of selectors) {
      const element = [...document.querySelectorAll(selector)].find(
        (candidate) => isVisible(candidate) && normalizeWhitespace(candidate.textContent)
      );
      if (element) {
        return normalizeWhitespace(element.textContent);
      }
    }
    return '';
  }

  function getPaymentRecipientName() {
    const heading = document.querySelector('#deliver-to-customer-text');
    if (!heading || !isVisible(heading)) {
      return null;
    }
    return normalizeWhitespace(heading.textContent).replace(/^Delivering\s+to\s+/i, '').trim();
  }

  function parseMoney(text) {
    let raw = String(text ?? '').replace(/\s/g, '').replace(/[^\d,.-]/g, '');
    if (!raw) {
      return Number.NaN;
    }

    const comma = raw.lastIndexOf(',');
    const dot = raw.lastIndexOf('.');
    if (comma >= 0 && dot >= 0) {
      const decimalIndex = Math.max(comma, dot);
      const integerPart = raw.slice(0, decimalIndex).replace(/[.,]/g, '');
      const decimalPart = raw.slice(decimalIndex + 1).replace(/[.,]/g, '');
      raw = `${integerPart}.${decimalPart}`;
    } else if (comma >= 0) {
      const decimalDigits = raw.length - comma - 1;
      raw = decimalDigits >= 1 && decimalDigits <= 2
        ? raw.replace(/\./g, '').replace(',', '.')
        : raw.replace(/,/g, '');
    } else if (dot >= 0) {
      const decimalDigits = raw.length - dot - 1;
      if (decimalDigits < 1 || decimalDigits > 2) {
        raw = raw.replace(/\./g, '');
      }
    }
    return Number(raw);
  }

  function getPlaceOrderButtons() {
    const selectors = [
      'input[data-testid="SPC_selectPlaceOrder"][data-client-component="PlaceYourOrder"]',
      'input[data-csa-c-slot-id="checkout-place-your-order-button"]',
      'input.place-your-order-button[type="submit"]',
      'input[id="placeOrder"][type="submit"]'
    ];
    const buttons = [];
    const seen = new Set();

    for (const selector of selectors) {
      for (const element of document.querySelectorAll(selector)) {
        if (!(element instanceof HTMLInputElement) || seen.has(element) || !element.isConnected) {
          continue;
        }
        seen.add(element);
        buttons.push(element);
      }
    }
    return buttons;
  }

  function getPlaceOrderButtonSet() {
    const all = getPlaceOrderButtons();
    const usable = all.filter((button) => isVisible(button) && isEnabled(button));
    const top =
      usable.find((button) => button.getAttribute('aria-labelledby') === 'submitOrderButtonId-announce') ||
      usable.find((button) => button.closest('#submitOrderButtonId')) ||
      null;
    const bottom =
      usable.find((button) => button.getAttribute('aria-labelledby') === 'bottomSubmitOrderButtonId-announce') ||
      null;
    const primary = top || usable[0] || null;
    const fallback =
      (bottom && bottom !== primary ? bottom : null) ||
      usable.find((button) => button !== primary) ||
      null;
    return { all, usable, top, bottom, primary, fallback };
  }

  function selectFallbackPlaceOrderButton(buttonSet, previousButton) {
    if (!buttonSet) {
      return null;
    }
    return (
      (buttonSet.bottom && buttonSet.bottom !== previousButton ? buttonSet.bottom : null) ||
      buttonSet.usable.find((button) => button !== previousButton) ||
      null
    );
  }

  function describePlaceOrderButton(button) {
    if (!button) {
      return '未知按钮';
    }
    const labelledBy = button.getAttribute('aria-labelledby') || '';
    if (labelledBy === 'submitOrderButtonId-announce' || button.closest('#submitOrderButtonId')) {
      return '顶部 Buy now';
    }
    if (labelledBy === 'bottomSubmitOrderButtonId-announce') {
      return '底部 Buy now';
    }
    return `Buy now（aria-labelledby=${labelledBy || '空'}）`;
  }

  function getVisibleSubmissionSpinnerCount() {
    const processingSelectors = [
      '.a-spinner-wrapper:not(.aok-hidden)',
      '.checkout-page-spinner:not(.aok-hidden)',
      '[data-testid*="spinner"]:not(.aok-hidden)',
      '[aria-busy="true"]'
    ];
    const seen = new Set();
    for (const selector of processingSelectors) {
      for (const element of document.querySelectorAll(selector)) {
        if (isVisible(element)) {
          seen.add(element);
        }
      }
    }
    return seen.size;
  }

  function hasOrderProcessingText() {
    const bodyText = normalizeWhitespace(document.body?.innerText || '');
    return /placing\s+your\s+order|processing\s+your\s+order|order\s+is\s+being\s+processed/i.test(bodyText);
  }

  function captureSubmissionSnapshot() {
    const buttonSet = getPlaceOrderButtonSet();
    return {
      url: location.href,
      allButtonCount: buttonSet.all.length,
      usableButtonCount: buttonSet.usable.length,
      spinnerCount: getVisibleSubmissionSpinnerCount(),
      hasProcessingText: hasOrderProcessingText()
    };
  }

  function getSubmissionEvidence(snapshot) {
    if (location.href !== snapshot.url) {
      return '页面 URL 已变化';
    }
    if (getReviewOrdersLink()) {
      return '已出现下单成功页面入口';
    }
    if (getFirstOrderCard()) {
      return '已进入订单记录页面';
    }

    if (!snapshot.hasProcessingText && hasOrderProcessingText()) {
      return '页面显示订单提交处理中';
    }

    const spinnerCount = getVisibleSubmissionSpinnerCount();
    if (spinnerCount > snapshot.spinnerCount) {
      return '页面出现新的提交处理中状态';
    }

    const current = getPlaceOrderButtonSet();
    if (snapshot.allButtonCount > 0 && current.all.length === 0) {
      return '付款按钮已从页面移除';
    }
    if (snapshot.usableButtonCount > 0 && current.usable.length < snapshot.usableButtonCount) {
      return '可用付款按钮数量已减少';
    }
    if (current.all.length > 0 && current.all.every((button) => !isVisible(button) || !isEnabled(button))) {
      return '付款按钮已全部隐藏或禁用';
    }
    return '';
  }

  async function nativeClickAndObserve(button, epoch, observeMs = 12000) {
    if (!button || !button.isConnected || !isVisible(button) || !isEnabled(button)) {
      return { clicked: false, evidence: '', error: '按钮在点击前已失效或不可用' };
    }

    const snapshot = captureSubmissionSnapshot();
    let unloading = false;
    const onBeforeUnload = () => {
      unloading = true;
    };
    window.addEventListener('beforeunload', onBeforeUnload, { once: true });
    window.addEventListener('pagehide', onBeforeUnload, { once: true });

    try {
      button.scrollIntoView({ block: 'center', inline: 'center', behavior: 'auto' });
      button.focus({ preventScroll: true });
      await sleep(160);

      if (!button.isConnected || !isVisible(button) || !isEnabled(button)) {
        return { clicked: false, evidence: '', error: 'Amazon 重绘页面后按钮引用已失效' };
      }

      HTMLInputElement.prototype.click.call(button);
      const evidence = await waitFor(
        () => (unloading ? '页面已开始跳转' : getSubmissionEvidence(snapshot)),
        observeMs,
        250,
        epoch
      );
      if (evidence === ABORTED) {
        return { clicked: true, evidence: ABORTED, error: '' };
      }
      return { clicked: true, evidence: evidence || '', error: '' };
    } catch (error) {
      return { clicked: false, evidence: '', error: error.message || String(error) };
    } finally {
      window.removeEventListener('beforeunload', onBeforeUnload);
      window.removeEventListener('pagehide', onBeforeUnload);
    }
  }

  function getReviewOrdersLink() {
    const links = [
      ...document.querySelectorAll('#widget-accountLevelActions a'),
      ...document.querySelectorAll('a.a-link-emphasis')
    ];
    return links.find((link) => /Review\s+or\s+edit\s+your\s+recent\s+orders/i.test(link.textContent || '')) || null;
  }

  function getFirstOrderCard() {
    return (
      document.querySelector('#yourOrderHistorySection [id="orderCard"]') ||
      document.querySelector('#yourOrderInfoSection [id="orderCard"]')
    );
  }

  function getOrderCardRecipientName(card) {
    if (!card) {
      return null;
    }
    const full = card.querySelector('.shipToTriggerTextTruncate .a-truncate-full');
    if (full) {
      return normalizeWhitespace(full.textContent);
    }
    const fallback = card.querySelector('.shipToTriggerTextTruncate');
    return fallback ? normalizeWhitespace(fallback.textContent) : null;
  }

  function getOrderCardOrderId(card) {
    if (!card) {
      return null;
    }
    const orderIdField = card.querySelector('#orderIdField') || card;
    return normalizeWhitespace(orderIdField.textContent).match(/\b\d{3}-\d{7}-\d{7}\b/)?.[0] || null;
  }

  async function transition(context, nextPhase, status, logMessage, level = 'info', metadata = {}) {
    return send({
      type: 'SET_PHASE',
      runId: context.state.runId,
      expectedPhase: context.state.phase,
      nextPhase,
      status,
      logMessage,
      level,
      ...metadata
    });
  }

  async function pause(context, reason) {
    return send({
      type: 'PAUSE_ERROR',
      runId: context.state.runId,
      expectedPhase: context.state.phase,
      reason
    });
  }

  async function pauseAtPhase(context, expectedPhase, reason) {
    return send({
      type: 'PAUSE_ERROR',
      runId: context.state.runId,
      expectedPhase,
      reason
    });
  }

  async function skip(context, reason, metadata = {}) {
    return send({
      type: 'SKIP_ROW',
      runId: context.state.runId,
      expectedPhase: context.state.phase,
      reason,
      ...(metadata && typeof metadata === 'object' ? metadata : {})
    });
  }

  async function pageLog(context, message, level = 'info') {
    return send({
      type: 'PAGE_LOG',
      runId: context.state.runId,
      message,
      level
    });
  }

  async function handleProductPage(context, epoch) {
    const blocker = detectBlockingPage();
    if (blocker) {
      await pause(context, blocker);
      return;
    }

    if (detectProductNotFoundPage()) {
      await skip(context, '未找到商品，跳过');
      return;
    }

    const currentAsin = extractAsinFromCurrentPage();
    if (currentAsin && currentAsin !== context.row.asin) {
      await pause(context, `当前商品 ASIN 为 ${currentAsin}，与目标 ${context.row.asin} 不一致。`);
      return;
    }

    const productResult = await waitFor(
      () => {
        if (detectProductNotFoundPage()) {
          return { type: 'not-found' };
        }
        const product = getActiveProductModule(context.row.asin);
        return product ? { type: 'product', product } : null;
      },
      30000,
      300,
      epoch
    );

    if (productResult === ABORTED) {
      return;
    }
    if (productResult?.type === 'not-found' || detectProductNotFoundPage()) {
      await skip(context, '未找到商品，跳过');
      return;
    }
    if (!productResult?.product) {
      await pause(context, detectBlockingPage() || '商品页面未找到当前可用的下单模块或 Buy Now 按钮。');
      return;
    }

    const buyBoxAsin = String(productResult.product.moduleAsin || '').toUpperCase();
    if (buyBoxAsin && buyBoxAsin !== context.row.asin) {
      await pause(context, `当前下单模块 ASIN 为 ${buyBoxAsin}，与目标 ${context.row.asin} 不一致。`);
      return;
    }

    const response = await transition(
      context,
      'VERIFY_PRODUCT_PRICE',
      '正在检查商品含税单价',
      '已识别当前商品下单模块，开始检查含税单价。'
    );
    if (response?.ok) {
      scheduleRun(100);
    }
  }

  async function handleVerifyProductPrice(context, epoch) {
    const blocker = detectBlockingPage();
    if (blocker) {
      await pause(context, blocker);
      return;
    }

    const result = await waitFor(
      () => {
        if (detectProductNotFoundPage()) {
          return { type: 'not-found' };
        }
        const product = getActiveProductModule(context.row.asin);
        if (!product) {
          return null;
        }
        const price = getProductUnitPrice(product);
        return price.sources.length > 0 ? { type: 'price', product, price } : null;
      },
      25000,
      250,
      epoch
    );

    if (result === ABORTED) {
      return;
    }
    if (result?.type === 'not-found' || detectProductNotFoundPage()) {
      await skip(context, '未找到商品，跳过');
      return;
    }
    if (!result?.price) {
      await pause(context, '商品页面当前下单模块中无法读取含税单价，停止等待人工检查。');
      return;
    }

    const sourceDescription = describePriceSources(result.price.sources) || '未知来源';
    if (result.price.conflict) {
      await pause(context, `商品含税单价来源不一致：${sourceDescription}。`);
      return;
    }
    if (!Number.isFinite(result.price.value)) {
      await pause(context, `商品含税单价无法解析：${sourceDescription}。`);
      return;
    }
    if (Math.abs(result.price.value - 2) > 0.0001) {
      await skip(context, '金额不为2，跳过', { observedUnitPrice: result.price.value });
      return;
    }

    const response = await transition(
      context,
      'SELECT_QUANTITY',
      '商品含税单价为 €2.00，准备设置数量',
      `商品含税单价检查通过：€2.00（${sourceDescription}）。`,
      'success',
      { observedUnitPrice: result.price.value }
    );
    if (response?.ok) {
      scheduleRun(100);
    }
  }

  async function handleSelectQuantity(context, epoch) {
    const targetQuantity = Number(context.row.requestedQuantity);
    if (!Number.isSafeInteger(targetQuantity) || targetQuantity <= 0) {
      await pause(context, `当前数据行 quantity to ship 无法解析为正整数：${context.row.quantityToShip || '空'}。`);
      return;
    }

    const product = await waitFor(() => getActiveProductModule(context.row.asin), 20000, 250, epoch);
    if (product === ABORTED) {
      return;
    }
    if (!product) {
      await pause(context, '设置数量时未找到当前可用的商品下单模块。');
      return;
    }

    const picker = findQuantityPicker(product, context.row.asin);
    if (targetQuantity === 1) {
      const response = await transition(
        context,
        'VERIFY_QUANTITY',
        '目标数量为1，准备回读核对',
        '目标数量为 1，不修改数量选择栏，进入数量回读核对。'
      );
      if (response?.ok) {
        scheduleRun(100);
      }
      return;
    }

    if (!picker) {
      await skip(context, '限购，跳过');
      return;
    }

    const exactOptions = getExactQuantityOptions(picker.select);
    const exactOption = exactOptions.find((entry) => entry.value === String(targetQuantity));
    if (!exactOption) {
      const available = exactOptions.map((entry) => entry.value).join(', ') || '无精准数字选项';
      await pageLog(
        context,
        `目标数量 ${targetQuantity} 不在精准数字选项中；当前精准选项：${available}。带“+”的选项不使用。`,
        'warning'
      );
      await skip(context, '限购，跳过');
      return;
    }

    const response = await transition(
      context,
      'VERIFY_QUANTITY',
      `正在选择并核对数量 ${targetQuantity}`,
      `已找到精准数量选项 ${targetQuantity}，准备点击数量下拉选项。`
    );
    if (!response?.ok) {
      return;
    }

    const freshProduct = getActiveProductModule(context.row.asin);
    const freshPicker = findQuantityPicker(freshProduct, context.row.asin);
    const freshExactOption = freshPicker
      ? getExactQuantityOptions(freshPicker.select).find((entry) => entry.value === String(targetQuantity))
      : null;
    if (!freshProduct || !freshPicker || !freshExactOption) {
      await pauseAtPhase(
        context,
        'VERIFY_QUANTITY',
        `准备点击数量 ${targetQuantity} 时 Amazon 重绘了下单模块，无法重新定位精准数量选项。`
      );
      return;
    }

    const clickResult = await clickExactQuantityOption(freshPicker.select, targetQuantity, epoch);
    if (clickResult.aborted) {
      return;
    }
    if (!clickResult.ok) {
      await pauseAtPhase(context, 'VERIFY_QUANTITY', clickResult.error || '无法点击精准数量选项。');
      return;
    }

    await pageLog(context, `已点击精准数量选项 ${targetQuantity}，等待 Amazon 更新数量显示。`);
    scheduleRun(450);
  }

  async function handleVerifyQuantity(context, epoch) {
    const targetQuantity = Number(context.row.requestedQuantity);
    if (!Number.isSafeInteger(targetQuantity) || targetQuantity <= 0) {
      await pause(context, '数量核对阶段的目标数量无效。');
      return;
    }

    const result = await waitFor(
      () => {
        if (detectProductNotFoundPage()) {
          return { type: 'not-found' };
        }
        const product = getActiveProductModule(context.row.asin);
        if (!product) {
          return null;
        }
        const readback = getQuantityReadback(product, targetQuantity, context.row.asin);
        return readback.exact ? { type: 'quantity', product, readback } : null;
      },
      22000,
      250,
      epoch
    );

    if (result === ABORTED) {
      return;
    }
    if (result?.type === 'not-found' || detectProductNotFoundPage()) {
      await skip(context, '未找到商品，跳过');
      return;
    }
    if (!result?.readback) {
      const currentProduct = getActiveProductModule(context.row.asin);
      const currentReadback = getQuantityReadback(currentProduct, targetQuantity, context.row.asin);
      await pause(
        context,
        `数量选择栏回读与目标数量 ${targetQuantity} 不一致：${describeQuantityReadback(currentReadback)}。`
      );
      return;
    }

    const response = await transition(
      context,
      'WAIT_CHECKOUT',
      `数量 ${targetQuantity} 已核对，准备点击商品页 Buy Now`,
      `数量回读验证通过：目标数量和页面显示均为 ${targetQuantity}。`,
      'success',
      { selectedQuantity: targetQuantity }
    );
    if (!response?.ok) {
      return;
    }

    const freshProduct = getActiveProductModule(context.row.asin);
    if (!freshProduct?.button) {
      await pauseAtPhase(context, 'WAIT_CHECKOUT', '数量核对通过后重新定位商品页 Buy Now 失败。');
      return;
    }
    const freshReadback = getQuantityReadback(freshProduct, targetQuantity, context.row.asin);
    if (!freshReadback.exact) {
      await pauseAtPhase(
        context,
        'WAIT_CHECKOUT',
        `点击 Buy Now 前数量再次回读不一致：${describeQuantityReadback(freshReadback)}。`
      );
      return;
    }

    HTMLInputElement.prototype.click.call(freshProduct.button);
    await pageLog(context, `已点击商品页面 Buy Now，购买数量 ${targetQuantity}。`);
    scheduleRun(600);
  }

  async function handleCheckoutPage(context, epoch) {
    const blocker = detectBlockingPage();
    if (blocker) {
      await pause(context, blocker);
      return;
    }

    const addAddressLink = await waitFor(
      () => {
        const link = document.querySelector('#add-new-address-popover-link');
        return link && isVisible(link) ? link : null;
      },
      35000,
      300,
      epoch
    );

    if (addAddressLink === ABORTED) {
      return;
    }
    if (!addAddressLink) {
      await pause(context, '下单页面未找到 Add a new delivery address。');
      return;
    }

    const response = await transition(
      context,
      'WAIT_ADDRESS_FORM',
      '正在打开新建地址窗口',
      '已找到并点击 Add a new delivery address。'
    );
    if (!response?.ok) {
      return;
    }

    addAddressLink.click();
    scheduleRun(450);
  }

  async function handleAddressForm(context, epoch) {
    const fields = await waitFor(findAddressFields, 25000, 250, epoch);
    if (fields === ABORTED) {
      return;
    }
    if (!fields) {
      await pause(context, getVisibleAddressError() || '未出现完整的新建地址表单。');
      return;
    }

    if (fields.country && fields.country.value !== 'DE') {
      await pause(context, `地址国家不是 Germany（当前值：${fields.country.value || '空'}）。`);
      return;
    }

    for (let attempt = 1; attempt <= 2; attempt += 1) {
      setInputValue(fields.fullName, context.row.normalizedName);
      setInputValue(fields.phone, context.row.phoneNumber);
      setInputValue(fields.street, context.row.shipAddress);
      setInputValue(fields.extra, '');
      setInputValue(fields.postal, context.row.shipPostalCode);
      await sleep(500);
      setInputValue(fields.city, context.row.shipCity);
      await sleep(350);

      const valid =
        valuesMatch(fields.fullName.value, context.row.normalizedName) &&
        String(fields.phone.value).trim() === String(context.row.phoneNumber).trim() &&
        valuesMatch(fields.street.value, context.row.shipAddress) &&
        valuesMatch(fields.postal.value, context.row.shipPostalCode) &&
        valuesMatch(fields.city.value, context.row.shipCity);

      if (valid) {
        break;
      }

      if (attempt === 2) {
        await pause(context, '地址表单回读结果与输入数据不一致。');
        return;
      }
    }

    const useAddressButton = getVisibleUseAddressButton();
    if (!useAddressButton) {
      await pause(context, '新建地址窗口未找到可用的 Use this address 按钮。');
      return;
    }

    const response = await transition(
      context,
      'WAIT_ADDRESS_RESULT',
      '地址已填写并验证，等待地址处理结果',
      '姓名、电话、地址、邮编和城市已填写并回读验证，点击 Use this address。'
    );
    if (!response?.ok) {
      return;
    }

    useAddressButton.click();
    scheduleRun(700);
  }

  async function handleAddressResult(context, epoch) {
    const result = await waitFor(
      () => {
        const suggestionDialog = getVisibleAddressSuggestionDialog();
        if (suggestionDialog) {
          return { type: 'suggestion' };
        }
        if (getPaymentRecipientName() && getPlaceOrderButtonSet().usable.length > 0) {
          return { type: 'payment' };
        }
        const error = getVisibleAddressError();
        if (error) {
          return { type: 'error', error };
        }
        return null;
      },
      18000,
      300,
      epoch
    );

    if (result === ABORTED) {
      return;
    }
    if (!result) {
      await pause(context, '点击 Use this address 后，未出现推荐地址窗口或付款页面。');
      return;
    }
    if (result.type === 'error') {
      await pause(context, `Amazon 地址验证错误：${result.error}`);
      return;
    }
    if (result.type === 'payment') {
      const response = await transition(
        context,
        'VERIFY_PAYMENT_NAME',
        '正在检查付款页面收件人姓名',
        '未出现推荐地址窗口，已进入付款页面。'
      );
      if (response?.ok) {
        scheduleRun(100);
      }
      return;
    }

    const response = await transition(
      context,
      'WAIT_MANUAL_ADDRESS',
      '等待人工选择推荐地址并点击 Use this address',
      '检测到推荐地址窗口；插件不会自动选择 Original address。请人工选择地址并点击 Use this address，完成后插件将自动继续。',
      'warning'
    );
    if (response?.ok) {
      scheduleRun(800);
    }
  }

  async function handleWaitManualAddress(context) {
    const blocker = detectBlockingPage();
    if (blocker) {
      await pause(context, blocker);
      return;
    }

    // An underlying checkout page can remain in the DOM while Amazon's modal is
    // open. Never resume until the address-suggestion dialog itself is gone.
    if (getVisibleAddressSuggestionDialog()) {
      scheduleRun(900);
      return;
    }

    if (getPaymentRecipientName() && getPlaceOrderButtonSet().usable.length > 0) {
      const response = await transition(
        context,
        'VERIFY_PAYMENT_NAME',
        '人工地址选择完成，正在检查付款页面收件人姓名',
        '人工地址选择已完成，页面已进入付款步骤，插件自动恢复工作。'
      );
      if (response?.ok) {
        scheduleRun(100);
      }
      return;
    }

    // The user may choose Original, Suggested, or edit the address. The plugin
    // intentionally does not click either radio button or the confirmation button.
    scheduleRun(900);
  }

  async function handleWaitPayment(context, epoch) {
    const paymentReady = await waitFor(
      () => getPaymentRecipientName() && getPlaceOrderButtonSet().usable.length > 0,
      45000,
      350,
      epoch
    );
    if (paymentReady === ABORTED) {
      return;
    }
    if (!paymentReady) {
      await pause(context, detectBlockingPage() || '未进入可识别的付款页面。');
      return;
    }

    const response = await transition(
      context,
      'VERIFY_PAYMENT_NAME',
      '正在检查付款页面收件人姓名',
      '付款页面已加载；付款页金额不再参与检查。'
    );
    if (response?.ok) {
      scheduleRun(100);
    }
  }

  async function handleVerifyPayment(context, epoch) {
    const paymentData = await waitFor(
      () => {
        const recipientName = getPaymentRecipientName();
        const buttonSet = getPlaceOrderButtonSet();
        if (recipientName && buttonSet.usable.length > 0) {
          return { recipientName, buttonCount: buttonSet.usable.length };
        }
        return null;
      },
      30000,
      300,
      epoch
    );

    if (paymentData === ABORTED) {
      return;
    }
    if (!paymentData) {
      await pause(context, '付款页面未找到收件人姓名或可用的最终 Buy now 按钮。');
      return;
    }

    if (!namesMatch(paymentData.recipientName, context.row.normalizedName)) {
      await pause(
        context,
        `付款页面收件人姓名不一致：页面为“${paymentData.recipientName}”，目标为“${context.row.normalizedName}”。`
      );
      return;
    }

    const prepared = await send({
      type: 'BEFORE_FINAL_SUBMIT',
      runId: context.state.runId,
      observedRecipientName: paymentData.recipientName
    });
    if (!prepared?.ok) {
      return;
    }

    const finalContext = await send({ type: 'GET_CONTEXT' });
    if (
      !finalContext?.ok ||
      !finalContext.isWorkTab ||
      finalContext.state?.runId !== context.state.runId ||
      finalContext.state?.mode !== 'running' ||
      finalContext.state?.phase !== 'WAIT_ORDER_SUCCESS'
    ) {
      return;
    }

    let buttonSet = getPlaceOrderButtonSet();
    if (!buttonSet.primary) {
      await pauseAtPhase(context, 'WAIT_ORDER_SUCCESS', '进入最终提交阶段后重新定位最终 Buy now 失败；未执行付款点击。');
      return;
    }

    await pageLog(
      context,
      `付款页面收件人姓名核对通过；不检查付款页金额。共识别到 ${buttonSet.all.length} 个 Buy now 元素、${buttonSet.usable.length} 个可用按钮；先尝试${describePlaceOrderButton(buttonSet.primary)}。`
    );

    // The log/storage round trip can give Amazon time to repaint the checkout widget.
    // Re-query immediately before clicking so that a detached DOM reference is never used.
    buttonSet = getPlaceOrderButtonSet();
    const primaryButton = buttonSet.primary;
    if (!primaryButton) {
      await pauseAtPhase(context, 'WAIT_ORDER_SUCCESS', '最终点击前 Amazon 重绘了付款模块，重新定位顶部 Buy now 失败。');
      return;
    }

    const primaryDescription = describePlaceOrderButton(primaryButton);
    const primaryResult = await nativeClickAndObserve(primaryButton, epoch, 12000);
    if (primaryResult.evidence === ABORTED) {
      return;
    }
    if (primaryResult.evidence) {
      await pageLog(context, `${primaryDescription}已点击，检测到提交迹象：${primaryResult.evidence}。`, 'success');
      scheduleRun(500);
      return;
    }

    await pageLog(
      context,
      primaryResult.clicked
        ? `${primaryDescription}点击后 12 秒内未检测到跳转或处理状态，准备使用第二个 Buy now 兜底。`
        : `${primaryDescription}未能执行点击（${primaryResult.error || '未知原因'}），准备使用第二个 Buy now 兜底。`,
      'warning'
    );

    buttonSet = getPlaceOrderButtonSet();
    const fallbackButton = selectFallbackPlaceOrderButton(buttonSet, primaryButton);
    if (!fallbackButton) {
      await pageLog(context, '未找到独立的第二个可用 Buy now 按钮，将继续等待页面结果。', 'warning');
      scheduleRun(500);
      return;
    }

    const fallbackDescription = describePlaceOrderButton(fallbackButton);
    await pageLog(context, `尝试兜底按钮：${fallbackDescription}。`, 'warning');

    buttonSet = getPlaceOrderButtonSet();
    const freshFallback = selectFallbackPlaceOrderButton(buttonSet, primaryButton);
    if (!freshFallback) {
      await pageLog(context, '记录兜底步骤后按钮被 Amazon 重绘，未再次点击；继续等待页面结果。', 'warning');
      scheduleRun(500);
      return;
    }

    const fallbackResult = await nativeClickAndObserve(freshFallback, epoch, 15000);
    if (fallbackResult.evidence === ABORTED) {
      return;
    }
    if (fallbackResult.evidence) {
      await pageLog(
        context,
        `${describePlaceOrderButton(freshFallback)}已点击，检测到提交迹象：${fallbackResult.evidence}。`,
        'success'
      );
    } else {
      await pageLog(
        context,
        fallbackResult.clicked
          ? '第二个 Buy now 已执行点击，但 15 秒内仍未检测到跳转；继续等待下单成功页面。'
          : `第二个 Buy now 点击失败：${fallbackResult.error || '未知原因'}；继续等待页面结果。`,
        'warning'
      );
    }
    scheduleRun(500);
  }

  async function handleWaitOrderSuccess(context, epoch) {
    const result = await waitFor(
      () => {
        const firstCard = getFirstOrderCard();
        if (firstCard) {
          return { type: 'orders' };
        }
        const reviewLink = getReviewOrdersLink();
        if (reviewLink && isVisible(reviewLink)) {
          return { type: 'success', reviewLink };
        }
        return null;
      },
      90000,
      500,
      epoch
    );

    if (result === ABORTED) {
      return;
    }
    if (!result) {
      await pause(context, '点击最终 Buy now 后未找到下单成功页面，订单结果未确认。');
      return;
    }

    const response = await transition(
      context,
      'WAIT_ORDER_HISTORY',
      '正在核对最新订单',
      result.type === 'success'
        ? '下单成功页面已出现，点击 Review or edit your recent orders。'
        : '当前已在所有订单页面，开始核对第一张订单卡片。'
    );
    if (!response?.ok) {
      return;
    }

    if (result.type === 'success') {
      result.reviewLink.click();
    }
    scheduleRun(700);
  }

  async function handleOrderHistory(context, epoch) {
    const card = await waitFor(getFirstOrderCard, 45000, 350, epoch);
    if (card === ABORTED) {
      return;
    }
    if (!card) {
      await pause(context, '所有订单页面未找到第一张订单卡片。');
      return;
    }

    const recipientName = getOrderCardRecipientName(card);
    if (!recipientName) {
      await pause(context, '第一张订单卡片未读取到 Dispatch to 姓名。');
      return;
    }
    if (!namesMatch(recipientName, context.row.normalizedName)) {
      await pause(
        context,
        `第一张订单卡片收件人不一致：卡片为“${recipientName}”，目标为“${context.row.normalizedName}”。`
      );
      return;
    }

    const orderId = getOrderCardOrderId(card);
    if (!orderId) {
      await pause(context, '第一张订单卡片未读取到有效 Order ID。');
      return;
    }

    await send({
      type: 'ORDER_SUCCESS',
      runId: context.state.runId,
      orderId,
      observedRecipientName: recipientName
    });
  }

  async function runAutomation() {
    if (executing) {
      rerunRequested = true;
      return;
    }

    executing = true;
    rerunRequested = false;

    try {
      const context = await send({ type: 'GET_CONTEXT' });
      if (!context?.ok || !context.isWorkTab || !context.state || !context.row) {
        return;
      }
      if (context.state.mode !== 'running') {
        return;
      }

      activeRunId = context.state.runId;
      activeRowIndex = context.state.currentIndex;
      const epoch = abortGeneration;

      switch (context.state.phase) {
        case 'WAIT_PRODUCT':
          await handleProductPage(context, epoch);
          break;
        case 'VERIFY_PRODUCT_PRICE':
          await handleVerifyProductPrice(context, epoch);
          break;
        case 'SELECT_QUANTITY':
          await handleSelectQuantity(context, epoch);
          break;
        case 'VERIFY_QUANTITY':
          await handleVerifyQuantity(context, epoch);
          break;
        case 'WAIT_CHECKOUT':
          await handleCheckoutPage(context, epoch);
          break;
        case 'WAIT_ADDRESS_FORM':
          await handleAddressForm(context, epoch);
          break;
        case 'WAIT_ADDRESS_RESULT':
          await handleAddressResult(context, epoch);
          break;
        case 'WAIT_MANUAL_ADDRESS':
          await handleWaitManualAddress(context);
          break;
        case 'WAIT_PAYMENT':
          await handleWaitPayment(context, epoch);
          break;
        case 'VERIFY_PAYMENT_NAME':
          await handleVerifyPayment(context, epoch);
          break;
        case 'WAIT_ORDER_SUCCESS':
          await handleWaitOrderSuccess(context, epoch);
          break;
        case 'WAIT_ORDER_HISTORY':
          await handleOrderHistory(context, epoch);
          break;
        default:
          break;
      }
    } finally {
      executing = false;
      if (rerunRequested) {
        scheduleRun(100);
      }
    }
  }

  scheduleRun(300);
})();
