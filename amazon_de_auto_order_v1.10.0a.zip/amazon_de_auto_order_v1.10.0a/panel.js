(()=>{'use strict';const _0xe4a228649471=Object.freeze(["oa26j7KkpbKSta6TtKG0pQ==","oa26j7KkpbKIqbO0r7K5","oa26j7KkpbKMr6ez","oa26j7KkpbKEsqGmtJKvt7M=","oa26j7KkpbKTpbS0qa6nsw==","oa26g6GytIK1qaykqa6njK+jqw==","tKWttY+ypKWyiaQ=","lKWtteCPsqSlsuCJhA==","oa26jKmuqw==","gY2a4Kyprqs=","sbWhrrSptLmUr5OoqbA=","sbWhrrSptLngtK/gs6ipsA==","sqWjqbCppa60jqGtpQ==","sqWjqbCppa604K6hraU=","sKivrqWOta2ipbI=","sKivrqXgrrWtoqWy","s6ipsIGkpLKls7M=","s6ipsOChpKSypbOz","oaSksqWzs/I=","s6ipsIOptLk=","s6ipsOCjqbS5","s6ipsJCvs7ShrIOvpKU=","s6ipsOCwr7O0oazgo6+kpQ==","srWurqmupw==","sKG1s6Wk","tLKhrrOptKmvrqmupw==","JmBhKWpMJWRxKHRlL3xMKG93KEFUJ3N7k6ihrqehrg==","KH5TJUVlKWJEJmNAJl9lJUZyJ2pBL3xMJ21JJX5FJHp6JXdlJWREJ1BG","J3tEJVBIJU1VKWJEJmNAJl9lJUlNJ2FuKG5kKHRtJ0lpJ29uJHh6J2l6","KUBQKGFMKWJEJmNAJl9lJ3tEJVBIJU1VJVVGJVNB","Jm1jJXxPJUpgKHRtJUlNJUZNJmxhJ2FuKG5kKHRtJ0lpJ29uJHh6J2l6","KUBQKGFMJm1jJXxPJUpgJUVlKHRtJ0lpJ29u","J2FuKG5k4IGkpKWk4LSv4KKhs6ultOAkeE4ndG8obmEmVXApR08=","JmB4JW95JkB7JlVwKUdPJXl24JCyr6OlpaTgtK/gg6ilo6uvtbQ=","JklTJXxAJVVGJVNBKWF1JXl2KG9GJUhrJHhLJU1VJmhhJV1X","JmNAJl9lJVVGJVNBJVBrJ2hOJU1VJHt34CJCbPLu8PA=","KUBJJktpJ3J+JUdGKHRtJHlwJlVwKUdP","JVteKG97JXl2JmB4JW95KHRtJHlwJlVwKUdP","J21JJX5FJHhLJU1VJkhWJHtYJmx+KUBJJktpKWF1KV1i","KUBJJktp4IGtpbKpo6Gu4IW4sLKls7Pgpa6kqa6n4Kmu4PHw8Pk=","J0J5JUd7JVxwJV1AJmhhJV1X4IOooa6npQ==","J21JJX5FJVxwJV1AKUBJJktpKWF1KV1iJUpgKH19","J21JJX5FJlZwJXt6JVxwJV1AJ2pXJU9j","J21JJX5FJVxwJV1AKWpMKG9BJ3tTJl5c","J21JJX5FJHp6JXdlKUBJJktpJk5oKE1QJVxwJV1A","J21JJX5FJlxAJ3tIJHtYJmx+KWF1KV1i","J2FuKG5kJHtYJmx+JlZ5JXxPJXl2KH9bJUVlJlxAJ3tI4IK1ueCur7c=","JmB4JW95JHtYJmx+KWF1JlR2JHt2JHp6JWdTJVBN","J21JJX5FJHhLJU1VJkhQJUpfKWF1KV1i","JmB4JW95J2xsJHhAJXxgKG5iJU1VJU1hJ0lHJWdTJVBNJVJMJlZw4I+ypKWy4ImE","JUhHJk1iJUhwJHhLJHhAJl1hJlVwJk1u","J21JJX5FJHhLJHhAJU1VJHhLJU1VKVd0KVpU","JHt7JUphJW5MJkhQ","JHt7JUphJXdyJUFcJm1i","KH9QKGFMJHht","JXdyJlpCJUFc","JUhHJk1iJHht","JXdyJW5MJkhQ","JXdyJUFcJm1i","sKWupKmupw==","47K1ro2vpKU=","46O1srKlrrSSr7c=","46O1srKlrrSQqKGzpQ==","47ChtbOlkqWhs6+u","46G1tKivsqm6obSpr66GoamstbKlgqGy","47KltqGsqaShtKWBtbSor7KpuqG0qa+ugrSu","46Osr7Oll6mupK+3grSu","47O0obK0grSu","47KltLK5k6upsLClpIK0rg==","47ChtbOlgrSu","46OvrrSprrWlgrSu","47OrqbCCtK4=","47O0r7CCtK4=","46+wpa6UoaKCtK4=","46+ypKWyia60pbK2oayTpaOvrqSz","46OspaGylK+kobmPsqSlsrOCtK4=","46OspaGyg6GytIyvo6uCtK4=","46GkpJKvt7OCtK4=","47Klra+2pYKsoa6rgrSu","46OspaGyia6wtbSCtK4=","46OvsLmPsqSlsomks4K0rg==","46W4sK+ytJKlo6+ypLODs7aCtK4=","46OvsLmSpaOvsqSzgrSu","46OvsLmMr6eCtK4=","46OspaGyjK+ngrSu","46musLW0lKGirKWCr6S5","47Klo6+ypLOUoaKspYKvpLk=","46yvp4OvrrShqa6lsg==","47SvobO0","","r6KqpaO0","pbKyr7I=","qKmkpKWu","obW0qK+yqbqlpA==","pqGprKWk","gZWUiJ+GgYmMhYQ=","tLI=","tKQ=","qa6wtbTtsq+37a61raKlsg==","qa6wtbQ=","tKW4tA==","r6am","obKpoe2soaKlrA==","L3xMJ2xs4A==","4ChhTA==","sKGztKU=","tKW4tO+wrKGprg==","yQ==","4g==","yg==","zQ==","J3JYKHR0JWRxKHRlL3xaJ2xs4A==","4ChhTCZcSeA=","4CVIVy98TCZJeSlHTyZVcCZNbiV/RSlheyR4ZSZgfCR4euA=","4CVIVy98W6GkpLKls7Py4CR4eidpeiZXdiR5XyhmQSR/XSdVWSdpeiVIVyNAQg==","J3JYKHR0JWRxKHRlL3xaJHtOJX1TJUlNJU1VJUVDJmB8JXxAJWdLJlxAJWRaKH9YKEN9J3JYKHR04A==","4CVIVy98TCdsbOA=","4ChhTCh2RSVHeih+UyVFZShhaCZgfChMQyVbdCNAQg==","JXdyJkxJJHldJUhXJlZwJmB8JXxPJ3JYKHR04A==","4ChhTCZVcCZNbiNAQg==","JXdyJ3JYKHR04A==","4ChhTCVNVSVIVyZVcCZNbiNAQg==","qa6wtbSbpKG0oe2mqaWspJ0=","k4GWhZ+EkoGGlJ+Sj5eT","4A==","s7Wjo6Wzsw==","sqWjr7Kk7bO1o6Ols7M=","oqyvo6ulpA==","sqWjr7Kk7aWysq+y","s6upsLClpA==","sqWjr7Kk7behsq6prqc=","pa2wtLnto6WsrA==","JlpCJldgJXdlJH1cKG5wJX1V","pKm2","rK+n7aWtsLS5","JlpCJldgJldlJX9X","rK+n7bKvtw==","qa6mrw==","s7Chrg==","rK+n7bSpraU=","rK+n7ayltqWs","rK+n7bKvt+2uta2ipbI=","J2xs","KGFM","IkBU","rK+n7a2ls7Ohp6U=","JlxqJXxAJWdL","JlxqJ19l","JVxwJV1AJ3tE4A==","7w==","4AJ34CdsbOA=","4ChhTOACd+Ane0QlUEjg","J2xs4A==","4ChhTODv4CVFceA=","4CZdYQ==","JUVx4A==","l4GJlJ+JjpSFkpaBjA==","J21JJX5FJHhLJHhAJU1VL3xMJUlpJH1ZJ3pm4A==","4CdnUg==","JlpCJUFcJU5fJVtgL3xa","o6+tsKyltKWk","s7SvsLClpA==","orW0tK+u7OCprrC1tA==","JWRNJUh2JWRxKHRlL3xa","gZOJjg==","oaSksqWzsw==","o6m0uQ==","sK+ztKGs4KOvpKU=","JXdlJH1cJ3tTJl5c","4uI=","+w==","zco=","pa7th4I=","hbWyr7Cl74Klsqyprg==","rrWtpbKpow==","8u2kqaeptA==","qPLz","7Q==","nw==","L3t/","tKW4tO+js7b7o6ihsrOltP21tKbt+A==","oQ==","oa2huq+un6+ypKWyn7evsqufsqWjr7Kks58=","7qOztg==","o6ypo6s=","koWWgYyJhIGUhZ+BlZSIj5KJmoGUiY+O","JnJhJlxJJU9vJWREJ1BGJ1pEJlVwJk1uKGFMI0BC","Jm9PJU1VJHhLJU1VJld2KVd0KVd0KVpUJX9FKWF7Jlhv4PAiQFPz9vDw4CdaRCZVdCZVcCdnUiNAQg==","k5SBkpSfkpWO","KWJEJmNAJl9lJU9RJ05wJUZyJ2pBL3xMJHt7JUphJXdyJlpCJUFcJ21JJX5FJHp6JXdlJWREJ1BGI0BC","JHt7JUphJXdyJXxAJWdLI0BC","JX1TJUlNJXdlJH1cKG5wJX1VJHhtJnJhJlxJJU9vKUdNJHhLJ1pEKHdzKH9HKGFMI0BC","JXBGJkxJJX1TJUlNKH5TJUVlKGFoJmB8J1pEJlxAJlZwJlVwJk1uKUdNJlZwJWREJ1BG4A==","4CZdYSh3cyh/RyhucCV9VSNAQsrK","JklAJlxJ4LKls7WstP2zq6mwsKWk4CdaRChhTClDfSR8WilHTSZWcCR4SyVNVS98TCVMRSZLbCJAXJSlrbXgj7KkpbLgiYQlfVMlZGkld3IkeEsof0clTVUiQF0lUkwiQFwkenold2Uod3Mof0cvfEgobmIlTVUne1MmXlwmXGonYW4obmQvfEkiQF0jQEI=","JXdyJU9WJX5X4I+ypKWy4ImE4CdaRCZIUCVKXyhhTCR4TSR8WilHTSR4SyNAQiZtZCZTTSR9XCVPbyhDfSlAYCZIUClHTSVkTShuYiVNVS98TChvdydhbihuZCV3ciR6eiV3ZSZjQCZfZSNAQg==","koWUkpmfk4uJkJCFhJ+SlY4=","KUdNJHhLJHt7JUphKWJEJmNAJl9lJU9RJ05wJUZyJ2pBL3xMJXdyJlpCJUFcJ21JJX5FJHp6JXdlJWREJ1BGI0BC","JXdyJXxAJWdLKUdNJHhL4A==","4CZdYSh3cyh/RyhucCV9VSNAQg==","kIGVk4WfkpWO","JHt7JUphJXdyJlpCJUFcI0BC","g4+OlImOlYWfkpWO","JHt7JUphJ3tnJ3ttJklnKGFMI0BC","l4GJlJ+PkoSFkp+TlYODhZOT","l4GJlJ+PkoSFkp+IiZOUj5KZ","JX1TJUlNKG5iJU1VJU9vKEN9JXdyJ3tPJk9QJHpkJH1GJXBaJlxqJU9WJX5X4I+ypKWy4ImEI0BCKHdzKH9HJVBOJHhNJHxaJUZZJUVlJX1TJWRpJHhLJU1VKG5wJX1VL3xMKUdNJlZwKH9QKGFMJ1t4JVBM4JSlrbXgj7KkpbLgiYTgJU9vKEN9KUBgJkhQKUdNJWRNJHhLJU1VI0BCJ2FuJW5aKHdzKH9HJX1TJUlNKGFMJVBXL3xf","k4uJkJ+DlZKShY6Un42BjpWBjA==","JX1TJUlNKGFMJXdyKHdzKH9HI0BC","JX1TJUlNJW1YJVxo4IOBkpSfgpWJjISJjofgJ3tEJVBIJU1VJW5JJUVoKVRBI0BCJUFcJm1iJHt7JUphJVBOKVRBJHtNJHxaJH9dJ1VZL3xMJX9FKWF7JUVIJHp6JXdlJmNAJl9lKHRtJ0lpJ29uJVJMJlxAKH9RKG5iJU1VL3xMJUZNJH1/J1RoIkBcJ2FuKG5kJXdyJHp6JXdlJmNAJl9lJXl2JnhFKVlkJ3tEJVBIJU1VKVRBIkBdI0BCJ2FuJW5aJUFcJm1iJUVoKUNoJHt7JUphJVBXL3xf","JX1TJUlNKG5iJU1VJU9vKEN9JXdyJ3tPJk9QJHpkJH1GJXBaJlxqJU9WJX5X4I+ypKWy4ImEI0BCJUFcJm1iJVBOJHhNJHxaJUZZJUVlJX1TJWRpJHhLJU1VKG5wJX1VL3xMKUdNJlZwKH9QKGFMJU9vKEN9KUBgJkhQKUdNJWRNJHhLJU1VI0BCJ2FuJW5aJUFcJm1iJUVoKUNoJHt7JUphJVBXL3xf","k5SPkJ+SlY4=","JHt7JUphJXdyJUFcJm1iI0BC","j5CFjp+Xj5KLn5SBgg==","J2FuJW5aJnhFJ2l6KH5TJUVlKGFoJmB8JVJMJX1TJUlNJXdyJ3tTJl1fJHt7JUphJ1pEJXdlJH1cKG5wJX1VJVBXL3xfJX1TJWRpJkhQJUpfJHhLJU1VKVhyKUdNJWRNKG5wJX1VJHhNJHxaKGJrJUhgKVlkI0BC","g4yFgZKfhJKBhpSfko+Xkw==","KH5TJUVlJlVwJk1uJXdyJnhFJ2l6L3xbJX1TJWRpJkhQJUpfJHhLJU1VKVhyKUdNJWRNKG5wJX1VJHtNJH9dJ1VZI0BC","o6ihrqel","JHtFJVxoJkJoJXdyJ3tPJHp6JXdlJmNAJl9l4IGtobqvruAmdHslSmgodG0nSWknb24lUkwmXEAof1EobmIlTVUlUE4mSU0oQ30meEUpWWQjQELKyiZ4RSlZZCVQTi98TCV9UyVJTSd7RCVQSCVNVSR7eyVKYSR8WiR/XSZMQSVBXCZtYidKdiZAQS98WyhvZSZMSSlSbiR4TSR8WiVIYClZZCh0bSdJaSdvbiVVRiVTQS98TCR5XyR4TSR8WiVGWSVFZeCPsqSlsuCJhCNAQidhbiVuWiZ4RSlZZOCDgZKUn4KViYyEiY6H4Cd7RCVQSCVNVSlUQSVQVy98Xw==","g4yFgZKfg4GSlJ+ClYmMhImOh5+Mj4OL","J3tEJVBIJU1VJW5JJUVoKVRBJXdyJnhFKVlkI0BC","JX1TJUlNJnJhJlxJJ3tEJVBIJU1VJW5JJUVoKVRBI0BC","J2FuJW5aJnhFJ2l6JHtKJWRpJXdyJkhQJUpfKE53JU9W4I+ypKWy4ImE4CdaROCUpa214I+ypKWy4ImE4ClYcilHTSVkTShucCV9VSVQVy98X8rKJnhFJ2l6JVBOL3xMKH9ZJHpb4JSlrbXgj7KkpbLgiYTgJHtKJWRpJU9vJHtlJUZNJmxhJHhLJU1VI0BCJXdlJH1cKG5wJX1VI0BBKH5TJUVlJlVwJk1uJVJMJXdlJH1cJldlJX9XJHhNJHxaKGJrJnhFKVlkI0BC","g4yFgZKflI+EgZmfj5KEhZKfkoWDj5KEkw==","JXdyJnhFJ2l64A==","4CZdYeA=","JHtKJWRp","4CdaRCZIUCVKXyR4SyVNVShucCV9VSNAQg==","JXdlJH1cKG5wJX1VJHhtJnJhJlxJJU9vJWRNJUh2J1pE4I+ypKWy4ImEI0BC","JXdyJWRNJUh24A==","4CR4auCPsqSlsuCJhCNAQg==","JnJhJlxJJU9vJW98JUd6J1pEJXdlJH1cKG5wJX1VI0BC","JXdyJW98JUd64A==","4CZdYSV3ZSR9XChucCV9VSNAQg==","JXdlJH1cKG5wJX1VJXdyJWRNJUh2I0BC","JXdlJH1cJldlJX9XJXdyJWRNJUh2I0BC","J2FuJW5aJnhFJ2l6JXdlJH1cJldlJX9XJVBXL3xfJXdlJH1cKG5wJX1VJVJMJX1TJWRpJkhQJUpfJHhLJU1VKVhyKUdNJWRNKG5wJX1VJHhNJHxaKGJrJUhgKVlkI0BC","g4yFgZKfjI+Hkw==","JXdlJH1cJldlJX9XJXdyJnhFJ2l6I0BC","gZWUiI+SiZqBlImPjp+DiIGOh4WE","rK+joaw=","h4WUn4GMjJ+EgZSB"]),_0x9cd09ac67e8b=[];if(((_0xe4a228649471.length^192^12549^55968)>>>0)!==60311){throw new Error('Integrity error');}function _0x5a86870dc68b(_0x2d5cc3){const _0x1075dd=((_0x2d5cc3-55968)^12549);if(_0x9cd09ac67e8b[_0x1075dd]!==undefined)return _0x9cd09ac67e8b[_0x1075dd];const _0xd2e048=atob(_0xe4a228649471[_0x1075dd]),_0xa6e4d3=new Uint8Array(_0xd2e048.length);for(let _0xadcbab=0;_0xadcbab<_0xd2e048.length;_0xadcbab++)_0xa6e4d3[_0xadcbab]=_0xd2e048.charCodeAt(_0xadcbab)^192;return _0x9cd09ac67e8b[_0x1075dd]=new TextDecoder().decode(_0xa6e4d3);}const _0x27781c66ba6d = Object.freeze({
    RUN_STATE: _0x5a86870dc68b(68517),
    HISTORY: _0x5a86870dc68b(68516),
    LOGS: _0x5a86870dc68b(68519),
    DRAFT_ROWS: _0x5a86870dc68b(68518),
    SETTINGS: _0x5a86870dc68b(68513),
    CART_LOCK: _0x5a86870dc68b(68512)
});
const _0x600e8e13885a = Object.freeze([
    { key: _0x5a86870dc68b(68515), label: _0x5a86870dc68b(68514) },
    { key: _0x5a86870dc68b(68525), label: _0x5a86870dc68b(68524) },
    { key: _0x5a86870dc68b(68527), label: _0x5a86870dc68b(68526) },
    { key: _0x5a86870dc68b(68521), label: _0x5a86870dc68b(68520) },
    { key: _0x5a86870dc68b(68523), label: _0x5a86870dc68b(68522) },
    { key: _0x5a86870dc68b(68533), label: _0x5a86870dc68b(68532) },
    { key: _0x5a86870dc68b(68535), label: _0x5a86870dc68b(68535) },
    { key: _0x5a86870dc68b(68534), label: _0x5a86870dc68b(68529) },
    { key: _0x5a86870dc68b(68528), label: _0x5a86870dc68b(68531) }
]);
const _0x6f45f55dec29 = new Set([_0x5a86870dc68b(68530), _0x5a86870dc68b(68541), _0x5a86870dc68b(68540)]);
const _0x7ba06870a364 = _0x5a86870dc68b(68543);
const _0x960464294aa8 = Object.freeze({
    PRECHECK_CONFLICT: _0x5a86870dc68b(68542),
    CHECK_CART_BEFORE_PRECHECK: _0x5a86870dc68b(68537),
    GROUP_PRECHECK_PRODUCT: _0x5a86870dc68b(68536),
    CHECK_CART_BEFORE_BUILD: _0x5a86870dc68b(68539),
    GROUP_ADD_PRODUCT: _0x5a86870dc68b(68538),
    WAIT_GROUP_ADD_RESULT: _0x5a86870dc68b(68549),
    GROUP_PROCEED_CHECKOUT: _0x5a86870dc68b(68548),
    WAIT_PRODUCT: _0x5a86870dc68b(68551),
    VERIFY_PRODUCT_PRICE: _0x5a86870dc68b(68550),
    SELECT_QUANTITY: _0x5a86870dc68b(68545),
    VERIFY_QUANTITY: _0x5a86870dc68b(68544),
    WAIT_CHECKOUT: _0x5a86870dc68b(68547),
    SELECT_PAYMENT_CARD: _0x5a86870dc68b(68546),
    WAIT_CHANGE_ADDRESS: _0x5a86870dc68b(68557),
    WAIT_ADD_ADDRESS_AFTER_CHANGE: _0x5a86870dc68b(68556),
    WAIT_ADDRESS_FORM: _0x5a86870dc68b(68559),
    WAIT_ADDRESS_RESULT: _0x5a86870dc68b(68558),
    WAIT_MANUAL_ADDRESS: _0x5a86870dc68b(68553),
    WAIT_PAYMENT: _0x5a86870dc68b(68552),
    CONFIRM_PAYMENT_METHOD: _0x5a86870dc68b(68555),
    VERIFY_PAYMENT_NAME: _0x5a86870dc68b(68554),
    WAIT_ORDER_SUCCESS: _0x5a86870dc68b(68565),
    WAIT_ORDER_HISTORY: _0x5a86870dc68b(68564),
    TRANSITIONING: _0x5a86870dc68b(68567),
    WAIT_INTERVAL: _0x5a86870dc68b(68566),
    COMPLETED: _0x5a86870dc68b(68561),
    STOPPED: _0x5a86870dc68b(68560)
});
const _0x820d8c7943d4 = Object.freeze({
    running: _0x5a86870dc68b(68563),
    paused: _0x5a86870dc68b(68562),
    transitioning: _0x5a86870dc68b(68573),
    completed: _0x5a86870dc68b(68572),
    stopped: _0x5a86870dc68b(68575)
});
let _0xb3ef0c591ee4 = [];
let _0xf75432d950ea = null;
let _0x87ec51b2b698 = [];
let _0x88e64f38612c = { orderIntervalSeconds: 30 };
let _0xb547d505b30d = null;
let _0x43f36b13fcb2 = null;
let _0x64e1a2314452 = null;
let _0x0a43e749a3f5 = _0x5a86870dc68b(68574);
let _0x8cd9ca7f0758 = false;
const _0x78429c9b51ec = {
    runMode: document.querySelector(_0x5a86870dc68b(68569)),
    currentRow: document.querySelector(_0x5a86870dc68b(68568)),
    currentPhase: document.querySelector(_0x5a86870dc68b(68571)),
    pauseReason: document.querySelector(_0x5a86870dc68b(68570)),
    authorizationFailureBar: document.querySelector(_0x5a86870dc68b(68581)),
    revalidateAuthorizationBtn: document.querySelector(_0x5a86870dc68b(68580)),
    closeWindowBtn: document.querySelector(_0x5a86870dc68b(68583)),
    startBtn: document.querySelector(_0x5a86870dc68b(68582)),
    retrySkippedBtn: document.querySelector(_0x5a86870dc68b(68577)),
    pauseBtn: document.querySelector(_0x5a86870dc68b(68576)),
    continueBtn: document.querySelector(_0x5a86870dc68b(68579)),
    skipBtn: document.querySelector(_0x5a86870dc68b(68578)),
    stopBtn: document.querySelector(_0x5a86870dc68b(68589)),
    openTabBtn: document.querySelector(_0x5a86870dc68b(68588)),
    orderIntervalSeconds: document.querySelector(_0x5a86870dc68b(68591)),
    clearTodayOrdersBtn: document.querySelector(_0x5a86870dc68b(68590)),
    clearCartLockBtn: document.querySelector(_0x5a86870dc68b(68585)),
    addRowsBtn: document.querySelector(_0x5a86870dc68b(68584)),
    removeBlankBtn: document.querySelector(_0x5a86870dc68b(68587)),
    clearInputBtn: document.querySelector(_0x5a86870dc68b(68586)),
    copyOrderIdsBtn: document.querySelector(_0x5a86870dc68b(68597)),
    exportRecordsCsvBtn: document.querySelector(_0x5a86870dc68b(68596)),
    copyRecordsBtn: document.querySelector(_0x5a86870dc68b(68599)),
    copyLogBtn: document.querySelector(_0x5a86870dc68b(68598)),
    clearLogBtn: document.querySelector(_0x5a86870dc68b(68593)),
    inputTableBody: document.querySelector(_0x5a86870dc68b(68592)),
    recordsTableBody: document.querySelector(_0x5a86870dc68b(68595)),
    logContainer: document.querySelector(_0x5a86870dc68b(68594)),
    toast: document.querySelector(_0x5a86870dc68b(68605))
};
function _0xe8d6b114e071() {
    return crypto.randomUUID();
}
function _0x5c8df82c9289() {
    return {
        _rowId: _0xe8d6b114e071(),
        ...Object.fromEntries(_0x600e8e13885a.map(({ key: _0x3699b2a21973 }) => [_0x3699b2a21973, _0x5a86870dc68b(68604)]))
    };
}
function _0xeb589779cf4e(_0x0eec84db5082) {
    const _0x45a4893f44e3 = _0x0eec84db5082 && typeof _0x0eec84db5082 === _0x5a86870dc68b(68607) ? _0x0eec84db5082 : {};
    const _0x07e3b8846e93 = String(_0x45a4893f44e3._rowId || _0x45a4893f44e3.draftRowId || _0x5a86870dc68b(68604)).trim() || _0xe8d6b114e071();
    return {
        _rowId: _0x07e3b8846e93,
        ...Object.fromEntries(_0x600e8e13885a.map(({ key: _0xa26f85c10826 }) => [_0xa26f85c10826, String(_0x45a4893f44e3[_0xa26f85c10826] ?? _0x5a86870dc68b(68604))]))
    };
}
function _0xa87cb087f3e5(_0xde20c4ba104b, _0x15534958f376 = 12) {
    const _0x214b77c1b9dd = _0xde20c4ba104b.map(_0xeb589779cf4e);
    while (_0x214b77c1b9dd.length < _0x15534958f376) {
        _0x214b77c1b9dd.push(_0x5c8df82c9289());
    }
    return _0x214b77c1b9dd;
}
function _0xe071602742c9(_0xa9a866c20b7e) {
    return _0x600e8e13885a.every(({ key: _0x5723f7f61279 }) => String(_0xa9a866c20b7e?.[_0x5723f7f61279] ?? _0x5a86870dc68b(68604)).trim() === _0x5a86870dc68b(68604));
}
function _0x7531f9850a2e(_0x22eed9f0c3c4, _0x23e3d4fb76ef = false) {
    clearTimeout(_0x64e1a2314452);
    _0x78429c9b51ec.toast.textContent = _0x22eed9f0c3c4;
    _0x78429c9b51ec.toast.classList.toggle(_0x5a86870dc68b(68606), _0x23e3d4fb76ef);
    _0x78429c9b51ec.toast.classList.remove(_0x5a86870dc68b(68601));
    _0x64e1a2314452 = setTimeout(() => _0x78429c9b51ec.toast.classList.add(_0x5a86870dc68b(68601)), 4000);
}
function _0x1a9d211c6961(_0xbb0b4fd18cd1, _0x62b5b3f94d95 = true) {
    if (_0xbb0b4fd18cd1?.authorized) {
        _0x0a43e749a3f5 = _0x5a86870dc68b(68600);
        _0x8cd9ca7f0758 = false;
        _0x78429c9b51ec.authorizationFailureBar.classList.add(_0x5a86870dc68b(68601));
        _0xd42da4927745();
        return;
    }
    _0x0a43e749a3f5 = _0x5a86870dc68b(68603);
    _0x78429c9b51ec.authorizationFailureBar.classList.remove(_0x5a86870dc68b(68601));
    _0xd42da4927745();
    if (_0x62b5b3f94d95 && !_0x8cd9ca7f0758) {
        _0x8cd9ca7f0758 = true;
        window.alert(_0x7ba06870a364);
    }
}
function _0x6e103e97519f(_0x042ff072be18) {
    return Boolean(_0x042ff072be18?.code === _0x5a86870dc68b(68602) ||
        _0x042ff072be18?.authorization?.authorized === false);
}
async function _0xf5b37fbcd2d2(_0x51d5a26256ab, _0xe6cc9bcdc315 = {}) {
    try {
        const _0x8a15f80297a1 = await chrome.runtime.sendMessage({ type: _0x51d5a26256ab, ..._0xe6cc9bcdc315 });
        if (_0x8a15f80297a1?.authorization) {
            _0x1a9d211c6961(_0x8a15f80297a1.authorization, true);
        }
        if (_0x6e103e97519f(_0x8a15f80297a1)) {
            _0x1a9d211c6961(_0x8a15f80297a1.authorization || { authorized: false }, true);
            return _0x8a15f80297a1;
        }
        if (!_0x8a15f80297a1?.ok && _0x8a15f80297a1?.error) {
            _0x7531f9850a2e(_0x8a15f80297a1.error, true);
        }
        return _0x8a15f80297a1;
    }
    catch (_0x93c44b604fa0) {
        _0x7531f9850a2e(_0x93c44b604fa0.message || String(_0x93c44b604fa0), true);
        return { ok: false, error: _0x93c44b604fa0.message || String(_0x93c44b604fa0) };
    }
}
function _0xa973c28ff56b() {
    _0x78429c9b51ec.inputTableBody.replaceChildren();
    const _0x1e40fd363d21 = document.createDocumentFragment();
    _0xb3ef0c591ee4.forEach((_0xbc2957c34cfe, _0xa93fe428e2e3) => {
        const _0x9dd7f40109ab = document.createElement(_0x5a86870dc68b(68613));
        const _0x15720711e791 = document.createElement(_0x5a86870dc68b(68612));
        _0x15720711e791.className = _0x5a86870dc68b(68615);
        _0x15720711e791.textContent = String(_0xa93fe428e2e3 + 1);
        _0x9dd7f40109ab.appendChild(_0x15720711e791);
        _0x600e8e13885a.forEach(({ key: _0xf891359e1a71, label: _0x409b66c1a429 }, _0x3b144d7ae5d1) => {
            const _0x26e2bb4340d6 = document.createElement(_0x5a86870dc68b(68612));
            const _0xc57d5939a513 = document.createElement(_0x5a86870dc68b(68614));
            _0xc57d5939a513.type = _0x5a86870dc68b(68609);
            _0xc57d5939a513.value = String(_0xbc2957c34cfe[_0xf891359e1a71] ?? _0x5a86870dc68b(68604));
            _0xc57d5939a513.autocomplete = _0x5a86870dc68b(68608);
            _0xc57d5939a513.spellcheck = false;
            _0xc57d5939a513.setAttribute(_0x5a86870dc68b(68611), (_0x5a86870dc68b(68604) + _0x409b66c1a429 + _0x5a86870dc68b(68610) + (_0xa93fe428e2e3 + 1) + _0x5a86870dc68b(68621)));
            _0xc57d5939a513.dataset.rowIndex = String(_0xa93fe428e2e3);
            _0xc57d5939a513.dataset.columnIndex = String(_0x3b144d7ae5d1);
            _0xc57d5939a513.dataset.field = _0xf891359e1a71;
            _0xc57d5939a513.addEventListener(_0x5a86870dc68b(68614), () => {
                _0xb3ef0c591ee4[_0xa93fe428e2e3][_0xf891359e1a71] = _0xc57d5939a513.value;
                _0x189b0b39467e();
            });
            _0xc57d5939a513.addEventListener(_0x5a86870dc68b(68620), (_0x44adbc5497cf) => {
                const _0x650e0b5228e7 = _0x44adbc5497cf.clipboardData?.getData(_0x5a86870dc68b(68623)) || _0x5a86870dc68b(68604);
                if (!_0x650e0b5228e7.includes(_0x5a86870dc68b(68622)) && !/[\r\n]/.test(_0x650e0b5228e7)) {
                    return;
                }
                _0x44adbc5497cf.preventDefault();
                _0xe07f3c1af873(_0xa93fe428e2e3, _0x3b144d7ae5d1, _0x650e0b5228e7);
            });
            _0x26e2bb4340d6.appendChild(_0xc57d5939a513);
            _0x9dd7f40109ab.appendChild(_0x26e2bb4340d6);
        });
        _0x1e40fd363d21.appendChild(_0x9dd7f40109ab);
    });
    _0x78429c9b51ec.inputTableBody.appendChild(_0x1e40fd363d21);
    _0xd42da4927745();
}
function _0x07211ae5abc8(_0x0a4e21e4002a) {
    const _0x33360b5fb9ef = [];
    let _0x0ede7103df30 = [];
    let _0x491925ebd92a = _0x5a86870dc68b(68604);
    let _0xee86406df7f5 = false;
    for (let _0xe32622b0c976 = 0; _0xe32622b0c976 < _0x0a4e21e4002a.length; _0xe32622b0c976 += 1) {
        const _0x6595a3d3ec1a = _0x0a4e21e4002a[_0xe32622b0c976];
        const _0x082cbf336698 = _0x0a4e21e4002a[_0xe32622b0c976 + 1];
        if (_0x6595a3d3ec1a === _0x5a86870dc68b(68617)) {
            if (_0xee86406df7f5 && _0x082cbf336698 === _0x5a86870dc68b(68617)) {
                _0x491925ebd92a += _0x5a86870dc68b(68617);
                _0xe32622b0c976 += 1;
            }
            else {
                _0xee86406df7f5 = !_0xee86406df7f5;
            }
            continue;
        }
        if (!_0xee86406df7f5 && _0x6595a3d3ec1a === _0x5a86870dc68b(68622)) {
            _0x0ede7103df30.push(_0x491925ebd92a);
            _0x491925ebd92a = _0x5a86870dc68b(68604);
            continue;
        }
        if (!_0xee86406df7f5 && (_0x6595a3d3ec1a === _0x5a86870dc68b(68616) || _0x6595a3d3ec1a === _0x5a86870dc68b(68619))) {
            if (_0x6595a3d3ec1a === _0x5a86870dc68b(68619) && _0x082cbf336698 === _0x5a86870dc68b(68616)) {
                _0xe32622b0c976 += 1;
            }
            _0x0ede7103df30.push(_0x491925ebd92a);
            _0x33360b5fb9ef.push(_0x0ede7103df30);
            _0x0ede7103df30 = [];
            _0x491925ebd92a = _0x5a86870dc68b(68604);
            continue;
        }
        _0x491925ebd92a += _0x6595a3d3ec1a;
    }
    _0x0ede7103df30.push(_0x491925ebd92a);
    _0x33360b5fb9ef.push(_0x0ede7103df30);
    while (_0x33360b5fb9ef.length > 1 && _0x33360b5fb9ef[_0x33360b5fb9ef.length - 1].every((_0x8c944e9bada2) => _0x8c944e9bada2 === _0x5a86870dc68b(68604))) {
        _0x33360b5fb9ef.pop();
    }
    return _0x33360b5fb9ef;
}
function _0xe07f3c1af873(_0x8bf7aa0ba868, _0xd3c3dcb1a2e0, _0x066fa7b4a1b2) {
    const _0xc032defee647 = _0x07211ae5abc8(_0x066fa7b4a1b2);
    const _0x00c0736bdb0f = _0xc032defee647.some((_0x06f8c343cc85) => _0x06f8c343cc85.length > 1);
    if (_0x00c0736bdb0f) {
        const _0x4c27461f387a = _0xc032defee647.findIndex((_0x9f3fafec3281) => _0x9f3fafec3281.length !== _0x600e8e13885a.length);
        if (_0x4c27461f387a >= 0) {
            _0x7531f9850a2e((_0x5a86870dc68b(68618) + (_0x4c27461f387a + 1) + _0x5a86870dc68b(68629) + _0xc032defee647[_0x4c27461f387a].length + _0x5a86870dc68b(68628) + _0x600e8e13885a.length + _0x5a86870dc68b(68631)), true);
            return;
        }
        _0xd3c3dcb1a2e0 = 0;
    }
    const _0x67783d3f7b22 = _0x600e8e13885a.length - _0xd3c3dcb1a2e0;
    const _0x4ac388344367 = _0xc032defee647.findIndex((_0x6623bed42edf) => _0x6623bed42edf.length > _0x67783d3f7b22);
    if (_0x4ac388344367 >= 0) {
        _0x7531f9850a2e((_0x5a86870dc68b(68630) + _0x67783d3f7b22 + _0x5a86870dc68b(68625) + (_0x4ac388344367 + 1) + _0x5a86870dc68b(68624)), true);
        return;
    }
    const _0xc7e9f5d5d336 = _0x8bf7aa0ba868 + _0xc032defee647.length;
    while (_0xb3ef0c591ee4.length < _0xc7e9f5d5d336) {
        _0xb3ef0c591ee4.push(_0x5c8df82c9289());
    }
    _0xc032defee647.forEach((_0x6ed86e080032, _0xef92b84dabf3) => {
        _0x6ed86e080032.forEach((_0xbd061a99b4f5, _0x537580148d99) => {
            const _0x070e2e279b9f = _0xd3c3dcb1a2e0 + _0x537580148d99;
            if (_0x070e2e279b9f >= _0x600e8e13885a.length) {
                return;
            }
            const _0x1c98e91d36d2 = _0x600e8e13885a[_0x070e2e279b9f].key;
            _0xb3ef0c591ee4[_0x8bf7aa0ba868 + _0xef92b84dabf3][_0x1c98e91d36d2] = _0xbd061a99b4f5;
        });
    });
    _0xb3ef0c591ee4 = _0xa87cb087f3e5(_0xb3ef0c591ee4);
    _0xa973c28ff56b();
    _0x189b0b39467e(0);
    _0x7531f9850a2e(_0x00c0736bdb0f ? (_0x5a86870dc68b(68627) + _0xc032defee647.length + _0x5a86870dc68b(68626)) : (_0x5a86870dc68b(68637) + _0xc032defee647.length + _0x5a86870dc68b(68636)));
}
function _0x65a3fb1542eb() {
    const _0x0fd5258dc7fe = [..._0x78429c9b51ec.inputTableBody.querySelectorAll(_0x5a86870dc68b(68639))];
    _0x0fd5258dc7fe.forEach((_0xbda212fd0044) => {
        const _0x30e13977ee35 = Number(_0xbda212fd0044.dataset.rowIndex);
        const _0x9ad25fe3f4e4 = _0xbda212fd0044.dataset.field;
        if (_0xb3ef0c591ee4[_0x30e13977ee35] && _0x9ad25fe3f4e4) {
            _0xb3ef0c591ee4[_0x30e13977ee35][_0x9ad25fe3f4e4] = _0xbda212fd0044.value;
        }
    });
    return _0xb3ef0c591ee4.map(_0xeb589779cf4e);
}
function _0x189b0b39467e(_0xe8d21faacfc6 = 450) {
    clearTimeout(_0x43f36b13fcb2);
    _0x43f36b13fcb2 = setTimeout(async () => {
        _0x43f36b13fcb2 = null;
        if (_0xf75432d950ea && _0x6f45f55dec29.has(_0xf75432d950ea.mode)) {
            return;
        }
        _0x65a3fb1542eb();
        await _0xf5b37fbcd2d2(_0x5a86870dc68b(68638), { rows: _0xb3ef0c591ee4 });
    }, _0xe8d21faacfc6);
}
function _0xcac8ab4b2b95(_0x2028388ec004) {
    return String(_0x2028388ec004 ?? _0x5a86870dc68b(68604)).replace(/[\t\r\n]+/g, _0x5a86870dc68b(68633)).trim();
}
function _0x74f2d965d413(_0xdebf69df4316, _0xbd4e1aadbd6b, _0xb0b4ddef4a2c = _0x5a86870dc68b(68604)) {
    const _0x1f296bed78ce = document.createElement(_0x5a86870dc68b(68612));
    _0x1f296bed78ce.textContent = String(_0xbd4e1aadbd6b ?? _0x5a86870dc68b(68604));
    _0x1f296bed78ce.title = String(_0xbd4e1aadbd6b ?? _0x5a86870dc68b(68604));
    if (_0xb0b4ddef4a2c) {
        _0x1f296bed78ce.className = _0xb0b4ddef4a2c;
    }
    _0xdebf69df4316.appendChild(_0x1f296bed78ce);
}
function _0x98cde2a2b7af(_0x0343c94b3738) {
    if (_0x0343c94b3738.result === _0x5a86870dc68b(68632)) {
        return _0x5a86870dc68b(68635);
    }
    if (_0x0343c94b3738.result === _0x5a86870dc68b(68634)) {
        return _0x5a86870dc68b(68645);
    }
    if (_0x0343c94b3738.result === _0x5a86870dc68b(68644)) {
        return _0x5a86870dc68b(68647);
    }
    return _0x5a86870dc68b(68604);
}
function _0xbdb7f2b93ffe(_0x7aca4a304206) {
    if (_0x7aca4a304206?.result === _0x5a86870dc68b(68632) && /^\d{3}-\d{7}-\d{7}$/.test(String(_0x7aca4a304206?.orderId || _0x5a86870dc68b(68604)).trim())) {
        return String(_0x7aca4a304206.orderId).trim();
    }
    return String(_0x7aca4a304206?.status || _0x5a86870dc68b(68604));
}
function _0x73b5722663ca() {
    _0x78429c9b51ec.recordsTableBody.replaceChildren();
    const _0x4e1bc3cafa31 = Array.isArray(_0xf75432d950ea?.rows) ? _0xf75432d950ea.rows : [];
    if (_0x4e1bc3cafa31.length === 0) {
        const _0x9292ddbaed9a = document.createElement(_0x5a86870dc68b(68613));
        const _0x75ef63c7ab6e = document.createElement(_0x5a86870dc68b(68612));
        _0x75ef63c7ab6e.colSpan = 7;
        _0x75ef63c7ab6e.className = _0x5a86870dc68b(68646);
        _0x75ef63c7ab6e.textContent = _0x5a86870dc68b(68641);
        _0x9292ddbaed9a.appendChild(_0x75ef63c7ab6e);
        _0x78429c9b51ec.recordsTableBody.appendChild(_0x9292ddbaed9a);
        return;
    }
    const _0xb94ca3b38a60 = document.createDocumentFragment();
    _0x4e1bc3cafa31.forEach((_0x0bc3a8d0a5eb) => {
        const _0xf47c1d8a8e61 = document.createElement(_0x5a86870dc68b(68613));
        _0x74f2d965d413(_0xf47c1d8a8e61, _0x0bc3a8d0a5eb.temuOrderId || _0x5a86870dc68b(68604));
        _0x74f2d965d413(_0xf47c1d8a8e61, _0x0bc3a8d0a5eb.asin || _0x5a86870dc68b(68604));
        _0x74f2d965d413(_0xf47c1d8a8e61, _0x0bc3a8d0a5eb.recipientName || _0x5a86870dc68b(68604));
        _0x74f2d965d413(_0xf47c1d8a8e61, _0x0bc3a8d0a5eb.shipAddress || _0x5a86870dc68b(68604));
        _0x74f2d965d413(_0xf47c1d8a8e61, _0x0bc3a8d0a5eb.shipCity || _0x5a86870dc68b(68604));
        _0x74f2d965d413(_0xf47c1d8a8e61, _0x0bc3a8d0a5eb.shipPostalCode || _0x5a86870dc68b(68604));
        _0x74f2d965d413(_0xf47c1d8a8e61, _0xbdb7f2b93ffe(_0x0bc3a8d0a5eb), _0x98cde2a2b7af(_0x0bc3a8d0a5eb));
        _0xb94ca3b38a60.appendChild(_0xf47c1d8a8e61);
    });
    _0x78429c9b51ec.recordsTableBody.appendChild(_0xb94ca3b38a60);
}
function _0xd892ba227501() {
    _0x78429c9b51ec.logContainer.replaceChildren();
    if (!Array.isArray(_0x87ec51b2b698) || _0x87ec51b2b698.length === 0) {
        const _0xe61dcac7b7e5 = document.createElement(_0x5a86870dc68b(68640));
        _0xe61dcac7b7e5.className = _0x5a86870dc68b(68643);
        _0xe61dcac7b7e5.textContent = _0x5a86870dc68b(68642);
        _0x78429c9b51ec.logContainer.appendChild(_0xe61dcac7b7e5);
        return;
    }
    const _0x597c1dcb8267 = document.createDocumentFragment();
    _0x87ec51b2b698.forEach((_0x381488a28913) => {
        const _0xa9fa80cdc588 = document.createElement(_0x5a86870dc68b(68640));
        _0xa9fa80cdc588.className = _0x5a86870dc68b(68653);
        _0xa9fa80cdc588.dataset.level = _0x381488a28913.level || _0x5a86870dc68b(68652);
        const _0x0119aca3a537 = document.createElement(_0x5a86870dc68b(68655));
        _0x0119aca3a537.className = _0x5a86870dc68b(68654);
        _0x0119aca3a537.textContent = _0x381488a28913.time || _0x5a86870dc68b(68604);
        const _0xcb8e873a7650 = document.createElement(_0x5a86870dc68b(68655));
        _0xcb8e873a7650.className = _0x5a86870dc68b(68649);
        _0xcb8e873a7650.textContent = _0x381488a28913.level || _0x5a86870dc68b(68652);
        const _0xc214539244a0 = document.createElement(_0x5a86870dc68b(68655));
        _0xc214539244a0.className = _0x5a86870dc68b(68648);
        _0xc214539244a0.textContent = _0x381488a28913.rowNumber ? (_0x5a86870dc68b(68651) + _0x381488a28913.rowNumber + _0x5a86870dc68b(68650)) : _0x5a86870dc68b(68661);
        const _0xc6c970c9f2d4 = document.createElement(_0x5a86870dc68b(68655));
        _0xc6c970c9f2d4.className = _0x5a86870dc68b(68660);
        _0xc6c970c9f2d4.textContent = _0x381488a28913.message || _0x5a86870dc68b(68604);
        _0xa9fa80cdc588.append(_0x0119aca3a537, _0xcb8e873a7650, _0xc214539244a0, _0xc6c970c9f2d4);
        _0x597c1dcb8267.appendChild(_0xa9fa80cdc588);
    });
    _0x78429c9b51ec.logContainer.appendChild(_0x597c1dcb8267);
    _0x78429c9b51ec.logContainer.scrollTop = _0x78429c9b51ec.logContainer.scrollHeight;
}
function _0xfc50fe83939d() {
    if (!_0xf75432d950ea) {
        _0x78429c9b51ec.runMode.textContent = _0x5a86870dc68b(68663);
        _0x78429c9b51ec.currentRow.textContent = _0x5a86870dc68b(68661);
        _0x78429c9b51ec.currentPhase.textContent = _0x5a86870dc68b(68661);
        _0x78429c9b51ec.pauseReason.classList.add(_0x5a86870dc68b(68601));
        _0x78429c9b51ec.pauseReason.textContent = _0x5a86870dc68b(68604);
        return;
    }
    _0x78429c9b51ec.runMode.textContent = _0x820d8c7943d4[_0xf75432d950ea.mode] || _0xf75432d950ea.mode || _0x5a86870dc68b(68662);
    const _0x5c56ad7fb6d8 = Number.isInteger(_0xf75432d950ea.currentIndex) ? _0xf75432d950ea.rows?.[_0xf75432d950ea.currentIndex] : null;
    const _0x8d6423312942 = Number.isInteger(_0xf75432d950ea.currentGroupIndex) ? _0xf75432d950ea.groups?.[_0xf75432d950ea.currentGroupIndex] : null;
    if (_0x5c56ad7fb6d8 && _0x8d6423312942) {
        const _0x99ed8b4a381f = _0xf75432d950ea.currentGroupIndex + 1;
        const _0x24146d079f2f = _0xf75432d950ea.groups?.length || 0;
        _0x78429c9b51ec.currentRow.textContent = _0x8d6423312942.isCombined
            ? (_0x5a86870dc68b(68657) + _0x99ed8b4a381f + _0x5a86870dc68b(68656) + _0x24146d079f2f + _0x5a86870dc68b(68659) + _0x5c56ad7fb6d8.rowNumber + _0x5a86870dc68b(68658) + (_0x8d6423312942.rowIndexes?.length || 0) + _0x5a86870dc68b(68621)) : (_0x5a86870dc68b(68657) + _0x99ed8b4a381f + _0x5a86870dc68b(68656) + _0x24146d079f2f + _0x5a86870dc68b(68659) + _0x5c56ad7fb6d8.rowNumber + _0x5a86870dc68b(68621));
    }
    else {
        _0x78429c9b51ec.currentRow.textContent = _0x5c56ad7fb6d8 ? (_0x5a86870dc68b(68669) + _0x5c56ad7fb6d8.rowNumber + _0x5a86870dc68b(68668) + _0xf75432d950ea.rows.length + _0x5a86870dc68b(68671)) : (_0x5a86870dc68b(68670) + (_0xf75432d950ea.rows?.length || 0) + _0x5a86870dc68b(68671));
    }
    if (_0xf75432d950ea.phase === _0x5a86870dc68b(68665)) {
        const _0x0f6e0a6d0a5a = Date.parse(String(_0xf75432d950ea.intervalEndsAt || _0x5a86870dc68b(68604)));
        const _0x86bdfe3e163e = _0xf75432d950ea.mode === _0x5a86870dc68b(68541)
            ? Math.max(0, Number(_0xf75432d950ea.intervalRemainingSeconds || 0))
            : Math.max(0, Math.ceil((Number.isFinite(_0x0f6e0a6d0a5a) ? _0x0f6e0a6d0a5a - Date.now() : 0) / 1000));
        _0x78429c9b51ec.currentPhase.textContent = (_0x5a86870dc68b(68664) + _0x86bdfe3e163e + _0x5a86870dc68b(68667));
    }
    else {
        _0x78429c9b51ec.currentPhase.textContent = _0x960464294aa8[_0xf75432d950ea.phase] || _0xf75432d950ea.phase || _0x5a86870dc68b(68661);
    }
    if (_0xf75432d950ea.pauseReason) {
        _0x78429c9b51ec.pauseReason.textContent = (_0x5a86870dc68b(68666) + _0xf75432d950ea.pauseReason + _0x5a86870dc68b(68604));
        _0x78429c9b51ec.pauseReason.classList.remove(_0x5a86870dc68b(68601));
    }
    else {
        _0x78429c9b51ec.pauseReason.classList.add(_0x5a86870dc68b(68601));
        _0x78429c9b51ec.pauseReason.textContent = _0x5a86870dc68b(68604);
    }
}
function _0xd42da4927745() {
    const _0x03f8c1396022 = _0xf75432d950ea?.mode || _0x5a86870dc68b(68604);
    const _0xf2f48da60b4f = _0x6f45f55dec29.has(_0x03f8c1396022);
    const _0x6e3f930d1791 = _0x03f8c1396022 === _0x5a86870dc68b(68530) || _0x03f8c1396022 === _0x5a86870dc68b(68540);
    const _0xbb0c68bcf565 = _0x03f8c1396022 === _0x5a86870dc68b(68541);
    _0x78429c9b51ec.startBtn.disabled = _0xf2f48da60b4f;
    const _0xff27683a5624 = Array.isArray(_0xf75432d950ea?.rows) ? _0xf75432d950ea.rows : [];
    const _0x038cc8fec8fb = _0xff27683a5624.some((_0x64b84bffd534) => _0x64b84bffd534?.result === _0x5a86870dc68b(68644) && !/^\d{3}-\d{7}-\d{7}$/.test(String(_0x64b84bffd534?.orderId || _0x5a86870dc68b(68604)).trim()));
    const _0x0e156a0fc9cf = _0x03f8c1396022 === _0x5a86870dc68b(68677) || _0x03f8c1396022 === _0x5a86870dc68b(68676);
    _0x78429c9b51ec.retrySkippedBtn.disabled = !_0x0e156a0fc9cf || Boolean(_0xb547d505b30d) || !_0x038cc8fec8fb;
    _0x78429c9b51ec.pauseBtn.disabled = !_0x6e3f930d1791;
    _0x78429c9b51ec.continueBtn.disabled = !_0xbb0c68bcf565;
    _0x78429c9b51ec.skipBtn.disabled = !_0xbb0c68bcf565 || Boolean(_0xb547d505b30d);
    _0x78429c9b51ec.stopBtn.disabled = !_0xf2f48da60b4f;
    _0x78429c9b51ec.openTabBtn.disabled = !Number.isInteger(_0xf75432d950ea?.workTabId);
    _0x78429c9b51ec.orderIntervalSeconds.disabled = _0xf2f48da60b4f;
    _0x78429c9b51ec.clearTodayOrdersBtn.disabled = _0xf2f48da60b4f || Boolean(_0xb547d505b30d);
    _0x78429c9b51ec.clearCartLockBtn.disabled = !_0xb547d505b30d || _0x6e3f930d1791;
    _0x78429c9b51ec.addRowsBtn.disabled = _0xf2f48da60b4f;
    _0x78429c9b51ec.removeBlankBtn.disabled = _0xf2f48da60b4f;
    _0x78429c9b51ec.clearInputBtn.disabled = _0xf2f48da60b4f;
    const _0xb9cd3352eb48 = _0xff27683a5624.some((_0x2d4a4e2ff57c) => _0x2d4a4e2ff57c?.result === _0x5a86870dc68b(68632) && /^\d{3}-\d{7}-\d{7}$/.test(String(_0x2d4a4e2ff57c?.orderId || _0x5a86870dc68b(68604)).trim()));
    _0x78429c9b51ec.copyOrderIdsBtn.disabled = !_0xb9cd3352eb48;
    _0x78429c9b51ec.exportRecordsCsvBtn.disabled = _0xff27683a5624.length === 0;
    _0x78429c9b51ec.copyRecordsBtn.disabled = _0xff27683a5624.length === 0;
    _0x78429c9b51ec.inputTableBody.querySelectorAll(_0x5a86870dc68b(68614)).forEach((_0x9d7472c076a3) => {
        _0x9d7472c076a3.disabled = _0xf2f48da60b4f;
    });
    const _0x86aaa01e8788 = _0x0a43e749a3f5 !== _0x5a86870dc68b(68600);
    _0x78429c9b51ec.authorizationFailureBar.classList.toggle(_0x5a86870dc68b(68601), _0x0a43e749a3f5 !== _0x5a86870dc68b(68603));
    if (_0x86aaa01e8788) {
        document.querySelectorAll(_0x5a86870dc68b(68679)).forEach((_0xf2ad180e6432) => {
            _0xf2ad180e6432.disabled = true;
        });
        _0x78429c9b51ec.revalidateAuthorizationBtn.disabled = _0x0a43e749a3f5 !== _0x5a86870dc68b(68603);
        _0x78429c9b51ec.closeWindowBtn.disabled = _0x0a43e749a3f5 !== _0x5a86870dc68b(68603);
        _0x78429c9b51ec.copyLogBtn.disabled = false;
        _0x78429c9b51ec.exportRecordsCsvBtn.disabled = _0xff27683a5624.length === 0;
    }
}
function _0x107718fc9e74() {
    _0xfc50fe83939d();
    _0x73b5722663ca();
    _0xd42da4927745();
}
async function _0xe8c4b536b22b(_0xbd87e8dc5315, _0xf1a3b8555382) {
    try {
        await navigator.clipboard.writeText(_0xbd87e8dc5315);
        _0x7531f9850a2e(_0xf1a3b8555382);
    }
    catch (_0x88243b12e789) {
        _0x7531f9850a2e((_0x5a86870dc68b(68678) + (_0x88243b12e789.message || String(_0x88243b12e789)) + _0x5a86870dc68b(68604)), true);
    }
}
function _0x81af587c3ebd() {
    const _0x62b8ec7899cd = [
        _0x5a86870dc68b(68514),
        _0x5a86870dc68b(68673),
        _0x5a86870dc68b(68520),
        _0x5a86870dc68b(68672),
        _0x5a86870dc68b(68675),
        _0x5a86870dc68b(68674),
        _0x5a86870dc68b(68685)
    ];
    const _0xab86ea3daeef = Array.isArray(_0xf75432d950ea?.rows) ? _0xf75432d950ea.rows : [];
    const _0xf3abdc858f5c = _0xab86ea3daeef.map((_0x4fcaff6f14c5) => [
        _0x4fcaff6f14c5.temuOrderId,
        _0x4fcaff6f14c5.asin,
        _0x4fcaff6f14c5.recipientName,
        _0x4fcaff6f14c5.shipAddress,
        _0x4fcaff6f14c5.shipCity,
        _0x4fcaff6f14c5.shipPostalCode,
        _0xbdb7f2b93ffe(_0x4fcaff6f14c5)
    ].map(_0xcac8ab4b2b95).join(_0x5a86870dc68b(68622)));
    return [_0x62b8ec7899cd.join(_0x5a86870dc68b(68622)), ..._0xf3abdc858f5c].join(_0x5a86870dc68b(68616));
}
function _0xd09f8f310e4e() {
    const _0x36fa30e86c06 = Array.isArray(_0xf75432d950ea?.rows) ? _0xf75432d950ea.rows : [];
    const _0x405ca4a74dcd = [];
    for (const _0x90240acf3ec1 of _0x36fa30e86c06) {
        const _0x623ab774ae51 = _0x90240acf3ec1?.result === _0x5a86870dc68b(68632) ? String(_0x90240acf3ec1?.orderId || _0x5a86870dc68b(68604)).trim() : _0x5a86870dc68b(68604);
        if (!/^\d{3}-\d{7}-\d{7}$/.test(_0x623ab774ae51)) {
            continue;
        }
        _0x405ca4a74dcd.push(_0x623ab774ae51);
    }
    return _0x405ca4a74dcd;
}
function _0x6eca227b7a2f(_0x09b617efa239) {
    const _0xb242236633fd = String(_0x09b617efa239 ?? _0x5a86870dc68b(68604)).replace(/\r?\n/g, _0x5a86870dc68b(68633)).trim();
    return (_0x5a86870dc68b(68617) + _0xb242236633fd.replace(/"/g, _0x5a86870dc68b(68684)) + _0x5a86870dc68b(68617));
}
function _0xa7c92f8ac53d() {
    const _0x2c5720adc01e = [
        _0x5a86870dc68b(68514),
        _0x5a86870dc68b(68673),
        _0x5a86870dc68b(68520),
        _0x5a86870dc68b(68672),
        _0x5a86870dc68b(68675),
        _0x5a86870dc68b(68674),
        _0x5a86870dc68b(68685)
    ];
    const _0xd941b83326b2 = Array.isArray(_0xf75432d950ea?.rows) ? _0xf75432d950ea.rows : [];
    const _0x8d1f29986daf = _0xd941b83326b2.map((_0x9ce22bfdea21) => [
        _0x9ce22bfdea21.temuOrderId,
        _0x9ce22bfdea21.asin,
        _0x9ce22bfdea21.recipientName,
        _0x9ce22bfdea21.shipAddress,
        _0x9ce22bfdea21.shipCity,
        _0x9ce22bfdea21.shipPostalCode,
        _0xbdb7f2b93ffe(_0x9ce22bfdea21)
    ].map(_0x6eca227b7a2f).join(_0x5a86870dc68b(68687)));
    return [_0x2c5720adc01e.map(_0x6eca227b7a2f).join(_0x5a86870dc68b(68687)), ..._0x8d1f29986daf].join(_0x5a86870dc68b(68686));
}
function _0x8b6b8e96ad9f(_0xdd0b354dcffb = new Date()) {
    const _0x27982b507cb5 = new Intl.DateTimeFormat(_0x5a86870dc68b(68681), {
        timeZone: _0x5a86870dc68b(68680),
        year: _0x5a86870dc68b(68683),
        month: _0x5a86870dc68b(68682),
        day: _0x5a86870dc68b(68682),
        hour: _0x5a86870dc68b(68682),
        minute: _0x5a86870dc68b(68682),
        second: _0x5a86870dc68b(68682),
        hourCycle: _0x5a86870dc68b(68693)
    }).formatToParts(_0xdd0b354dcffb);
    const _0xb9d2e2c354d4 = Object.fromEntries(_0x27982b507cb5.map((_0x9346e1a0a12a) => [_0x9346e1a0a12a.type, _0x9346e1a0a12a.value]));
    return (_0x5a86870dc68b(68604) + _0xb9d2e2c354d4.year + _0x5a86870dc68b(68692) + _0xb9d2e2c354d4.month + _0x5a86870dc68b(68692) + _0xb9d2e2c354d4.day + _0x5a86870dc68b(68695) + _0xb9d2e2c354d4.hour + _0x5a86870dc68b(68692) + _0xb9d2e2c354d4.minute + _0x5a86870dc68b(68692) + _0xb9d2e2c354d4.second + _0x5a86870dc68b(68604));
}
function _0xd027ea1f81e7() {
    const _0x68043cae1da0 = (_0x5a86870dc68b(68694) + _0xa7c92f8ac53d() + _0x5a86870dc68b(68604));
    const _0x2bd0c68c532a = new Blob([_0x68043cae1da0], { type: _0x5a86870dc68b(68689) });
    const _0x9b9ca2d1f716 = URL.createObjectURL(_0x2bd0c68c532a);
    const _0x5c77230ebac1 = document.createElement(_0x5a86870dc68b(68688));
    _0x5c77230ebac1.href = _0x9b9ca2d1f716;
    _0x5c77230ebac1.download = (_0x5a86870dc68b(68691) + _0x8b6b8e96ad9f() + _0x5a86870dc68b(68690));
    document.body.appendChild(_0x5c77230ebac1);
    _0x5c77230ebac1.click();
    _0x5c77230ebac1.remove();
    setTimeout(() => URL.revokeObjectURL(_0x9b9ca2d1f716), 1000);
}
function _0xb78350df6e83() {
    return (Array.isArray(_0x87ec51b2b698) ? _0x87ec51b2b698 : [])
        .map((_0xaca22455ed36) => [
        _0xaca22455ed36.time || _0x5a86870dc68b(68604),
        String(_0xaca22455ed36.level || _0x5a86870dc68b(68652)).toUpperCase(),
        _0xaca22455ed36.rowNumber ? (_0x5a86870dc68b(68651) + _0xaca22455ed36.rowNumber + _0x5a86870dc68b(68650)) : _0x5a86870dc68b(68604),
        _0xcac8ab4b2b95(_0xaca22455ed36.message)
    ].join(_0x5a86870dc68b(68622)))
        .join(_0x5a86870dc68b(68616));
}
_0x78429c9b51ec.revalidateAuthorizationBtn.addEventListener(_0x5a86870dc68b(68701), async () => {
    _0x8cd9ca7f0758 = false;
    _0x78429c9b51ec.revalidateAuthorizationBtn.disabled = true;
    const _0x7562eefc3f12 = await _0xf5b37fbcd2d2(_0x5a86870dc68b(68700));
    if (_0x7562eefc3f12?.authorization?.authorized) {
        _0x1a9d211c6961(_0x7562eefc3f12.authorization, false);
    }
    else {
        _0x1a9d211c6961({ authorized: false }, true);
    }
});
_0x78429c9b51ec.closeWindowBtn.addEventListener(_0x5a86870dc68b(68701), () => {
    window.close();
});
_0x78429c9b51ec.startBtn.addEventListener(_0x5a86870dc68b(68701), async () => {
    _0x65a3fb1542eb();
    const _0x230423254b7a = _0xb3ef0c591ee4.filter((_0x74b11ecbba62) => !_0xe071602742c9(_0x74b11ecbba62));
    if (_0x230423254b7a.length === 0) {
        _0x7531f9850a2e(_0x5a86870dc68b(68703), true);
        return;
    }
    const _0x431c68e70e1d = Number(_0x78429c9b51ec.orderIntervalSeconds.value);
    if (!Number.isInteger(_0x431c68e70e1d) || _0x431c68e70e1d < 0 || _0x431c68e70e1d > 3600) {
        _0x7531f9850a2e(_0x5a86870dc68b(68702), true);
        _0x78429c9b51ec.orderIntervalSeconds.focus();
        return;
    }
    const _0x23c9021972ce = await _0xf5b37fbcd2d2(_0x5a86870dc68b(68697), {
        rows: _0xb3ef0c591ee4,
        orderIntervalSeconds: _0x431c68e70e1d
    });
    if (_0x23c9021972ce?.ok) {
        if (_0x23c9021972ce.started) {
            _0x88e64f38612c = { orderIntervalSeconds: _0x431c68e70e1d };
        }
        _0x7531f9850a2e(_0x23c9021972ce.paused ? _0x5a86870dc68b(68696) : _0x5a86870dc68b(68699), Boolean(_0x23c9021972ce.paused));
    }
});
_0x78429c9b51ec.retrySkippedBtn.addEventListener(_0x5a86870dc68b(68701), async () => {
    _0x65a3fb1542eb();
    const _0x8175137e4042 = (Array.isArray(_0xf75432d950ea?.rows) ? _0xf75432d950ea.rows : []).filter((_0x69ce5a1bf320) => _0x69ce5a1bf320?.result === _0x5a86870dc68b(68644) && !/^\d{3}-\d{7}-\d{7}$/.test(String(_0x69ce5a1bf320?.orderId || _0x5a86870dc68b(68604)).trim()));
    if (_0x8175137e4042.length === 0) {
        _0x7531f9850a2e(_0x5a86870dc68b(68698), true);
        return;
    }
    const _0x94c4f5224676 = Number(_0x78429c9b51ec.orderIntervalSeconds.value);
    if (!Number.isInteger(_0x94c4f5224676) || _0x94c4f5224676 < 0 || _0x94c4f5224676 > 3600) {
        _0x7531f9850a2e(_0x5a86870dc68b(68702), true);
        _0x78429c9b51ec.orderIntervalSeconds.focus();
        return;
    }
    const _0x97abf3ccd392 = window.confirm((_0x5a86870dc68b(68709) + _0x8175137e4042.length + _0x5a86870dc68b(68708)) + _0x5a86870dc68b(68711) + _0x5a86870dc68b(68710));
    if (!_0x97abf3ccd392) {
        return;
    }
    const _0x73a28af47d7f = await _0xf5b37fbcd2d2(_0x5a86870dc68b(68705), {
        rows: _0xb3ef0c591ee4,
        orderIntervalSeconds: _0x94c4f5224676
    });
    if (_0x73a28af47d7f?.ok) {
        if (_0x73a28af47d7f.started) {
            _0x88e64f38612c = { orderIntervalSeconds: _0x94c4f5224676 };
        }
        _0x7531f9850a2e(_0x73a28af47d7f.paused
            ? _0x5a86870dc68b(68704) : (_0x5a86870dc68b(68707) + (_0x73a28af47d7f.retryCount || _0x8175137e4042.length) + _0x5a86870dc68b(68706)), Boolean(_0x73a28af47d7f.paused));
    }
});
_0x78429c9b51ec.pauseBtn.addEventListener(_0x5a86870dc68b(68701), async () => {
    const _0x94ea39f9a97b = await _0xf5b37fbcd2d2(_0x5a86870dc68b(68717));
    if (_0x94ea39f9a97b?.ok) {
        _0x7531f9850a2e(_0x5a86870dc68b(68716));
    }
});
_0x78429c9b51ec.continueBtn.addEventListener(_0x5a86870dc68b(68701), async () => {
    const _0x219b4cc9484b = await _0xf5b37fbcd2d2(_0x5a86870dc68b(68719));
    if (_0x219b4cc9484b?.ok) {
        _0x7531f9850a2e(_0x5a86870dc68b(68718));
    }
});
_0x78429c9b51ec.skipBtn.addEventListener(_0x5a86870dc68b(68701), async () => {
    const _0x6c3a5ed1dbed = [_0x5a86870dc68b(68713), _0x5a86870dc68b(68712)].includes(_0xf75432d950ea?.phase);
    if (_0x6c3a5ed1dbed) {
        const _0x3b76d487dd2e = window.confirm(_0x5a86870dc68b(68715));
        if (!_0x3b76d487dd2e) {
            return;
        }
    }
    const _0x8a79514caa40 = await _0xf5b37fbcd2d2(_0x5a86870dc68b(68714));
    if (_0x8a79514caa40?.ok) {
        _0x7531f9850a2e(_0x5a86870dc68b(68725));
    }
});
_0x78429c9b51ec.stopBtn.addEventListener(_0x5a86870dc68b(68701), async () => {
    const _0x4072315acd77 = [_0x5a86870dc68b(68713), _0x5a86870dc68b(68712)].includes(_0xf75432d950ea?.phase);
    if (_0xb547d505b30d) {
        const _0x76dcd1067370 = window.confirm(_0x5a86870dc68b(68724));
        if (!_0x76dcd1067370) {
            return;
        }
    }
    else if (_0x4072315acd77) {
        const _0x2d8891a7c831 = window.confirm(_0x5a86870dc68b(68727));
        if (!_0x2d8891a7c831) {
            return;
        }
    }
    const _0x7f4515d46200 = await _0xf5b37fbcd2d2(_0x5a86870dc68b(68726));
    if (_0x7f4515d46200?.ok) {
        _0x7531f9850a2e(_0x5a86870dc68b(68721));
    }
});
_0x78429c9b51ec.openTabBtn.addEventListener(_0x5a86870dc68b(68701), () => _0xf5b37fbcd2d2(_0x5a86870dc68b(68720)));
_0x78429c9b51ec.addRowsBtn.addEventListener(_0x5a86870dc68b(68701), () => {
    _0x65a3fb1542eb();
    for (let _0x48f1134f3980 = 0; _0x48f1134f3980 < 10; _0x48f1134f3980 += 1) {
        _0xb3ef0c591ee4.push(_0x5c8df82c9289());
    }
    _0xa973c28ff56b();
    _0x189b0b39467e(0);
});
_0x78429c9b51ec.removeBlankBtn.addEventListener(_0x5a86870dc68b(68701), () => {
    _0x65a3fb1542eb();
    _0xb3ef0c591ee4 = _0xa87cb087f3e5(_0xb3ef0c591ee4.filter((_0x10c32265e578) => !_0xe071602742c9(_0x10c32265e578)));
    _0xa973c28ff56b();
    _0x189b0b39467e(0);
});
_0x78429c9b51ec.clearInputBtn.addEventListener(_0x5a86870dc68b(68701), async () => {
    const _0xac6426183c41 = window.confirm(_0x5a86870dc68b(68723));
    if (!_0xac6426183c41) {
        return;
    }
    const _0x77a645995db2 = await _0xf5b37fbcd2d2(_0x5a86870dc68b(68722));
    if (_0x77a645995db2?.ok) {
        _0xb3ef0c591ee4 = _0xa87cb087f3e5([]);
        _0xf75432d950ea = null;
        _0xa973c28ff56b();
        _0x107718fc9e74();
        _0x7531f9850a2e(_0x5a86870dc68b(68733));
    }
});
_0x78429c9b51ec.orderIntervalSeconds.addEventListener(_0x5a86870dc68b(68732), () => {
    const _0x453e348df655 = Number(_0x78429c9b51ec.orderIntervalSeconds.value);
    if (!Number.isInteger(_0x453e348df655) || _0x453e348df655 < 0 || _0x453e348df655 > 3600) {
        _0x78429c9b51ec.orderIntervalSeconds.value = String(_0x88e64f38612c.orderIntervalSeconds ?? 30);
        _0x7531f9850a2e(_0x5a86870dc68b(68702), true);
    }
});
_0x78429c9b51ec.clearCartLockBtn.addEventListener(_0x5a86870dc68b(68701), async () => {
    const _0x6b5448f1ab09 = window.confirm(_0x5a86870dc68b(68735));
    if (!_0x6b5448f1ab09) {
        return;
    }
    const _0x631f78450ee4 = await _0xf5b37fbcd2d2(_0x5a86870dc68b(68734));
    if (_0x631f78450ee4?.ok) {
        _0x7531f9850a2e(_0x631f78450ee4.cleared ? _0x5a86870dc68b(68729) : _0x5a86870dc68b(68728));
    }
});
_0x78429c9b51ec.clearTodayOrdersBtn.addEventListener(_0x5a86870dc68b(68701), async () => {
    const _0x06af6504abfd = window.confirm(_0x5a86870dc68b(68731));
    if (!_0x06af6504abfd) {
        return;
    }
    const _0x27ce6ffbac1e = await _0xf5b37fbcd2d2(_0x5a86870dc68b(68730));
    if (_0x27ce6ffbac1e?.ok) {
        _0x7531f9850a2e((_0x5a86870dc68b(68741) + (_0x27ce6ffbac1e.clearedCount || 0) + _0x5a86870dc68b(68740) + (_0x27ce6ffbac1e.dateKey || _0x5a86870dc68b(68743)) + _0x5a86870dc68b(68742)));
    }
});
_0x78429c9b51ec.copyOrderIdsBtn.addEventListener(_0x5a86870dc68b(68701), () => {
    const _0x71002e64ed5e = _0xd09f8f310e4e();
    if (_0x71002e64ed5e.length === 0) {
        _0x7531f9850a2e(_0x5a86870dc68b(68737), true);
        return;
    }
    _0xe8c4b536b22b(_0x71002e64ed5e.join(_0x5a86870dc68b(68616)), (_0x5a86870dc68b(68736) + _0x71002e64ed5e.length + _0x5a86870dc68b(68739)));
});
_0x78429c9b51ec.exportRecordsCsvBtn.addEventListener(_0x5a86870dc68b(68701), () => {
    const _0xd51e36896a2c = Array.isArray(_0xf75432d950ea?.rows) ? _0xf75432d950ea.rows : [];
    if (_0xd51e36896a2c.length === 0) {
        _0x7531f9850a2e(_0x5a86870dc68b(68738), true);
        return;
    }
    _0xd027ea1f81e7();
    _0x7531f9850a2e((_0x5a86870dc68b(68749) + _0xd51e36896a2c.length + _0x5a86870dc68b(68748)));
});
_0x78429c9b51ec.copyRecordsBtn.addEventListener(_0x5a86870dc68b(68701), () => {
    _0xe8c4b536b22b(_0x81af587c3ebd(), _0x5a86870dc68b(68751));
});
_0x78429c9b51ec.copyLogBtn.addEventListener(_0x5a86870dc68b(68701), () => {
    _0xe8c4b536b22b(_0xb78350df6e83(), _0x5a86870dc68b(68750));
});
_0x78429c9b51ec.clearLogBtn.addEventListener(_0x5a86870dc68b(68701), async () => {
    const _0x7b505ad2714e = window.confirm(_0x5a86870dc68b(68745));
    if (!_0x7b505ad2714e) {
        return;
    }
    const _0x775025730c31 = await _0xf5b37fbcd2d2(_0x5a86870dc68b(68744));
    if (_0x775025730c31?.ok) {
        _0x87ec51b2b698 = [];
        _0xd892ba227501();
        _0x7531f9850a2e(_0x5a86870dc68b(68747));
    }
});
chrome.runtime.onMessage.addListener((_0x039ecd449cf2) => {
    if (_0x039ecd449cf2?.type !== _0x5a86870dc68b(68746)) {
        return;
    }
    _0x1a9d211c6961({ authorized: Boolean(_0x039ecd449cf2.authorized) }, !_0x039ecd449cf2.authorized);
});
chrome.storage.onChanged.addListener((_0xe93148ddc57b, _0x5f1b8749d1a4) => {
    if (_0x5f1b8749d1a4 !== _0x5a86870dc68b(68757)) {
        return;
    }
    if (_0xe93148ddc57b[_0x27781c66ba6d.RUN_STATE]) {
        _0xf75432d950ea = _0xe93148ddc57b[_0x27781c66ba6d.RUN_STATE].newValue || null;
        _0x107718fc9e74();
    }
    if (_0xe93148ddc57b[_0x27781c66ba6d.LOGS]) {
        _0x87ec51b2b698 = Array.isArray(_0xe93148ddc57b[_0x27781c66ba6d.LOGS].newValue)
            ? _0xe93148ddc57b[_0x27781c66ba6d.LOGS].newValue
            : [];
        _0xd892ba227501();
    }
    if (_0xe93148ddc57b[_0x27781c66ba6d.SETTINGS]) {
        _0x88e64f38612c = _0xe93148ddc57b[_0x27781c66ba6d.SETTINGS].newValue || { orderIntervalSeconds: 30 };
        if (!(_0xf75432d950ea && _0x6f45f55dec29.has(_0xf75432d950ea.mode))) {
            _0x78429c9b51ec.orderIntervalSeconds.value = String(_0x88e64f38612c.orderIntervalSeconds ?? 30);
        }
    }
    if (_0xe93148ddc57b[_0x27781c66ba6d.CART_LOCK]) {
        _0xb547d505b30d = _0xe93148ddc57b[_0x27781c66ba6d.CART_LOCK].newValue || null;
        _0xd42da4927745();
    }
});
async function _0xeb220529db69() {
    const _0x2d568e446f50 = await _0xf5b37fbcd2d2(_0x5a86870dc68b(68756));
    const _0x4ed91b75db46 = _0x2d568e446f50?.data || {};
    _0xf75432d950ea = _0x4ed91b75db46[_0x27781c66ba6d.RUN_STATE] || null;
    _0x87ec51b2b698 = Array.isArray(_0x4ed91b75db46[_0x27781c66ba6d.LOGS]) ? _0x4ed91b75db46[_0x27781c66ba6d.LOGS] : [];
    _0x88e64f38612c = _0x4ed91b75db46[_0x27781c66ba6d.SETTINGS] && typeof _0x4ed91b75db46[_0x27781c66ba6d.SETTINGS] === _0x5a86870dc68b(68607)
        ? _0x4ed91b75db46[_0x27781c66ba6d.SETTINGS]
        : { orderIntervalSeconds: 30 };
    _0xb547d505b30d = _0x4ed91b75db46[_0x27781c66ba6d.CART_LOCK] || null;
    _0x78429c9b51ec.orderIntervalSeconds.value = String(_0x88e64f38612c.orderIntervalSeconds ?? 30);
    _0xb3ef0c591ee4 = _0xa87cb087f3e5(Array.isArray(_0x4ed91b75db46[_0x27781c66ba6d.DRAFT_ROWS]) ? _0x4ed91b75db46[_0x27781c66ba6d.DRAFT_ROWS] : []);
    _0xa973c28ff56b();
    _0x107718fc9e74();
    _0xd892ba227501();
    _0x1a9d211c6961(_0x2d568e446f50?.authorization || { authorized: false }, true);
}
setInterval(() => {
    if (_0xf75432d950ea?.phase === _0x5a86870dc68b(68665)) {
        _0xfc50fe83939d();
    }
}, 1000);
_0xeb220529db69().catch((_0x95353f2b68d8) => _0x7531f9850a2e(_0x95353f2b68d8.message || String(_0x95353f2b68d8), true));})();
