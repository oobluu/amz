(()=>{'use strict';const _0x5e6d68cc9de6=Object.freeze(["GxcANQgeHwgoDxQpDhsOHw==","GxcANQgeHwgyEwkOFQgD","GxcALh8XDzUIHh8IMxQeHwI=","GxcAORsIDjgPExYeExQdNhUZEQ==","GxcANQgeHwg2FR0J","GxcANQgeHwg+CBscDigVDQk=","GxcANQgeHwgpHw4OExQdCQ==","GxcAOw8OFTUIHh8IOw8OEhUIEwAbDhMVFA==","CA8UFBMUHQ==","ChsPCR8e","DggbFAkTDhMVFBMUHQ==","LTszLiU1KD4/KCUpLzk5Pykp","LTszLiU1KD4/KCUyMykuNSgj","PSg1LyolOz4+JSooNT4vOS4=","LTszLiU9KDUvKiU7Pj4lKD8pLzYu","PSg1LyolKig1OT8/PiU5Mj85MTUvLg==","LTszLiU5Mj85MTUvLg==","KT82PzkuJSo7Izc/NC4lOTsoPg==","LTszLiU5Mjs0PT8lOz4+KD8pKQ==","LTszLiU7Pj4lOz4+KD8pKSU7PC4/KCU5Mjs0PT8=","LTszLiU7Pj4oPykpJTw1KDc=","LTszLiU7Pj4oPykpJSg/KS82Lg==","LTszLiU3OzQvOzYlOz4+KD8pKQ==","LTszLiUqOyM3PzQu","OTU0PDMoNyUqOyM3PzQuJTc/LjI1Pg==","LD8oMzwjJSo7Izc/NC4lNDs3Pw==","GxcAVxUIHh8IVxMUDh8IDBsWQA==","Eg4OCglAVVUbFBsUV0tIT0NKQ09CQklUGRUJVB8PVxwIGxQRHA8IDlQXAwsZFhUPHlQZFRdVS1UbDw4VFQgeHwhUEg4XFg==","nNrbk9D2n97Lks7flcb2ktXNkvvuncnBKRIbFB0bFA==","Sg==","Gw8OEhUIEwAfHg==","Oy8uMjUoMyA7LjM1NCU5Mjs0PT8+","HwgIFQg=","","JQw=","JQ4=","PT8u","FBVXCQ4VCB8=","FRcTDg==","Mi4uKiU=","HBsTFh8e","OxgVCA4/CAgVCA==","LjM3PzUvLg==","KD8rLz8pLiU8OzM2Pz4=","Oy8uMiU8OzM2Pz4=","FRgQHxkO","nO3anMnvn9TznPTonsLxn/fvk+3Ok+DulcbgnsHBn/DbWjM+Wp7C95/X4p/m0pn6+A==","HxRXPTg=","Pw8IFQofVTgfCBYTFA==","FA8XHwgTGQ==","SFceEx0TDg==","Vw==","ABJXOTQ=","EkhJ","NDwxOQ==","Wg==","Hh9XPj8=","GxcbABUUVB4f","VBsXGwAVFFQeHw==","GwkTFA==","OykzNA==","Dh8XD0A=","NSg+Pyg/Pg==","Bg==","nsXbnPvVnsL3n9T2nO/Olcb2ks3JksX9","Lh8XD1o1CB4fCFozPp7CwJ3TwJXG9pLNyZLF/Q==","nO/Kk/31nNrGn8b1k+7jktXVlcb2ks3JksX9","OzcgWhYTFBGc7dqc7/KVxvaSzcmSxf0=","n8T/n97+ner8","Ch8UHhMUHQ==","Ag==","BgY=","HQgVDwpX","CB8bHgM=","CRETCgofHg==","n+r2n+bKn+f6ncH+n+ryn/fvn9fin+bSn8b4n8LClcb2nO/OncH+ks3JksX9","GBYVGREfHg==","ndfzn8T/nsDAn83fnNn6nOXflcbg","CggVGR8JCRMUHQ==","CQ8ZGR8JCQ==","nsLxn/fvnPLqn/Dl","Lh8XD1o1CB4fCFozPlo=","Wp/9wJ30yp/m0p7C95/q9pzuzJ7BzJ/myp/n+p3B/pXG9p/NyJ/75pzX2J3X85/E/57AwJ/N35zZ+pzl35n6+A==","Wp7B8J/e05/NyJzm85LU2J/375XG9p7H/Jzm1pzW25/myp/n+pn6+5/v/J/p+5zy7JzvypP99Z3XxJ/q957C95/q9pXG9p/NyJ/75pzX2J3X85/E/57AwJ/N35zZ+pzl35n6+A==","Lh8XD1o1CB4fCFozPp/H6Z/e05/NyJ7C8ZLF/Z/375XG9pLNyZLF/Q==","ndfzn8T/k/33nsLx","n8fpn/P3ksTpn//fktvSnNrGn9fin+bSk/33n973n/z/k/nSktv2nNr9ktX8lcb2nMzzn/Xwn/Tln83fnsfmktTKn8fvndbWWg==","mfr7","WpLb9pn6+JLVzZzC/53TwJ/DzJP995zsyp3I4pLOzp/q9J/895P9957C8Zn6+A==","nObzWg==","Wpzn25LNyZLF/ZLUyp/H75/NyJ7B9J/H6Z/z95LE6Z//35Lb0pzaxp/y2pPj3pzy7Jzt2pzJ75/Vw5/A7pXG8p/05Z3W1lo=","WpLb9pXG85XG9p7C95L5x57F55LV+5/U85//0pLc/J3h7J/N357H5p3B6Zzk5pn6+A==","n8fpn/P3n83fnsfmktTKn8fvnsLXnMjbnObzn/XVk/33nsLxneD+ks3JksX9ktv2mfr4","k/33nsLxnO/KnPfUnsLXWi4fFw9aNQgeHwhaMz5a","ChsUHxZUEg4XFg==","ChUKDwo=","GxgVDw5AGBYbFBE=","FBUIFxsW","nO3anMnvn/Lhn8HAWjsXGwAVFFqfzd+ex+ac2v2d18ST28+Z+vg=","n83fnsfmnNr9ndfEk9vPnsL3n9fin+bSmfr4","LTsxPyU7Ly41NzsuMzU0","n/L9nPfYn+/8n+n7nNr9ndfEk9vP","ORIIFRcfWpzm0JLF7p/h5Jzsyp/N357H5pza/Z3XxJPbz1ozPpn6+A==","n97Lks7flcbg","GB8cFQgfVxwTCAkOVxseHg==","n9fin+bSnObQnML/k+PeneD+ncH+n+ryn/fvks7XnfPTndXUn9Tzn//Sk+77lcb2nsHBn/DbnObQn+rVn/DSmfr4ktXNn//ynsDAn83fnNn6nOXfks7XnfPTndXUn+j2nOb6ksXrktTYn/fvlcb2n/z3nsfFne7SmPrmnML/k+PencH+n+ryn/fvk+77mPrnnPbzk+jUmfr4","n9fin+bSnObQnML/k+PeneD+ncH+n+ryn/fvks7XnfPTndXUn9Tzn//Sk+77mfr4ktXNn//ynsDAn83fnNn6nOXfks7XnfPTndXUn+j2ktTYn/fvlcb2n/z3nML/k+PencH+n+ryn/fvk+77mfr4","n83InObznObQncHpnOflnsHBn/Dbmfr4ktXNnsfFne7SncHdncHXmfr7ks3JksX9n8fpn/P3ktv2nPLsn/vmnNfYnPbzk+jUn97+ner8nfTKnObznsHBn/Dbmfr4","nNX1n/fvk+3Ok+Dun8X/k9vBnOLVWkqY+ulJTEpKWp3g/pzvzpzvypn6+A==","nMjbnObzn/XVn97+ner8neD+nO/KnPfUktv2mfr4","ExQcFQ==","nsHBn/Dbk9j+nNn6nOXfn8b6n93xlcbgn//LWg==","Wpzn25Pn5J3TwJzvypz31JXG9p/8/5P50p/H2Jzy6lo=","Wp7C0JzuzJ7BzJ7AwJ/myp/n+p3B/pn6+A==","ksTpn//fktvSnNrGnsXnnPb7n/Tln93xk9vAn8D1lcbhn+bKn+f6ncH+nPbzn//Mn+bSktvSnNrGnsLXnOb6nO3Tn/3AnfTKneD+ktv2n/XNnsH0nsLwn8T6nsLxn97+ner8mfr4","DRsIFBMUHQ==","n+r2n+bKn+f6ncH+n+ryn/fvn9fin+bSnsL3n+r2ne7PktXnn/XNndr7lcb2n8r8nsfFne7Sn/Tln93xksTpn//fnsLXnOb6n//yn/3AnfTKnsL6ktv2neD+ne7PktXnn/XNndr7lcbg","mfr4","k9j+nNn6nOXfn9T2nPLqlcbgn8T/n97+ner8n+bKn+f6ncH+Wg==","Wp7C0JXG8p//zJ7C153B/p/q8p/371o=","Wp7C0JXG85XG9pPY/p//8pLNyZLF/Vo=","WpLb9pn6+A==","Kig/OTI/OTElOTU0PDYzOS4=","GRUXChYfDh8e","OTU3KjY/Lj8+","nMjbnObzk+b6ktz7nsLxn/fvneD+nObznO/yn+bKn+f6ncH+lcb2nsHBn/DbncHpnOflmfr4","Lig7NCkzLjM1NDM0PQ==","n/fvktv2n+bKn+f6ncH+ncHdncHXnsfFne7SWjgPA1o0FQ2VxuGf6vaf3emf6veewu6f1Pac786f5sqf5/qd4cKf6vad4P6f3uCS2/af5sqf5/qdwf6ex8Wd7tJaOx4eWg4VWhgbCREfDlqf6vKfw8yewvGf9++Z+vg=","ncH+n+ryn/fvnsbgn//yn9T2nO/Ok9j+nNn6nOXfn//SncH+lcbhnsHBnP71nsL6ktv2k+b6ktz7ks3JksX9nO3Mlcb2nO/OnsLQn+bKn+f6ncH+nsL3nsLxn/fvmfr4","ncH+n+ryn/fvn8b6n93xk9j+nNn6nOXfn/P3mfr7nNfZn8b1n/Daks7Xn/P3mfr7nNX1nNbbn/Daks7Xn+r0n+j2WioIFRkfHx5an/P3n+f9nNrCn9XDks7XnfPTndXUnO/Kk/31mfr4","nPLqn/Dln/Xsn8TtnsL6nsLQWjsXGwAVFFo1CB4fCFozPlqf6vSd1/OfxP9a","Wp3d6JXG9p/895/e/p3q/J7C8Z7C+p7C0J/myp/n+p3B/pn6+A==","n9fin+bSnObQnML/k+PeneD+ncH+n+ryn/fvks7XnfPTndXUn9Tzn//Sk+77lcb2nsL3kvnHn+rVn/DSk/33nsLxnsHBn/Dbmfr4","n9fin+bSnObQnML/k+PeneD+ncH+n+ryn/fvks7XnfPTndXUn9Tzn//Sk+77mfr4ktXNn//ynsDAn83fnNn6nOXfn8PMnML/k+Pemfr4","CQ4VCgofHg==","n/XQnObznsHBn/Dbn83In9T2nPLqnPLsn83In/vmnNfYn+r0lcb2nPP3kvnHk/33nsLxnPP6nObzks3JksX9n/fvmfr4","n8b6n93xmPrmk/33nsLxnPP6nObzks3JksX9n/fvmPrnlcbgnsfFne7Sn8fpn/P3ksTpn//fktvSnNrGnOb6nOzKnO/KnPfUlcb2n//Lk/rznPHTWg==","Wpzn21oJERMKCh8eWpLUyp/H75n6+A==","nObWnNbbk/33nsLxnPbzne7SnPLNktTEn9TgncHvksX9Wi4fFw9aNQgeHwhaMz5an8fpn97TnPLqn/DlktTKn8fvlcb2n/b/nPHWktTYn/fvncHpnOTmnObQndvUktTeneD+nsDAn83fks3JksX9ktv2lcbhn83In/Xsn8TtWjUIHh8IWjM+Wp3g/pzy6p/w5ZLb9p7F55z2+57C95/14pn6+A==","k/33nsLxn+bKn+f6ncH+nsH3nPbzn//Mn+bSn8fpn/P3ksTpn//fktvSnNrGnsLXnOb6nO3Tn/3AnfTKneD+ktv2n/XNnsH0nsLwn8T6nsLxn97+ner8mfr4","k/33nsLxncH+n+ryn/fvn9fin+bSnsL3n+r2ne7PktXnn/XNndr7lcb2n8r8nsfFne7Sn8fpn/P3ksTpn//fnsLXnOb6n//yn/3AnfTKnsL6ktv2neD+ne7PktXnn/XNndr7lcbg","k/33nsLxk9j+nNn6nOXfn9T2nPLqlcbgn8T/n97+ner8n+bKn+f6ncH+Wg==","Wp7C0JXG85XG4Z/H6Z/z957B957CwFoJERMKCh8eWp3g/p/N357H5pLUyp/H71o=","GxYWVwkREwoKHx4=","k/33nsLxnO/KnPfUnsLXnMjbnObzn/XVncHdncHXnsLxn/fvneD+nObznO/yn+bKn+f6ncH+lcb2nsHBn/DbncHpnOflmfr4","k/33nsLxnsHBn/DbnsLXlcb2n/fvktv2nsfFne7SWjgPA1o0FQ2VxuGf6vaf3emf6vef6vaf1Pac786f5sqf5/qd4P6f3uCS2/aT/fec7Mqdwf6c8uqSzted89Od1dSdwf6f6vKf9++Z+vg=","nPLqn/Dln/Xsn8TtnsL6nsLQnOzKWjsXGwAVFFo1CB4fCFozPlqf6vSd1/OfxP9a","Wp3d6JXG9p/895/e/p3q/J7C8Z7C+p7C0JP9957C8Z/myp/n+p3B/pn6+A==","nMzynPvVnsL3nOLVnOffkv3Qn8fpn/P3n83fnsfmnNr9ndfEk9vPmfr4","nsHBn/DbnfPynObWn83IncH1n/Xin/bsmfr4","n8fpn/P3k+LMnNTPn83In/XinsLAWg==","nsHBn/Dbn8fpn/P3nObQksXqktv2mfr4","GBUVFh8bFA==","k9vPk+fYnfDMnPr7n8b4n8LCmfr4","nsHBn/DbnfDMnPr7n83IncH1n/Xin/bsmfr4","n8fpn/P3k+LMnNTPnsL3nOLVnsHinNbEk9vPn93pn+r3k9D2ktX7k+LMnNTPlcbg","nPPEnsL3n/LKn8fpn/P3nsLxn/fvncH+mfr4","nOb6ncHynPXqnsDen/P3neD+nO7MnsHMnsDAn93pn+r3nsL0n8fpn/P3n+bKn+f6ncH+nsL3nsL6kv3Omfr4","ncH+n+ryn/fvn8PMk+fknPP6nObzktv2k/nHn83In9T2nPLqk9j+nNn6nOXfn+j2n/Dan//fks7XnfPTndXUmfr4","ncH+n+ryn/fvks7XnfPTndXUn9Tzn//Sk+77nsL3n9fin+bSnPLsnsL0n8fpn/P3n+bKn+f6ncH+nsL3nsL6kv3Omfr4","nOb6ncHynPXqnsDen/P3nMjbnObznObznO/yneD+n+/8n+n7n+rRndL0n/fvnsHNWpj41khUSkpanNrbk9D2ktTKn8fvmfr4","nOb6ncHynPXqnsDen/P3nMjbnObznObznO/yneD+ncjEn/38nO/Kk/31nNrbk9D2ktTKn8fvmfr4","nOb6ncHynsHinNbEn/P3n/XrnfTKWi4fFw9aNQgeHwhaMz5a","Wp7B8J/e05/NyJzm85zy6p/w5ZLU2J/375XG9p/NyJ/75pzX2J7B35P7xZ//95P995/e957C8Z/375n6+A==","nNfZn+bSnPXqnsDencH+n+ryktTYn/fvlcbyndfzn8T/kvTNn/XsWjUIHh8IWjM+lcbz","HBMUGxZXCQ8YFxMO","nNfZn+bSnPXqnsDektTYn/fvlcbyndfzn8T/kvTNn/XsWjUIHh8IWjM+lcbz","ncH+n+ryn/fvn//LWg==","WpLb9pn6+5z6wZzvypP99Vo=","lcb2nsHinNbEk9vPnO7MnsHMnsDAn93pn+r3n83InNrCn9XDlcbhks7XnfPTndXUn9Tzn//Sk+77n8r8nsXnne/jn/LKn/Xsn8TtWjUIHh8IWjM+mfr4","n+/8n+n7n+rRndL0n/fvnsHNWpj41khUSkqZ+vudyMSf/fyc78qT/fVa","Wp/o9p7B4pzWxJPbz5zuzJ7BzJ7AwJ/d6Z/q95/n/Z/NyJzawp/Vw5XG4Z/10Jzm85/17J/E7Vo1CB4fCFozPlqf6vSc8/eS1Nuf/9+fx+mf3tOewvGf9++S1Mqfx++Z+vg=","nPPEnsL3n/LKn/38n979n97+ner8neD+n+bKn+f6ncH+mfr4","OTI/OTElOTsoLiU4Pzw1KD8lKig/OTI/OTE=","LTszLiUqKDU+Lzku","ncH+n+ryn/fvk9j+nNn6nOXfn/P3nNfZn+bSndvUktTeks7XnfPTndXUnsLAndPA","n8b6n93xncH+n+ryn/fvlcbg","WpLb9pXG9g==","Wp7C0J/u1Z7C+louHxcPWjUIHh8IWjM+lcb2nPrBnO/Kk/31Wg==","nNfZn+bSnPPpn8b6n+/8n+n7k9vPk+fY","ndbWWg==","WpLb9pXG4J/G+p/d8Z/375Lb9lo4DwNaNBUNWpzP+53S8ZXG9i4fFw9aNQgeHwhaMz5a","lcb2OykzNFo=","lcb2neHUnNr9nO/Kk/31Wg==","nNfZn+bSnsLAnsLxnsL6nsLQn+bKn+f6ncH+n/Lhn8HAnfHWndHxn83fnsfmnNr9ndfEk9vPlcbhn+r0n/XKncHrn9TgnOzKnNr9ndfEn+r0n//Jk+3XnsLwnsL6ncH+nNr9ndfEk9vPmfr4","n/L9nPfYn/LKnsLxnsL6nsLQn+bKn+f6ncH+nNr9ndfEk9vP","n/L9nPfYn/LKnsLxnsL6nsLQn+bKn+f6ncH+nNr9ndfEk9vPn97Lks7fmfr4","nO3anMnvnPPpn8b6n+/8n+n7k9vPk+fYlcbg","nPP6nObznObznO/yn+bKn+f6ncH+n97+ner8n9T2nPLqmfr4","LTszLiUzNC4/KCw7Ng==","ndfzn8T/nsLxn/fvk+3Ok+Dulcby","nd3olcbz","ks3nndzBnsLxnsL6nsLQn+bKn+f6ncH+ksXinObzWg==","Wp3d6JXG4Z3X85/E/53B6Zzn5Z/q9J7B9J3W1lo=","WpLb9p/G+p/d8Zn6+A==","nO3anMnvn9TznPTonsLxnsL6n/fvk+3Ok+Dulcbg","nsLxn/fvk+3Ok+DuncHpnOfllcb2n8b6n93xn97+ner8nsLxnsL6nsLQn+bKn+f6ncH+mfr4","OTI/OTElOTsoLiU4Pzw1KD8lOC8zNj4=","n8fpn/P3k+LMnNTPnsL3kvnHndvUktTendPAks7XnfPTndXUlcbg","n8fpn/P3nsL3nOLVncH+n+ryn/fvmfr4","ks7XnfPTndXUnO/Kk/31nsL3nOLVSpXG4A==","PSg1LyolKig/OTI/OTElKig1Pi85Lg==","ncH+n+ryn/fvk9j+nNn6nOXflcbgnNfZn+bSnNrCn9XDn+/8n+n7","ncH+n+ryn/fvk9j+nNn6nOXfn/P3ndvUktTeks7XnfPTndXUnO/Kk/31nsLASpn6+A==","nNfZn8b1n/Daks7Xn/P3n/XrnfTKn83InObzncH+n+ryn/fvks7XnfPTndXUn9Tzn//Sk+77mfr4","nNfZn8b1n/Dan//fks7XnfPTndXUlcbgnNfZn+bSn97+ner8ndbWS5Lb9p/v/J/p+w==","nNfZn8b1n/Dan//fks7XnfPTndXUlcbgnNfZn+bSnNrCn9XDn+/8n+n7","ncH+n+ryn/fvnNfZn8b1n/Daks7Xn/P3n/z3nNbbndvUktTeks7XnfPTndXUnO/Kk/31nsLASpXG4Z/NyJ/BwJ3R8Vo5OyguJTgvMzY+MzQ9Wp/U85//0pPu+5n6+A==","n8fpn/P3k+LMnNTPnsL3nOLVncH+n+ryn/fvk9j+nNn6nOXflcbg","nPPEnsL3n/LKncH+n+ryn/fvn8fpn/P3ktv2mfr4","ncH+n+ryn/fvk9j+nNn6nOXfktv2nc7Yn8bvn83IncH1n/Xin/bsmfr4","ncH+n+ryn/fvk9j+nNn6nOXfn+HknsbaneD+n+/8n+n7n/fvnsHNnO3anO/ymfr4","ncH+n+ryn/fvk9j+nNn6nOXfn+HknsbaneD+nO/Kk/31nO3anO/ymfr4","ncH+n+ryn/fvk9j+nNn6nOXfk/rgksX9","ncH+n+ryn/fvk9j+nNn6nOXfk/rgksX9lcbgOykzNFo=","lcb2n+rRndL0n/fvnsHNWpj41khUSkqVxvadyMSf/fyc78qT/fVa","ncH+n+ryn/fvk9j+nNn6nOXflcbgnNfZn+bSnPPpn8b6nfHWndHxn+/8n+n7nNr9ndfEk9vP","nsLwnsL6nsHMn+/8n+n7k9j+nNn6nOXfn9T2nPLqlcbhn//Jk+3XnO3dn+/8n+n7nNr9ndfEn8PMnsLAndbWWg==","WpLb9pzz6Z/G+p3x1p3R8Zza/Z3XxJPbz5n6+A==","ncH+n+ryn/fvk9j+nNn6nOXfn/L9nPfYn+/8n+n7nNr9ndfEk9vP","ncH+n+ryn/fvk9j+nNn6nOXfn9T2nPLq","ncH+n+ryn/fvk9j+nNn6nOXfn9T2nPLqlcb2nNfZn8b1n/Daks7Xn/P3k/33nOzKndvUktTeks7XnfPTndXUnsLAndPA","ncH+n+ryn/fvn//Sk/nSn+/8n+n7k9j+nNn6nOXfk/rgksX9lcb2n/38n979n+bSnOzKneD+ndbWnsL6nsHMn+/8n+n7nNr9ndfEk9vPn/z3nNbbnNn6nOXfks7XnfPTndXUnsLAndPAmfr4","n//Jk+3XnOb6n+r0nsL6nsLQk9j+nNn6nOXfn+/8n+n7nNr9ndfElcb2n8PMnsLAnNfZn8b1n/Daks7XndbWnsL6nsHMn+/8n+n7nPPpn8b6nOzKneD+nfHWndHxnNr9ndfEk9vPmfr4","ncH+n+ryn/fvnsH0k9j+nNn6nOXfn/L9nPfYn/LKnNfZn8b1n/Daks7X","ncH+n+ryn/fvn+/8n+n7k9j+nNn6nOXfnObQk/rgksX9","lcbhktXfnO7MnsHMnsDAn+bKn+f6ncH+n//Sk/nSnsL3nsLxn/fvmfr4","n8fpn/P3k+LMnNTPnsL3nOLVncH+n+ryn/fvnNfZn8b1n/Daks7Xlcbg","ncH+n+ryn/fvks7XnfPTndXUn9Tzn//Sk+77nO3anO/ymfr4","ncH+n+ryn/fvnNfZn8b1n/Daks7Xktv2nc7Yn8bvn83IncH1n/Xin/bsmfr4","nNfZn8b1n/Daks7Xn/P3neD+nO/Kk/31nsL0neHUnNr9nO/Kk/31nsL3nsL6kv3Omfr4","nNfZn8b1n/Daks7Xn/P3neD+n+/8n+n7n+rRndL0n/fvnsHNnsL3nOLVWpj41khUSkqZ+vg=","nNfZn+bSn/Dan//fks7XnfPTndXUlcbyn9T2nPLqn+r0n8Dunc7VktTbWg==","Wp7BzJXG8w==","Gx4eExQdVxMOHxc=","nNfZn8b1n/Daks7Xn/P3n/z3nNbbnNrCn9XDk/rgksX9lcbgOykzNFo=","WrntWg==","lcbhnfjDn/3Bn+r0ks7XnfPTndXUn8Dunc7VktTbWg==","Wp7BzJn6+A==","n8fpn/P3k+LMnNTPnsL3nOLVncH+n+ryn/fvn/Daks7XncHpnOTmndvUktTelcbg","nNfZn8b1n/Daks7Xn+HknsbaneD+nO/Kk/31nsL0neHUnNr9nO/Kk/31nsL3nsL6kv3Omfr4","nNfZn8b1n/Daks7Xn+HknsbaneD+n+/8n+n7n+rRndL0n/fvnsHNnsL3nOLVWpj41khUSkqZ+vg=","ks7XnfPTndXUnc7VktTbnO/Kk/31n8b4n8LClcbgn8DunsLAWg==","lcb2k9vPk+fYnsLAWg==","n83In/Dan//fks7XnfPTndXUlcbync7VktTbWg==","n83In/Dan//fks7XnfPTndXUlcbgOykzNFo=","lcbhnc7VktTbks7XnfPTndXUnO/Kk/31Wg==","GA8TFh4TFB0=","nNfZn8b1n/Dan//fks7XnfPTndXUlcbgnNfZn+bSnPPpn8b6nfHWndHxn+/8n+n7nNr9ndfEk9vP","nsLwnsL6nsHMn+/8n+n7n83InPLqn/Dln/Dan//fks7XnfPTndXUlcbhn//Jk+3XnPLqn/DlnM3Bn/Dak9vPk+fYn8PMnsLAndbWWg==","ncH+n+ryn/fvnNfZn8b1n/Daks7Xn/L9nPfYn+/8n+n7nNr9ndfEk9vP","ncH+n+ryn/fvn+/8n+n7n83In//Sk/nSn/Dan//fks7XnfPTndXUlcb2n/38n979WioIFRkfHx5aDhVaORIfGREVDw4=","CB8bHgNXDhVXGRIfGREVDw4=","ncH+n+ryn/fvn//Sk/nSn+/8n+n7n83In/Dan//fks7XnfPTndXUlcb2nPrBnO/Kk/31Wg==","lcb2n/38n979nsDen/XznNn6nOXfn8PMncHpndTtmfr4","n8fpn/P3k+LMnNTPnsL3nOLVWioIFRkfHx5aDhVaORIfGREVDw6VxuA=","KggVGR8fHlqf8/eSzted89Od1dSc78qT/fWfwO6ewsBa","KggVGR8fHlqc9vOT6NSc4sSd3sBa","WhMOHxcJlcb2nsL0k9j+nOblWg==","Wp7C957C+pL9zpn6+A==","n83InNrCn9XDks7XnfPTndXUnPrBnO/Kk/31lcb2nNfZn+bSksXhn//fnsLxn/fvk9vPk+fY","GRIfGREVDw4=","KggVGR8fHlqf8/eSzted89Od1dSc78qT/fWc2sKf1cOT+uCSxf2VxuA=","KggVGR8fHlqf8/eSzted89Od1dSc78qT/fWewvSc9vOT6NRaEw4fFwlanO/Kn+f9nNrCn9XDk/rgksX9lcbg","n8fpn/P3nMjbnObznsHBn/Dbmfr4","nPPEnsL3n/LKn8fpn/P3nO/KnPfUktv2nPLsn+bKn+f6ncH+mfr4","ncH+n+ryn/fvn83IncH1n8b6n93xnOT+n8HAks7XnfPTndXUlcb2nsL3kvnHneHOnPTfks3JksX9mfr4ktXNn//ynsDAn83fnNn6nOXfks7XnfPTndXUn+j2nOb6ksXrktTYn/fvlcb2n/z3nML/k+PencH+n+ryn/fvk+77mfr4","nsDAn83fks3JksX9","ks3JksX9","lcbyktTYn/fvncHpnOTmnObQndvUktTelcbz","lcbhktXfnO7MnsHMnsDAn+bKn+f6ncH+n//Sk/nSks3JksX9mfr4","n8fpn/P3k+LMnNTPnsL3nOLVktTYn/fvnNrCn9XDk+LMnNTPlcbg","nPPEnsL3n/LKn8fpn/P3n+bKn+f6ncH+mfr4","NQgeHwhaMz5anNrGn8b1nO3anO/ymfr4","ncH+n+ryn/fvnPLqn/DlktTKn8fvn/P3ks7XnfPTndXUn9Tzn//Sk+77nsL3n9fin+bSnPLsnsL3n/bDk//3mfr4","ncH+n+ryn/fvnsLxn/fvnPLqn/Dllcb2","WpLb9p//y53u0lo1CB4fCFozPpXG4A==","nsLxn/fvnPLqn/Dllcb2NQgeHwhaMz6VxuA=","n83In/Xsn8TtncH+n+ryn/fvWjUIHh8IWjM+lcb2OTsoLiU4LzM2PjM0PVqf1POf/9KT7vufzciS/dCf8NKcwv+T496Z+vg=","n8fpn/P3nsHBn/DbnsL3n97+nsD0n/XVnOD4n/vmnfDMnPr7mfr4","nsDAn83fnOD4n/vm","lcbyk+3Ok+Dun/PTnsfjncDcWg==","Wp3d6JXG8w==","n83InOD4n/vmlcbgnsDAn83fnOD4n/vm","nsHBn/Dbn83InsDAn83fnOD4n/vmmfr4","n8fpn/P3nMjbnObzn83InOD4n/vmnsHBn/Dbmfr4","k9j+nNn6nOXfn9fin+bSWi4fFw9aNQgeHwhaMz5an+bKn+f6nPLsndfEn+r3n/zIndD7lcb2nsL3kvnHneHOnPTfncHdncHXmfr4ktXNn/vmnNfYnsHBn/Dbn8PMnsXUnO7DksTpn//fnO/KnPfUmfr4","ncH+n+ryn/fvks7XnfPTndXUn9Tzn//Sk+77n83InsL3n9fin+bSlcb2nsL3kvnHncHdncHXn8fpn/P3nsHBn/Dbmfr4ktXNn/vmnNfYn+r0k/33nOzKn8b6n93xmfr4","nsHBn/DbncHdncHXnPPdktv2lcb2nsLxn/fvk+3Ok+DuktTbnO3MnPvYn973mfr4","OxcbABUUWp/N357H5pza/Z3XxJPbz5/NyJ//yZPt15XG9p/H6Z/z95PizJzUz57C95L5x5/U85//0pL90J/w0pz72J/e95n6+JLVzZ7AwJ/N35zZ+pzl35/q9J/75pzX2J7BwZ/w25XG4ZLx35zm853B/p/q8p/375Pu+5XG9pLVzZ3b1JLU3pLO153z053V1J/o9pLU2J/375/q9JzC/5Pj3pn6+A==","ncHdncHXnPPdktv2ncH+n+ryn/fvn8fpn/P3nNffk9De","ncHdncHXnPPdktv2n8fpn/P3nNffk9De","nsHBn/DbncHdncHXnPPdktv2mfr4","n8fpn/P3nMjbnObzn/XVn/vmnNfYneD+nsHBn/Dbmfr4","KS41Kio/Pg==","n83In/vmnNfYlcbyncH+n+ryn/fvks7XnfPTndXUk+77nsH3nsXnne/jlcbz","n83In/vmnNfYlcbyktTYn/fvncHpnOTmnObQndvUktTelcbz","n83In/vmnNfY","nsHBn/Dbn83In/vmnNfYlcbhOTsoLiU4LzM2PjM0PVqf1POf/9KT7vuewfeexeed7+OZ+viS1c2ewMCfzd+c2fqc5d+Szted89Od1dSf6Pac5vqSxeuS1Nif9++f6vSf/Pecwv+T496dwf6f6vKf9++T7vuZ+vg=","nsHBn/Dbn83In/vmnNfYlcbhn8fpn/P3ktTYn/fvncHpnOTmnsH3nObQndvUktTelcb2nsLunsL3nsbgn/zjn//fn8fpn97Tk+LIk/33n973ktTKn8fvmfr4","nsHBn/Dbn83In/vmnNfYmfr4","n8fpn/P3nMjbnObzncH+n+ryn/fvks7XnfPTndXUn9Tzn//Sk+77mfr4","nsHBn/DbnsH3n+bSksXqktv2lcb2nsL3kvnHnML/k+PencH+n+ryn/fvks7XnfPTndXUk+77mfr4ktXNn//ynOD4n/vmnPLsn/vmnNfYnsHBn/Dbmfr4","ncH+n+ryn/fvk+77n83Ine7Lne7SnPLNndvUktTen+r0nML/k+Pelcb2nsHBn/Dbn83In/vmnNfY","ne7SnPLNndvUktTen83InsDAn83fnNn6nOXfks7XnfPTndXUn/XwnOb6ksXrktTYn/fvlcb2n83InML/k+PencH+n+ryn/fvk+77lcbyncH+Wg==","nObQneXf","lcbzmfr4","nsHBn/DbksXqktv2nOblk+3OnsL3kvnHnsXUnO7DksTpn//fnO/KnPfUmfr4","nsHBn/DbksXqktv2nOblk+3OnsL3kvnHnML/ndPAksTpn//fnO/KnPfUmfr4","n9fin+bSnObQnML/k+PeneD+ncH+n+ryn/fvks7XnfPTndXUk+77lcb2nsL3kvnHnML/ndPAnsHBn/DbktTKn8fvmfr4","nsHBn/DbksXqktv2nOblk+3OnsL3kvnHnML/ndPAn8fpn97TnsLxn/fvktTKn8fvmfr4","n83InML/ndPAWg==","Wpzn21o=","Wp3g/pzy6p/w5Z7C8Z/375PiyJP995/e95LUyp/H75n6+A==","LxQbGBYfWg4VWhUKHxRaChsUHxZA","n/f9ncDdn+r0nsHBn/Dbn83In/vmnNfYlcb2ktXNnsDAn83fnNn6nOXfn8fpn/P3WjsXGwAVFFqT28+T59g=","n/f9ncDdn+r0n83In/vmnNfYnO3dnfPynObQncHpnOflnsHBn/Dblcb2ktXNnsDAn83fndvUktTenOLVn+rcn83InsDdne7lktTYn/fvmfr4","nNn6nM/xn/LKnObQnML/k+PeneD+ncH+n+ryn/fvks7XnfPTndXUk+77lcbhnOzKnsHBn/DbnsbgktjRk+LBnNfYlcb2neHOn/LKnsDAn83fnNn6nOXfn8PMnML/k+PektXfk+77mfr4","KD8sOzYzPjsuPyU7Ly4yNSgzIDsuMzU0","OTI/OTElOy8uMjUoMyA7LjM1NA==","PT8uJTk1NC4/Ii4=","PT8uJTs2NiU+Oy47","KS47KC4lKC80","KD8uKCMlKTEzKio/PiUoLzQ=","KTssPyU+KDs8LiUoNS0p","OTY/OyglPig7PC4lKDUtKQ==","OTY/OyglNjU9KQ==","KTssPyUpPy4uMzQ9KQ==","OTY/OyglLjU+OyMlNSg+PyglKD85NSg+KQ==","OTY/OyglOTsoLiU4LzM2PjM0PSU2NTkx","KT8uJSoyOyk/","KjsvKT8lPygoNSg=","OD88NSg/JTwzNDs2JSkvODczLg==","Kjs9PyU2NT0=","KTEzKiUoNS0=","PSg1LyolOTsoLiU/NyouIw==","PSg1LyolKig/OTI/OTElKjspKQ==","PSg1LyolKig/OTI/OTElPDszNg==","PSg1LyolOD88NSg/JTs+Pg==","PSg1LyolMy4/NyU7Pj4/Pg==","PSg1LyolOD88NSg/JSooNTk/Pz4=","NSg+PyglKS85OT8pKQ==","KjsvKT8lKC80","OTU0LjM0Lz8lKC80","KS41KiUoLzQ=","KTEzKiU5LygoPzQuJTc7NC87Ng==","NSo/NCUtNSgxJS47OA==","ndfzn8T/k+3Ok+DunOblk+3OWjsXGwAVFFqfzd+ex+ac2v2d18ST28+S2NGf/8mT7deVxuGT7c6T4O6dwemc5+Wf6vSfyvyS/dCf8NKf8uGfwcCc7Mqc2v2d18ST28+Z+vg=","OxcbABUUWp/N357H5pza/Z3XxJPbz5/NyJ//yZPt15XG4Z3B/p/q8p/375LO153z053V1JPu+57B957F553v45XG9pLVzZ7AwJ/N35zZ+pzl35LO153z053V1J/o9pLU2J/375n6+A==","OxcbABUUWp/N357H5pza/Z3XxJPbz5/NyJLY0Z//yZPt15n6+A=="]),_0x081b0d7e5f2b=[];if(((_0x5e6d68cc9de6.length^122^23197^26436)>>>0)!==15613){throw new Error('Integrity error');}function _0x4cbcf6dd9e80(_0xf76492){const _0xc1bcd2=((_0xf76492-26436)^23197);if(_0x081b0d7e5f2b[_0xc1bcd2]!==undefined)return _0x081b0d7e5f2b[_0xc1bcd2];const _0x26b137=atob(_0x5e6d68cc9de6[_0xc1bcd2]),_0x097f4b=new Uint8Array(_0x26b137.length);for(let _0xe06447=0;_0xe06447<_0x26b137.length;_0xe06447++)_0x097f4b[_0xe06447]=_0x26b137.charCodeAt(_0xe06447)^122;return _0x081b0d7e5f2b[_0xc1bcd2]=new TextDecoder().decode(_0x097f4b);}const _0x21777dfa17c3 = Object.freeze({
    RUN_STATE: _0x4cbcf6dd9e80(49633),
    HISTORY: _0x4cbcf6dd9e80(49632),
    ORDER_INDEX: _0x4cbcf6dd9e80(49635),
    CART_LOCK: _0x4cbcf6dd9e80(49634),
    LOGS: _0x4cbcf6dd9e80(49629),
    DRAFT_ROWS: _0x4cbcf6dd9e80(49628),
    SETTINGS: _0x4cbcf6dd9e80(49631),
    AUTHORIZATION: _0x4cbcf6dd9e80(49630)
});
const _0xabf6b76ade62 = Object.freeze({
    orderIntervalSeconds: 30
});
const _0x9888f9a67033 = 3000;
const _0xc51bf8f6faa9 = 3000;
const _0xf9204977f1d4 = new Set([_0x4cbcf6dd9e80(49625), _0x4cbcf6dd9e80(49624), _0x4cbcf6dd9e80(49627)]);
const _0xa963c5cdea9b = new Set([_0x4cbcf6dd9e80(49626), _0x4cbcf6dd9e80(49621)]);
const _0x6843391fe37b = new Set([
    _0x4cbcf6dd9e80(49620),
    _0x4cbcf6dd9e80(49623),
    _0x4cbcf6dd9e80(49622),
    _0x4cbcf6dd9e80(49617),
    _0x4cbcf6dd9e80(49616),
    _0x4cbcf6dd9e80(49619),
    _0x4cbcf6dd9e80(49618),
    _0x4cbcf6dd9e80(49613),
    _0x4cbcf6dd9e80(49612),
    _0x4cbcf6dd9e80(49615),
    _0x4cbcf6dd9e80(49614),
    _0x4cbcf6dd9e80(49609),
    _0x4cbcf6dd9e80(49608),
    _0x4cbcf6dd9e80(49626),
    _0x4cbcf6dd9e80(49621)
]);
const _0xc047e286bef0 = new Set([
    _0x4cbcf6dd9e80(49623),
    _0x4cbcf6dd9e80(49622),
    _0x4cbcf6dd9e80(49617),
    _0x4cbcf6dd9e80(49616),
    _0x4cbcf6dd9e80(49619),
    _0x4cbcf6dd9e80(49618),
    _0x4cbcf6dd9e80(49613),
    _0x4cbcf6dd9e80(49612),
    _0x4cbcf6dd9e80(49615),
    _0x4cbcf6dd9e80(49614),
    _0x4cbcf6dd9e80(49609),
    _0x4cbcf6dd9e80(49608),
    _0x4cbcf6dd9e80(49626),
    _0x4cbcf6dd9e80(49621)
]);
const _0xc1fe486716a7 = _0x4cbcf6dd9e80(49611);
const _0x98ce58702bce = /^\d{3}-\d{7}-\d{7}$/;
const _0x943a7b8eb231 = 11;
const _0x9b5f5787445e = Object.freeze({
    endpoint: _0x4cbcf6dd9e80(49610),
    cacheMs: 8 * 60 * 60 * 1000,
    timeoutMs: 10000,
    expectedStatus: 200,
    failureMessage: _0x4cbcf6dd9e80(49605)
});
let _0x9670046a495c = null;
let _0x492efb835d84 = null;
let _0x6105d03cbb45 = Promise.resolve();
const _0x4ac3ccde585a = new Map();
function _0xe8a3692c3553(_0xbdd02906a6e6) {
    const _0xd38ce4a6ac18 = _0x6105d03cbb45.then(_0xbdd02906a6e6, _0xbdd02906a6e6);
    _0x6105d03cbb45 = _0xd38ce4a6ac18.catch(() => undefined);
    return _0xd38ce4a6ac18;
}
function _0xba7bb6005bc1() {
    const _0x77773fe281ed = chrome.runtime.getManifest();
    return String(_0x77773fe281ed.version_name || _0x77773fe281ed.version || _0x4cbcf6dd9e80(49604));
}
function _0x0922cf25480e(_0x223a0e591dd2) {
    return { authorized: _0x223a0e591dd2?.status === _0x4cbcf6dd9e80(49607) };
}
function _0x54ff91d07e7d(_0x5095e2e375f7, _0xb602d39a624d = Date.now()) {
    return Boolean(_0x5095e2e375f7 &&
        _0x5095e2e375f7.status === _0x4cbcf6dd9e80(49607) &&
        _0x5095e2e375f7.version === _0xba7bb6005bc1() &&
        Number(_0x5095e2e375f7.expiresAt) > _0xb602d39a624d);
}
async function _0xc65fce9ace1e(_0x31e3f9be9457) {
    if (_0x492efb835d84 === _0x31e3f9be9457) {
        return;
    }
    _0x492efb835d84 = _0x31e3f9be9457;
    try {
        await chrome.runtime.sendMessage({
            type: _0x4cbcf6dd9e80(49606),
            authorized: Boolean(_0x31e3f9be9457)
        });
    }
    catch {
    }
}
function _0xf773357aaa5b(_0xac953bc8766b, _0x23d397d4740e) {
    if (!_0xac953bc8766b || !_0xf9204977f1d4.has(_0xac953bc8766b.mode)) {
        return;
    }
    _0xac953bc8766b.authorizationBlocked = true;
    _0xac953bc8766b.updatedAt = new Date().toISOString();
    if (_0xa963c5cdea9b.has(_0xac953bc8766b.phase)) {
        _0xac953bc8766b.authorizationFailureDeferred = true;
        return;
    }
    _0xac953bc8766b.authorizationFailureDeferred = false;
    _0xac953bc8766b.mode = _0x4cbcf6dd9e80(49624);
    _0xac953bc8766b.pauseReason = _0x9b5f5787445e.failureMessage;
    const _0x72368653fd6a = _0xa933c8eed5e2(_0xac953bc8766b);
    const _0x504e8b10a4b5 = _0x23d397d4740e?.[_0x23d397d4740e.length - 1];
    if (_0x504e8b10a4b5?.message !== _0x9b5f5787445e.failureMessage) {
        _0xc70b7be9a6b7(_0x23d397d4740e, _0x4cbcf6dd9e80(49665), _0x9b5f5787445e.failureMessage, _0x72368653fd6a?.rowNumber ?? null);
    }
}
async function _0x687327a89c42() {
    const _0x25b17f2240f2 = await chrome.storage.local.get([_0x21777dfa17c3.RUN_STATE, _0x21777dfa17c3.LOGS]);
    const _0xfdfce4e14d7e = _0x25b17f2240f2[_0x21777dfa17c3.RUN_STATE] || null;
    const _0xd4b3fa09d5a3 = Array.isArray(_0x25b17f2240f2[_0x21777dfa17c3.LOGS]) ? _0x25b17f2240f2[_0x21777dfa17c3.LOGS] : [];
    _0xf773357aaa5b(_0xfdfce4e14d7e, _0xd4b3fa09d5a3);
    await chrome.storage.local.set({
        [_0x21777dfa17c3.RUN_STATE]: _0xfdfce4e14d7e,
        [_0x21777dfa17c3.LOGS]: _0xd4b3fa09d5a3
    });
    await _0xc65fce9ace1e(false);
}
async function _0xc838abfe75a7() {
    const _0x8f7196e10810 = await chrome.storage.local.get(_0x21777dfa17c3.RUN_STATE);
    const _0xac8a82726453 = _0x8f7196e10810[_0x21777dfa17c3.RUN_STATE] || null;
    if (_0xac8a82726453?.authorizationBlocked) {
        _0xac8a82726453.authorizationBlocked = false;
        _0xac8a82726453.authorizationFailureDeferred = false;
        if (_0xac8a82726453.pauseReason === _0x9b5f5787445e.failureMessage) {
            _0xac8a82726453.pauseReason = _0x4cbcf6dd9e80(49664);
        }
        _0xac8a82726453.updatedAt = new Date().toISOString();
        await chrome.storage.local.set({ [_0x21777dfa17c3.RUN_STATE]: _0xac8a82726453 });
    }
    await _0xc65fce9ace1e(true);
}
async function _0x71b6c4d88c9f() {
    const _0x8a62ad792671 = new AbortController();
    const _0x1b9573500a1a = setTimeout(() => _0x8a62ad792671.abort(), _0x9b5f5787445e.timeoutMs);
    try {
        const _0x7be8c8463ee7 = new URL(_0x9b5f5787445e.endpoint);
        _0x7be8c8463ee7.searchParams.set(_0x4cbcf6dd9e80(49667), _0xba7bb6005bc1());
        _0x7be8c8463ee7.searchParams.set(_0x4cbcf6dd9e80(49666), String(Date.now()));
        const _0x7e2f9e3a30fb = await fetch(_0x7be8c8463ee7.toString(), {
            method: _0x4cbcf6dd9e80(49661),
            cache: _0x4cbcf6dd9e80(49660),
            credentials: _0x4cbcf6dd9e80(49663),
            redirect: _0x4cbcf6dd9e80(49665),
            signal: _0x8a62ad792671.signal
        });
        if (_0x7e2f9e3a30fb.status !== _0x9b5f5787445e.expectedStatus) {
            throw new Error((_0x4cbcf6dd9e80(49662) + _0x7e2f9e3a30fb.status + _0x4cbcf6dd9e80(49664)));
        }
        try {
            await _0x7e2f9e3a30fb.body?.cancel();
        }
        catch {
        }
        const _0x5b964d03d4fa = Date.now();
        return {
            status: _0x4cbcf6dd9e80(49607),
            version: _0xba7bb6005bc1(),
            checkedAt: _0x5b964d03d4fa,
            expiresAt: _0x5b964d03d4fa + _0x9b5f5787445e.cacheMs
        };
    }
    finally {
        clearTimeout(_0x1b9573500a1a);
    }
}
async function _0x8b2dc19450f4(_0xa8f18076871e = false) {
    const _0x81cb48f4f262 = await chrome.storage.local.get(_0x21777dfa17c3.AUTHORIZATION);
    const _0x46bf27daeac2 = _0x81cb48f4f262[_0x21777dfa17c3.AUTHORIZATION] || null;
    const _0x484bf2c6f476 = Date.now();
    if (!_0xa8f18076871e && _0x54ff91d07e7d(_0x46bf27daeac2, _0x484bf2c6f476)) {
        return _0x0922cf25480e(_0x46bf27daeac2);
    }
    if (!_0xa8f18076871e &&
        _0x46bf27daeac2?.status === _0x4cbcf6dd9e80(49657) &&
        _0x46bf27daeac2.version === _0xba7bb6005bc1()) {
        await _0x687327a89c42();
        return _0x0922cf25480e(_0x46bf27daeac2);
    }
    if (_0x9670046a495c) {
        return _0x9670046a495c;
    }
    _0x9670046a495c = (async () => {
        try {
            const _0xf80e89d60fbf = await _0x71b6c4d88c9f();
            await chrome.storage.local.set({ [_0x21777dfa17c3.AUTHORIZATION]: _0xf80e89d60fbf });
            await _0xc838abfe75a7();
            return _0x0922cf25480e(_0xf80e89d60fbf);
        }
        catch (_0xd5e787bf871e) {
            const _0xf1e7b1c5fc3d = {
                status: _0x4cbcf6dd9e80(49657),
                version: _0xba7bb6005bc1(),
                checkedAt: Date.now(),
                expiresAt: 0,
                reason: _0xd5e787bf871e?.name === _0x4cbcf6dd9e80(49656) ? _0x4cbcf6dd9e80(49659) : _0x4cbcf6dd9e80(49658)
            };
            await chrome.storage.local.set({ [_0x21777dfa17c3.AUTHORIZATION]: _0xf1e7b1c5fc3d });
            await _0x687327a89c42();
            return _0x0922cf25480e(_0xf1e7b1c5fc3d);
        }
        finally {
            _0x9670046a495c = null;
        }
    })();
    return _0x9670046a495c;
}
function _0x8cd7bc4210a7(_0x0aeb509a7ffc = null) {
    return {
        ok: false,
        code: _0x4cbcf6dd9e80(49653),
        error: _0x9b5f5787445e.failureMessage,
        authorization: _0x0aeb509a7ffc || { authorized: false, status: _0x4cbcf6dd9e80(49657) }
    };
}
async function _0xf768835a0775(_0xf250c5fab711 = false) {
    const _0xedb492578037 = await _0x8b2dc19450f4(_0xf250c5fab711);
    return _0xedb492578037.authorized
        ? { ok: true, authorization: _0xedb492578037 }
        : _0x8cd7bc4210a7(_0xedb492578037);
}
async function _0x9b7a20193054(_0xc5b9397fb043) {
    const _0x773cc3be0625 = await _0xf768835a0775(false);
    if (!_0x773cc3be0625.ok) {
        return _0x773cc3be0625;
    }
    return _0xc5b9397fb043();
}
async function _0xa193a8de4588() {
    const _0xb9d5f663e42b = await _0x8b2dc19450f4(false);
    const _0xa47b9bda3716 = await _0x603145195ada();
    return { ok: true, data: _0xa47b9bda3716, authorization: _0xb9d5f663e42b };
}
async function _0xeec4ef20173a() {
    const _0xb2a94fe6f1ed = await _0x8b2dc19450f4(true);
    return _0xb2a94fe6f1ed.authorized
        ? { ok: true, authorization: _0xb2a94fe6f1ed }
        : _0x8cd7bc4210a7(_0xb2a94fe6f1ed);
}
async function _0x52115b46564d(_0x5616a4f7d388) {
    const _0x7ba4946acc1d = await chrome.storage.local.get(_0x21777dfa17c3.RUN_STATE);
    const _0x04b21aa3bb2d = _0x7ba4946acc1d[_0x21777dfa17c3.RUN_STATE] || null;
    const _0xbda847931e15 = Boolean(_0x04b21aa3bb2d &&
        _0x5616a4f7d388.tab?.id === _0x04b21aa3bb2d.workTabId &&
        _0xa963c5cdea9b.has(_0x04b21aa3bb2d.phase));
    if (!_0xbda847931e15) {
        const _0x0c03433be8e6 = await _0xf768835a0775(false);
        if (!_0x0c03433be8e6.ok) {
            return _0x0c03433be8e6;
        }
    }
    const _0xf283ec586e1d = await _0xa2238fd6a8fd(_0x5616a4f7d388);
    if (_0xbda847931e15) {
        const _0x56d170b76032 = await chrome.storage.local.get(_0x21777dfa17c3.AUTHORIZATION);
        _0xf283ec586e1d.authorization = _0x0922cf25480e(_0x56d170b76032[_0x21777dfa17c3.AUTHORIZATION]);
        _0xf283ec586e1d.authorizationDeferred = !_0xf283ec586e1d.authorization.authorized;
    }
    else {
        _0xf283ec586e1d.authorization = { authorized: true, status: _0x4cbcf6dd9e80(49607) };
    }
    return _0xf283ec586e1d;
}
function _0xf9ec002844ce(_0x9488868e0f79) {
    return new Promise((_0x91dc04503b97) => setTimeout(_0x91dc04503b97, _0x9488868e0f79));
}
function _0xf5767a497dd7(_0x84c01d246bff, _0xc4c4a4ec5b78 = _0xabf6b76ade62.orderIntervalSeconds) {
    const _0x75f6b630c52c = Number(_0x84c01d246bff);
    if (!Number.isInteger(_0x75f6b630c52c) || _0x75f6b630c52c < 0 || _0x75f6b630c52c > 3600) {
        return _0xc4c4a4ec5b78;
    }
    return _0x75f6b630c52c;
}
function _0xa85f13940f9b(_0x0b21fb03bc71) {
    const _0x93e9a4cf4972 = _0x0b21fb03bc71 && typeof _0x0b21fb03bc71 === _0x4cbcf6dd9e80(49652) ? _0x0b21fb03bc71 : {};
    return {
        orderIntervalSeconds: _0xf5767a497dd7(_0x93e9a4cf4972.orderIntervalSeconds, _0xabf6b76ade62.orderIntervalSeconds)
    };
}
function _0xde4244574fd5(_0x311cdbace748) {
    return _0x98ce58702bce.test(String(_0x311cdbace748 ?? _0x4cbcf6dd9e80(49664)).trim());
}
function _0x638fdf459481(_0x59cf878d8ef0) {
    const _0x1798f0df39e1 = String(_0x59cf878d8ef0 ?? _0x4cbcf6dd9e80(49664)).trim();
    if (!/^[1-9]\d*$/.test(_0x1798f0df39e1)) {
        return null;
    }
    const _0x68501833019f = Number(_0x1798f0df39e1);
    return Number.isSafeInteger(_0x68501833019f) ? _0x68501833019f : null;
}
function _0x37dcb67e8377(_0xf2d1e38d1aa4) {
    return (_0x4cbcf6dd9e80(49664) + _0xc1fe486716a7 + _0x4cbcf6dd9e80(49664) + String(_0xf2d1e38d1aa4 || _0x4cbcf6dd9e80(49664)) + _0x4cbcf6dd9e80(49664));
}
function _0x242062d82715(_0xd9f52e0bfaba) {
    const _0x2b7d01afe25c = _0x4ac3ccde585a.get(_0xd9f52e0bfaba);
    if (_0x2b7d01afe25c !== undefined) {
        clearTimeout(_0x2b7d01afe25c);
        _0x4ac3ccde585a.delete(_0xd9f52e0bfaba);
    }
}
async function _0xb8dfb473846f(_0x9a70b26f0b9f) {
    if (!_0x9a70b26f0b9f) {
        return false;
    }
    return chrome.alarms.clear(_0x37dcb67e8377(_0x9a70b26f0b9f));
}
async function _0xe26d015b0a8e(_0xaf44f7c80600) {
    _0x242062d82715(_0xaf44f7c80600);
    try {
        await _0xb8dfb473846f(_0xaf44f7c80600);
    }
    catch {
    }
}
function _0xf0e30f6bb0ca(_0x9b62da4fc540) {
    const _0x2b0567cb7874 = Date.parse(String(_0x9b62da4fc540?.intervalEndsAt || _0x4cbcf6dd9e80(49664)));
    if (Number.isFinite(_0x2b0567cb7874)) {
        return Math.max(0, _0x2b0567cb7874 - Date.now());
    }
    const _0xe4e44246f93a = Number(_0x9b62da4fc540?.intervalRemainingSeconds || 0);
    return Math.max(0, _0xe4e44246f93a * 1000);
}
async function _0x40f5546ca56c(_0xb4d4bb3355eb, _0xc4c64085960a) {
    const _0xfc9de0b951d6 = _0xb4d4bb3355eb?.runId;
    if (!_0xfc9de0b951d6) {
        throw new Error(_0x4cbcf6dd9e80(49655));
    }
    const _0x491e34607ddc = Math.max(0, Number(_0xc4c64085960a) || 0);
    const _0x5ca659ef64e5 = Date.now() + _0x491e34607ddc;
    await _0xe26d015b0a8e(_0xfc9de0b951d6);
    await chrome.alarms.create(_0x37dcb67e8377(_0xfc9de0b951d6), { when: _0x5ca659ef64e5 });
    if (_0x491e34607ddc <= 60000) {
        const _0x971a71b6fcb7 = setTimeout(() => {
            _0x4ac3ccde585a.delete(_0xfc9de0b951d6);
            _0xe8a3692c3553(() => _0x2eb21256f3e4(_0xfc9de0b951d6)).catch((_0x61fd6dc944c1) => console.error(_0x61fd6dc944c1));
        }, _0x491e34607ddc);
        _0x4ac3ccde585a.set(_0xfc9de0b951d6, _0x971a71b6fcb7);
    }
}
function _0xac1031e3efac(_0xe02680e63771 = new Date()) {
    const _0xefc7231a7f28 = new Intl.DateTimeFormat(_0x4cbcf6dd9e80(49654), {
        timeZone: _0x4cbcf6dd9e80(49649),
        year: _0x4cbcf6dd9e80(49648),
        month: _0x4cbcf6dd9e80(49651),
        day: _0x4cbcf6dd9e80(49651)
    }).formatToParts(_0xe02680e63771);
    const _0x72e0ffa0cf8d = Object.fromEntries(_0xefc7231a7f28.map((_0x3212382ad7ff) => [_0x3212382ad7ff.type, _0x3212382ad7ff.value]));
    return (_0x4cbcf6dd9e80(49664) + _0x72e0ffa0cf8d.year + _0x4cbcf6dd9e80(49650) + _0x72e0ffa0cf8d.month + _0x4cbcf6dd9e80(49650) + _0x72e0ffa0cf8d.day + _0x4cbcf6dd9e80(49664));
}
function _0x90caaed66711(_0xabafe18fa45b = new Date()) {
    return new Intl.DateTimeFormat(_0x4cbcf6dd9e80(49645), {
        timeZone: _0x4cbcf6dd9e80(49649),
        year: _0x4cbcf6dd9e80(49648),
        month: _0x4cbcf6dd9e80(49651),
        day: _0x4cbcf6dd9e80(49651),
        hour: _0x4cbcf6dd9e80(49651),
        minute: _0x4cbcf6dd9e80(49651),
        second: _0x4cbcf6dd9e80(49651),
        hourCycle: _0x4cbcf6dd9e80(49644)
    }).format(_0xabafe18fa45b);
}
function _0xca73cf69c048(_0x4c9c48e47595) {
    return String(_0x4c9c48e47595 ?? _0x4cbcf6dd9e80(49664))
        .normalize(_0x4cbcf6dd9e80(49647))
        .replace(/\s+/g, _0x4cbcf6dd9e80(49646))
        .trim();
}
function _0xc0605a04af37(_0x9428259e83ee) {
    return String(_0x9428259e83ee ?? _0x4cbcf6dd9e80(49664))
        .normalize(_0x4cbcf6dd9e80(49647))
        .replace(/[^\p{L}\p{M}\s\-'’]/gu, _0x4cbcf6dd9e80(49646))
        .replace(/\s+/g, _0x4cbcf6dd9e80(49646))
        .trim();
}
function _0x6212b0dfb520(_0x55f26c3016f8) {
    return _0xca73cf69c048(_0x55f26c3016f8).toLocaleLowerCase(_0x4cbcf6dd9e80(49641));
}
function _0x40f4a8626ae8(_0x68a60edf86ca) {
    return String(_0x68a60edf86ca ?? _0x4cbcf6dd9e80(49664))
        .normalize(_0x4cbcf6dd9e80(49647))
        .replace(/\s+/g, _0x4cbcf6dd9e80(49664))
        .trim()
        .toUpperCase();
}
function _0xd855f240a5a5(_0x0e30be5426bc) {
    return String(_0x0e30be5426bc ?? _0x4cbcf6dd9e80(49664))
        .normalize(_0x4cbcf6dd9e80(49647))
        .trim()
        .slice(0, 200);
}
function _0xe3ef474f6bd2(_0xa3d743313d99) {
    const _0xd2f72b99c706 = String(_0xa3d743313d99 ?? _0x4cbcf6dd9e80(49664)).trim();
    if (!_0xd2f72b99c706) {
        return null;
    }
    let _0x884e586b2b20;
    try {
        _0x884e586b2b20 = new URL(_0xd2f72b99c706);
    }
    catch {
        return null;
    }
    const _0xc91f95524d0c = _0x884e586b2b20.hostname.toLowerCase();
    if (_0xc91f95524d0c !== _0x4cbcf6dd9e80(49640) && !_0xc91f95524d0c.endsWith(_0x4cbcf6dd9e80(49643))) {
        return null;
    }
    const _0x118be056dda3 = [
        /\/(?:dp|gp\/product|gp\/aw\/d)\/([A-Z0-9]{10})(?:[/?]|$)/i,
        /\/product\/([A-Z0-9]{10})(?:[/?]|$)/i
    ];
    for (const _0x00038e824bad of _0x118be056dda3) {
        const _0x754980cdef50 = _0x884e586b2b20.pathname.match(_0x00038e824bad);
        if (_0x754980cdef50) {
            return _0x754980cdef50[1].toUpperCase();
        }
    }
    const _0x379b2da117cb = _0x884e586b2b20.searchParams.get(_0x4cbcf6dd9e80(49642)) || _0x884e586b2b20.searchParams.get(_0x4cbcf6dd9e80(49637));
    if (_0x379b2da117cb && /^[A-Z0-9]{10}$/i.test(_0x379b2da117cb)) {
        return _0x379b2da117cb.toUpperCase();
    }
    return null;
}
function _0x512d143486d6(_0xd124a176e442) {
    const _0xddf1810b57c2 = _0x40f4a8626ae8(_0xd124a176e442);
    return _0xddf1810b57c2 ? (_0x4cbcf6dd9e80(49636) + _0xddf1810b57c2 + _0x4cbcf6dd9e80(49664)) : _0x4cbcf6dd9e80(49664);
}
function _0x4cf2dd9aff73(_0x3ed721548544, _0x8148e49e26b6) {
    const _0xa4b2942930ce = String(_0x3ed721548544 || _0x4cbcf6dd9e80(49664)).trim();
    if (/^\d{4}-\d{2}-\d{2}$/.test(_0xa4b2942930ce)) {
        return _0xa4b2942930ce;
    }
    const _0x49e263c2b6de = new Date(_0x8148e49e26b6 || _0x4cbcf6dd9e80(49664));
    return Number.isNaN(_0x49e263c2b6de.getTime()) ? _0x4cbcf6dd9e80(49664) : _0xac1031e3efac(_0x49e263c2b6de);
}
function _0xaeb8aa4ec5d7(_0x82daeeca3f7b) {
    const _0x0dab8b94e7ff = [];
    for (const _0xc2b0b4a8509e of Array.isArray(_0x82daeeca3f7b) ? _0x82daeeca3f7b : []) {
        const _0xa581246aa088 = _0x40f4a8626ae8(_0xc2b0b4a8509e?.temuOrderIdKey || _0xc2b0b4a8509e?.temuOrderId || _0x4cbcf6dd9e80(49664));
        const _0x4309357ed17e = String(_0xc2b0b4a8509e?.orderId || _0x4cbcf6dd9e80(49664)).trim();
        if (!_0xa581246aa088 || _0xc2b0b4a8509e?.status !== _0x4cbcf6dd9e80(49639) || !_0xde4244574fd5(_0x4309357ed17e)) {
            continue;
        }
        _0x0dab8b94e7ff.push({
            ..._0xc2b0b4a8509e,
            temuOrderId: _0xa581246aa088,
            temuOrderIdKey: _0xa581246aa088,
            status: _0x4cbcf6dd9e80(49639),
            orderId: _0x4309357ed17e,
            dateKey: _0x4cf2dd9aff73(_0xc2b0b4a8509e?.dateKey, _0xc2b0b4a8509e?.updatedAt || _0xc2b0b4a8509e?.createdAt),
            addressSignature: String(_0xc2b0b4a8509e?.addressSignature || _0x4cbcf6dd9e80(49664)),
            itemSignature: String(_0xc2b0b4a8509e?.itemSignature || _0x4cbcf6dd9e80(49664)),
            temuSignature: String(_0xc2b0b4a8509e?.temuSignature || _0x4cbcf6dd9e80(49664)),
            groupSignature: String(_0xc2b0b4a8509e?.groupSignature || _0x4cbcf6dd9e80(49664)),
            updatedAt: _0xc2b0b4a8509e?.updatedAt || _0xc2b0b4a8509e?.createdAt || new Date().toISOString()
        });
    }
    return _0x0dab8b94e7ff;
}
function _0xf0ccabd2d36d(_0xe1752dbddc97, _0xf585251275ce = []) {
    const _0xe52b9b1c5f42 = {};
    const _0xa10ee0aade68 = [];
    if (_0xe1752dbddc97 && typeof _0xe1752dbddc97 === _0x4cbcf6dd9e80(49652) && !Array.isArray(_0xe1752dbddc97)) {
        for (const _0x732adbbf23f8 of Object.values(_0xe1752dbddc97)) {
            const _0x3192d35614fc = _0x40f4a8626ae8(_0x732adbbf23f8?.temuOrderId || _0x4cbcf6dd9e80(49664));
            const _0xdabf23eae68d = String(_0x732adbbf23f8?.orderId || _0x4cbcf6dd9e80(49664)).trim();
            if (!_0x3192d35614fc || _0x732adbbf23f8?.status !== _0x4cbcf6dd9e80(49639) || !_0xde4244574fd5(_0xdabf23eae68d)) {
                continue;
            }
            _0xa10ee0aade68.push({
                ..._0x732adbbf23f8,
                temuOrderId: _0x3192d35614fc,
                orderId: _0xdabf23eae68d,
                status: _0x4cbcf6dd9e80(49639),
                dateKey: _0x4cf2dd9aff73(_0x732adbbf23f8?.dateKey, _0x732adbbf23f8?.updatedAt),
                addressSignature: String(_0x732adbbf23f8?.addressSignature || _0x4cbcf6dd9e80(49664)),
                itemSignature: String(_0x732adbbf23f8?.itemSignature || _0x4cbcf6dd9e80(49664)),
                temuSignature: String(_0x732adbbf23f8?.temuSignature || _0x4cbcf6dd9e80(49664)),
                groupSignature: String(_0x732adbbf23f8?.groupSignature || _0x4cbcf6dd9e80(49664)),
                updatedAt: _0x732adbbf23f8?.updatedAt || new Date(0).toISOString()
            });
        }
    }
    for (const _0x3d24ae13b435 of _0xf585251275ce) {
        _0xa10ee0aade68.push({
            temuOrderId: _0x40f4a8626ae8(_0x3d24ae13b435.temuOrderIdKey || _0x3d24ae13b435.temuOrderId),
            status: _0x4cbcf6dd9e80(49639),
            orderId: _0x3d24ae13b435.orderId,
            dateKey: _0x3d24ae13b435.dateKey,
            addressSignature: String(_0x3d24ae13b435.addressSignature || _0x4cbcf6dd9e80(49664)),
            itemSignature: String(_0x3d24ae13b435.itemSignature || _0x4cbcf6dd9e80(49664)),
            temuSignature: String(_0x3d24ae13b435.temuSignature || _0x4cbcf6dd9e80(49664)),
            groupSignature: String(_0x3d24ae13b435.groupSignature || _0x4cbcf6dd9e80(49664)),
            updatedAt: _0x3d24ae13b435.updatedAt
        });
    }
    for (const _0xd1c3f29c5d94 of _0xa10ee0aade68) {
        const _0x41a355834977 = _0x512d143486d6(_0xd1c3f29c5d94.temuOrderId);
        if (!_0x41a355834977) {
            continue;
        }
        const _0x0698cb45e1fc = _0xe52b9b1c5f42[_0x41a355834977];
        if (!_0x0698cb45e1fc || String(_0xd1c3f29c5d94.updatedAt) >= String(_0x0698cb45e1fc.updatedAt || _0x4cbcf6dd9e80(49664))) {
            _0xe52b9b1c5f42[_0x41a355834977] = _0xd1c3f29c5d94;
        }
    }
    return _0xe52b9b1c5f42;
}
function _0x8c72f69286bb(_0xab29c247ff4c, _0xc037b7e0efbe, _0x2f6b8f388f18 = null) {
    return {
        id: (_0x4cbcf6dd9e80(49664) + Date.now() + _0x4cbcf6dd9e80(49650) + Math.random().toString(16).slice(2) + _0x4cbcf6dd9e80(49664)),
        time: _0x90caaed66711(),
        isoTime: new Date().toISOString(),
        level: _0xab29c247ff4c,
        rowNumber: _0x2f6b8f388f18,
        message: _0xc037b7e0efbe
    };
}
function _0xc70b7be9a6b7(_0x58b6ab903559, _0xbadeb80dd63a, _0x85b02435a7ee, _0xd5b7566fd02f = null) {
    const _0x69e5953cb30d = Array.isArray(_0x58b6ab903559) ? _0x58b6ab903559 : [];
    _0x69e5953cb30d.push(_0x8c72f69286bb(_0xbadeb80dd63a, _0x85b02435a7ee, _0xd5b7566fd02f));
    if (_0x69e5953cb30d.length > _0x9888f9a67033) {
        _0x69e5953cb30d.splice(0, _0x69e5953cb30d.length - _0x9888f9a67033);
    }
    return _0x69e5953cb30d;
}
function _0xd3324508e9f2(_0xd622c7d655d0, _0xbac835cd3248) {
    const _0xb8a2e3a47e14 = _0xd622c7d655d0 && typeof _0xd622c7d655d0 === _0x4cbcf6dd9e80(49652) ? _0xd622c7d655d0 : {};
    const _0x9927014758f4 = _0xd855f240a5a5(_0xb8a2e3a47e14._rowId || _0xb8a2e3a47e14.draftRowId) || crypto.randomUUID();
    const _0x5dcdf3269681 = _0xca73cf69c048(_0xb8a2e3a47e14.temuOrderId);
    const _0x17f7c1191546 = _0x40f4a8626ae8(_0x5dcdf3269681);
    const _0x56dc91995915 = String(_0xb8a2e3a47e14.amzLink ?? _0x4cbcf6dd9e80(49664)).trim();
    const _0x76d310868cb8 = String(_0xb8a2e3a47e14.quantityToShip ?? _0x4cbcf6dd9e80(49664)).trim();
    const _0x137d2f5b6454 = String(_0xb8a2e3a47e14.recipientName ?? _0x4cbcf6dd9e80(49664)).trim();
    const _0x244b463bdd0c = String(_0xb8a2e3a47e14.phoneNumber ?? _0x4cbcf6dd9e80(49664)).trim();
    const _0xc207b566a1c6 = _0xca73cf69c048(_0xb8a2e3a47e14.shipAddress);
    const _0x6d76f585cb07 = _0xca73cf69c048(_0xb8a2e3a47e14.address2);
    const _0x5978f8cf8a46 = _0xca73cf69c048(_0xb8a2e3a47e14.shipCity);
    const _0x1a752add5af4 = _0xca73cf69c048(_0xb8a2e3a47e14.shipPostalCode);
    const _0x7bdf80b0f2f1 = _0xc0605a04af37(_0x137d2f5b6454);
    const _0x3e7b8a71a984 = _0x6212b0dfb520(_0x7bdf80b0f2f1);
    const _0xdd3daf6172e6 = _0x638fdf459481(_0x76d310868cb8);
    const _0x9dd671f82ec2 = _0xe3ef474f6bd2(_0x56dc91995915);
    const _0xdb8e85d56db0 = _0x7bdf80b0f2f1 && _0xc207b566a1c6 && _0x5978f8cf8a46 && _0x1a752add5af4
        ? [
            _0x3e7b8a71a984,
            _0x6212b0dfb520(_0xc207b566a1c6),
            _0x6212b0dfb520(_0x6d76f585cb07),
            _0x6212b0dfb520(_0x5978f8cf8a46),
            _0x6212b0dfb520(_0x1a752add5af4)
        ].join(_0x4cbcf6dd9e80(49638))
        : _0x4cbcf6dd9e80(49664);
    let _0x783a404d364c = _0x4cbcf6dd9e80(49664);
    if (!_0x7bdf80b0f2f1 || !_0xc207b566a1c6 || !_0x5978f8cf8a46 || !_0x1a752add5af4 || !_0x244b463bdd0c) {
        _0x783a404d364c = _0x4cbcf6dd9e80(49697);
    }
    else if (!_0x17f7c1191546) {
        _0x783a404d364c = _0x4cbcf6dd9e80(49696);
    }
    else if (_0xdd3daf6172e6 === null) {
        _0x783a404d364c = _0x4cbcf6dd9e80(49699);
    }
    else if (!_0x9dd671f82ec2) {
        _0x783a404d364c = _0x4cbcf6dd9e80(49698);
    }
    return {
        id: crypto.randomUUID(),
        draftRowId: _0x9927014758f4,
        sourceIndex: _0xbac835cd3248,
        rowNumber: _0xbac835cd3248 + 1,
        temuOrderId: _0x5dcdf3269681,
        normalizedTemuOrderId: _0x17f7c1191546,
        amzLink: _0x56dc91995915,
        quantityToShip: _0x76d310868cb8,
        recipientName: _0x137d2f5b6454,
        normalizedName: _0x7bdf80b0f2f1,
        normalizedNameKey: _0x3e7b8a71a984,
        requestedQuantity: _0xdd3daf6172e6,
        phoneNumber: _0x244b463bdd0c,
        shipAddress: _0xc207b566a1c6,
        address2: _0x6d76f585cb07,
        shipCity: _0x5978f8cf8a46,
        shipPostalCode: _0x1a752add5af4,
        asin: _0x9dd671f82ec2,
        addressSignature: _0xdb8e85d56db0,
        groupId: _0x4cbcf6dd9e80(49664),
        groupKey: _0xdb8e85d56db0,
        groupPosition: null,
        groupSize: 0,
        initialFailureReason: _0x783a404d364c,
        status: _0x4cbcf6dd9e80(49693),
        result: _0x4cbcf6dd9e80(49692),
        orderId: _0x4cbcf6dd9e80(49664),
        observedUnitPrice: _0x4cbcf6dd9e80(49664),
        selectedQuantity: _0x4cbcf6dd9e80(49664),
        precheckPassed: false,
        addedToCart: false,
        updatedAt: new Date().toISOString()
    };
}
function _0xaad2fd3f5bd9(_0x4e9d74dbe0ca) {
    return [
        _0x4e9d74dbe0ca.temuOrderId,
        _0x4e9d74dbe0ca.amzLink,
        _0x4e9d74dbe0ca.quantityToShip,
        _0x4e9d74dbe0ca.recipientName,
        _0x4e9d74dbe0ca.phoneNumber,
        _0x4e9d74dbe0ca.shipAddress,
        _0x4e9d74dbe0ca.address2,
        _0x4e9d74dbe0ca.shipCity,
        _0x4e9d74dbe0ca.shipPostalCode
    ].every((_0x5905a8406db6) => String(_0x5905a8406db6 ?? _0x4cbcf6dd9e80(49664)).trim() === _0x4cbcf6dd9e80(49664));
}
function _0x43b6a7957fcd(_0x147e7a1cbc8f, _0x5e96f0d9913f, _0x4b5a2937c1e5) {
    _0x147e7a1cbc8f.status = _0x5e96f0d9913f;
    _0x147e7a1cbc8f.result = _0x4b5a2937c1e5;
    _0x147e7a1cbc8f.updatedAt = new Date().toISOString();
}
function _0x6003fa09f718(_0x9aaeb8eefbd8, _0xf0839a76fa6e) {
    const _0xdcd235fed7da = new Map();
    for (const _0xff9fe7196ce4 of _0xf0839a76fa6e) {
        const _0x3b3c27314491 = _0x9aaeb8eefbd8[_0xff9fe7196ce4];
        if (!_0x3b3c27314491?.asin || !Number.isSafeInteger(_0x3b3c27314491.requestedQuantity) || _0x3b3c27314491.requestedQuantity <= 0) {
            continue;
        }
        _0xdcd235fed7da.set(_0x3b3c27314491.asin, (_0xdcd235fed7da.get(_0x3b3c27314491.asin) || 0) + _0x3b3c27314491.requestedQuantity);
    }
    return [..._0xdcd235fed7da.entries()]
        .sort(([_0xf3a45101490d], [_0x0084219f1247]) => _0xf3a45101490d.localeCompare(_0x0084219f1247))
        .map(([_0x48ceb7b3592b, _0x38cd58cee94e]) => ({ asin: _0x48ceb7b3592b, quantity: _0x38cd58cee94e }));
}
function _0xc8b7a579bf0b(_0xf79794ada544) {
    return (Array.isArray(_0xf79794ada544) ? _0xf79794ada544 : [])
        .map((_0x5d1ca8b4c943) => (_0x4cbcf6dd9e80(49664) + _0x5d1ca8b4c943.asin + _0x4cbcf6dd9e80(49695) + _0x5d1ca8b4c943.quantity + _0x4cbcf6dd9e80(49664)))
        .join(_0x4cbcf6dd9e80(49638));
}
function _0xf025d0b90c68(_0x0bd0504e3aeb, _0x048bdaf9854c, _0x3de277e210df) {
    return _0x048bdaf9854c.rowIndexes.filter((_0xfc64e45e7d0d) => _0x0bd0504e3aeb[_0xfc64e45e7d0d]?.normalizedTemuOrderId === _0x3de277e210df);
}
function _0x2ab6057fa92b(_0x87dbff87fd47, _0xf0d693ec77cb, _0xb2771f856175) {
    const _0x1e3ec04400f2 = [..._0xf0d693ec77cb].sort((_0x755405ed48d2, _0xe5f669f331cb) => _0x87dbff87fd47[_0x755405ed48d2].sourceIndex - _0x87dbff87fd47[_0xe5f669f331cb].sourceIndex);
    const _0xc088c1c5ceb1 = _0x1e3ec04400f2[0];
    const _0xd7ba3246afa5 = _0x87dbff87fd47[_0xc088c1c5ceb1];
    const _0x53ce8f58c69c = [...new Set(_0x1e3ec04400f2.map((_0x89d1e2b40560) => _0xca73cf69c048(_0x87dbff87fd47[_0x89d1e2b40560].phoneNumber)).filter(Boolean))];
    const _0x75e83e8e3501 = _0x6003fa09f718(_0x87dbff87fd47, _0x1e3ec04400f2);
    const _0x64d4fdef9645 = _0x75e83e8e3501.reduce((_0x5f60c3eaa4a9, _0xb799ebbed723) => _0x5f60c3eaa4a9 + _0xb799ebbed723.quantity, 0);
    const _0x9a0627c68127 = [...new Set(_0x1e3ec04400f2.map((_0x204c9c93c80a) => _0x87dbff87fd47[_0x204c9c93c80a].normalizedTemuOrderId).filter(Boolean))];
    const _0xa3ec04964ca4 = {};
    const _0x96031a3b5dc4 = {};
    for (const _0x29d8d060494d of _0x9a0627c68127) {
        const _0x3cccbfe0cd2d = _0xf025d0b90c68(_0x87dbff87fd47, { rowIndexes: _0x1e3ec04400f2 }, _0x29d8d060494d);
        const _0x49d1ae99fc54 = _0x6003fa09f718(_0x87dbff87fd47, _0x3cccbfe0cd2d);
        const _0x6cd566ebc104 = _0xc8b7a579bf0b(_0x49d1ae99fc54);
        _0x96031a3b5dc4[_0x29d8d060494d] = _0x6cd566ebc104;
        _0xa3ec04964ca4[_0x29d8d060494d] = (_0x4cbcf6dd9e80(49664) + _0xd7ba3246afa5.addressSignature + _0x4cbcf6dd9e80(49694) + _0x6cd566ebc104 + _0x4cbcf6dd9e80(49664));
    }
    const _0x9acb779d732d = (_0x4cbcf6dd9e80(49689) + _0xb2771f856175 + _0x4cbcf6dd9e80(49650) + crypto.randomUUID() + _0x4cbcf6dd9e80(49664));
    _0x1e3ec04400f2.forEach((_0xc3b3e84d69f8, _0x9c03191d1b38) => {
        _0x87dbff87fd47[_0xc3b3e84d69f8].groupId = _0x9acb779d732d;
        _0x87dbff87fd47[_0xc3b3e84d69f8].groupPosition = _0x9c03191d1b38;
        _0x87dbff87fd47[_0xc3b3e84d69f8].groupSize = _0x1e3ec04400f2.length;
    });
    return {
        id: _0x9acb779d732d,
        key: _0xd7ba3246afa5.addressSignature,
        sortKey: [
            _0x6212b0dfb520(_0xd7ba3246afa5.shipAddress),
            _0x6212b0dfb520(_0xd7ba3246afa5.address2),
            _0x6212b0dfb520(_0xd7ba3246afa5.shipCity),
            _0x6212b0dfb520(_0xd7ba3246afa5.shipPostalCode),
            _0xd7ba3246afa5.normalizedNameKey
        ].join(_0x4cbcf6dd9e80(49638)),
        originalPosition: _0xd7ba3246afa5.sourceIndex,
        rowIndexes: _0x1e3ec04400f2,
        primaryRowIndex: _0xc088c1c5ceb1,
        isCombined: _0x1e3ec04400f2.length > 1,
        normalizedName: _0xd7ba3246afa5.normalizedName,
        normalizedNameKey: _0xd7ba3246afa5.normalizedNameKey,
        shipAddress: _0xd7ba3246afa5.shipAddress,
        address2: _0xd7ba3246afa5.address2,
        shipCity: _0xd7ba3246afa5.shipCity,
        shipPostalCode: _0xd7ba3246afa5.shipPostalCode,
        phoneNumber: _0xd7ba3246afa5.phoneNumber,
        phoneMismatch: _0x53ce8f58c69c.length > 1,
        phoneNumbers: _0x53ce8f58c69c,
        addressSignature: _0xd7ba3246afa5.addressSignature,
        expectedItems: _0x75e83e8e3501,
        expectedItemSignature: _0xc8b7a579bf0b(_0x75e83e8e3501),
        expectedTotalQuantity: _0x64d4fdef9645,
        uniqueTemuOrderIds: _0x9a0627c68127,
        temuSignatures: _0xa3ec04964ca4,
        temuItemSignatures: _0x96031a3b5dc4,
        groupSignature: (_0x4cbcf6dd9e80(49664) + _0xd7ba3246afa5.addressSignature + _0x4cbcf6dd9e80(49694) + _0xc8b7a579bf0b(_0x75e83e8e3501) + _0x4cbcf6dd9e80(49664)),
        result: _0x4cbcf6dd9e80(49688),
        status: _0x4cbcf6dd9e80(49693),
        triggerRowIndex: null,
        precheckCursor: 0,
        addCursor: 0,
        expectedCartCount: 0,
        actualDeliveryAddress: _0x4cbcf6dd9e80(49664),
        orderId: _0x4cbcf6dd9e80(49664),
        updatedAt: new Date().toISOString()
    };
}
function _0x226ac3a339cd(_0x85b8ec789ec3, _0x83348de24390, _0x7a0a21a8f9d8, _0x7e9d3dfefd70) {
    _0x83348de24390.result = _0x4cbcf6dd9e80(49691);
    _0x83348de24390.status = _0x7e9d3dfefd70;
    _0x83348de24390.triggerRowIndex = _0x7a0a21a8f9d8;
    _0x83348de24390.updatedAt = new Date().toISOString();
    for (const _0xb6c4161fb4fa of _0x83348de24390.rowIndexes) {
        const _0xd83bf018612c = _0x85b8ec789ec3[_0xb6c4161fb4fa];
        const _0xd2dbda6a9b4f = _0xb6c4161fb4fa === _0x7a0a21a8f9d8 || _0x83348de24390.rowIndexes.length === 1
            ? _0x7e9d3dfefd70 : _0x4cbcf6dd9e80(49690);
        _0x43b6a7957fcd(_0xd83bf018612c, _0xd2dbda6a9b4f, _0x4cbcf6dd9e80(49691));
    }
}
function _0x7bffd74ea3dc(_0xf0329bddca64, _0x972b65fe890f, _0x29f59cd8d7b4) {
    _0x972b65fe890f.result = _0x4cbcf6dd9e80(49685);
    _0x972b65fe890f.status = (_0x4cbcf6dd9e80(49684) + _0x29f59cd8d7b4 + _0x4cbcf6dd9e80(49664));
    _0x972b65fe890f.updatedAt = new Date().toISOString();
    for (const _0x0c900bb5b133 of _0x972b65fe890f.rowIndexes) {
        _0x43b6a7957fcd(_0xf0329bddca64[_0x0c900bb5b133], (_0x4cbcf6dd9e80(49684) + _0x29f59cd8d7b4 + _0x4cbcf6dd9e80(49664)), _0x4cbcf6dd9e80(49685));
    }
}
function _0xe1f605a7091c(_0xf73e56948075, _0x26c2931ae09c, _0x6b2a34c49be6) {
    _0x26c2931ae09c.result = _0x4cbcf6dd9e80(49687);
    _0x26c2931ae09c.status = _0x6b2a34c49be6;
    _0x26c2931ae09c.updatedAt = new Date().toISOString();
    for (const _0xbdfd28f50493 of _0x26c2931ae09c.rowIndexes) {
        const _0xa46746addaea = _0xf73e56948075[_0xbdfd28f50493];
        if (_0xa46746addaea.result !== _0x4cbcf6dd9e80(49686) && _0xa46746addaea.result !== _0x4cbcf6dd9e80(49691)) {
            _0x43b6a7957fcd(_0xa46746addaea, _0x6b2a34c49be6, _0x4cbcf6dd9e80(49687));
        }
    }
}
function _0xa5a7c226e186(_0xdf49ff77f44a, _0x02f57e5b0af7, _0xff0ba75bf7f0) {
    _0x02f57e5b0af7.result = _0x4cbcf6dd9e80(49686);
    _0x02f57e5b0af7.status = _0x4cbcf6dd9e80(49681);
    _0x02f57e5b0af7.orderId = _0xff0ba75bf7f0;
    _0x02f57e5b0af7.updatedAt = new Date().toISOString();
    for (const _0x4c31e8af55a2 of _0x02f57e5b0af7.rowIndexes) {
        const _0x796258957c6c = _0xdf49ff77f44a[_0x4c31e8af55a2];
        _0x796258957c6c.orderId = _0xff0ba75bf7f0;
        _0x43b6a7957fcd(_0x796258957c6c, _0x4cbcf6dd9e80(49681), _0x4cbcf6dd9e80(49686));
    }
}
function _0x3b4de81b4f97(_0xfa0e463c6bf2, _0x825d7e649fac, _0x0126d8289e55) {
    const _0xbed3ae52a828 = _0xf0ccabd2d36d(_0x0126d8289e55, _0x825d7e649fac);
    const _0x73460a6bf36d = _0xac1031e3efac();
    const _0x4faeecb2d524 = (Array.isArray(_0xfa0e463c6bf2) ? _0xfa0e463c6bf2 : [])
        .map((_0xba1e40ba332e, _0xaed756cec5d8) => _0xd3324508e9f2(_0xba1e40ba332e, _0xaed756cec5d8))
        .filter((_0xccc8d6bb15e4) => !_0xaad2fd3f5bd9(_0xccc8d6bb15e4));
    const _0x88d649d57c75 = new Map();
    for (let _0xfa60580ddd51 = 0; _0xfa60580ddd51 < _0x4faeecb2d524.length; _0xfa60580ddd51 += 1) {
        const _0x19fa58440cac = _0x4faeecb2d524[_0xfa60580ddd51];
        if (!_0x19fa58440cac.addressSignature) {
            _0x43b6a7957fcd(_0x19fa58440cac, _0x19fa58440cac.initialFailureReason || _0x4cbcf6dd9e80(49697), _0x4cbcf6dd9e80(49691));
            continue;
        }
        if (!_0x88d649d57c75.has(_0x19fa58440cac.addressSignature)) {
            _0x88d649d57c75.set(_0x19fa58440cac.addressSignature, []);
        }
        _0x88d649d57c75.get(_0x19fa58440cac.addressSignature).push(_0xfa60580ddd51);
    }
    const _0x599889e25c39 = [..._0x88d649d57c75.values()].map((_0x9ea362f7ad42, _0x7eed40e208dc) => _0x2ab6057fa92b(_0x4faeecb2d524, _0x9ea362f7ad42, _0x7eed40e208dc + 1));
    _0x599889e25c39.sort((_0xf324ba19e892, _0x1ac9cd554f0c) => _0xf324ba19e892.originalPosition - _0x1ac9cd554f0c.originalPosition);
    for (const _0xb30135642012 of _0x599889e25c39) {
        const _0x44a355e4ede7 = _0xb30135642012.rowIndexes.find((_0xdcc8e080dbc8) => _0x4faeecb2d524[_0xdcc8e080dbc8].initialFailureReason);
        if (_0x44a355e4ede7 !== undefined) {
            _0x226ac3a339cd(_0x4faeecb2d524, _0xb30135642012, _0x44a355e4ede7, _0x4faeecb2d524[_0x44a355e4ede7].initialFailureReason);
        }
        else {
            _0xb30135642012.result = _0x4cbcf6dd9e80(49688);
            _0xb30135642012.status = _0x4cbcf6dd9e80(49693);
            for (const _0xc4ca529e5da3 of _0xb30135642012.rowIndexes) {
                _0x43b6a7957fcd(_0x4faeecb2d524[_0xc4ca529e5da3], _0x4cbcf6dd9e80(49693), _0x4cbcf6dd9e80(49688));
            }
        }
    }
    const _0x3a77c0fa8f74 = [];
    const _0x9ad754b4787c = new Map();
    for (const _0x006e3cab389c of _0x599889e25c39) {
        for (const _0xe7e6d4a1932f of _0x006e3cab389c.uniqueTemuOrderIds) {
            if (!_0x9ad754b4787c.has(_0xe7e6d4a1932f)) {
                _0x9ad754b4787c.set(_0xe7e6d4a1932f, new Set());
            }
            _0x9ad754b4787c.get(_0xe7e6d4a1932f).add(_0x006e3cab389c.id);
        }
    }
    for (const [_0xa79fd9dec822, _0x8c82c1dd4398] of _0x9ad754b4787c.entries()) {
        if (_0x8c82c1dd4398.size <= 1) {
            continue;
        }
        const _0xd163c737992b = (_0x4cbcf6dd9e80(49680) + _0xa79fd9dec822 + _0x4cbcf6dd9e80(49683));
        _0x3a77c0fa8f74.push(_0xd163c737992b);
        for (const _0xe8bbf3b54f6e of _0x8c82c1dd4398) {
            const _0x683c80cffc86 = _0x599889e25c39.find((_0xa14f18690a01) => _0xa14f18690a01.id === _0xe8bbf3b54f6e);
            if (_0x683c80cffc86) {
                _0x7bffd74ea3dc(_0x4faeecb2d524, _0x683c80cffc86, _0xd163c737992b);
            }
        }
    }
    for (const _0xad0cefcc2e5b of _0x599889e25c39) {
        if (_0xad0cefcc2e5b.result !== _0x4cbcf6dd9e80(49688)) {
            continue;
        }
        let _0x90d8a7cc000d = null;
        let _0xc306745fbc3f = null;
        for (const _0xc510b41da1fc of _0xad0cefcc2e5b.uniqueTemuOrderIds) {
            const _0x1bdd203f4489 = _0xbed3ae52a828[_0x512d143486d6(_0xc510b41da1fc)];
            if (!_0x1bdd203f4489 ||
                _0x1bdd203f4489.status !== _0x4cbcf6dd9e80(49639) ||
                _0x1bdd203f4489.dateKey !== _0x73460a6bf36d ||
                !_0xde4244574fd5(_0x1bdd203f4489.orderId)) {
                continue;
            }
            const _0x6f59206f21c8 = _0xad0cefcc2e5b.temuSignatures[_0xc510b41da1fc] || _0x4cbcf6dd9e80(49664);
            if (_0x1bdd203f4489.temuSignature && _0x6f59206f21c8 && _0x1bdd203f4489.temuSignature !== _0x6f59206f21c8) {
                _0xc306745fbc3f = (_0x4cbcf6dd9e80(49680) + _0xc510b41da1fc + _0x4cbcf6dd9e80(49682));
                break;
            }
            const _0x66f9e2b70f4a = _0xad0cefcc2e5b.rowIndexes.find((_0xf3e9d61bec70) => _0x4faeecb2d524[_0xf3e9d61bec70].normalizedTemuOrderId === _0xc510b41da1fc);
            _0x90d8a7cc000d = {
                triggerRowIndex: _0x66f9e2b70f4a,
                reason: _0x4cbcf6dd9e80(49677)
            };
            break;
        }
        if (_0xc306745fbc3f) {
            _0x3a77c0fa8f74.push(_0xc306745fbc3f);
            _0x7bffd74ea3dc(_0x4faeecb2d524, _0xad0cefcc2e5b, _0xc306745fbc3f);
        }
        else if (_0x90d8a7cc000d) {
            _0x226ac3a339cd(_0x4faeecb2d524, _0xad0cefcc2e5b, _0x90d8a7cc000d.triggerRowIndex, _0x90d8a7cc000d.reason);
        }
    }
    const _0x7f3e95021e4e = [...new Set(Object.values(_0xbed3ae52a828)
            .filter((_0xe164676cdcb3) => _0xe164676cdcb3?.dateKey === _0x73460a6bf36d && _0xde4244574fd5(_0xe164676cdcb3?.orderId))
            .map((_0xa4f023dbb1e9) => _0xa4f023dbb1e9.orderId))];
    return { rows: _0x4faeecb2d524, groups: _0x599889e25c39, orderIndex: _0xbed3ae52a828, fatalConflicts: _0x3a77c0fa8f74, knownOrderIds: _0x7f3e95021e4e };
}
function _0x21bf3b4f1c01(_0x593004ae6d18, _0x4d0cbeef80f7, _0x7be9726ae127, _0x1ad1f5d0a917) {
    const _0x058c513a7ac1 = _0xf0ccabd2d36d(_0x1ad1f5d0a917, _0x7be9726ae127);
    const _0x3fa9953facc0 = Array.isArray(_0x593004ae6d18) ? _0x593004ae6d18 : [];
    const _0x26bd00f352c7 = Array.isArray(_0x4d0cbeef80f7) ? _0x4d0cbeef80f7 : [];
    const _0xbf52341fc3e4 = new Map();
    const _0xf1e9ec044148 = new Map();
    for (const _0x510362b797e6 of _0x26bd00f352c7) {
        const _0xd6232315fa7a = _0xd855f240a5a5(_0x510362b797e6?.draftRowId);
        if (_0xd6232315fa7a && !_0xbf52341fc3e4.has(_0xd6232315fa7a)) {
            _0xbf52341fc3e4.set(_0xd6232315fa7a, _0x510362b797e6);
        }
        if (Number.isInteger(_0x510362b797e6?.sourceIndex) && !_0xf1e9ec044148.has(_0x510362b797e6.sourceIndex)) {
            _0xf1e9ec044148.set(_0x510362b797e6.sourceIndex, _0x510362b797e6);
        }
    }
    const _0x94e5644135c6 = new Set();
    const _0x1d8deabdbb99 = [];
    const _0xe3e22b31760f = [];
    const _0x056276d53ca6 = [];
    for (let _0x329b6e58b558 = 0; _0x329b6e58b558 < _0x3fa9953facc0.length; _0x329b6e58b558 += 1) {
        const _0xee6276c3b7f2 = _0x3fa9953facc0[_0x329b6e58b558] && typeof _0x3fa9953facc0[_0x329b6e58b558] === _0x4cbcf6dd9e80(49652)
            ? _0x3fa9953facc0[_0x329b6e58b558]
            : {};
        if (_0xaad2fd3f5bd9(_0xee6276c3b7f2)) {
            continue;
        }
        const _0x4e7dd9b25c37 = _0xd855f240a5a5(_0xee6276c3b7f2._rowId || _0xee6276c3b7f2.draftRowId);
        let _0x2d2fc99357a5 = _0x4e7dd9b25c37 ? _0xbf52341fc3e4.get(_0x4e7dd9b25c37) : null;
        if (!_0x2d2fc99357a5) {
            const _0xd5ee7d6c523d = _0xf1e9ec044148.get(_0x329b6e58b558) || null;
            if (!_0x4e7dd9b25c37 || !_0xd855f240a5a5(_0xd5ee7d6c523d?.draftRowId)) {
                _0x2d2fc99357a5 = _0xd5ee7d6c523d;
            }
        }
        if (!_0x2d2fc99357a5) {
            continue;
        }
        if (_0x94e5644135c6.has(_0x2d2fc99357a5)) {
            _0x056276d53ca6.push(_0x2d2fc99357a5.rowNumber || _0x329b6e58b558 + 1);
            continue;
        }
        _0x94e5644135c6.add(_0x2d2fc99357a5);
        const _0x4d05c2cd5edf = _0x2d2fc99357a5.result === _0x4cbcf6dd9e80(49691) && !_0xde4244574fd5(_0x2d2fc99357a5.orderId);
        if (_0x4d05c2cd5edf) {
            const _0x37ba6fac33b5 = _0xd3324508e9f2(_0xee6276c3b7f2, _0x329b6e58b558);
            _0x37ba6fac33b5.id = _0x2d2fc99357a5.id || _0x37ba6fac33b5.id;
            _0x37ba6fac33b5.draftRowId = _0x4e7dd9b25c37 || _0xd855f240a5a5(_0x2d2fc99357a5.draftRowId) || _0x37ba6fac33b5.draftRowId;
            _0x37ba6fac33b5.status = _0x4cbcf6dd9e80(49676);
            _0x37ba6fac33b5.result = _0x4cbcf6dd9e80(49692);
            const _0xfadce3efb287 = _0x1d8deabdbb99.length;
            _0x1d8deabdbb99.push(_0x37ba6fac33b5);
            _0xe3e22b31760f.push(_0xfadce3efb287);
            continue;
        }
        _0x1d8deabdbb99.push({
            ..._0x2d2fc99357a5,
            draftRowId: _0x4e7dd9b25c37 || _0xd855f240a5a5(_0x2d2fc99357a5.draftRowId) || crypto.randomUUID(),
            sourceIndex: _0x329b6e58b558,
            rowNumber: _0x329b6e58b558 + 1
        });
    }
    const _0x9bf161494cdb = [];
    for (const _0x86646d887178 of _0x26bd00f352c7) {
        if (_0x94e5644135c6.has(_0x86646d887178)) {
            continue;
        }
        const _0xc27f415c60ce = _0x86646d887178.result === _0x4cbcf6dd9e80(49691) && !_0xde4244574fd5(_0x86646d887178.orderId);
        if (_0xc27f415c60ce) {
            _0x9bf161494cdb.push(_0x86646d887178.rowNumber || _0x86646d887178.sourceIndex + 1);
            continue;
        }
        _0x1d8deabdbb99.push({ ..._0x86646d887178 });
    }
    if (_0x056276d53ca6.length > 0) {
        return {
            error: (_0x4cbcf6dd9e80(49679) + _0x056276d53ca6.join(_0x4cbcf6dd9e80(49678)) + _0x4cbcf6dd9e80(49673))
        };
    }
    if (_0x9bf161494cdb.length > 0) {
        return {
            error: (_0x4cbcf6dd9e80(49672) + _0x9bf161494cdb.length + _0x4cbcf6dd9e80(49675) + _0x9bf161494cdb.join(_0x4cbcf6dd9e80(49678)) + _0x4cbcf6dd9e80(49674))
        };
    }
    if (_0xe3e22b31760f.length === 0) {
        return { error: _0x4cbcf6dd9e80(49669) };
    }
    const _0xd881203a6c45 = new Map();
    for (const _0x1bbdd7ae8840 of _0xe3e22b31760f) {
        const _0x0dbca9ce8821 = _0x1d8deabdbb99[_0x1bbdd7ae8840];
        if (!_0x0dbca9ce8821.addressSignature) {
            _0x43b6a7957fcd(_0x0dbca9ce8821, _0x0dbca9ce8821.initialFailureReason || _0x4cbcf6dd9e80(49697), _0x4cbcf6dd9e80(49691));
            continue;
        }
        if (!_0xd881203a6c45.has(_0x0dbca9ce8821.addressSignature)) {
            _0xd881203a6c45.set(_0x0dbca9ce8821.addressSignature, []);
        }
        _0xd881203a6c45.get(_0x0dbca9ce8821.addressSignature).push(_0x1bbdd7ae8840);
    }
    const _0xeea962dc9ca2 = [..._0xd881203a6c45.values()].map((_0x8a04f2a49e5f, _0x1ca4c6d30ba2) => _0x2ab6057fa92b(_0x1d8deabdbb99, _0x8a04f2a49e5f, _0x1ca4c6d30ba2 + 1));
    _0xeea962dc9ca2.sort((_0xd574be4b1502, _0x80264b0f61b6) => _0xd574be4b1502.originalPosition - _0x80264b0f61b6.originalPosition);
    for (const _0x708607f5bf67 of _0xeea962dc9ca2) {
        const _0xa8fb2fb46cb4 = _0x708607f5bf67.rowIndexes.find((_0xda002c3f2f73) => _0x1d8deabdbb99[_0xda002c3f2f73].initialFailureReason);
        if (_0xa8fb2fb46cb4 !== undefined) {
            _0x226ac3a339cd(_0x1d8deabdbb99, _0x708607f5bf67, _0xa8fb2fb46cb4, _0x1d8deabdbb99[_0xa8fb2fb46cb4].initialFailureReason);
        }
        else {
            _0x708607f5bf67.result = _0x4cbcf6dd9e80(49688);
            _0x708607f5bf67.status = _0x4cbcf6dd9e80(49676);
            for (const _0xcb72b6422aed of _0x708607f5bf67.rowIndexes) {
                _0x43b6a7957fcd(_0x1d8deabdbb99[_0xcb72b6422aed], _0x4cbcf6dd9e80(49676), _0x4cbcf6dd9e80(49688));
            }
        }
    }
    const _0x6fc2937e8804 = [];
    const _0xf52f9720feb9 = new Map();
    for (const _0x398dbc1f4fcd of _0xeea962dc9ca2) {
        for (const _0xf90f079f2661 of _0x398dbc1f4fcd.uniqueTemuOrderIds) {
            if (!_0xf52f9720feb9.has(_0xf90f079f2661)) {
                _0xf52f9720feb9.set(_0xf90f079f2661, new Set());
            }
            _0xf52f9720feb9.get(_0xf90f079f2661).add(_0x398dbc1f4fcd.id);
        }
    }
    for (const [_0xc7bc2ca5073d, _0x2da25f76afd9] of _0xf52f9720feb9.entries()) {
        if (_0x2da25f76afd9.size <= 1) {
            continue;
        }
        const _0xe97f18f94667 = (_0x4cbcf6dd9e80(49668) + _0xc7bc2ca5073d + _0x4cbcf6dd9e80(49683));
        _0x6fc2937e8804.push(_0xe97f18f94667);
        for (const _0x69a50d14c8fa of _0x2da25f76afd9) {
            const _0xa108059596e4 = _0xeea962dc9ca2.find((_0xb0c70d3e7d7c) => _0xb0c70d3e7d7c.id === _0x69a50d14c8fa);
            if (_0xa108059596e4) {
                _0x7bffd74ea3dc(_0x1d8deabdbb99, _0xa108059596e4, _0xe97f18f94667);
            }
        }
    }
    const _0x0948193447bd = [...new Set([
            ...Object.values(_0x058c513a7ac1)
                .map((_0x6210c11b3c40) => String(_0x6210c11b3c40?.orderId || _0x4cbcf6dd9e80(49664)).trim())
                .filter(_0xde4244574fd5),
            ..._0x26bd00f352c7.map((_0xc6c03766c5be) => String(_0xc6c03766c5be?.orderId || _0x4cbcf6dd9e80(49664)).trim())
                .filter(_0xde4244574fd5)
        ])];
    return {
        rows: _0x1d8deabdbb99,
        groups: _0xeea962dc9ca2,
        orderIndex: _0x058c513a7ac1,
        fatalConflicts: _0x6fc2937e8804,
        knownOrderIds: _0x0948193447bd,
        retryCount: _0xe3e22b31760f.length
    };
}
function _0x589ffb3858ed(_0x324da1f64817, _0x492bda567e41 = -1) {
    for (let _0x250549fc0b6b = _0x492bda567e41 + 1; _0x250549fc0b6b < _0x324da1f64817.length; _0x250549fc0b6b += 1) {
        if (_0x324da1f64817[_0x250549fc0b6b]?.result === _0x4cbcf6dd9e80(49688)) {
            return _0x250549fc0b6b;
        }
    }
    return -1;
}
function _0xc77f4848e0bd(_0x8560b1dcf834) {
    if (!_0x8560b1dcf834 || !Array.isArray(_0x8560b1dcf834.groups) || !Number.isInteger(_0x8560b1dcf834.currentGroupIndex)) {
        return null;
    }
    return _0x8560b1dcf834.groups[_0x8560b1dcf834.currentGroupIndex] || null;
}
function _0xa933c8eed5e2(_0xd93b4875b683) {
    if (!_0xd93b4875b683 || !Array.isArray(_0xd93b4875b683.rows) || !Number.isInteger(_0xd93b4875b683.currentIndex)) {
        return null;
    }
    return _0xd93b4875b683.rows[_0xd93b4875b683.currentIndex] || null;
}
function _0xe7759fd6c561(_0x4f64b63aedd0) {
    const _0x511a7e7bc477 = _0xc77f4848e0bd(_0x4f64b63aedd0);
    if (!_0x511a7e7bc477 || !Array.isArray(_0x4f64b63aedd0?.rows)) {
        return _0xa933c8eed5e2(_0x4f64b63aedd0);
    }
    return _0x4f64b63aedd0.rows[_0x511a7e7bc477.primaryRowIndex] || _0xa933c8eed5e2(_0x4f64b63aedd0);
}
async function _0x603145195ada() {
    return chrome.storage.local.get([
        _0x21777dfa17c3.RUN_STATE,
        _0x21777dfa17c3.HISTORY,
        _0x21777dfa17c3.ORDER_INDEX,
        _0x21777dfa17c3.CART_LOCK,
        _0x21777dfa17c3.LOGS,
        _0x21777dfa17c3.DRAFT_ROWS,
        _0x21777dfa17c3.SETTINGS
    ]);
}
async function _0xe1bc71889e25() {
    const _0xd55f54e4c7ba = chrome.runtime.getURL(_0x4cbcf6dd9e80(49671));
    const _0xcb061a82029d = await chrome.windows.getAll({ populate: true });
    for (const _0xce72bd9fa1e3 of _0xcb061a82029d) {
        const _0x00270d67d0f8 = _0xce72bd9fa1e3.tabs?.find((_0x6d446300c5a6) => _0x6d446300c5a6.url === _0xd55f54e4c7ba);
        if (_0x00270d67d0f8) {
            await chrome.windows.update(_0xce72bd9fa1e3.id, { focused: true });
            await chrome.tabs.update(_0x00270d67d0f8.id, { active: true });
            return;
        }
    }
    await chrome.windows.create({
        url: _0xd55f54e4c7ba,
        type: _0x4cbcf6dd9e80(49670),
        width: 1440,
        height: 920,
        focused: true
    });
}
async function _0x3a18869c73a9(_0x987e1bc03bc0 = null) {
    if (Number.isInteger(_0x987e1bc03bc0)) {
        try {
            const _0xa4950801b730 = await chrome.tabs.get(_0x987e1bc03bc0);
            await chrome.tabs.update(_0xa4950801b730.id, { url: _0x4cbcf6dd9e80(49729), active: true });
            await chrome.windows.update(_0xa4950801b730.windowId, { focused: true });
            await _0xf9ec002844ce(120);
            return _0xa4950801b730.id;
        }
        catch {
        }
    }
    const _0x91ecae298118 = await chrome.windows.getAll({ windowTypes: [_0x4cbcf6dd9e80(49728)] });
    const _0x8d169ea886b5 = _0x91ecae298118.find((_0xc2bed49d1d82) => _0xc2bed49d1d82.focused) || _0x91ecae298118[0];
    if (_0x8d169ea886b5) {
        const _0x475b1734920d = await chrome.tabs.create({
            windowId: _0x8d169ea886b5.id,
            url: _0x4cbcf6dd9e80(49729),
            active: true
        });
        await chrome.windows.update(_0x8d169ea886b5.id, { focused: true });
        return _0x475b1734920d.id;
    }
    const _0x961426e64bd5 = await chrome.windows.create({
        type: _0x4cbcf6dd9e80(49728),
        url: _0x4cbcf6dd9e80(49729),
        focused: true
    });
    const _0xed88515413f6 = _0x961426e64bd5.tabs?.[0]?.id;
    if (!Number.isInteger(_0xed88515413f6)) {
        throw new Error(_0x4cbcf6dd9e80(49731));
    }
    return _0xed88515413f6;
}
async function _0x7bf4ab7c3df0(_0xf0efc048143e) {
    if (!Number.isInteger(_0xf0efc048143e)) {
        throw new Error(_0x4cbcf6dd9e80(49730));
    }
    const _0x56fce3519842 = await chrome.tabs.get(_0xf0efc048143e);
    await chrome.tabs.update(_0xf0efc048143e, { active: true });
    await chrome.windows.update(_0x56fce3519842.windowId, { focused: true });
}
async function _0x49c0aaeecf35(_0xd11cac30d7cb) {
    if (!Number.isInteger(_0xd11cac30d7cb)) {
        return;
    }
    try {
        await chrome.tabs.sendMessage(_0xd11cac30d7cb, { type: _0x4cbcf6dd9e80(49725) });
    }
    catch {
    }
}
async function _0x41e77a857846(_0x6e3082dcb30c, _0x41a39923627b) {
    if (!Number.isInteger(_0x6e3082dcb30c)) {
        throw new Error(_0x4cbcf6dd9e80(49730));
    }
    await chrome.tabs.update(_0x6e3082dcb30c, { url: _0x41a39923627b, active: true });
    await _0x7bf4ab7c3df0(_0x6e3082dcb30c);
}
async function _0xe10b90fbf183(_0xee572a4568ee, _0x61d3d7357d9a, _0x3609bdb63650, _0xa7652ac5458c = {}, _0xa8e453b670c2 = _0x4cbcf6dd9e80(49724)) {
    const _0x47443d4fdd5a = Number.isInteger(_0xee572a4568ee?.workTabId) ? _0xee572a4568ee.workTabId : null;
    let _0x5d37d7b55fe5 = null;
    let _0xad5406e89cab = null;
    if (_0x47443d4fdd5a !== null) {
        try {
            _0x5d37d7b55fe5 = await chrome.tabs.get(_0x47443d4fdd5a);
        }
        catch {
            _0x5d37d7b55fe5 = null;
        }
    }
    try {
        if (_0x5d37d7b55fe5) {
            const _0x3dc3bec30964 = {
                windowId: _0x5d37d7b55fe5.windowId,
                url: _0x4cbcf6dd9e80(49729),
                active: true
            };
            if (Number.isInteger(_0x5d37d7b55fe5.index)) {
                _0x3dc3bec30964.index = _0x5d37d7b55fe5.index + 1;
            }
            const _0xbd84dd1ce2ce = await chrome.tabs.create(_0x3dc3bec30964);
            if (!Number.isInteger(_0xbd84dd1ce2ce?.id)) {
                throw new Error(_0x4cbcf6dd9e80(49727));
            }
            _0xad5406e89cab = _0xbd84dd1ce2ce.id;
            await chrome.windows.update(_0x5d37d7b55fe5.windowId, { focused: true });
        }
        else {
            _0xad5406e89cab = await _0x3a18869c73a9(null);
        }
        _0xee572a4568ee.workTabId = _0xad5406e89cab;
        _0xee572a4568ee.updatedAt = new Date().toISOString();
        await _0xd68338758035(_0xee572a4568ee, _0x61d3d7357d9a, _0xa7652ac5458c);
        await _0x41e77a857846(_0xad5406e89cab, _0x3609bdb63650);
        if (_0x47443d4fdd5a !== null && _0x47443d4fdd5a !== _0xad5406e89cab) {
            try {
                await chrome.tabs.remove(_0x47443d4fdd5a);
            }
            catch {
            }
        }
        return { ok: true, oldTabId: _0x47443d4fdd5a, newTabId: _0xad5406e89cab };
    }
    catch (_0x555db8b6ab2a) {
        if (Number.isInteger(_0xad5406e89cab) && _0xad5406e89cab !== _0x47443d4fdd5a) {
            try {
                await chrome.tabs.remove(_0xad5406e89cab);
            }
            catch {
            }
        }
        let _0x66d196f9d5dd = false;
        if (_0x47443d4fdd5a !== null) {
            try {
                await chrome.tabs.get(_0x47443d4fdd5a);
                _0x66d196f9d5dd = true;
            }
            catch {
                _0x66d196f9d5dd = false;
            }
        }
        _0xee572a4568ee.workTabId = _0x66d196f9d5dd ? _0x47443d4fdd5a : null;
        _0xee572a4568ee.mode = _0x4cbcf6dd9e80(49624);
        _0xee572a4568ee.pauseReason = (_0x4cbcf6dd9e80(49664) + _0xa8e453b670c2 + _0x4cbcf6dd9e80(49726) + (_0x555db8b6ab2a.message || String(_0x555db8b6ab2a)) + _0x4cbcf6dd9e80(49664));
        _0xee572a4568ee.updatedAt = new Date().toISOString();
        const _0xc2e5c58330e6 = _0xc77f4848e0bd(_0xee572a4568ee);
        const _0xcbac7962d483 = _0xa933c8eed5e2(_0xee572a4568ee);
        if (_0xc2e5c58330e6?.isCombined) {
            _0x7bffd74ea3dc(_0xee572a4568ee.rows, _0xc2e5c58330e6, _0xee572a4568ee.pauseReason);
        }
        else if (_0xcbac7962d483) {
            _0x43b6a7957fcd(_0xcbac7962d483, (_0x4cbcf6dd9e80(49684) + _0xee572a4568ee.pauseReason + _0x4cbcf6dd9e80(49664)), _0x4cbcf6dd9e80(49685));
        }
        _0xc70b7be9a6b7(_0x61d3d7357d9a, _0x4cbcf6dd9e80(49665), _0xee572a4568ee.pauseReason, _0xcbac7962d483?.rowNumber ?? null);
        await _0xd68338758035(_0xee572a4568ee, _0x61d3d7357d9a, _0xa7652ac5458c);
        return { ok: false, error: _0xee572a4568ee.pauseReason };
    }
}
async function _0xd68338758035(_0x671adf24a336, _0xa0569d630ca2, _0x8f7f3b3a6b11 = {}) {
    await chrome.storage.local.set({
        [_0x21777dfa17c3.RUN_STATE]: _0x671adf24a336,
        [_0x21777dfa17c3.LOGS]: _0xa0569d630ca2,
        ..._0x8f7f3b3a6b11
    });
}
function _0x9bc79ac17b6e(_0xa07f26add1fe, _0xc6a727b86856) {
    return {
        version: 1,
        runId: _0xa07f26add1fe.runId,
        groupId: _0xc6a727b86856.id,
        groupSignature: _0xc6a727b86856.groupSignature,
        rowNumbers: _0xc6a727b86856.rowIndexes.map((_0x2c5360b248e5) => _0xa07f26add1fe.rows[_0x2c5360b248e5].rowNumber),
        temuOrderIds: _0xc6a727b86856.uniqueTemuOrderIds,
        expectedTotalQuantity: _0xc6a727b86856.expectedTotalQuantity,
        expectedItems: _0xc6a727b86856.expectedItems,
        addedRowIndexes: [],
        expectedCartCount: 0,
        stage: _0x4cbcf6dd9e80(49721),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
}
function _0xbc5b9eab3e5d(_0x90ce610cc116, _0xa7bd10b1b0cd, _0xfd2fdcecd0f9) {
    return Boolean(_0x90ce610cc116 &&
        _0x90ce610cc116.runId === _0xa7bd10b1b0cd?.runId &&
        _0x90ce610cc116.groupId === _0xfd2fdcecd0f9?.id &&
        _0x90ce610cc116.groupSignature === _0xfd2fdcecd0f9?.groupSignature);
}
async function _0x5eb404f81b46(_0xe8748bca58b3, _0x563aec597d88) {
    const _0x3521f71f7380 = await _0x603145195ada();
    const _0x3ed1b58d0462 = Array.isArray(_0x3521f71f7380[_0x21777dfa17c3.LOGS]) ? _0x3521f71f7380[_0x21777dfa17c3.LOGS] : [];
    if (_0x3521f71f7380[_0x21777dfa17c3.CART_LOCK]) {
        _0xc70b7be9a6b7(_0x3ed1b58d0462, _0x4cbcf6dd9e80(49665), _0x4cbcf6dd9e80(49720));
        await chrome.storage.local.set({ [_0x21777dfa17c3.LOGS]: _0x3ed1b58d0462 });
        return {
            ok: false,
            error: _0x4cbcf6dd9e80(49723)
        };
    }
    const _0x54956fedd47e = _0x3521f71f7380[_0x21777dfa17c3.RUN_STATE];
    if (_0x54956fedd47e && _0xf9204977f1d4.has(_0x54956fedd47e.mode)) {
        return {
            ok: false,
            error: _0x4cbcf6dd9e80(49722)
        };
    }
    if (_0x54956fedd47e?.runId) {
        await _0xe26d015b0a8e(_0x54956fedd47e.runId);
    }
    const _0xe14e07e117f4 = _0xa85f13940f9b(_0x3521f71f7380[_0x21777dfa17c3.SETTINGS]);
    const _0x33814ee151f1 = _0x563aec597d88 ?? _0xe14e07e117f4.orderIntervalSeconds;
    const _0x242cadd5835c = Number(_0x33814ee151f1);
    if (!Number.isInteger(_0x242cadd5835c) || _0x242cadd5835c < 0 || _0x242cadd5835c > 3600) {
        return { ok: false, error: _0x4cbcf6dd9e80(49717) };
    }
    const _0xad603bbde8ee = _0x242cadd5835c;
    const _0x57f97d467261 = { orderIntervalSeconds: _0xad603bbde8ee };
    const _0xb97da5d4b523 = _0xaeb8aa4ec5d7(_0x3521f71f7380[_0x21777dfa17c3.HISTORY]);
    const _0x6ea0a87b0e51 = _0x3b4de81b4f97(_0xe8748bca58b3, _0xb97da5d4b523, _0x3521f71f7380[_0x21777dfa17c3.ORDER_INDEX]);
    const { rows: _0xecceb3c66c7b, groups: _0x605e0ab3800f, orderIndex: _0x9d20c8bd02d2, fatalConflicts: _0xeecd85c990e5, knownOrderIds: _0x648394a8d4c5 } = _0x6ea0a87b0e51;
    if (_0xecceb3c66c7b.length === 0) {
        return { ok: false, error: _0x4cbcf6dd9e80(49716) };
    }
    _0xc70b7be9a6b7(_0x3ed1b58d0462, _0x4cbcf6dd9e80(49719), (_0x4cbcf6dd9e80(49718) + _0xecceb3c66c7b.length + _0x4cbcf6dd9e80(49713) + _0x605e0ab3800f.length + _0x4cbcf6dd9e80(49712)));
    _0xc70b7be9a6b7(_0x3ed1b58d0462, _0x4cbcf6dd9e80(49719), _0x4cbcf6dd9e80(49715));
    for (const _0x4e1bd4bda501 of _0x605e0ab3800f) {
        if (_0x4e1bd4bda501.phoneMismatch) {
            const _0xf56198420b5e = _0xecceb3c66c7b[_0x4e1bd4bda501.primaryRowIndex];
            _0xc70b7be9a6b7(_0x3ed1b58d0462, _0x4cbcf6dd9e80(49714), (_0x4cbcf6dd9e80(49709) + _0xf56198420b5e.phoneNumber + _0x4cbcf6dd9e80(49708)), _0xf56198420b5e.rowNumber);
        }
    }
    const _0xece7d502deb4 = _0x605e0ab3800f.filter((_0xeb7e4f9b732a) => _0xeb7e4f9b732a.result === _0x4cbcf6dd9e80(49688)).length;
    const _0xdf2f055fcf1b = _0x605e0ab3800f.filter((_0xfdb6d043d06a) => _0xfdb6d043d06a.result === _0x4cbcf6dd9e80(49688) && _0xfdb6d043d06a.isCombined).length;
    const _0xc74bb0289893 = _0xecceb3c66c7b.filter((_0x10733cb08b45) => _0x10733cb08b45.result === _0x4cbcf6dd9e80(49691)).length;
    _0xc70b7be9a6b7(_0x3ed1b58d0462, _0x4cbcf6dd9e80(49719), (_0x4cbcf6dd9e80(49711) + _0xece7d502deb4 + _0x4cbcf6dd9e80(49710) + _0xdf2f055fcf1b + _0x4cbcf6dd9e80(49705) + _0xc74bb0289893 + _0x4cbcf6dd9e80(49704)));
    if (_0xeecd85c990e5.length > 0) {
        const _0xe2133e503ef6 = _0x605e0ab3800f.findIndex((_0x91b24474fea9) => _0x91b24474fea9.result === _0x4cbcf6dd9e80(49685));
        const _0xcb8ea524fa6f = _0x605e0ab3800f[_0xe2133e503ef6] || null;
        const _0xaa579b8f7dec = {
            version: _0x943a7b8eb231,
            runId: crypto.randomUUID(),
            mode: _0x4cbcf6dd9e80(49624),
            phase: _0x4cbcf6dd9e80(49707),
            pauseReason: _0xeecd85c990e5[0],
            currentGroupIndex: _0xe2133e503ef6 >= 0 ? _0xe2133e503ef6 : null,
            currentIndex: _0xcb8ea524fa6f?.primaryRowIndex ?? null,
            rows: _0xecceb3c66c7b,
            groups: _0x605e0ab3800f,
            workTabId: null,
            orderIntervalSeconds: _0xad603bbde8ee,
            intervalEndsAt: null,
            intervalRemainingSeconds: 0,
            knownOrderIds: _0x648394a8d4c5,
            todayDateKey: _0xac1031e3efac(),
            startedAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        _0xeecd85c990e5.forEach((_0x849765436fd9) => _0xc70b7be9a6b7(_0x3ed1b58d0462, _0x4cbcf6dd9e80(49665), _0x849765436fd9));
        await _0xd68338758035(_0xaa579b8f7dec, _0x3ed1b58d0462, {
            [_0x21777dfa17c3.DRAFT_ROWS]: Array.isArray(_0xe8748bca58b3) ? _0xe8748bca58b3 : [],
            [_0x21777dfa17c3.HISTORY]: _0xb97da5d4b523,
            [_0x21777dfa17c3.ORDER_INDEX]: _0x9d20c8bd02d2
        });
        return { ok: true, state: _0xaa579b8f7dec, paused: true, started: false };
    }
    const _0xdcd52f3d5f64 = _0x589ffb3858ed(_0x605e0ab3800f);
    if (_0xdcd52f3d5f64 === -1) {
        const _0x3784b864b185 = {
            version: _0x943a7b8eb231,
            runId: crypto.randomUUID(),
            mode: _0x4cbcf6dd9e80(49706),
            phase: _0x4cbcf6dd9e80(49701),
            pauseReason: _0x4cbcf6dd9e80(49664),
            currentGroupIndex: null,
            currentIndex: null,
            rows: _0xecceb3c66c7b,
            groups: _0x605e0ab3800f,
            workTabId: null,
            orderIntervalSeconds: _0xad603bbde8ee,
            intervalEndsAt: null,
            intervalRemainingSeconds: 0,
            knownOrderIds: _0x648394a8d4c5,
            todayDateKey: _0xac1031e3efac(),
            startedAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        _0xc70b7be9a6b7(_0x3ed1b58d0462, _0x4cbcf6dd9e80(49686), _0x4cbcf6dd9e80(49700));
        await _0xd68338758035(_0x3784b864b185, _0x3ed1b58d0462, {
            [_0x21777dfa17c3.DRAFT_ROWS]: Array.isArray(_0xe8748bca58b3) ? _0xe8748bca58b3 : [],
            [_0x21777dfa17c3.HISTORY]: _0xb97da5d4b523,
            [_0x21777dfa17c3.ORDER_INDEX]: _0x9d20c8bd02d2
        });
        return { ok: true, state: _0x3784b864b185, started: false };
    }
    const _0x9c2d262025ce = Number.isInteger(_0x54956fedd47e?.workTabId) ? _0x54956fedd47e.workTabId : null;
    let _0x914422feb666;
    try {
        _0x914422feb666 = await _0x3a18869c73a9(_0x9c2d262025ce);
    }
    catch (_0x3e32db61ce87) {
        return { ok: false, error: _0x3e32db61ce87.message || String(_0x3e32db61ce87) };
    }
    const _0x204321edcbaa = {
        version: _0x943a7b8eb231,
        runId: crypto.randomUUID(),
        mode: _0x4cbcf6dd9e80(49627),
        phase: _0x4cbcf6dd9e80(49703),
        pauseReason: _0x4cbcf6dd9e80(49664),
        currentGroupIndex: _0xdcd52f3d5f64,
        currentIndex: _0x605e0ab3800f[_0xdcd52f3d5f64].primaryRowIndex,
        rows: _0xecceb3c66c7b,
        groups: _0x605e0ab3800f,
        workTabId: _0x914422feb666,
        orderIntervalSeconds: _0xad603bbde8ee,
        intervalEndsAt: null,
        intervalRemainingSeconds: 0,
        knownOrderIds: _0x648394a8d4c5,
        todayDateKey: _0xac1031e3efac(),
        startedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    _0xc70b7be9a6b7(_0x3ed1b58d0462, _0x4cbcf6dd9e80(49719), _0x4cbcf6dd9e80(49702));
    _0xc70b7be9a6b7(_0x3ed1b58d0462, _0x4cbcf6dd9e80(49719), _0x4cbcf6dd9e80(49505));
    _0xc70b7be9a6b7(_0x3ed1b58d0462, _0x4cbcf6dd9e80(49719), _0x4cbcf6dd9e80(49504));
    _0xc70b7be9a6b7(_0x3ed1b58d0462, _0x4cbcf6dd9e80(49719), (_0x4cbcf6dd9e80(49507) + _0xad603bbde8ee + _0x4cbcf6dd9e80(49506)));
    await _0xd68338758035(_0x204321edcbaa, _0x3ed1b58d0462, {
        [_0x21777dfa17c3.DRAFT_ROWS]: Array.isArray(_0xe8748bca58b3) ? _0xe8748bca58b3 : [],
        [_0x21777dfa17c3.HISTORY]: _0xb97da5d4b523,
        [_0x21777dfa17c3.ORDER_INDEX]: _0x9d20c8bd02d2
    });
    const _0x8382ea1e06e9 = await _0x484b55d57ccd(_0x204321edcbaa, _0x3ed1b58d0462, false);
    const _0x4c78db41b50a = !_0x8382ea1e06e9?.error && !_0x8382ea1e06e9?.authorizationFailed;
    if (_0x4c78db41b50a) {
        await chrome.storage.local.set({ [_0x21777dfa17c3.SETTINGS]: _0x57f97d467261 });
    }
    return {
        ok: true,
        state: _0x204321edcbaa,
        started: _0x4c78db41b50a,
        paused: Boolean(_0x8382ea1e06e9?.error || _0x8382ea1e06e9?.authorizationFailed),
        settings: _0x4c78db41b50a ? _0x57f97d467261 : _0xe14e07e117f4
    };
}
async function _0x6ac461b238b8(_0x00639eed047e, _0xd249661a2fc1) {
    const _0x3344dcf4b39b = await _0x603145195ada();
    const _0xcd662a2f0c5a = Array.isArray(_0x3344dcf4b39b[_0x21777dfa17c3.LOGS]) ? _0x3344dcf4b39b[_0x21777dfa17c3.LOGS] : [];
    const _0xe1d806ccc13f = _0x3344dcf4b39b[_0x21777dfa17c3.RUN_STATE];
    if (_0x3344dcf4b39b[_0x21777dfa17c3.CART_LOCK]) {
        _0xc70b7be9a6b7(_0xcd662a2f0c5a, _0x4cbcf6dd9e80(49665), _0x4cbcf6dd9e80(49501));
        await chrome.storage.local.set({ [_0x21777dfa17c3.LOGS]: _0xcd662a2f0c5a });
        return { ok: false, error: _0x4cbcf6dd9e80(49500) };
    }
    if (!_0xe1d806ccc13f || ![_0x4cbcf6dd9e80(49706), _0x4cbcf6dd9e80(49503)].includes(_0xe1d806ccc13f.mode)) {
        return { ok: false, error: _0x4cbcf6dd9e80(49502) };
    }
    if (_0xe1d806ccc13f.runId) {
        await _0xe26d015b0a8e(_0xe1d806ccc13f.runId);
    }
    const _0xfe13394fbe68 = _0xa85f13940f9b(_0x3344dcf4b39b[_0x21777dfa17c3.SETTINGS]);
    const _0xc8dc79bfba9c = _0xd249661a2fc1 ?? _0xfe13394fbe68.orderIntervalSeconds;
    const _0xbb498ff4dc5e = Number(_0xc8dc79bfba9c);
    if (!Number.isInteger(_0xbb498ff4dc5e) || _0xbb498ff4dc5e < 0 || _0xbb498ff4dc5e > 3600) {
        return { ok: false, error: _0x4cbcf6dd9e80(49717) };
    }
    const _0xe949e214746a = _0xbb498ff4dc5e;
    const _0xd0b804cfd410 = { orderIntervalSeconds: _0xe949e214746a };
    const _0x080414c4d906 = _0xaeb8aa4ec5d7(_0x3344dcf4b39b[_0x21777dfa17c3.HISTORY]);
    const _0xa6ebeae5ad53 = _0x21bf3b4f1c01(_0x00639eed047e, _0xe1d806ccc13f.rows, _0x080414c4d906, _0x3344dcf4b39b[_0x21777dfa17c3.ORDER_INDEX]);
    if (_0xa6ebeae5ad53.error) {
        _0xc70b7be9a6b7(_0xcd662a2f0c5a, _0x4cbcf6dd9e80(49665), _0xa6ebeae5ad53.error);
        await chrome.storage.local.set({ [_0x21777dfa17c3.LOGS]: _0xcd662a2f0c5a });
        return { ok: false, error: _0xa6ebeae5ad53.error };
    }
    const { rows: _0x7cc1215845ab, groups: _0x27f80ad0f2e1, orderIndex: _0x2d792b2b0b95, fatalConflicts: _0x624fca17faa1, knownOrderIds: _0xcaede6fab061, retryCount: _0x1e707ecb248b } = _0xa6ebeae5ad53;
    _0xc70b7be9a6b7(_0xcd662a2f0c5a, _0x4cbcf6dd9e80(49714), (_0x4cbcf6dd9e80(49497) + _0x1e707ecb248b + _0x4cbcf6dd9e80(49496)));
    _0xc70b7be9a6b7(_0xcd662a2f0c5a, _0x4cbcf6dd9e80(49714), _0x4cbcf6dd9e80(49499));
    _0xc70b7be9a6b7(_0xcd662a2f0c5a, _0x4cbcf6dd9e80(49719), _0x4cbcf6dd9e80(49498));
    for (const _0x98b746457f84 of _0x27f80ad0f2e1) {
        if (_0x98b746457f84.phoneMismatch) {
            const _0x49c6d28be168 = _0x7cc1215845ab[_0x98b746457f84.primaryRowIndex];
            _0xc70b7be9a6b7(_0xcd662a2f0c5a, _0x4cbcf6dd9e80(49714), (_0x4cbcf6dd9e80(49493) + _0x49c6d28be168.phoneNumber + _0x4cbcf6dd9e80(49708)), _0x49c6d28be168.rowNumber);
        }
    }
    const _0x931db2c08df1 = _0x27f80ad0f2e1.filter((_0xb6c3b318d4ba) => _0xb6c3b318d4ba.result === _0x4cbcf6dd9e80(49688)).length;
    const _0xfd8c8d91ebed = _0x27f80ad0f2e1.filter((_0x8224229cc883) => _0x8224229cc883.result === _0x4cbcf6dd9e80(49688) && _0x8224229cc883.isCombined).length;
    const _0xff4e22125a83 = _0x7cc1215845ab.filter((_0x4f020804ce53) => _0x4f020804ce53.result === _0x4cbcf6dd9e80(49691)).length;
    _0xc70b7be9a6b7(_0xcd662a2f0c5a, _0x4cbcf6dd9e80(49719), (_0x4cbcf6dd9e80(49492) + _0x931db2c08df1 + _0x4cbcf6dd9e80(49710) + _0xfd8c8d91ebed + _0x4cbcf6dd9e80(49495) + _0xff4e22125a83 + _0x4cbcf6dd9e80(49704)));
    const _0xd75450b6f515 = {
        version: _0x943a7b8eb231,
        runId: crypto.randomUUID(),
        retryMode: _0x4cbcf6dd9e80(49494),
        bypassTodayOrderCheck: true,
        rows: _0x7cc1215845ab,
        groups: _0x27f80ad0f2e1,
        orderIntervalSeconds: _0xe949e214746a,
        intervalEndsAt: null,
        intervalRemainingSeconds: 0,
        knownOrderIds: _0xcaede6fab061,
        todayDateKey: _0xac1031e3efac(),
        startedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    if (_0x624fca17faa1.length > 0) {
        const _0x0bfd87f2db70 = _0x27f80ad0f2e1.findIndex((_0xffa849aa2533) => _0xffa849aa2533.result === _0x4cbcf6dd9e80(49685));
        const _0x5f0e4d7b428d = _0x27f80ad0f2e1[_0x0bfd87f2db70] || null;
        const _0x2a73bf19ef86 = {
            ..._0xd75450b6f515,
            mode: _0x4cbcf6dd9e80(49624),
            phase: _0x4cbcf6dd9e80(49707),
            pauseReason: _0x624fca17faa1[0],
            currentGroupIndex: _0x0bfd87f2db70 >= 0 ? _0x0bfd87f2db70 : null,
            currentIndex: _0x5f0e4d7b428d?.primaryRowIndex ?? null,
            workTabId: null
        };
        _0x624fca17faa1.forEach((_0xe1ee252d8c39) => _0xc70b7be9a6b7(_0xcd662a2f0c5a, _0x4cbcf6dd9e80(49665), _0xe1ee252d8c39));
        await _0xd68338758035(_0x2a73bf19ef86, _0xcd662a2f0c5a, {
            [_0x21777dfa17c3.DRAFT_ROWS]: Array.isArray(_0x00639eed047e) ? _0x00639eed047e : [],
            [_0x21777dfa17c3.HISTORY]: _0x080414c4d906,
            [_0x21777dfa17c3.ORDER_INDEX]: _0x2d792b2b0b95
        });
        return { ok: true, state: _0x2a73bf19ef86, paused: true, retryCount: _0x1e707ecb248b, started: false };
    }
    const _0xbdeee97c78ea = _0x589ffb3858ed(_0x27f80ad0f2e1);
    if (_0xbdeee97c78ea === -1) {
        const _0xc085c9404c13 = {
            ..._0xd75450b6f515,
            mode: _0x4cbcf6dd9e80(49706),
            phase: _0x4cbcf6dd9e80(49701),
            pauseReason: _0x4cbcf6dd9e80(49664),
            currentGroupIndex: null,
            currentIndex: null,
            workTabId: null
        };
        _0xc70b7be9a6b7(_0xcd662a2f0c5a, _0x4cbcf6dd9e80(49686), _0x4cbcf6dd9e80(49489));
        await _0xd68338758035(_0xc085c9404c13, _0xcd662a2f0c5a, {
            [_0x21777dfa17c3.DRAFT_ROWS]: Array.isArray(_0x00639eed047e) ? _0x00639eed047e : [],
            [_0x21777dfa17c3.HISTORY]: _0x080414c4d906,
            [_0x21777dfa17c3.ORDER_INDEX]: _0x2d792b2b0b95
        });
        return { ok: true, state: _0xc085c9404c13, retryCount: _0x1e707ecb248b, started: false };
    }
    let _0xbbcb306a6505;
    try {
        _0xbbcb306a6505 = await _0x3a18869c73a9(Number.isInteger(_0xe1d806ccc13f.workTabId) ? _0xe1d806ccc13f.workTabId : null);
    }
    catch (_0x42e0bbf1e648) {
        return { ok: false, error: _0x42e0bbf1e648.message || String(_0x42e0bbf1e648) };
    }
    const _0x6672ba151730 = {
        ..._0xd75450b6f515,
        mode: _0x4cbcf6dd9e80(49627),
        phase: _0x4cbcf6dd9e80(49703),
        pauseReason: _0x4cbcf6dd9e80(49664),
        currentGroupIndex: _0xbdeee97c78ea,
        currentIndex: _0x27f80ad0f2e1[_0xbdeee97c78ea].primaryRowIndex,
        workTabId: _0xbbcb306a6505
    };
    _0xc70b7be9a6b7(_0xcd662a2f0c5a, _0x4cbcf6dd9e80(49719), _0x4cbcf6dd9e80(49488));
    _0xc70b7be9a6b7(_0xcd662a2f0c5a, _0x4cbcf6dd9e80(49719), (_0x4cbcf6dd9e80(49491) + _0xe949e214746a + _0x4cbcf6dd9e80(49490)));
    await _0xd68338758035(_0x6672ba151730, _0xcd662a2f0c5a, {
        [_0x21777dfa17c3.DRAFT_ROWS]: Array.isArray(_0x00639eed047e) ? _0x00639eed047e : [],
        [_0x21777dfa17c3.HISTORY]: _0x080414c4d906,
        [_0x21777dfa17c3.ORDER_INDEX]: _0x2d792b2b0b95
    });
    const _0xb7ea4d67369c = await _0x484b55d57ccd(_0x6672ba151730, _0xcd662a2f0c5a, false);
    const _0x1d4d4ce62eeb = !_0xb7ea4d67369c?.error && !_0xb7ea4d67369c?.authorizationFailed;
    if (_0x1d4d4ce62eeb) {
        await chrome.storage.local.set({ [_0x21777dfa17c3.SETTINGS]: _0xd0b804cfd410 });
    }
    return {
        ok: true,
        state: _0x6672ba151730,
        retryCount: _0x1e707ecb248b,
        started: _0x1d4d4ce62eeb,
        paused: Boolean(_0xb7ea4d67369c?.error || _0xb7ea4d67369c?.authorizationFailed),
        settings: _0x1d4d4ce62eeb ? _0xd0b804cfd410 : _0xfe13394fbe68
    };
}
async function _0x8e5ee9af3e0f(_0x96e5c368ff92, _0x0156e49f6568) {
    const _0x5ba513b4c3ae = await _0x603145195ada();
    const _0x650509c54384 = _0x5ba513b4c3ae[_0x21777dfa17c3.RUN_STATE];
    const _0x67e4f432d53b = Array.isArray(_0x5ba513b4c3ae[_0x21777dfa17c3.LOGS]) ? _0x5ba513b4c3ae[_0x21777dfa17c3.LOGS] : [];
    if (!_0x650509c54384 || _0x0156e49f6568.tab?.id !== _0x650509c54384.workTabId) {
        return { ok: false, error: _0x4cbcf6dd9e80(49485) };
    }
    if (_0x650509c54384.runId !== _0x96e5c368ff92.runId) {
        return { ok: false, error: _0x4cbcf6dd9e80(49484) };
    }
    if (_0x96e5c368ff92.expectedPhase && _0x650509c54384.phase !== _0x96e5c368ff92.expectedPhase) {
        return { ok: false, stale: true, error: (_0x4cbcf6dd9e80(49487) + _0x650509c54384.phase + _0x4cbcf6dd9e80(49708)) };
    }
    if (_0x650509c54384.mode !== _0x4cbcf6dd9e80(49625)) {
        return { ok: false, paused: true, error: _0x4cbcf6dd9e80(49486) };
    }
    const _0x6ada11f03464 = _0xa933c8eed5e2(_0x650509c54384);
    const _0xf948312c12d4 = _0xc77f4848e0bd(_0x650509c54384);
    _0x650509c54384.phase = _0x96e5c368ff92.nextPhase;
    _0x650509c54384.updatedAt = new Date().toISOString();
    if (_0x6ada11f03464 && Number.isFinite(Number(_0x96e5c368ff92.observedUnitPrice))) {
        _0x6ada11f03464.observedUnitPrice = Number(_0x96e5c368ff92.observedUnitPrice).toFixed(2);
    }
    if (_0x6ada11f03464 && Number.isSafeInteger(Number(_0x96e5c368ff92.selectedQuantity)) && Number(_0x96e5c368ff92.selectedQuantity) > 0) {
        _0x6ada11f03464.selectedQuantity = Number(_0x96e5c368ff92.selectedQuantity);
    }
    if (_0xf948312c12d4 && _0x96e5c368ff92.observedDeliveryAddress) {
        _0xf948312c12d4.actualDeliveryAddress = _0xca73cf69c048(_0x96e5c368ff92.observedDeliveryAddress);
    }
    if (typeof _0x96e5c368ff92.paymentMethodAttempted === _0x4cbcf6dd9e80(49481)) {
        _0x650509c54384.paymentMethodAttempted = _0x96e5c368ff92.paymentMethodAttempted;
    }
    if (_0x96e5c368ff92.status) {
        if (_0xf948312c12d4?.isCombined && _0xc047e286bef0.has(_0x96e5c368ff92.nextPhase)) {
            _0xe1f605a7091c(_0x650509c54384.rows, _0xf948312c12d4, _0x96e5c368ff92.status);
        }
        else if (_0x6ada11f03464) {
            _0x43b6a7957fcd(_0x6ada11f03464, _0x96e5c368ff92.status, _0x4cbcf6dd9e80(49687));
        }
    }
    if (_0x96e5c368ff92.logMessage) {
        _0xc70b7be9a6b7(_0x67e4f432d53b, _0x96e5c368ff92.level || _0x4cbcf6dd9e80(49719), _0x96e5c368ff92.logMessage, _0x6ada11f03464?.rowNumber ?? null);
    }
    await _0xd68338758035(_0x650509c54384, _0x67e4f432d53b);
    return { ok: true, state: _0x650509c54384 };
}
async function _0xbc8db8cd7917(_0x5bc84cf21892, _0x22fef0bf61c4) {
    const _0x11042a531d8e = await chrome.storage.local.get(_0x21777dfa17c3.RUN_STATE);
    const _0x564cfb5cedc4 = _0x11042a531d8e[_0x21777dfa17c3.RUN_STATE] || null;
    const _0x5126eb4f05a6 = Boolean(_0x564cfb5cedc4 &&
        _0x22fef0bf61c4.tab?.id === _0x564cfb5cedc4.workTabId &&
        _0x564cfb5cedc4.runId === _0x5bc84cf21892.runId &&
        _0xa963c5cdea9b.has(_0x564cfb5cedc4.phase) &&
        _0xa963c5cdea9b.has(_0x5bc84cf21892.nextPhase));
    if (!_0x5126eb4f05a6) {
        const _0xecda1b1d5884 = await _0xf768835a0775(false);
        if (!_0xecda1b1d5884.ok) {
            return _0xecda1b1d5884;
        }
    }
    return _0x8e5ee9af3e0f(_0x5bc84cf21892, _0x22fef0bf61c4);
}
async function _0x151fc24d4794(_0x04944eae2578, _0xb463ea2eedef) {
    const _0xc74af91b9553 = await _0x603145195ada();
    const _0x9217402a3855 = _0xc74af91b9553[_0x21777dfa17c3.RUN_STATE];
    const _0xe4ca235db49b = Array.isArray(_0xc74af91b9553[_0x21777dfa17c3.LOGS]) ? _0xc74af91b9553[_0x21777dfa17c3.LOGS] : [];
    if (!_0x9217402a3855 || _0xb463ea2eedef.tab?.id !== _0x9217402a3855.workTabId || _0x9217402a3855.runId !== _0x04944eae2578.runId) {
        return { ok: false, stale: true };
    }
    if (_0x04944eae2578.expectedPhase && _0x9217402a3855.phase !== _0x04944eae2578.expectedPhase) {
        return { ok: false, stale: true };
    }
    const _0x9b000a8ad071 = _0xa933c8eed5e2(_0x9217402a3855);
    const _0x2fb55864138a = _0xc77f4848e0bd(_0x9217402a3855);
    _0x9217402a3855.mode = _0x4cbcf6dd9e80(49624);
    _0x9217402a3855.pauseReason = _0x04944eae2578.reason || _0x4cbcf6dd9e80(49480);
    _0x9217402a3855.updatedAt = new Date().toISOString();
    if (_0x2fb55864138a?.isCombined) {
        _0x7bffd74ea3dc(_0x9217402a3855.rows, _0x2fb55864138a, _0x9217402a3855.pauseReason);
    }
    else if (_0x9b000a8ad071) {
        _0x43b6a7957fcd(_0x9b000a8ad071, (_0x4cbcf6dd9e80(49684) + _0x9217402a3855.pauseReason + _0x4cbcf6dd9e80(49664)), _0x4cbcf6dd9e80(49685));
    }
    _0xc70b7be9a6b7(_0xe4ca235db49b, _0x4cbcf6dd9e80(49665), _0x9217402a3855.pauseReason, _0x9b000a8ad071?.rowNumber ?? null);
    await _0xd68338758035(_0x9217402a3855, _0xe4ca235db49b);
    return { ok: true, state: _0x9217402a3855 };
}
async function _0x4d92dceed7ed(_0x3c2b0df3ef3d, _0x3c7a19069406) {
    const _0x1d9024743acb = await _0x603145195ada();
    const _0xcb26c167724f = _0x1d9024743acb[_0x21777dfa17c3.RUN_STATE];
    const _0x0fbce72ff870 = Array.isArray(_0x1d9024743acb[_0x21777dfa17c3.LOGS]) ? _0x1d9024743acb[_0x21777dfa17c3.LOGS] : [];
    const _0x9e3ded955264 = _0xaeb8aa4ec5d7(_0x1d9024743acb[_0x21777dfa17c3.HISTORY]);
    const _0xdc78ba61adab = _0xf0ccabd2d36d(_0x1d9024743acb[_0x21777dfa17c3.ORDER_INDEX], _0x9e3ded955264);
    let _0x7ab8cea70eef = _0x1d9024743acb[_0x21777dfa17c3.CART_LOCK] || null;
    if (!_0xcb26c167724f || _0x3c7a19069406.tab?.id !== _0xcb26c167724f.workTabId || _0xcb26c167724f.runId !== _0x3c2b0df3ef3d.runId) {
        return { ok: false, stale: true, error: _0x4cbcf6dd9e80(49483) };
    }
    if (_0xcb26c167724f.mode !== _0x4cbcf6dd9e80(49625) || _0xcb26c167724f.phase !== _0x4cbcf6dd9e80(49608)) {
        return { ok: false, stale: true, error: (_0x4cbcf6dd9e80(49482) + _0xcb26c167724f.phase + _0x4cbcf6dd9e80(49664)) };
    }
    const _0xd87d173529ea = _0xc77f4848e0bd(_0xcb26c167724f);
    const _0x59fa469a3408 = _0xe7759fd6c561(_0xcb26c167724f);
    if (!_0xd87d173529ea || !_0x59fa469a3408) {
        return { ok: false, error: _0x4cbcf6dd9e80(49477) };
    }
    const _0x93d23ff651be = _0xca73cf69c048(_0x3c2b0df3ef3d.observedRecipientName);
    if (!_0x93d23ff651be || _0x6212b0dfb520(_0x93d23ff651be) !== _0x6212b0dfb520(_0xd87d173529ea.normalizedName)) {
        return { ok: false, error: _0x4cbcf6dd9e80(49476) };
    }
    if (_0xd87d173529ea.isCombined) {
        if (!_0xd87d173529ea.rowIndexes.every((_0x04ce178101f4) => _0xcb26c167724f.rows[_0x04ce178101f4].precheckPassed && _0xcb26c167724f.rows[_0x04ce178101f4].addedToCart)) {
            return { ok: false, error: _0x4cbcf6dd9e80(49479) };
        }
        if (!_0xbc5b9eab3e5d(_0x7ab8cea70eef, _0xcb26c167724f, _0xd87d173529ea)) {
            return { ok: false, error: _0x4cbcf6dd9e80(49478) };
        }
    }
    else {
        const _0xbaf631f1e5cd = Number(_0x59fa469a3408.observedUnitPrice);
        if (!Number.isFinite(_0xbaf631f1e5cd) || Math.abs(_0xbaf631f1e5cd - 2) > 0.0001) {
            return { ok: false, error: _0x4cbcf6dd9e80(49537) };
        }
        const _0x930112009968 = Number(_0x59fa469a3408.selectedQuantity);
        if (!Number.isSafeInteger(_0x930112009968) ||
            _0x930112009968 <= 0 ||
            _0x930112009968 !== _0x59fa469a3408.requestedQuantity) {
            return { ok: false, error: _0x4cbcf6dd9e80(49536) };
        }
    }
    if (!_0xcb26c167724f.bypassTodayOrderCheck) {
        const _0xcd362c3e1e8c = _0xac1031e3efac();
        for (const _0xc114d0ea3a3e of _0xd87d173529ea.uniqueTemuOrderIds) {
            const _0xfd5e3bdb7e8d = _0xdc78ba61adab[_0x512d143486d6(_0xc114d0ea3a3e)];
            if (_0xfd5e3bdb7e8d?.status === _0x4cbcf6dd9e80(49639) &&
                _0xfd5e3bdb7e8d.dateKey === _0xcd362c3e1e8c &&
                _0xde4244574fd5(_0xfd5e3bdb7e8d.orderId)) {
                _0xcb26c167724f.mode = _0x4cbcf6dd9e80(49624);
                _0xcb26c167724f.pauseReason = (_0x4cbcf6dd9e80(49539) + _0xc114d0ea3a3e + _0x4cbcf6dd9e80(49538));
                if (_0xd87d173529ea.isCombined) {
                    _0x7bffd74ea3dc(_0xcb26c167724f.rows, _0xd87d173529ea, _0xcb26c167724f.pauseReason);
                }
                else {
                    _0x43b6a7957fcd(_0x59fa469a3408, (_0x4cbcf6dd9e80(49684) + _0xcb26c167724f.pauseReason + _0x4cbcf6dd9e80(49664)), _0x4cbcf6dd9e80(49685));
                }
                _0xc70b7be9a6b7(_0x0fbce72ff870, _0x4cbcf6dd9e80(49665), _0xcb26c167724f.pauseReason, _0x59fa469a3408.rowNumber);
                await _0xd68338758035(_0xcb26c167724f, _0x0fbce72ff870, {
                    [_0x21777dfa17c3.HISTORY]: _0x9e3ded955264,
                    [_0x21777dfa17c3.ORDER_INDEX]: _0xdc78ba61adab
                });
                return { ok: false, error: _0xcb26c167724f.pauseReason };
            }
        }
    }
    _0xd87d173529ea.actualDeliveryAddress = _0xca73cf69c048(_0x3c2b0df3ef3d.observedDeliveryAddress || _0xd87d173529ea.actualDeliveryAddress);
    if (_0xd87d173529ea.isCombined) {
        _0xe1f605a7091c(_0xcb26c167724f.rows, _0xd87d173529ea, _0x4cbcf6dd9e80(49533));
        _0x7ab8cea70eef = {
            ..._0x7ab8cea70eef,
            stage: _0x4cbcf6dd9e80(49532),
            actualDeliveryAddress: _0xd87d173529ea.actualDeliveryAddress,
            updatedAt: new Date().toISOString()
        };
    }
    else {
        _0x43b6a7957fcd(_0x59fa469a3408, _0x4cbcf6dd9e80(49535), _0x4cbcf6dd9e80(49687));
    }
    _0xcb26c167724f.phase = _0x4cbcf6dd9e80(49626);
    _0xcb26c167724f.updatedAt = new Date().toISOString();
    _0xc70b7be9a6b7(_0x0fbce72ff870, _0x4cbcf6dd9e80(49714), _0xd87d173529ea.isCombined
        ? (_0x4cbcf6dd9e80(49534) + _0xd87d173529ea.rowIndexes.length + _0x4cbcf6dd9e80(49529) + _0xd87d173529ea.expectedTotalQuantity + _0x4cbcf6dd9e80(49528)) : (_0x4cbcf6dd9e80(49531) + _0x59fa469a3408.requestedQuantity + _0x4cbcf6dd9e80(49530)), _0x59fa469a3408.rowNumber);
    const _0x636bf371bdbe = {
        [_0x21777dfa17c3.HISTORY]: _0x9e3ded955264,
        [_0x21777dfa17c3.ORDER_INDEX]: _0xdc78ba61adab
    };
    if (_0xd87d173529ea.isCombined) {
        _0x636bf371bdbe[_0x21777dfa17c3.CART_LOCK] = _0x7ab8cea70eef;
    }
    await _0xd68338758035(_0xcb26c167724f, _0x0fbce72ff870, _0x636bf371bdbe);
    return { ok: true, state: _0xcb26c167724f };
}
async function _0x484b55d57ccd(_0x8f7bb71bca8d, _0x65ca25220ca0, _0x9c8bcfd64b5e = true) {
    const _0xb820596bd2a1 = await _0x8b2dc19450f4(false);
    if (!_0xb820596bd2a1.authorized) {
        _0xf773357aaa5b(_0x8f7bb71bca8d, _0x65ca25220ca0);
        await _0xd68338758035(_0x8f7bb71bca8d, _0x65ca25220ca0);
        return { completed: false, authorizationFailed: true, error: _0x9b5f5787445e.failureMessage };
    }
    const _0x5c1cdae92f72 = _0xc77f4848e0bd(_0x8f7bb71bca8d);
    if (!_0x5c1cdae92f72) {
        return { completed: false, error: _0x4cbcf6dd9e80(49525) };
    }
    _0x5c1cdae92f72.precheckCursor = 0;
    _0x5c1cdae92f72.addCursor = 0;
    _0x5c1cdae92f72.expectedCartCount = 0;
    _0x5c1cdae92f72.actualDeliveryAddress = _0x4cbcf6dd9e80(49664);
    _0x5c1cdae92f72.orderId = _0x4cbcf6dd9e80(49664);
    _0x5c1cdae92f72.result = _0x4cbcf6dd9e80(49687);
    _0x5c1cdae92f72.updatedAt = new Date().toISOString();
    for (const _0x568a36161957 of _0x5c1cdae92f72.rowIndexes) {
        const _0x3579ec9e15af = _0x8f7bb71bca8d.rows[_0x568a36161957];
        _0x3579ec9e15af.precheckPassed = false;
        _0x3579ec9e15af.addedToCart = false;
        _0x3579ec9e15af.observedUnitPrice = _0x4cbcf6dd9e80(49664);
        _0x3579ec9e15af.selectedQuantity = _0x4cbcf6dd9e80(49664);
        _0x3579ec9e15af.orderId = _0x4cbcf6dd9e80(49664);
    }
    const _0x90dbac844c20 = _0x5c1cdae92f72.rowIndexes[0];
    const _0xb3722391170f = _0x8f7bb71bca8d.rows[_0x90dbac844c20];
    _0x8f7bb71bca8d.currentIndex = _0x90dbac844c20;
    _0x8f7bb71bca8d.mode = _0x4cbcf6dd9e80(49625);
    _0x8f7bb71bca8d.phase = _0x5c1cdae92f72.isCombined ? _0x4cbcf6dd9e80(49524) : _0x4cbcf6dd9e80(49527);
    _0x8f7bb71bca8d.pauseReason = _0x4cbcf6dd9e80(49664);
    _0x8f7bb71bca8d.intervalEndsAt = null;
    _0x8f7bb71bca8d.intervalRemainingSeconds = 0;
    _0x8f7bb71bca8d.paymentMethodAttempted = false;
    _0x8f7bb71bca8d.updatedAt = new Date().toISOString();
    if (_0x5c1cdae92f72.isCombined) {
        _0xe1f605a7091c(_0x8f7bb71bca8d.rows, _0x5c1cdae92f72, _0x4cbcf6dd9e80(49526));
        _0xc70b7be9a6b7(_0x65ca25220ca0, _0x4cbcf6dd9e80(49719), (_0x4cbcf6dd9e80(49521) + _0x5c1cdae92f72.rowIndexes.length + _0x4cbcf6dd9e80(49520) + _0x5c1cdae92f72.uniqueTemuOrderIds.length + _0x4cbcf6dd9e80(49523) + _0x5c1cdae92f72.expectedTotalQuantity + _0x4cbcf6dd9e80(49708)), _0xb3722391170f.rowNumber);
    }
    else {
        _0x43b6a7957fcd(_0xb3722391170f, _0x4cbcf6dd9e80(49522), _0x4cbcf6dd9e80(49687));
        _0xc70b7be9a6b7(_0x65ca25220ca0, _0x4cbcf6dd9e80(49719), (_0x4cbcf6dd9e80(49517) + _0xb3722391170f.rowNumber + _0x4cbcf6dd9e80(49516) + _0xb3722391170f.temuOrderId + _0x4cbcf6dd9e80(49519) + _0xb3722391170f.asin + _0x4cbcf6dd9e80(49518) + _0xb3722391170f.requestedQuantity + _0x4cbcf6dd9e80(49708)), _0xb3722391170f.rowNumber);
    }
    if (_0x9c8bcfd64b5e) {
        _0xc70b7be9a6b7(_0x65ca25220ca0, _0x4cbcf6dd9e80(49719), _0x4cbcf6dd9e80(49513), _0xb3722391170f.rowNumber);
        const _0xf16de4b5f297 = await _0xe10b90fbf183(_0x8f7bb71bca8d, _0x65ca25220ca0, _0xb3722391170f.amzLink, {}, _0x4cbcf6dd9e80(49512));
        return _0xf16de4b5f297.ok
            ? { completed: false }
            : { completed: false, error: _0xf16de4b5f297.error || _0x4cbcf6dd9e80(49515) };
    }
    try {
        let _0xe83a365770e0 = false;
        if (Number.isInteger(_0x8f7bb71bca8d.workTabId)) {
            try {
                await chrome.tabs.get(_0x8f7bb71bca8d.workTabId);
                _0xe83a365770e0 = true;
            }
            catch {
                _0xe83a365770e0 = false;
            }
        }
        if (!_0xe83a365770e0) {
            _0x8f7bb71bca8d.workTabId = await _0x3a18869c73a9(null);
        }
        await _0xd68338758035(_0x8f7bb71bca8d, _0x65ca25220ca0);
        await _0x41e77a857846(_0x8f7bb71bca8d.workTabId, _0xb3722391170f.amzLink);
        return { completed: false };
    }
    catch (_0xeb57a893d6fd) {
        _0x8f7bb71bca8d.mode = _0x4cbcf6dd9e80(49624);
        _0x8f7bb71bca8d.pauseReason = (_0x4cbcf6dd9e80(49514) + (_0xeb57a893d6fd.message || String(_0xeb57a893d6fd)) + _0x4cbcf6dd9e80(49664));
        if (_0x5c1cdae92f72.isCombined) {
            _0x7bffd74ea3dc(_0x8f7bb71bca8d.rows, _0x5c1cdae92f72, _0x8f7bb71bca8d.pauseReason);
        }
        else {
            _0x43b6a7957fcd(_0xb3722391170f, (_0x4cbcf6dd9e80(49684) + _0x8f7bb71bca8d.pauseReason + _0x4cbcf6dd9e80(49664)), _0x4cbcf6dd9e80(49685));
        }
        _0xc70b7be9a6b7(_0x65ca25220ca0, _0x4cbcf6dd9e80(49665), _0x8f7bb71bca8d.pauseReason, _0xb3722391170f.rowNumber);
        await _0xd68338758035(_0x8f7bb71bca8d, _0x65ca25220ca0);
        return { completed: false, error: _0x8f7bb71bca8d.pauseReason };
    }
}
async function _0x692a17365254(_0xe891f6971e2c, _0x6f0b5237acfb, _0xcd103207a146, _0x48fd4fc8c183 = 0) {
    const _0xd31bbecb3c93 = await _0x8b2dc19450f4(false);
    if (!_0xd31bbecb3c93.authorized) {
        _0xe891f6971e2c.authorizationBlocked = true;
        _0xe891f6971e2c.authorizationFailureDeferred = false;
        _0xe891f6971e2c.mode = _0x4cbcf6dd9e80(49624);
        _0xe891f6971e2c.pauseReason = _0x9b5f5787445e.failureMessage;
        _0xe891f6971e2c.updatedAt = new Date().toISOString();
        const _0xaa60b19d363a = _0xa933c8eed5e2(_0xe891f6971e2c);
        const _0x429d3efa4d03 = _0x6f0b5237acfb?.[_0x6f0b5237acfb.length - 1];
        if (_0x429d3efa4d03?.message !== _0x9b5f5787445e.failureMessage) {
            _0xc70b7be9a6b7(_0x6f0b5237acfb, _0x4cbcf6dd9e80(49665), _0x9b5f5787445e.failureMessage, _0xaa60b19d363a?.rowNumber ?? null);
        }
        await _0xd68338758035(_0xe891f6971e2c, _0x6f0b5237acfb);
        return { completed: false, authorizationFailed: true, error: _0x9b5f5787445e.failureMessage };
    }
    const _0x817bc0e9d5b5 = _0xe891f6971e2c.currentGroupIndex;
    const _0x9d9bfa91bbfc = _0x589ffb3858ed(_0xe891f6971e2c.groups, Number.isInteger(_0x817bc0e9d5b5) ? _0x817bc0e9d5b5 : -1);
    if (_0x9d9bfa91bbfc === -1) {
        await _0xe26d015b0a8e(_0xe891f6971e2c.runId);
        _0xe891f6971e2c.mode = _0x4cbcf6dd9e80(49706);
        _0xe891f6971e2c.phase = _0x4cbcf6dd9e80(49701);
        _0xe891f6971e2c.pauseReason = _0x4cbcf6dd9e80(49664);
        _0xe891f6971e2c.currentGroupIndex = null;
        _0xe891f6971e2c.currentIndex = null;
        _0xe891f6971e2c.intervalEndsAt = null;
        _0xe891f6971e2c.intervalRemainingSeconds = 0;
        _0xe891f6971e2c.updatedAt = new Date().toISOString();
        _0xc70b7be9a6b7(_0x6f0b5237acfb, _0x4cbcf6dd9e80(49686), _0xcd103207a146 || _0x4cbcf6dd9e80(49509));
        await _0xd68338758035(_0xe891f6971e2c, _0x6f0b5237acfb);
        return { completed: true };
    }
    _0xe891f6971e2c.currentGroupIndex = _0x9d9bfa91bbfc;
    const _0x0b9ada3e4b7b = _0xe891f6971e2c.groups[_0x9d9bfa91bbfc];
    _0xe891f6971e2c.currentIndex = _0x0b9ada3e4b7b.primaryRowIndex;
    const _0xaa5c2768f897 = _0xf5767a497dd7(_0x48fd4fc8c183, 0);
    if (_0xaa5c2768f897 > 0) {
        _0xe891f6971e2c.mode = _0x4cbcf6dd9e80(49627);
        _0xe891f6971e2c.phase = _0x4cbcf6dd9e80(49508);
        _0xe891f6971e2c.pauseReason = _0x4cbcf6dd9e80(49664);
        _0xe891f6971e2c.intervalEndsAt = new Date(Date.now() + _0xaa5c2768f897 * 1000).toISOString();
        _0xe891f6971e2c.intervalRemainingSeconds = _0xaa5c2768f897;
        _0xe1f605a7091c(_0xe891f6971e2c.rows, _0x0b9ada3e4b7b, (_0x4cbcf6dd9e80(49511) + _0xaa5c2768f897 + _0x4cbcf6dd9e80(49510)));
        _0xe891f6971e2c.updatedAt = new Date().toISOString();
        const _0xd4761a18f197 = _0xe891f6971e2c.rows[_0x0b9ada3e4b7b.primaryRowIndex];
        _0xc70b7be9a6b7(_0x6f0b5237acfb, _0x4cbcf6dd9e80(49719), (_0x4cbcf6dd9e80(49569) + _0xaa5c2768f897 + _0x4cbcf6dd9e80(49568) + _0xd4761a18f197.rowNumber + _0x4cbcf6dd9e80(49571)), _0xd4761a18f197.rowNumber);
        await _0xd68338758035(_0xe891f6971e2c, _0x6f0b5237acfb);
        try {
            await _0x40f5546ca56c(_0xe891f6971e2c, _0xaa5c2768f897 * 1000);
            return { completed: false, waiting: true };
        }
        catch (_0xa04209b5cfef) {
            _0xe891f6971e2c.mode = _0x4cbcf6dd9e80(49624);
            _0xe891f6971e2c.pauseReason = (_0x4cbcf6dd9e80(49570) + (_0xa04209b5cfef.message || String(_0xa04209b5cfef)) + _0x4cbcf6dd9e80(49664));
            _0x7bffd74ea3dc(_0xe891f6971e2c.rows, _0x0b9ada3e4b7b, _0xe891f6971e2c.pauseReason);
            _0xc70b7be9a6b7(_0x6f0b5237acfb, _0x4cbcf6dd9e80(49665), _0xe891f6971e2c.pauseReason, _0xd4761a18f197.rowNumber);
            await _0xd68338758035(_0xe891f6971e2c, _0x6f0b5237acfb);
            return { completed: false, error: _0xe891f6971e2c.pauseReason };
        }
    }
    return _0x484b55d57ccd(_0xe891f6971e2c, _0x6f0b5237acfb, true);
}
async function _0x2eb21256f3e4(_0x86eacf4e3f6f) {
    const _0xd914d04a20ab = await _0x603145195ada();
    const _0x61e71125fbbd = _0xd914d04a20ab[_0x21777dfa17c3.RUN_STATE];
    const _0x901c28deb5fb = Array.isArray(_0xd914d04a20ab[_0x21777dfa17c3.LOGS]) ? _0xd914d04a20ab[_0x21777dfa17c3.LOGS] : [];
    if (!_0x61e71125fbbd ||
        _0x61e71125fbbd.runId !== _0x86eacf4e3f6f ||
        _0x61e71125fbbd.mode !== _0x4cbcf6dd9e80(49627) ||
        _0x61e71125fbbd.phase !== _0x4cbcf6dd9e80(49508)) {
        await _0xe26d015b0a8e(_0x86eacf4e3f6f);
        return { ok: false, stale: true };
    }
    const _0xd8495a7f93de = _0xf0e30f6bb0ca(_0x61e71125fbbd);
    if (_0xd8495a7f93de > 500) {
        _0x61e71125fbbd.intervalRemainingSeconds = Math.ceil(_0xd8495a7f93de / 1000);
        await _0xd68338758035(_0x61e71125fbbd, _0x901c28deb5fb);
        await _0x40f5546ca56c(_0x61e71125fbbd, _0xd8495a7f93de);
        return { ok: true, waiting: true };
    }
    await _0xe26d015b0a8e(_0x86eacf4e3f6f);
    _0x61e71125fbbd.intervalEndsAt = null;
    _0x61e71125fbbd.intervalRemainingSeconds = 0;
    const _0xce72d4d409eb = _0xc77f4848e0bd(_0x61e71125fbbd);
    const _0x6741ad1f0eae = _0xce72d4d409eb ? _0x61e71125fbbd.rows[_0xce72d4d409eb.primaryRowIndex] : null;
    _0xc70b7be9a6b7(_0x901c28deb5fb, _0x4cbcf6dd9e80(49719), _0x4cbcf6dd9e80(49565), _0x6741ad1f0eae?.rowNumber ?? null);
    await _0xd68338758035(_0x61e71125fbbd, _0x901c28deb5fb);
    await _0x484b55d57ccd(_0x61e71125fbbd, _0x901c28deb5fb, true);
    return { ok: true };
}
async function _0xa0f34c03e71a(_0x304c788854f9, _0xfc2381240cef) {
    const _0xea70ce0c8597 = await _0x603145195ada();
    const _0xfb931a0a8290 = _0xea70ce0c8597[_0x21777dfa17c3.RUN_STATE];
    const _0xa3ce2b8bb150 = Array.isArray(_0xea70ce0c8597[_0x21777dfa17c3.LOGS]) ? _0xea70ce0c8597[_0x21777dfa17c3.LOGS] : [];
    if (!_0xfb931a0a8290 || _0xfc2381240cef.tab?.id !== _0xfb931a0a8290.workTabId || _0xfb931a0a8290.runId !== _0x304c788854f9.runId) {
        return { ok: false, stale: true };
    }
    if (![_0x4cbcf6dd9e80(49524), _0x4cbcf6dd9e80(49564)].includes(_0xfb931a0a8290.phase)) {
        return { ok: false, stale: true, error: (_0x4cbcf6dd9e80(49567) + _0xfb931a0a8290.phase + _0x4cbcf6dd9e80(49664)) };
    }
    const _0x1e4d27f9ecf9 = _0xc77f4848e0bd(_0xfb931a0a8290);
    if (!_0x1e4d27f9ecf9?.isCombined) {
        return { ok: false, error: _0x4cbcf6dd9e80(49566) };
    }
    if (Number(_0x304c788854f9.cartCount) !== 0) {
        return { ok: false, error: (_0x4cbcf6dd9e80(49561) + _0x304c788854f9.cartCount + _0x4cbcf6dd9e80(49664)) };
    }
    const _0x68806ef6ce8d = _0x1e4d27f9ecf9.rowIndexes[0];
    const _0xe02228480044 = _0xfb931a0a8290.rows[_0x68806ef6ce8d];
    _0xfb931a0a8290.currentIndex = _0x68806ef6ce8d;
    if (_0xfb931a0a8290.phase === _0x4cbcf6dd9e80(49524)) {
        _0x1e4d27f9ecf9.precheckCursor = 0;
        _0xfb931a0a8290.phase = _0x4cbcf6dd9e80(49560);
        _0x43b6a7957fcd(_0xe02228480044, _0x4cbcf6dd9e80(49563), _0x4cbcf6dd9e80(49687));
        _0xc70b7be9a6b7(_0xa3ce2b8bb150, _0x4cbcf6dd9e80(49686), _0x4cbcf6dd9e80(49562), _0xe02228480044.rowNumber);
        await _0xd68338758035(_0xfb931a0a8290, _0xa3ce2b8bb150);
        await _0x49c0aaeecf35(_0xfb931a0a8290.workTabId);
        return { ok: true, state: _0xfb931a0a8290 };
    }
    if (_0xea70ce0c8597[_0x21777dfa17c3.CART_LOCK]) {
        return { ok: false, error: _0x4cbcf6dd9e80(49557) };
    }
    _0x1e4d27f9ecf9.addCursor = 0;
    _0x1e4d27f9ecf9.expectedCartCount = 0;
    const _0x0913aa48f708 = _0x9bc79ac17b6e(_0xfb931a0a8290, _0x1e4d27f9ecf9);
    _0xfb931a0a8290.phase = _0x4cbcf6dd9e80(49620);
    _0xe1f605a7091c(_0xfb931a0a8290.rows, _0x1e4d27f9ecf9, _0x4cbcf6dd9e80(49556));
    _0x43b6a7957fcd(_0xe02228480044, _0x4cbcf6dd9e80(49559), _0x4cbcf6dd9e80(49687));
    _0xc70b7be9a6b7(_0xa3ce2b8bb150, _0x4cbcf6dd9e80(49686), _0x4cbcf6dd9e80(49558), _0xe02228480044.rowNumber);
    await _0xd68338758035(_0xfb931a0a8290, _0xa3ce2b8bb150, { [_0x21777dfa17c3.CART_LOCK]: _0x0913aa48f708 });
    await _0x49c0aaeecf35(_0xfb931a0a8290.workTabId);
    return { ok: true, state: _0xfb931a0a8290 };
}
async function _0x76089b6dc9c4(_0xbffd4a3ec1ea, _0x1d1a63e67db7) {
    const _0xb0a927111d22 = await _0x603145195ada();
    const _0x4add385e5707 = _0xb0a927111d22[_0x21777dfa17c3.RUN_STATE];
    const _0x3cb164f715de = Array.isArray(_0xb0a927111d22[_0x21777dfa17c3.LOGS]) ? _0xb0a927111d22[_0x21777dfa17c3.LOGS] : [];
    if (!_0x4add385e5707 || _0x1d1a63e67db7.tab?.id !== _0x4add385e5707.workTabId || _0x4add385e5707.runId !== _0xbffd4a3ec1ea.runId) {
        return { ok: false, stale: true };
    }
    if (_0x4add385e5707.phase !== _0x4cbcf6dd9e80(49560)) {
        return { ok: false, stale: true, error: (_0x4cbcf6dd9e80(49553) + _0x4add385e5707.phase + _0x4cbcf6dd9e80(49664)) };
    }
    const _0x2f8d1b2111c6 = _0xc77f4848e0bd(_0x4add385e5707);
    const _0xac3a5f491db2 = _0xa933c8eed5e2(_0x4add385e5707);
    if (!_0x2f8d1b2111c6?.isCombined || !_0xac3a5f491db2) {
        return { ok: false, error: _0x4cbcf6dd9e80(49552) };
    }
    const _0x9a714193fa2c = _0x2f8d1b2111c6.rowIndexes[_0x2f8d1b2111c6.precheckCursor];
    if (_0x4add385e5707.currentIndex !== _0x9a714193fa2c) {
        return { ok: false, stale: true, error: _0x4cbcf6dd9e80(49555) };
    }
    const _0x89b0b46b788e = Number(_0xbffd4a3ec1ea.observedUnitPrice);
    const _0x20a6ffa7151e = Number(_0xbffd4a3ec1ea.selectedQuantity);
    if (!Number.isFinite(_0x89b0b46b788e) || Math.abs(_0x89b0b46b788e - 2) > 0.0001) {
        return { ok: false, error: _0x4cbcf6dd9e80(49554) };
    }
    if (!Number.isSafeInteger(_0x20a6ffa7151e) || _0x20a6ffa7151e !== _0xac3a5f491db2.requestedQuantity) {
        return { ok: false, error: _0x4cbcf6dd9e80(49549) };
    }
    _0xac3a5f491db2.observedUnitPrice = _0x89b0b46b788e.toFixed(2);
    _0xac3a5f491db2.selectedQuantity = _0x20a6ffa7151e;
    _0xac3a5f491db2.precheckPassed = true;
    _0x43b6a7957fcd(_0xac3a5f491db2, _0x4cbcf6dd9e80(49548), _0x4cbcf6dd9e80(49687));
    _0xc70b7be9a6b7(_0x3cb164f715de, _0x4cbcf6dd9e80(49686), (_0x4cbcf6dd9e80(49551) + _0xac3a5f491db2.asin + _0x4cbcf6dd9e80(49550) + _0x20a6ffa7151e + _0x4cbcf6dd9e80(49708)), _0xac3a5f491db2.rowNumber);
    if (_0x2f8d1b2111c6.precheckCursor + 1 < _0x2f8d1b2111c6.rowIndexes.length) {
        _0x2f8d1b2111c6.precheckCursor += 1;
        const _0xfdde66fd113a = _0x2f8d1b2111c6.rowIndexes[_0x2f8d1b2111c6.precheckCursor];
        const _0x333293fd48ed = _0x4add385e5707.rows[_0xfdde66fd113a];
        _0x4add385e5707.currentIndex = _0xfdde66fd113a;
        _0x4add385e5707.phase = _0x4cbcf6dd9e80(49560);
        _0x43b6a7957fcd(_0x333293fd48ed, _0x4cbcf6dd9e80(49545), _0x4cbcf6dd9e80(49687));
        _0xc70b7be9a6b7(_0x3cb164f715de, _0x4cbcf6dd9e80(49719), (_0x4cbcf6dd9e80(49544) + _0x333293fd48ed.rowNumber + _0x4cbcf6dd9e80(49547)), _0x333293fd48ed.rowNumber);
        _0x4add385e5707.updatedAt = new Date().toISOString();
        const _0x58a5230e6457 = await _0xe10b90fbf183(_0x4add385e5707, _0x3cb164f715de, _0x333293fd48ed.amzLink, {}, _0x4cbcf6dd9e80(49546));
        return _0x58a5230e6457.ok ? { ok: true, state: _0x4add385e5707 } : _0x58a5230e6457;
    }
    _0x2f8d1b2111c6.result = _0x4cbcf6dd9e80(49687);
    _0x2f8d1b2111c6.status = _0x4cbcf6dd9e80(49541);
    _0x4add385e5707.currentIndex = _0x2f8d1b2111c6.rowIndexes[0];
    _0x4add385e5707.phase = _0x4cbcf6dd9e80(49564);
    _0xe1f605a7091c(_0x4add385e5707.rows, _0x2f8d1b2111c6, _0x4cbcf6dd9e80(49540));
    _0xc70b7be9a6b7(_0x3cb164f715de, _0x4cbcf6dd9e80(49719), _0x4cbcf6dd9e80(49543), _0x4add385e5707.rows[_0x2f8d1b2111c6.rowIndexes[0]].rowNumber);
    _0xc70b7be9a6b7(_0x3cb164f715de, _0x4cbcf6dd9e80(49719), _0x4cbcf6dd9e80(49542), _0x4add385e5707.rows[_0x2f8d1b2111c6.rowIndexes[0]].rowNumber);
    _0x4add385e5707.updatedAt = new Date().toISOString();
    const _0xcb14c8e91331 = await _0xe10b90fbf183(_0x4add385e5707, _0x3cb164f715de, _0x4add385e5707.rows[_0x2f8d1b2111c6.rowIndexes[0]].amzLink, {}, _0x4cbcf6dd9e80(49601));
    return _0xcb14c8e91331.ok ? { ok: true, state: _0x4add385e5707 } : _0xcb14c8e91331;
}
async function _0xbbb10831cc5b(_0x1e84822556cc, _0x217141fd2092) {
    const _0x43766cf253e5 = await _0x603145195ada();
    const _0xe139c300f26c = _0x43766cf253e5[_0x21777dfa17c3.RUN_STATE];
    const _0x5c1531b8be6b = Array.isArray(_0x43766cf253e5[_0x21777dfa17c3.LOGS]) ? _0x43766cf253e5[_0x21777dfa17c3.LOGS] : [];
    if (!_0xe139c300f26c || _0x217141fd2092.tab?.id !== _0xe139c300f26c.workTabId || _0xe139c300f26c.runId !== _0x1e84822556cc.runId) {
        return { ok: false, stale: true };
    }
    if (_0xe139c300f26c.phase !== _0x4cbcf6dd9e80(49560)) {
        return { ok: false, stale: true };
    }
    const _0x6e09ffa46e57 = _0xc77f4848e0bd(_0xe139c300f26c);
    const _0xa342aef02506 = _0xa933c8eed5e2(_0xe139c300f26c);
    if (!_0x6e09ffa46e57?.isCombined || !_0xa342aef02506) {
        return { ok: false, error: _0x4cbcf6dd9e80(49552) };
    }
    if (Number.isFinite(Number(_0x1e84822556cc.observedUnitPrice))) {
        _0xa342aef02506.observedUnitPrice = Number(_0x1e84822556cc.observedUnitPrice).toFixed(2);
    }
    if (Number.isSafeInteger(Number(_0x1e84822556cc.selectedQuantity)) && Number(_0x1e84822556cc.selectedQuantity) > 0) {
        _0xa342aef02506.selectedQuantity = Number(_0x1e84822556cc.selectedQuantity);
    }
    const _0xc0730d9a99c3 = _0x1e84822556cc.reason || _0x4cbcf6dd9e80(49600);
    _0x226ac3a339cd(_0xe139c300f26c.rows, _0x6e09ffa46e57, _0xe139c300f26c.currentIndex, _0xc0730d9a99c3);
    _0xc70b7be9a6b7(_0x5c1531b8be6b, _0x4cbcf6dd9e80(49714), (_0x4cbcf6dd9e80(49664) + _0xc0730d9a99c3 + _0x4cbcf6dd9e80(49603)), _0xa342aef02506.rowNumber);
    _0xe139c300f26c.updatedAt = new Date().toISOString();
    await _0xd68338758035(_0xe139c300f26c, _0x5c1531b8be6b);
    await _0x692a17365254(_0xe139c300f26c, _0x5c1531b8be6b, _0x4cbcf6dd9e80(49509), 0);
    return { ok: true };
}
async function _0x1f143af89125(_0xb5c9f838d319, _0xc81f4558363e) {
    const _0xfa4ee029ef31 = await _0x603145195ada();
    const _0xf56b99bc4dd7 = _0xfa4ee029ef31[_0x21777dfa17c3.RUN_STATE];
    const _0x356ec834616f = Array.isArray(_0xfa4ee029ef31[_0x21777dfa17c3.LOGS]) ? _0xfa4ee029ef31[_0x21777dfa17c3.LOGS] : [];
    let _0x4b599bb77dc7 = _0xfa4ee029ef31[_0x21777dfa17c3.CART_LOCK] || null;
    if (!_0xf56b99bc4dd7 || _0xc81f4558363e.tab?.id !== _0xf56b99bc4dd7.workTabId || _0xf56b99bc4dd7.runId !== _0xb5c9f838d319.runId) {
        return { ok: false, stale: true };
    }
    if (_0xf56b99bc4dd7.phase !== _0x4cbcf6dd9e80(49620)) {
        return { ok: false, stale: true, error: (_0x4cbcf6dd9e80(49602) + _0xf56b99bc4dd7.phase + _0x4cbcf6dd9e80(49664)) };
    }
    const _0xfdcd39590620 = _0xc77f4848e0bd(_0xf56b99bc4dd7);
    const _0x11b2d4ec2ec1 = _0xa933c8eed5e2(_0xf56b99bc4dd7);
    if (!_0xfdcd39590620?.isCombined || !_0x11b2d4ec2ec1 || !_0xbc5b9eab3e5d(_0x4b599bb77dc7, _0xf56b99bc4dd7, _0xfdcd39590620)) {
        return { ok: false, error: _0x4cbcf6dd9e80(49597) };
    }
    const _0xa545afda0762 = _0xfdcd39590620.rowIndexes[_0xfdcd39590620.addCursor];
    if (_0xf56b99bc4dd7.currentIndex !== _0xa545afda0762) {
        return { ok: false, stale: true, error: _0x4cbcf6dd9e80(49596) };
    }
    const _0xf55429267e6a = Number(_0xb5c9f838d319.selectedQuantity);
    const _0x26157a06a3ea = Number(_0xb5c9f838d319.observedUnitPrice);
    if (!Number.isSafeInteger(_0xf55429267e6a) || _0xf55429267e6a !== _0x11b2d4ec2ec1.requestedQuantity) {
        return { ok: false, error: _0x4cbcf6dd9e80(49599) };
    }
    if (!Number.isFinite(_0x26157a06a3ea) || Math.abs(_0x26157a06a3ea - 2) > 0.0001) {
        return { ok: false, error: _0x4cbcf6dd9e80(49598) };
    }
    const _0x3774d50b1769 = _0xfdcd39590620.rowIndexes
        .slice(0, _0xfdcd39590620.addCursor + 1)
        .reduce((_0xb6a41ca99315, _0xcded24da47bc) => _0xb6a41ca99315 + _0xf56b99bc4dd7.rows[_0xcded24da47bc].requestedQuantity, 0);
    _0x11b2d4ec2ec1.observedUnitPrice = _0x26157a06a3ea.toFixed(2);
    _0x11b2d4ec2ec1.selectedQuantity = _0xf55429267e6a;
    _0x43b6a7957fcd(_0x11b2d4ec2ec1, (_0x4cbcf6dd9e80(49593) + _0x3774d50b1769 + _0x4cbcf6dd9e80(49592)), _0x4cbcf6dd9e80(49687));
    _0xf56b99bc4dd7.phase = _0x4cbcf6dd9e80(49623);
    _0xf56b99bc4dd7.updatedAt = new Date().toISOString();
    _0x4b599bb77dc7 = {
        ..._0x4b599bb77dc7,
        stage: _0x4cbcf6dd9e80(49595),
        pendingRowIndex: _0xf56b99bc4dd7.currentIndex,
        expectedCartCountAfter: _0x3774d50b1769,
        updatedAt: new Date().toISOString()
    };
    _0xc70b7be9a6b7(_0x356ec834616f, _0x4cbcf6dd9e80(49719), (_0x4cbcf6dd9e80(49594) + _0x11b2d4ec2ec1.asin + _0x4cbcf6dd9e80(49589) + _0xf55429267e6a + _0x4cbcf6dd9e80(49588) + _0x3774d50b1769 + _0x4cbcf6dd9e80(49591)), _0x11b2d4ec2ec1.rowNumber);
    await _0xd68338758035(_0xf56b99bc4dd7, _0x356ec834616f, { [_0x21777dfa17c3.CART_LOCK]: _0x4b599bb77dc7 });
    return { ok: true, state: _0xf56b99bc4dd7, expectedCartCountAfter: _0x3774d50b1769 };
}
async function _0x4ab7513bb29c(_0x54b8672c53e4, _0x171d888467a6) {
    const _0xf9196f0d4bec = await _0x603145195ada();
    const _0x9a4f8c52137a = _0xf9196f0d4bec[_0x21777dfa17c3.RUN_STATE];
    const _0x1b11b4369f7b = Array.isArray(_0xf9196f0d4bec[_0x21777dfa17c3.LOGS]) ? _0xf9196f0d4bec[_0x21777dfa17c3.LOGS] : [];
    let _0xe2ccc7953df5 = _0xf9196f0d4bec[_0x21777dfa17c3.CART_LOCK] || null;
    if (!_0x9a4f8c52137a || _0x171d888467a6.tab?.id !== _0x9a4f8c52137a.workTabId || _0x9a4f8c52137a.runId !== _0x54b8672c53e4.runId) {
        return { ok: false, stale: true };
    }
    if (_0x9a4f8c52137a.phase !== _0x4cbcf6dd9e80(49623)) {
        return { ok: false, stale: true, error: (_0x4cbcf6dd9e80(49590) + _0x9a4f8c52137a.phase + _0x4cbcf6dd9e80(49664)) };
    }
    const _0x0d0cb40cea22 = _0xc77f4848e0bd(_0x9a4f8c52137a);
    const _0xe45963f3cccb = _0xa933c8eed5e2(_0x9a4f8c52137a);
    if (!_0x0d0cb40cea22?.isCombined || !_0xe45963f3cccb || !_0xbc5b9eab3e5d(_0xe2ccc7953df5, _0x9a4f8c52137a, _0x0d0cb40cea22)) {
        return { ok: false, error: _0x4cbcf6dd9e80(49597) };
    }
    const _0x494f435b85aa = _0x0d0cb40cea22.rowIndexes[_0x0d0cb40cea22.addCursor];
    if (_0x9a4f8c52137a.currentIndex !== _0x494f435b85aa) {
        return { ok: false, stale: true, error: _0x4cbcf6dd9e80(49596) };
    }
    const _0x5a1e5ad2b9ce = Number(_0x54b8672c53e4.selectedQuantity);
    const _0x32440b50d6e4 = Number(_0x54b8672c53e4.observedUnitPrice);
    if (!Number.isSafeInteger(_0x5a1e5ad2b9ce) || _0x5a1e5ad2b9ce !== _0xe45963f3cccb.requestedQuantity) {
        return { ok: false, error: _0x4cbcf6dd9e80(49585) };
    }
    if (!Number.isFinite(_0x32440b50d6e4) || Math.abs(_0x32440b50d6e4 - 2) > 0.0001) {
        return { ok: false, error: _0x4cbcf6dd9e80(49584) };
    }
    const _0xa3b8ff173712 = _0x0d0cb40cea22.rowIndexes
        .slice(0, _0x0d0cb40cea22.addCursor + 1)
        .reduce((_0x007e691466cd, _0xf399de73c2ac) => _0x007e691466cd + _0x9a4f8c52137a.rows[_0xf399de73c2ac].requestedQuantity, 0);
    const _0x40709a7b34c5 = Number(_0x54b8672c53e4.cartCount);
    if (!Number.isSafeInteger(_0x40709a7b34c5) || _0x40709a7b34c5 !== _0xa3b8ff173712) {
        return {
            ok: false,
            error: (_0x4cbcf6dd9e80(49587) + _0xa3b8ff173712 + _0x4cbcf6dd9e80(49586) + _0x54b8672c53e4.cartCount + _0x4cbcf6dd9e80(49708))
        };
    }
    _0xe45963f3cccb.observedUnitPrice = _0x32440b50d6e4.toFixed(2);
    _0xe45963f3cccb.selectedQuantity = _0x5a1e5ad2b9ce;
    _0xe45963f3cccb.addedToCart = true;
    _0x0d0cb40cea22.expectedCartCount = _0xa3b8ff173712;
    _0x43b6a7957fcd(_0xe45963f3cccb, (_0x4cbcf6dd9e80(49581) + _0xa3b8ff173712 + _0x4cbcf6dd9e80(49592)), _0x4cbcf6dd9e80(49687));
    _0xc70b7be9a6b7(_0x1b11b4369f7b, _0x4cbcf6dd9e80(49686), (_0x4cbcf6dd9e80(49580) + _0xe45963f3cccb.asin + _0x4cbcf6dd9e80(49589) + _0x5a1e5ad2b9ce + _0x4cbcf6dd9e80(49583) + _0xa3b8ff173712 + _0x4cbcf6dd9e80(49708)), _0xe45963f3cccb.rowNumber);
    _0xe2ccc7953df5 = {
        ..._0xe2ccc7953df5,
        addedRowIndexes: [...new Set([...(_0xe2ccc7953df5.addedRowIndexes || []), _0x9a4f8c52137a.currentIndex])],
        expectedCartCount: _0xa3b8ff173712,
        stage: _0x4cbcf6dd9e80(49582),
        updatedAt: new Date().toISOString()
    };
    if (_0x0d0cb40cea22.addCursor + 1 < _0x0d0cb40cea22.rowIndexes.length) {
        _0x0d0cb40cea22.addCursor += 1;
        const _0xa40491f0f16b = _0x0d0cb40cea22.rowIndexes[_0x0d0cb40cea22.addCursor];
        const _0xfbc4630c831e = _0x9a4f8c52137a.rows[_0xa40491f0f16b];
        _0x9a4f8c52137a.currentIndex = _0xa40491f0f16b;
        _0x9a4f8c52137a.phase = _0x4cbcf6dd9e80(49620);
        _0x43b6a7957fcd(_0xfbc4630c831e, _0x4cbcf6dd9e80(49577), _0x4cbcf6dd9e80(49687));
        _0xc70b7be9a6b7(_0x1b11b4369f7b, _0x4cbcf6dd9e80(49719), (_0x4cbcf6dd9e80(49576) + _0xfbc4630c831e.rowNumber + _0x4cbcf6dd9e80(49547)), _0xfbc4630c831e.rowNumber);
        _0x9a4f8c52137a.updatedAt = new Date().toISOString();
        const _0x34d8faa05a11 = await _0xe10b90fbf183(_0x9a4f8c52137a, _0x1b11b4369f7b, _0xfbc4630c831e.amzLink, { [_0x21777dfa17c3.CART_LOCK]: _0xe2ccc7953df5 }, _0x4cbcf6dd9e80(49579));
        return _0x34d8faa05a11.ok ? { ok: true, state: _0x9a4f8c52137a } : _0x34d8faa05a11;
    }
    _0x9a4f8c52137a.phase = _0x4cbcf6dd9e80(49622);
    _0xe1f605a7091c(_0x9a4f8c52137a.rows, _0x0d0cb40cea22, _0x4cbcf6dd9e80(49578));
    _0xe2ccc7953df5.stage = _0x4cbcf6dd9e80(49573);
    _0xe2ccc7953df5.updatedAt = new Date().toISOString();
    _0x9a4f8c52137a.updatedAt = new Date().toISOString();
    _0xc70b7be9a6b7(_0x1b11b4369f7b, _0x4cbcf6dd9e80(49719), (_0x4cbcf6dd9e80(49572) + _0x0d0cb40cea22.expectedTotalQuantity + _0x4cbcf6dd9e80(49575)), _0xe45963f3cccb.rowNumber);
    await _0xd68338758035(_0x9a4f8c52137a, _0x1b11b4369f7b, { [_0x21777dfa17c3.CART_LOCK]: _0xe2ccc7953df5 });
    await _0x49c0aaeecf35(_0x9a4f8c52137a.workTabId);
    return { ok: true, state: _0x9a4f8c52137a };
}
async function _0x36da2c14184a(_0xdfbc9a76d2bd, _0xcd05468fdf46) {
    const _0x97886baac551 = await _0x603145195ada();
    const _0xa9b3e2196be5 = _0x97886baac551[_0x21777dfa17c3.RUN_STATE];
    const _0x72c2b59faa59 = Array.isArray(_0x97886baac551[_0x21777dfa17c3.LOGS]) ? _0x97886baac551[_0x21777dfa17c3.LOGS] : [];
    let _0x1a12b6bfd46b = _0x97886baac551[_0x21777dfa17c3.CART_LOCK] || null;
    if (!_0xa9b3e2196be5 || _0xcd05468fdf46.tab?.id !== _0xa9b3e2196be5.workTabId || _0xa9b3e2196be5.runId !== _0xdfbc9a76d2bd.runId) {
        return { ok: false, stale: true };
    }
    if (_0xa9b3e2196be5.phase !== _0x4cbcf6dd9e80(49622)) {
        return { ok: false, stale: true, error: (_0x4cbcf6dd9e80(49574) + _0xa9b3e2196be5.phase + _0x4cbcf6dd9e80(49664)) };
    }
    const _0x9996681fc621 = _0xc77f4848e0bd(_0xa9b3e2196be5);
    if (!_0x9996681fc621?.isCombined || !_0xbc5b9eab3e5d(_0x1a12b6bfd46b, _0xa9b3e2196be5, _0x9996681fc621)) {
        return { ok: false, error: _0x4cbcf6dd9e80(49597) };
    }
    const _0x9cd9982a544d = Number(_0xdfbc9a76d2bd.cartCount);
    if (!Number.isSafeInteger(_0x9cd9982a544d) || _0x9cd9982a544d !== _0x9996681fc621.expectedTotalQuantity) {
        return { ok: false, error: (_0x4cbcf6dd9e80(49889) + _0x9996681fc621.expectedTotalQuantity + _0x4cbcf6dd9e80(49586) + _0xdfbc9a76d2bd.cartCount + _0x4cbcf6dd9e80(49708)) };
    }
    if (_0xdfbc9a76d2bd.proceedItemCount !== null &&
        _0xdfbc9a76d2bd.proceedItemCount !== undefined &&
        Number(_0xdfbc9a76d2bd.proceedItemCount) !== _0x9996681fc621.expectedTotalQuantity) {
        return { ok: false, error: (_0x4cbcf6dd9e80(49888) + _0xdfbc9a76d2bd.proceedItemCount + _0x4cbcf6dd9e80(49891) + _0x9996681fc621.expectedTotalQuantity + _0x4cbcf6dd9e80(49890)) };
    }
    _0xa9b3e2196be5.currentIndex = _0x9996681fc621.primaryRowIndex;
    _0xa9b3e2196be5.phase = _0x4cbcf6dd9e80(49617);
    _0xe1f605a7091c(_0xa9b3e2196be5.rows, _0x9996681fc621, _0x4cbcf6dd9e80(49885));
    _0x1a12b6bfd46b = {
        ..._0x1a12b6bfd46b,
        stage: _0x4cbcf6dd9e80(49884),
        expectedCartCount: _0x9996681fc621.expectedTotalQuantity,
        proceedItemCount: _0xdfbc9a76d2bd.proceedItemCount ?? null,
        updatedAt: new Date().toISOString()
    };
    _0xc70b7be9a6b7(_0x72c2b59faa59, _0x4cbcf6dd9e80(49686), _0xdfbc9a76d2bd.proceedItemCount === null || _0xdfbc9a76d2bd.proceedItemCount === undefined
        ? (_0x4cbcf6dd9e80(49887) + _0x9cd9982a544d + _0x4cbcf6dd9e80(49591)) : (_0x4cbcf6dd9e80(49886) + _0x9cd9982a544d + _0x4cbcf6dd9e80(49591)), _0xa9b3e2196be5.rows[_0x9996681fc621.primaryRowIndex].rowNumber);
    _0xa9b3e2196be5.updatedAt = new Date().toISOString();
    await _0xd68338758035(_0xa9b3e2196be5, _0x72c2b59faa59, { [_0x21777dfa17c3.CART_LOCK]: _0x1a12b6bfd46b });
    return { ok: true, state: _0xa9b3e2196be5 };
}
async function _0xae14c8d6d6cc(_0x65acc5805e8b, _0x9f930cc73f79 = null, _0x433cfa4652fe = false) {
    const _0xb9a2f8bc3014 = await _0x603145195ada();
    const _0x60ede39e4f57 = _0xb9a2f8bc3014[_0x21777dfa17c3.RUN_STATE];
    const _0x84986b85b4f9 = Array.isArray(_0xb9a2f8bc3014[_0x21777dfa17c3.LOGS]) ? _0xb9a2f8bc3014[_0x21777dfa17c3.LOGS] : [];
    const _0x82b2aa38294d = _0xb9a2f8bc3014[_0x21777dfa17c3.CART_LOCK] || null;
    if (!_0x60ede39e4f57) {
        return { ok: false, error: _0x4cbcf6dd9e80(49881) };
    }
    if (_0x9f930cc73f79?.tab && _0x9f930cc73f79.tab.id !== _0x60ede39e4f57.workTabId) {
        return { ok: false, stale: true };
    }
    if (_0x65acc5805e8b.runId && _0x60ede39e4f57.runId !== _0x65acc5805e8b.runId) {
        return { ok: false, stale: true };
    }
    if (_0x65acc5805e8b.expectedPhase && _0x60ede39e4f57.phase !== _0x65acc5805e8b.expectedPhase) {
        return { ok: false, stale: true };
    }
    const _0x59c3a53c81e2 = _0xa933c8eed5e2(_0x60ede39e4f57);
    const _0xfcd735fb5763 = _0xc77f4848e0bd(_0x60ede39e4f57);
    if (!_0x59c3a53c81e2 || !_0xfcd735fb5763) {
        return { ok: false, error: _0x4cbcf6dd9e80(49880) };
    }
    if (_0xbc5b9eab3e5d(_0x82b2aa38294d, _0x60ede39e4f57, _0xfcd735fb5763)) {
        return {
            ok: false,
            error: _0x4cbcf6dd9e80(49883)
        };
    }
    if (_0x60ede39e4f57.phase === _0x4cbcf6dd9e80(49508)) {
        await _0xe26d015b0a8e(_0x60ede39e4f57.runId);
        _0x60ede39e4f57.intervalEndsAt = null;
        _0x60ede39e4f57.intervalRemainingSeconds = 0;
    }
    const _0xd7916f0cb462 = _0x65acc5805e8b.reason || (_0x433cfa4652fe ? _0x4cbcf6dd9e80(49882) : _0x4cbcf6dd9e80(49877));
    if (Number.isFinite(Number(_0x65acc5805e8b.observedUnitPrice))) {
        _0x59c3a53c81e2.observedUnitPrice = Number(_0x65acc5805e8b.observedUnitPrice).toFixed(2);
    }
    if (Number.isSafeInteger(Number(_0x65acc5805e8b.selectedQuantity)) && Number(_0x65acc5805e8b.selectedQuantity) > 0) {
        _0x59c3a53c81e2.selectedQuantity = Number(_0x65acc5805e8b.selectedQuantity);
    }
    const _0x30705a0e5d01 = _0xa963c5cdea9b.has(_0x60ede39e4f57.phase);
    const _0x06da1ce3ed8d = _0x433cfa4652fe && _0x30705a0e5d01 ? (_0x4cbcf6dd9e80(49664) + _0xd7916f0cb462 + _0x4cbcf6dd9e80(49876)) : _0xd7916f0cb462;
    if (_0xfcd735fb5763.isCombined) {
        _0x226ac3a339cd(_0x60ede39e4f57.rows, _0xfcd735fb5763, _0x60ede39e4f57.currentIndex, _0x06da1ce3ed8d);
        _0xc70b7be9a6b7(_0x84986b85b4f9, _0x4cbcf6dd9e80(49714), (_0x4cbcf6dd9e80(49664) + _0x06da1ce3ed8d + _0x4cbcf6dd9e80(49879)), _0x59c3a53c81e2.rowNumber);
    }
    else {
        _0xfcd735fb5763.result = _0x4cbcf6dd9e80(49691);
        _0xfcd735fb5763.status = _0x06da1ce3ed8d;
        _0x43b6a7957fcd(_0x59c3a53c81e2, _0x06da1ce3ed8d, _0x4cbcf6dd9e80(49691));
        _0xc70b7be9a6b7(_0x84986b85b4f9, _0x4cbcf6dd9e80(49714), _0x06da1ce3ed8d, _0x59c3a53c81e2.rowNumber);
    }
    await _0xd68338758035(_0x60ede39e4f57, _0x84986b85b4f9);
    await _0x692a17365254(_0x60ede39e4f57, _0x84986b85b4f9, _0x4cbcf6dd9e80(49509), 0);
    return { ok: true };
}
async function _0xb7f285a20f90(_0x2bde87eb9f50, _0x3b0d2fe140d9) {
    const _0x3f669b2e6c66 = await _0x603145195ada();
    const _0x1299f8709f6a = _0x3f669b2e6c66[_0x21777dfa17c3.RUN_STATE];
    const _0xd2778b9343ba = Array.isArray(_0x3f669b2e6c66[_0x21777dfa17c3.LOGS]) ? _0x3f669b2e6c66[_0x21777dfa17c3.LOGS] : [];
    const _0x832edf8f433d = _0xaeb8aa4ec5d7(_0x3f669b2e6c66[_0x21777dfa17c3.HISTORY]);
    const _0x36e2088089b4 = _0xf0ccabd2d36d(_0x3f669b2e6c66[_0x21777dfa17c3.ORDER_INDEX], _0x832edf8f433d);
    const _0x45d0d586b367 = _0x3f669b2e6c66[_0x21777dfa17c3.CART_LOCK] || null;
    if (!_0x1299f8709f6a || _0x3b0d2fe140d9.tab?.id !== _0x1299f8709f6a.workTabId || _0x1299f8709f6a.runId !== _0x2bde87eb9f50.runId) {
        return { ok: false, stale: true };
    }
    if (_0x1299f8709f6a.phase !== _0x4cbcf6dd9e80(49621)) {
        return { ok: false, stale: true, error: (_0x4cbcf6dd9e80(49878) + _0x1299f8709f6a.phase + _0x4cbcf6dd9e80(49664)) };
    }
    const _0xc3cbc3cacde9 = _0xc77f4848e0bd(_0x1299f8709f6a);
    const _0x22866340332c = _0xe7759fd6c561(_0x1299f8709f6a);
    if (!_0xc3cbc3cacde9 || !_0x22866340332c) {
        return { ok: false, error: _0x4cbcf6dd9e80(49873) };
    }
    const _0x8fb26fec8bbe = String(_0x2bde87eb9f50.orderId ?? _0x4cbcf6dd9e80(49664)).trim();
    if (!_0xde4244574fd5(_0x8fb26fec8bbe)) {
        return { ok: false, error: _0x4cbcf6dd9e80(49872) };
    }
    if (_0xc3cbc3cacde9.isCombined && !_0xbc5b9eab3e5d(_0x45d0d586b367, _0x1299f8709f6a, _0xc3cbc3cacde9)) {
        return { ok: false, error: _0x4cbcf6dd9e80(49875) };
    }
    const _0x6829f6ce88f3 = new Date().toISOString();
    const _0x4e3fa2b8f777 = _0xac1031e3efac();
    for (const _0xc0662fb7b789 of _0xc3cbc3cacde9.uniqueTemuOrderIds) {
        const _0xe08321321001 = _0xf025d0b90c68(_0x1299f8709f6a.rows, _0xc3cbc3cacde9, _0xc0662fb7b789);
        const _0x04472156eddf = _0x1299f8709f6a.rows[_0xe08321321001[0]];
        const _0x5405bb798e37 = _0xc3cbc3cacde9.temuItemSignatures[_0xc0662fb7b789] || _0x4cbcf6dd9e80(49664);
        const _0x739fe3037007 = _0xc3cbc3cacde9.temuSignatures[_0xc0662fb7b789] || _0x4cbcf6dd9e80(49664);
        _0x832edf8f433d.push({
            id: crypto.randomUUID(),
            runId: _0x1299f8709f6a.runId,
            rowNumbers: _0xe08321321001.map((_0xf67a4fc84fe1) => _0x1299f8709f6a.rows[_0xf67a4fc84fe1].rowNumber),
            dateKey: _0x4e3fa2b8f777,
            temuOrderId: _0x04472156eddf?.temuOrderId || _0xc0662fb7b789,
            temuOrderIdKey: _0xc0662fb7b789,
            asin: _0x04472156eddf?.asin || _0x4cbcf6dd9e80(49664),
            normalizedName: _0xc3cbc3cacde9.normalizedName,
            shipAddress: _0xc3cbc3cacde9.shipAddress,
            address2: _0xc3cbc3cacde9.address2,
            shipCity: _0xc3cbc3cacde9.shipCity,
            shipPostalCode: _0xc3cbc3cacde9.shipPostalCode,
            phoneNumber: _0xc3cbc3cacde9.phoneNumber,
            status: _0x4cbcf6dd9e80(49639),
            orderId: _0x8fb26fec8bbe,
            addressSignature: _0xc3cbc3cacde9.addressSignature,
            itemSignature: _0x5405bb798e37,
            temuSignature: _0x739fe3037007,
            groupSignature: _0xc3cbc3cacde9.groupSignature,
            expectedItems: _0x6003fa09f718(_0x1299f8709f6a.rows, _0xe08321321001),
            actualDeliveryAddress: _0xc3cbc3cacde9.actualDeliveryAddress,
            createdAt: _0x6829f6ce88f3,
            updatedAt: _0x6829f6ce88f3
        });
        _0x36e2088089b4[_0x512d143486d6(_0xc0662fb7b789)] = {
            temuOrderId: _0xc0662fb7b789,
            status: _0x4cbcf6dd9e80(49639),
            orderId: _0x8fb26fec8bbe,
            dateKey: _0x4e3fa2b8f777,
            addressSignature: _0xc3cbc3cacde9.addressSignature,
            itemSignature: _0x5405bb798e37,
            temuSignature: _0x739fe3037007,
            groupSignature: _0xc3cbc3cacde9.groupSignature,
            updatedAt: _0x6829f6ce88f3
        };
    }
    if (_0x832edf8f433d.length > _0xc51bf8f6faa9) {
        _0x832edf8f433d.splice(0, _0x832edf8f433d.length - _0xc51bf8f6faa9);
    }
    _0xa5a7c226e186(_0x1299f8709f6a.rows, _0xc3cbc3cacde9, _0x8fb26fec8bbe);
    _0x1299f8709f6a.knownOrderIds = [...new Set([...(_0x1299f8709f6a.knownOrderIds || []), _0x8fb26fec8bbe])];
    _0x1299f8709f6a.updatedAt = _0x6829f6ce88f3;
    _0xc70b7be9a6b7(_0xd2778b9343ba, _0x4cbcf6dd9e80(49686), _0xc3cbc3cacde9.isCombined
        ? (_0x4cbcf6dd9e80(49874) + _0xc3cbc3cacde9.rowIndexes.length + _0x4cbcf6dd9e80(49869) + _0x8fb26fec8bbe + _0x4cbcf6dd9e80(49664)) : (_0x4cbcf6dd9e80(49868) + _0x8fb26fec8bbe + _0x4cbcf6dd9e80(49664)), _0x22866340332c.rowNumber);
    const _0xd544feab18a6 = {
        [_0x21777dfa17c3.RUN_STATE]: _0x1299f8709f6a,
        [_0x21777dfa17c3.HISTORY]: _0x832edf8f433d,
        [_0x21777dfa17c3.ORDER_INDEX]: _0x36e2088089b4,
        [_0x21777dfa17c3.LOGS]: _0xd2778b9343ba
    };
    await chrome.storage.local.set(_0xd544feab18a6);
    if (_0xc3cbc3cacde9.isCombined) {
        await chrome.storage.local.remove(_0x21777dfa17c3.CART_LOCK);
        _0xc70b7be9a6b7(_0xd2778b9343ba, _0x4cbcf6dd9e80(49686), _0x4cbcf6dd9e80(49871), _0x22866340332c.rowNumber);
        await chrome.storage.local.set({ [_0x21777dfa17c3.LOGS]: _0xd2778b9343ba });
    }
    await _0x692a17365254(_0x1299f8709f6a, _0xd2778b9343ba, _0x4cbcf6dd9e80(49509), _0xf5767a497dd7(_0x1299f8709f6a.orderIntervalSeconds, _0xabf6b76ade62.orderIntervalSeconds));
    return { ok: true, orderId: _0x8fb26fec8bbe };
}
async function _0xca8e32a897bd() {
    const _0x6412b2dd7b68 = await _0x603145195ada();
    const _0xcb9eaa20c58e = _0x6412b2dd7b68[_0x21777dfa17c3.RUN_STATE];
    const _0x866672644d70 = Array.isArray(_0x6412b2dd7b68[_0x21777dfa17c3.LOGS]) ? _0x6412b2dd7b68[_0x21777dfa17c3.LOGS] : [];
    if (!_0xcb9eaa20c58e || !_0xf9204977f1d4.has(_0xcb9eaa20c58e.mode) || _0xcb9eaa20c58e.mode === _0x4cbcf6dd9e80(49624)) {
        return { ok: false, error: _0x4cbcf6dd9e80(49870) };
    }
    const _0x8139f2ec53e1 = _0xc77f4848e0bd(_0xcb9eaa20c58e);
    const _0x057c97e76787 = _0xa933c8eed5e2(_0xcb9eaa20c58e);
    if (_0xcb9eaa20c58e.phase === _0x4cbcf6dd9e80(49508)) {
        const _0x837d01884ace = _0xf0e30f6bb0ca(_0xcb9eaa20c58e);
        await _0xe26d015b0a8e(_0xcb9eaa20c58e.runId);
        _0xcb9eaa20c58e.intervalEndsAt = null;
        _0xcb9eaa20c58e.intervalRemainingSeconds = Math.ceil(_0x837d01884ace / 1000);
    }
    _0xcb9eaa20c58e.mode = _0x4cbcf6dd9e80(49624);
    _0xcb9eaa20c58e.pauseReason = _0x4cbcf6dd9e80(49865);
    _0xcb9eaa20c58e.updatedAt = new Date().toISOString();
    const _0x8601ab37df85 = _0xcb9eaa20c58e.phase === _0x4cbcf6dd9e80(49508)
        ? (_0x4cbcf6dd9e80(49864) + _0xcb9eaa20c58e.intervalRemainingSeconds + _0x4cbcf6dd9e80(49867)) : _0x4cbcf6dd9e80(49664);
    if (_0x8139f2ec53e1?.isCombined) {
        _0x7bffd74ea3dc(_0xcb9eaa20c58e.rows, _0x8139f2ec53e1, (_0x4cbcf6dd9e80(49865) + _0x8601ab37df85 + _0x4cbcf6dd9e80(49664)));
    }
    else if (_0x057c97e76787) {
        _0x43b6a7957fcd(_0x057c97e76787, (_0x4cbcf6dd9e80(49866) + _0x8601ab37df85 + _0x4cbcf6dd9e80(49664)), _0x4cbcf6dd9e80(49685));
    }
    _0xc70b7be9a6b7(_0x866672644d70, _0x4cbcf6dd9e80(49714), _0x4cbcf6dd9e80(49861), _0x057c97e76787?.rowNumber ?? null);
    await _0xd68338758035(_0xcb9eaa20c58e, _0x866672644d70);
    return { ok: true };
}
async function _0x8f7ac5262c13() {
    const _0x0739e95e7854 = await _0x603145195ada();
    const _0x1fc707b61906 = _0x0739e95e7854[_0x21777dfa17c3.RUN_STATE];
    const _0x19d84cd31806 = Array.isArray(_0x0739e95e7854[_0x21777dfa17c3.LOGS]) ? _0x0739e95e7854[_0x21777dfa17c3.LOGS] : [];
    const _0x25433e5a1383 = _0x0739e95e7854[_0x21777dfa17c3.CART_LOCK] || null;
    if (!_0x1fc707b61906 || _0x1fc707b61906.mode !== _0x4cbcf6dd9e80(49624)) {
        return { ok: false, error: _0x4cbcf6dd9e80(49860) };
    }
    if (_0x1fc707b61906.phase === _0x4cbcf6dd9e80(49707)) {
        return { ok: false, error: _0x4cbcf6dd9e80(49863) };
    }
    const _0xe711949265f4 = _0xc77f4848e0bd(_0x1fc707b61906);
    const _0x853e50caabc1 = _0xa933c8eed5e2(_0x1fc707b61906);
    if (_0xe711949265f4?.isCombined && _0x6843391fe37b.has(_0x1fc707b61906.phase) && !_0xbc5b9eab3e5d(_0x25433e5a1383, _0x1fc707b61906, _0xe711949265f4)) {
        return { ok: false, error: _0x4cbcf6dd9e80(49862) };
    }
    if (_0x1fc707b61906.phase === _0x4cbcf6dd9e80(49508)) {
        const _0x99983f9e531d = Math.max(0, Number(_0x1fc707b61906.intervalRemainingSeconds || 0) * 1000);
        _0x1fc707b61906.mode = _0x4cbcf6dd9e80(49627);
        _0x1fc707b61906.pauseReason = _0x4cbcf6dd9e80(49664);
        _0x1fc707b61906.intervalEndsAt = new Date(Date.now() + _0x99983f9e531d).toISOString();
        _0x1fc707b61906.intervalRemainingSeconds = Math.ceil(_0x99983f9e531d / 1000);
        _0x1fc707b61906.updatedAt = new Date().toISOString();
        if (_0xe711949265f4) {
            _0xe1f605a7091c(_0x1fc707b61906.rows, _0xe711949265f4, (_0x4cbcf6dd9e80(49511) + _0x1fc707b61906.intervalRemainingSeconds + _0x4cbcf6dd9e80(49510)));
        }
        _0xc70b7be9a6b7(_0x19d84cd31806, _0x4cbcf6dd9e80(49719), _0x4cbcf6dd9e80(49921), _0x853e50caabc1?.rowNumber ?? null);
        await _0xd68338758035(_0x1fc707b61906, _0x19d84cd31806);
        if (_0x99983f9e531d <= 0) {
            await _0x2eb21256f3e4(_0x1fc707b61906.runId);
        }
        else {
            await _0x40f5546ca56c(_0x1fc707b61906, _0x99983f9e531d);
        }
        return { ok: true };
    }
    let _0x13327539ef3a = false;
    if (Number.isInteger(_0x1fc707b61906.workTabId)) {
        try {
            await chrome.tabs.get(_0x1fc707b61906.workTabId);
            _0x13327539ef3a = true;
        }
        catch {
            _0x13327539ef3a = false;
        }
    }
    if (!_0x13327539ef3a) {
        const _0x5e8e78b7a282 = [_0x4cbcf6dd9e80(49527), _0x4cbcf6dd9e80(49524), _0x4cbcf6dd9e80(49560), _0x4cbcf6dd9e80(49564)].includes(_0x1fc707b61906.phase);
        if (!_0x5e8e78b7a282 || !_0x853e50caabc1?.amzLink || _0x0739e95e7854[_0x21777dfa17c3.CART_LOCK]) {
            return {
                ok: false,
                error: _0x4cbcf6dd9e80(49920)
            };
        }
        _0x1fc707b61906.workTabId = await _0x3a18869c73a9(null);
    }
    _0x1fc707b61906.mode = _0x4cbcf6dd9e80(49625);
    _0x1fc707b61906.pauseReason = _0x4cbcf6dd9e80(49664);
    _0x1fc707b61906.updatedAt = new Date().toISOString();
    if (_0xe711949265f4?.isCombined) {
        _0xe1f605a7091c(_0x1fc707b61906.rows, _0xe711949265f4, _0x4cbcf6dd9e80(49923));
    }
    else if (_0x853e50caabc1) {
        _0x43b6a7957fcd(_0x853e50caabc1, _0x4cbcf6dd9e80(49922), _0x4cbcf6dd9e80(49687));
    }
    _0xc70b7be9a6b7(_0x19d84cd31806, _0x4cbcf6dd9e80(49719), _0x4cbcf6dd9e80(49917), _0x853e50caabc1?.rowNumber ?? null);
    await _0xd68338758035(_0x1fc707b61906, _0x19d84cd31806);
    if (!_0x13327539ef3a && _0x853e50caabc1?.amzLink) {
        await _0x41e77a857846(_0x1fc707b61906.workTabId, _0x853e50caabc1.amzLink);
    }
    else {
        await _0x49c0aaeecf35(_0x1fc707b61906.workTabId);
    }
    return { ok: true };
}
async function _0xd559b6cb9394() {
    const _0x707c5327b901 = await _0x603145195ada();
    const _0x956cc89f839a = _0x707c5327b901[_0x21777dfa17c3.RUN_STATE];
    const _0x451c0c275789 = Array.isArray(_0x707c5327b901[_0x21777dfa17c3.LOGS]) ? _0x707c5327b901[_0x21777dfa17c3.LOGS] : [];
    const _0x82eb831fa38b = _0x707c5327b901[_0x21777dfa17c3.CART_LOCK] || null;
    if (!_0x956cc89f839a || !_0xf9204977f1d4.has(_0x956cc89f839a.mode)) {
        return { ok: false, error: _0x4cbcf6dd9e80(49916) };
    }
    const _0xfc26e84d04c4 = _0xc77f4848e0bd(_0x956cc89f839a);
    const _0x1a5ffde15996 = _0xa933c8eed5e2(_0x956cc89f839a);
    const _0x96b4a44a4581 = _0x956cc89f839a.phase;
    if (_0x96b4a44a4581 === _0x4cbcf6dd9e80(49508)) {
        await _0xe26d015b0a8e(_0x956cc89f839a.runId);
    }
    _0x956cc89f839a.mode = _0x4cbcf6dd9e80(49503);
    _0x956cc89f839a.phase = _0x4cbcf6dd9e80(49919);
    _0x956cc89f839a.pauseReason = _0x4cbcf6dd9e80(49664);
    _0x956cc89f839a.intervalEndsAt = null;
    _0x956cc89f839a.intervalRemainingSeconds = 0;
    _0x956cc89f839a.updatedAt = new Date().toISOString();
    const _0xe304c4c90826 = _0xbc5b9eab3e5d(_0x82eb831fa38b, _0x956cc89f839a, _0xfc26e84d04c4);
    const _0x34543f2ac595 = _0xe304c4c90826 ? _0x4cbcf6dd9e80(49918) : _0xa963c5cdea9b.has(_0x96b4a44a4581)
        ? _0x4cbcf6dd9e80(49913) : _0x4cbcf6dd9e80(49912);
    if (_0xfc26e84d04c4?.isCombined) {
        _0x7bffd74ea3dc(_0x956cc89f839a.rows, _0xfc26e84d04c4, _0x34543f2ac595);
    }
    else if (_0x1a5ffde15996 && (_0x1a5ffde15996.result === _0x4cbcf6dd9e80(49687) || _0x1a5ffde15996.result === _0x4cbcf6dd9e80(49685))) {
        _0x43b6a7957fcd(_0x1a5ffde15996, _0x34543f2ac595, _0x4cbcf6dd9e80(49685));
    }
    _0xc70b7be9a6b7(_0x451c0c275789, _0x4cbcf6dd9e80(49714), _0xe304c4c90826 ? _0x4cbcf6dd9e80(49915) : _0xa963c5cdea9b.has(_0x96b4a44a4581)
        ? _0x4cbcf6dd9e80(49914) : _0x4cbcf6dd9e80(49909), _0x1a5ffde15996?.rowNumber ?? null);
    await _0xd68338758035(_0x956cc89f839a, _0x451c0c275789);
    return { ok: true };
}
async function _0x2af33b93fdae() {
    const _0xce5c36775acc = await _0x603145195ada();
    const _0x42116b2781c2 = _0xce5c36775acc[_0x21777dfa17c3.RUN_STATE] || null;
    const _0x409848cf79b0 = Array.isArray(_0xce5c36775acc[_0x21777dfa17c3.LOGS]) ? _0xce5c36775acc[_0x21777dfa17c3.LOGS] : [];
    const _0x79b7ecc901ff = _0xce5c36775acc[_0x21777dfa17c3.CART_LOCK] || null;
    if (!_0x79b7ecc901ff) {
        return { ok: true, cleared: false, message: _0x4cbcf6dd9e80(49908) };
    }
    if (_0x42116b2781c2 && [_0x4cbcf6dd9e80(49625), _0x4cbcf6dd9e80(49627)].includes(_0x42116b2781c2.mode)) {
        return { ok: false, error: _0x4cbcf6dd9e80(49911) };
    }
    if (_0x42116b2781c2 && _0x42116b2781c2.runId === _0x79b7ecc901ff.runId) {
        const _0x80c0f6b05cc1 = _0xc77f4848e0bd(_0x42116b2781c2);
        if (_0x80c0f6b05cc1?.id === _0x79b7ecc901ff.groupId) {
            _0x7bffd74ea3dc(_0x42116b2781c2.rows, _0x80c0f6b05cc1, _0x4cbcf6dd9e80(49910));
        }
        _0x42116b2781c2.mode = _0x4cbcf6dd9e80(49503);
        _0x42116b2781c2.phase = _0x4cbcf6dd9e80(49919);
        _0x42116b2781c2.pauseReason = _0x4cbcf6dd9e80(49664);
        _0x42116b2781c2.updatedAt = new Date().toISOString();
    }
    _0xc70b7be9a6b7(_0x409848cf79b0, _0x4cbcf6dd9e80(49714), (_0x4cbcf6dd9e80(49905) + (_0x79b7ecc901ff.groupId || _0x4cbcf6dd9e80(49904)) + _0x4cbcf6dd9e80(49907)));
    await chrome.storage.local.remove(_0x21777dfa17c3.CART_LOCK);
    await chrome.storage.local.set({
        [_0x21777dfa17c3.RUN_STATE]: _0x42116b2781c2,
        [_0x21777dfa17c3.LOGS]: _0x409848cf79b0
    });
    return { ok: true, cleared: true };
}
async function _0xce41d296767e(_0x9b2939173d7b, _0x6bf0bafae957) {
    const _0x6da8e6765da5 = await _0x603145195ada();
    const _0x484b8ef10b23 = _0x6da8e6765da5[_0x21777dfa17c3.RUN_STATE];
    const _0xc49d5c7f8d43 = Array.isArray(_0x6da8e6765da5[_0x21777dfa17c3.LOGS]) ? _0x6da8e6765da5[_0x21777dfa17c3.LOGS] : [];
    if (!_0x484b8ef10b23 || _0x6bf0bafae957.tab?.id !== _0x484b8ef10b23.workTabId || _0x484b8ef10b23.runId !== _0x9b2939173d7b.runId) {
        return { ok: false, stale: true };
    }
    const _0x8f4cd444ad4f = _0xa933c8eed5e2(_0x484b8ef10b23);
    _0xc70b7be9a6b7(_0xc49d5c7f8d43, _0x9b2939173d7b.level || _0x4cbcf6dd9e80(49719), String(_0x9b2939173d7b.message || _0x4cbcf6dd9e80(49664)), _0x8f4cd444ad4f?.rowNumber ?? null);
    await chrome.storage.local.set({ [_0x21777dfa17c3.LOGS]: _0xc49d5c7f8d43 });
    return { ok: true };
}
async function _0xdc6fe8870e9c(_0x22106925c9af) {
    const _0x381b5ebd2a56 = await chrome.storage.local.get(_0x21777dfa17c3.RUN_STATE);
    const _0x57f470b3e5ad = _0x381b5ebd2a56[_0x21777dfa17c3.RUN_STATE];
    if (_0x57f470b3e5ad && _0xf9204977f1d4.has(_0x57f470b3e5ad.mode)) {
        return { ok: false, error: _0x4cbcf6dd9e80(49906) };
    }
    await chrome.storage.local.set({
        [_0x21777dfa17c3.DRAFT_ROWS]: Array.isArray(_0x22106925c9af) ? _0x22106925c9af : []
    });
    return { ok: true };
}
async function _0x3e9eab149477() {
    const _0xe45cc4cbe476 = await chrome.storage.local.get([_0x21777dfa17c3.RUN_STATE, _0x21777dfa17c3.CART_LOCK]);
    const _0x8d79d80a7960 = _0xe45cc4cbe476[_0x21777dfa17c3.RUN_STATE];
    if (_0x8d79d80a7960 && _0xf9204977f1d4.has(_0x8d79d80a7960.mode)) {
        return { ok: false, error: _0x4cbcf6dd9e80(49901) };
    }
    if (_0xe45cc4cbe476[_0x21777dfa17c3.CART_LOCK]) {
        return { ok: false, error: _0x4cbcf6dd9e80(49900) };
    }
    await chrome.storage.local.set({
        [_0x21777dfa17c3.DRAFT_ROWS]: [],
        [_0x21777dfa17c3.RUN_STATE]: null
    });
    return { ok: true };
}
async function _0xd61430395274() {
    await chrome.storage.local.set({ [_0x21777dfa17c3.LOGS]: [] });
    return { ok: true };
}
async function _0x63f8c9c922fb(_0x1382d96c5d40) {
    const _0x8778b29eb44c = _0x1382d96c5d40?.orderIntervalSeconds;
    const _0x5f01d99be263 = Number(_0x8778b29eb44c);
    if (!Number.isInteger(_0x5f01d99be263) || _0x5f01d99be263 < 0 || _0x5f01d99be263 > 3600) {
        return { ok: false, error: _0x4cbcf6dd9e80(49717) };
    }
    const _0x3e655caf2bee = await chrome.storage.local.get(_0x21777dfa17c3.SETTINGS);
    return {
        ok: true,
        settings: _0xa85f13940f9b(_0x3e655caf2bee[_0x21777dfa17c3.SETTINGS]),
        pendingOrderIntervalSeconds: _0x5f01d99be263
    };
}
async function _0x636dfbeb5e0e() {
    const _0x70f2219cacf6 = await _0x603145195ada();
    const _0xfb56b6409e4a = _0x70f2219cacf6[_0x21777dfa17c3.RUN_STATE];
    if (_0xfb56b6409e4a && _0xf9204977f1d4.has(_0xfb56b6409e4a.mode)) {
        return { ok: false, error: _0x4cbcf6dd9e80(49903) };
    }
    const _0xc4819edc1c16 = _0xac1031e3efac();
    const _0x6aedb40f51eb = Array.isArray(_0x70f2219cacf6[_0x21777dfa17c3.LOGS]) ? _0x70f2219cacf6[_0x21777dfa17c3.LOGS] : [];
    const _0xf740059d0988 = _0xaeb8aa4ec5d7(_0x70f2219cacf6[_0x21777dfa17c3.HISTORY]);
    const _0x714676ce4c62 = _0xf0ccabd2d36d(_0x70f2219cacf6[_0x21777dfa17c3.ORDER_INDEX], _0xf740059d0988);
    const _0xbd9a93c213b6 = new Set();
    for (const [_0x28791c0d74ef, _0x06a95ebb82bb] of Object.entries(_0x714676ce4c62)) {
        if (_0x06a95ebb82bb?.status === _0x4cbcf6dd9e80(49639) && _0x06a95ebb82bb.dateKey === _0xc4819edc1c16 && _0xde4244574fd5(_0x06a95ebb82bb.orderId)) {
            _0xbd9a93c213b6.add(_0x40f4a8626ae8(_0x06a95ebb82bb.temuOrderId));
            delete _0x714676ce4c62[_0x28791c0d74ef];
        }
    }
    const _0x12d0b1719b2c = _0xf740059d0988.filter((_0xabd33ef44db6) => {
        const _0x39794c420ed1 = _0xabd33ef44db6.status === _0x4cbcf6dd9e80(49639) &&
            _0xabd33ef44db6.dateKey === _0xc4819edc1c16 &&
            _0xde4244574fd5(_0xabd33ef44db6.orderId);
        if (_0x39794c420ed1) {
            _0xbd9a93c213b6.add(_0x40f4a8626ae8(_0xabd33ef44db6.temuOrderIdKey || _0xabd33ef44db6.temuOrderId));
        }
        return !_0x39794c420ed1;
    });
    _0xc70b7be9a6b7(_0x6aedb40f51eb, _0x4cbcf6dd9e80(49714), (_0x4cbcf6dd9e80(49902) + _0xbd9a93c213b6.size + _0x4cbcf6dd9e80(49897) + _0xc4819edc1c16 + _0x4cbcf6dd9e80(49896)));
    await chrome.storage.local.set({
        [_0x21777dfa17c3.HISTORY]: _0x12d0b1719b2c,
        [_0x21777dfa17c3.ORDER_INDEX]: _0x714676ce4c62,
        [_0x21777dfa17c3.LOGS]: _0x6aedb40f51eb
    });
    return { ok: true, clearedCount: _0xbd9a93c213b6.size, dateKey: _0xc4819edc1c16 };
}
async function _0xe96558850cce() {
    const _0xf1a9bd7d06c9 = await _0x603145195ada();
    const _0x2f3351e1e4e5 = _0xf1a9bd7d06c9[_0x21777dfa17c3.RUN_STATE];
    if (!_0x2f3351e1e4e5 || _0x2f3351e1e4e5.mode !== _0x4cbcf6dd9e80(49627) || _0x2f3351e1e4e5.phase !== _0x4cbcf6dd9e80(49508) || !_0x2f3351e1e4e5.runId) {
        return { ok: false, stale: true };
    }
    const _0x212a1bee28aa = _0xf0e30f6bb0ca(_0x2f3351e1e4e5);
    if (_0x212a1bee28aa <= 0) {
        return _0x2eb21256f3e4(_0x2f3351e1e4e5.runId);
    }
    await _0x40f5546ca56c(_0x2f3351e1e4e5, _0x212a1bee28aa);
    return { ok: true, waiting: true };
}
async function _0xa2238fd6a8fd(_0x8e87c973829b) {
    const _0xb03836ae6b58 = await chrome.storage.local.get([_0x21777dfa17c3.RUN_STATE, _0x21777dfa17c3.CART_LOCK]);
    const _0x59e761390dc3 = _0xb03836ae6b58[_0x21777dfa17c3.RUN_STATE] || null;
    const _0x5a5272f7959f = Boolean(_0x59e761390dc3 && _0x8e87c973829b.tab?.id === _0x59e761390dc3.workTabId);
    const _0xcdf71a13f818 = _0x5a5272f7959f ? _0xc77f4848e0bd(_0x59e761390dc3) : null;
    return {
        ok: true,
        isWorkTab: _0x5a5272f7959f,
        state: _0x59e761390dc3,
        row: _0x5a5272f7959f ? _0xa933c8eed5e2(_0x59e761390dc3) : null,
        group: _0xcdf71a13f818,
        orderRow: _0x5a5272f7959f ? _0xe7759fd6c561(_0x59e761390dc3) : null,
        cartLock: _0x5a5272f7959f ? _0xb03836ae6b58[_0x21777dfa17c3.CART_LOCK] || null : null
    };
}
chrome.action.onClicked.addListener(() => {
    _0xe1bc71889e25().catch((_0xf227104315c0) => console.error(_0x4cbcf6dd9e80(49899), _0xf227104315c0));
});
chrome.runtime.onInstalled.addListener(() => {
    _0xe8a3692c3553(async () => {
        const _0x68c51c39a309 = await _0x603145195ada();
        const _0x451f9b1579d1 = _0xaeb8aa4ec5d7(_0x68c51c39a309[_0x21777dfa17c3.HISTORY]);
        const _0xfa7dd1174bbd = _0xf0ccabd2d36d(_0x68c51c39a309[_0x21777dfa17c3.ORDER_INDEX], _0x451f9b1579d1);
        const _0x423250250ee8 = Array.isArray(_0x68c51c39a309[_0x21777dfa17c3.LOGS]) ? _0x68c51c39a309[_0x21777dfa17c3.LOGS] : [];
        const _0x1261c51572ad = _0xa85f13940f9b(_0x68c51c39a309[_0x21777dfa17c3.SETTINGS]);
        const _0x730199ed47bf = Array.isArray(_0x68c51c39a309[_0x21777dfa17c3.DRAFT_ROWS]) ? _0x68c51c39a309[_0x21777dfa17c3.DRAFT_ROWS] : [];
        const _0xcaefd0952f50 = _0x68c51c39a309[_0x21777dfa17c3.CART_LOCK] || null;
        let _0x1dc1aa1b38d9 = _0x68c51c39a309[_0x21777dfa17c3.RUN_STATE] || null;
        if (_0x1dc1aa1b38d9 && _0xf9204977f1d4.has(_0x1dc1aa1b38d9.mode) && Number(_0x1dc1aa1b38d9.version || 0) < _0x943a7b8eb231) {
            const _0x55315cc7ab99 = _0xa933c8eed5e2(_0x1dc1aa1b38d9);
            if (_0x55315cc7ab99) {
                _0x43b6a7957fcd(_0x55315cc7ab99, _0x4cbcf6dd9e80(49898), _0x4cbcf6dd9e80(49685));
            }
            _0x1dc1aa1b38d9 = {
                ..._0x1dc1aa1b38d9,
                version: _0x943a7b8eb231,
                mode: _0x4cbcf6dd9e80(49503),
                phase: _0x4cbcf6dd9e80(49919),
                pauseReason: _0x4cbcf6dd9e80(49664),
                intervalEndsAt: null,
                intervalRemainingSeconds: 0,
                updatedAt: new Date().toISOString()
            };
            _0xc70b7be9a6b7(_0x423250250ee8, _0x4cbcf6dd9e80(49714), _0x4cbcf6dd9e80(49893));
        }
        if (_0xcaefd0952f50) {
            _0xc70b7be9a6b7(_0x423250250ee8, _0x4cbcf6dd9e80(49714), _0x4cbcf6dd9e80(49892));
        }
        await chrome.storage.local.set({
            [_0x21777dfa17c3.RUN_STATE]: _0x1dc1aa1b38d9,
            [_0x21777dfa17c3.HISTORY]: _0x451f9b1579d1,
            [_0x21777dfa17c3.ORDER_INDEX]: _0xfa7dd1174bbd,
            [_0x21777dfa17c3.LOGS]: _0x423250250ee8,
            [_0x21777dfa17c3.DRAFT_ROWS]: _0x730199ed47bf,
            [_0x21777dfa17c3.SETTINGS]: _0x1261c51572ad
        });
        if (_0x1dc1aa1b38d9?.mode === _0x4cbcf6dd9e80(49627) && _0x1dc1aa1b38d9.phase === _0x4cbcf6dd9e80(49508)) {
            await _0xe96558850cce();
        }
    }).catch((_0x215cbf2061a4) => console.error(_0x215cbf2061a4));
});
chrome.runtime.onStartup.addListener(() => {
    _0xe8a3692c3553(_0xe96558850cce).catch((_0x77a82fb13998) => console.error(_0x77a82fb13998));
});
chrome.alarms.onAlarm.addListener((_0x8355cf276c97) => {
    if (!_0x8355cf276c97?.name?.startsWith(_0xc1fe486716a7)) {
        return;
    }
    const _0xe7bf5dad8d55 = _0x8355cf276c97.name.slice(_0xc1fe486716a7.length);
    _0xe8a3692c3553(() => _0x2eb21256f3e4(_0xe7bf5dad8d55)).catch((_0xac928de858d1) => console.error(_0xac928de858d1));
});
chrome.runtime.onMessage.addListener((_0x030b6efeb447, _0x65847b46b775, _0xd81362293e95) => {
    const _0x2e3fc70c0d1b = (_0x5a646d4e2e75) => {
        _0x5a646d4e2e75.then((_0x0c0ae0a853e6) => _0xd81362293e95(_0x0c0ae0a853e6))
            .catch((_0x85a17670c68b) => {
            console.error(_0x85a17670c68b);
            _0xd81362293e95({ ok: false, error: _0x85a17670c68b.message || String(_0x85a17670c68b) });
        });
    };
    switch (_0x030b6efeb447?.type) {
        case _0x4cbcf6dd9e80(49895):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(_0xeec4ef20173a));
            return true;
        case _0x4cbcf6dd9e80(49894):
            _0x2e3fc70c0d1b(_0xf768835a0775(false));
            return true;
        case _0x4cbcf6dd9e80(49606):
            _0xd81362293e95({ ok: true });
            return false;
        case _0x4cbcf6dd9e80(49953):
            _0x2e3fc70c0d1b(_0x52115b46564d(_0x65847b46b775));
            return true;
        case _0x4cbcf6dd9e80(49952):
            _0x2e3fc70c0d1b(_0xa193a8de4588());
            return true;
        case _0x4cbcf6dd9e80(49955):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0x9b7a20193054(() => _0x5eb404f81b46(_0x030b6efeb447.rows, _0x030b6efeb447.orderIntervalSeconds))));
            return true;
        case _0x4cbcf6dd9e80(49954):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0x9b7a20193054(() => _0x6ac461b238b8(_0x030b6efeb447.rows, _0x030b6efeb447.orderIntervalSeconds))));
            return true;
        case _0x4cbcf6dd9e80(49949):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0x9b7a20193054(() => _0xdc6fe8870e9c(_0x030b6efeb447.rows))));
            return true;
        case _0x4cbcf6dd9e80(49948):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0x9b7a20193054(_0x3e9eab149477)));
            return true;
        case _0x4cbcf6dd9e80(49951):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0x9b7a20193054(_0xd61430395274)));
            return true;
        case _0x4cbcf6dd9e80(49950):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0x9b7a20193054(() => _0x63f8c9c922fb(_0x030b6efeb447.settings))));
            return true;
        case _0x4cbcf6dd9e80(49945):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0x9b7a20193054(_0x636dfbeb5e0e)));
            return true;
        case _0x4cbcf6dd9e80(49944):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0x9b7a20193054(_0x2af33b93fdae)));
            return true;
        case _0x4cbcf6dd9e80(49947):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0xbc8db8cd7917(_0x030b6efeb447, _0x65847b46b775)));
            return true;
        case _0x4cbcf6dd9e80(49946):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0x151fc24d4794(_0x030b6efeb447, _0x65847b46b775)));
            return true;
        case _0x4cbcf6dd9e80(49941):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0x9b7a20193054(() => _0x4d92dceed7ed(_0x030b6efeb447, _0x65847b46b775))));
            return true;
        case _0x4cbcf6dd9e80(49940):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0xce41d296767e(_0x030b6efeb447, _0x65847b46b775)));
            return true;
        case _0x4cbcf6dd9e80(49943):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0x9b7a20193054(() => _0xae14c8d6d6cc(_0x030b6efeb447, _0x65847b46b775, false))));
            return true;
        case _0x4cbcf6dd9e80(49942):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0x9b7a20193054(() => _0xa0f34c03e71a(_0x030b6efeb447, _0x65847b46b775))));
            return true;
        case _0x4cbcf6dd9e80(49937):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0x9b7a20193054(() => _0x76089b6dc9c4(_0x030b6efeb447, _0x65847b46b775))));
            return true;
        case _0x4cbcf6dd9e80(49936):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0x9b7a20193054(() => _0xbbb10831cc5b(_0x030b6efeb447, _0x65847b46b775))));
            return true;
        case _0x4cbcf6dd9e80(49939):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0x9b7a20193054(() => _0x1f143af89125(_0x030b6efeb447, _0x65847b46b775))));
            return true;
        case _0x4cbcf6dd9e80(49938):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0x9b7a20193054(() => _0x4ab7513bb29c(_0x030b6efeb447, _0x65847b46b775))));
            return true;
        case _0x4cbcf6dd9e80(49933):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0x9b7a20193054(() => _0x36da2c14184a(_0x030b6efeb447, _0x65847b46b775))));
            return true;
        case _0x4cbcf6dd9e80(49932):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0xb7f285a20f90(_0x030b6efeb447, _0x65847b46b775)));
            return true;
        case _0x4cbcf6dd9e80(49935):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0x9b7a20193054(_0xca8e32a897bd)));
            return true;
        case _0x4cbcf6dd9e80(49934):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0x9b7a20193054(_0x8f7ac5262c13)));
            return true;
        case _0x4cbcf6dd9e80(49929):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0x9b7a20193054(_0xd559b6cb9394)));
            return true;
        case _0x4cbcf6dd9e80(49928):
            _0x2e3fc70c0d1b(_0xe8a3692c3553(() => _0x9b7a20193054(() => _0xae14c8d6d6cc({ reason: _0x4cbcf6dd9e80(49882) }, null, true))));
            return true;
        case _0x4cbcf6dd9e80(49931):
            _0x2e3fc70c0d1b(_0x9b7a20193054(() => chrome.storage.local
                .get(_0x21777dfa17c3.RUN_STATE)
                .then((_0x101257d007e7) => _0x7bf4ab7c3df0(_0x101257d007e7[_0x21777dfa17c3.RUN_STATE]?.workTabId))
                .then(() => ({ ok: true }))));
            return true;
        default:
            return false;
    }
});
chrome.tabs.onRemoved.addListener((_0xa65839958c33) => {
    _0xe8a3692c3553(async () => {
        const _0xc365288ba8fb = await _0x603145195ada();
        const _0xe0606f955fc5 = _0xc365288ba8fb[_0x21777dfa17c3.RUN_STATE];
        if (!_0xe0606f955fc5 || _0xa65839958c33 !== _0xe0606f955fc5.workTabId || !_0xf9204977f1d4.has(_0xe0606f955fc5.mode)) {
            return;
        }
        const _0x5e52e673510c = Array.isArray(_0xc365288ba8fb[_0x21777dfa17c3.LOGS]) ? _0xc365288ba8fb[_0x21777dfa17c3.LOGS] : [];
        const _0x7eea6c525f66 = _0xc77f4848e0bd(_0xe0606f955fc5);
        const _0x44035febd03b = _0xa933c8eed5e2(_0xe0606f955fc5);
        const _0x1857f4203ca3 = _0xc365288ba8fb[_0x21777dfa17c3.CART_LOCK] || null;
        _0xe0606f955fc5.workTabId = null;
        _0xe0606f955fc5.updatedAt = new Date().toISOString();
        if (_0xe0606f955fc5.phase === _0x4cbcf6dd9e80(49508) && _0xe0606f955fc5.mode === _0x4cbcf6dd9e80(49627)) {
            _0xc70b7be9a6b7(_0x5e52e673510c, _0x4cbcf6dd9e80(49714), _0x4cbcf6dd9e80(49930), _0x44035febd03b?.rowNumber ?? null);
            await _0xd68338758035(_0xe0606f955fc5, _0x5e52e673510c);
            return;
        }
        _0xe0606f955fc5.mode = _0x4cbcf6dd9e80(49624);
        _0xe0606f955fc5.pauseReason = _0xbc5b9eab3e5d(_0x1857f4203ca3, _0xe0606f955fc5, _0x7eea6c525f66)
            ? _0x4cbcf6dd9e80(49925) : _0x4cbcf6dd9e80(49924);
        if (_0x7eea6c525f66?.isCombined) {
            _0x7bffd74ea3dc(_0xe0606f955fc5.rows, _0x7eea6c525f66, _0xe0606f955fc5.pauseReason);
        }
        else if (_0x44035febd03b) {
            _0x43b6a7957fcd(_0x44035febd03b, (_0x4cbcf6dd9e80(49684) + _0xe0606f955fc5.pauseReason + _0x4cbcf6dd9e80(49664)), _0x4cbcf6dd9e80(49685));
        }
        _0xc70b7be9a6b7(_0x5e52e673510c, _0x4cbcf6dd9e80(49665), _0xe0606f955fc5.pauseReason, _0x44035febd03b?.rowNumber ?? null);
        await _0xd68338758035(_0xe0606f955fc5, _0x5e52e673510c);
    }).catch((_0x7ca2bd1e4b2c) => console.error(_0x7ca2bd1e4b2c));
});})();
