(()=>{'use strict';const _0xa52de76c67d0=Object.freeze(["HQAWFwAXFg==","BgATHAEbBhsdHBscFQ==","BRMbBg0TFhYAFwEBDRQdAB8=","IjMrPzc8Jh83Jjo9NhMmJjc/IiY3Ng==","IDczNit/Jj1/MTo3MTk9JyY=","HQAWFwANAQcRERcBAQ==","tunpt9jzten1ten/tNv1uvPesdLQ","tunpt9jzuu3CuvPetM7Nu8XmturfutHvtu38tMbruuzBt9f3tMfitN/8sdLQ","tenWt8Lat9/Hu/DWtPHStM33ve7ItP/xt876tPLqt/3rt8fUt8HT","BhsfFx0HBg==","BBcAGxQLDQITCx8XHAYNHBMfFw==","tODztM7bu87SuvTTturZt9/HtcjWtM7btMfat87it8/StenWve7etunpt9jztenBtM/NsdLQ","BRMbBg0bHAYXAAQTHg==","tNvStM7btM7btMfat87it8/StenWt/bWtcLUt/zetNrCsdLQ","AQYTAAYNAAcc","tu3ztNP9turft/zetMfmve7euuXhuu3V","EBcUHQAXDRQbHBMeDQEHEB8bBg==","tPHStOfZt9ritM74tOrXu8v2tcjWtenWt8Lat9/Huub/tdv7tf38u8bTve7JtMTitunpt9jztu7IuvD5u8rptP/wve7etcnmt9ritujot+X3tPHStM33t+vktOrXu8v2uv33u8bTsdLQ","MT0/Ij43Jjc2","Mz8oHSA2NyAaOyEmPSAr","tenWt8Lat9/Ht8fUt8HTt+Xgt9f6u9H6t9jyt9f3uub/tdv7tf38ve7et9XUt/bVcgIgPTE3NzZyJj1yETo3MTk9JyY=","tenWt8Lat9/Hu/DWtPHStM33t8nMtu7ytcjWtMfiu9XdtMXytMfasdLQ","tODztM7bt939t/bWtcLUtcjWtMfitN/8uvPesdLQ","t9/HuvPet87it8/StenWten1ten/tu/ttcb6chAnK3IcPSW97sm3wt639cG3wt+26sa3/N60x+a3zuK3z9K1yeq3wt61yNa39si68963zuK3z9K16da27+21xvpyEzY2ciY9cjAzITk3JnK3wtq36+S26tm338ex0tA=","tMfiu9XdtPLut+7du8bLuv39ve7euuXhuu3V","tenWt8Lat9/Hu/DWtPHStM33t9rVtN/wt8fUt8HTtPLVtf/su/Pn","MD49MTk3Ng==","tenWt8Lat9/Hu/DWtPHStM33t9vftfP8uvz2uub/tdv7tf38tMfiu9XdturoYrHS0A==","t//Kt876tM74tOrXu8v2tcjWtenWt8Lat9/Huub/tdv7tf38t/zbt9f6u8bTve7eturfutHvt8L9t9j6u9XfturZtunpt9jzsdLQ","Mz8ofz0gNjcgfzs8JjcgJDM+aA==","Mz8oETMgJhAnOz42Ozw1Hj0xOQ==","tenWt8Lat9/Huub/tdv7tf38t/zbt9f6u8bTt+Xgturft//Kt876ve7eturfutHvten1ten/t+/Bt9vftunpt9jzsdLQuv3lt9POtP/wt8Lcu9XftMTit+7St/XZsdLQ","BRMZFw0TBwYdHxMGGx0c","tP/xt876tNvBt+7St8fUt8HTu/Pnu8/w","Ijc8Njs8NQ==","IDcmICsfPTY3","tenWt8Lat9/Huub/tdv7tf38t/zbt9f6u8bTturft//Kt876tNrEturct+/Bt9vft87it8/StenWturfturSutXmsdLQ","AQYdAg0ABxw=","Ex8Icj47PDm0xfK0x9q97t665eG67dU=","t+zXt/bWtcLU","tenWt8Lat9/Hu/DWtPHStM33t/zetNrC","NyoiNzEmNzYBJjMmJyE=","tunpt9jzt+Xgtujot+X3tMjQt9POsdLQ","u/DWtPHStM33t//Kt876cgY3PydyHSA2NyByGxZyt87it8/StNrEtf/st8Lft9TgtfjTve7eturfutHvtcnmtNz3ten1ten/sdLQuv3lt9POtP/wtunpt9jzt+vktu38tMbruuzBt9f3tMfitN/8sdLQ","ISY9IiI3Ng==","tP/xt+7dt9jyuub/t9vftcjWtMfiu9Xdturctcn8tPLVtMfiu9XdturfturSutXmsdLQ","tenWt8Lat9/Hu/DWtPHStM33uvPetebwt+7Ht+Xgtendt93Kt97EsdLQ","BRMbBg0CAB0WBxEG","MycmOj0gOygzJjs9PBA+PTE5NzY=","t+/Bt9vfturftMr9tenWt8Lat9/HsdLQ","tenWt8Lat9/HtP/xt+7dt9jyuub/t9rVtN/wt8fUt8HTtPLVtf/su/Pn","tunpt9jzten1ten/tNv1uvPeve7eturZt9/Hu8Xmu8jGuvzztMXktNPwt/bfsdLQ","PD0gPzM+","PT87Jg==","t+XgtPLqt/3ruub/tdv7tf38tNLptMfiu9Xdve7etP/xt876uu3Jt9f3turZt9/Hu/Pnu8/w","tM7StenatN3Ctuj2t9vftcjWtMbktunktujot/XBt8Lfturct+/Bt9vft87it8/StenWturfturSutXmsdLQ","u9XfturZtMfitN/8tur/tODztM7bt939ten1ten/turZt9/HtcjWtM7btMfat87it8/StenWve7etunpt9jztenBtM/NsdLQ","ER4XEwANERMABg0QBxseFhscFQ0eHREZ","tunpt9jzt+Xgt9POtP/wve7JERMABg0QBxseFhscFXK3/Nu31/q7xtO26d+27c+1x8ux0tC6/eW26Oi35fe08dK0zfe65v+12/u1/fy3wN60ztK67cO6/PC338e3wty31N+06te7y/a16da3wtq338e7xtOx0tA=","t+/Bt9vftODztM7bt939t9POtP/wtcjWtunpt9jzsdLQ","t+Xgt9POtP/wve7auvzwt9/HtenBtMzOtM74tfP8uvz2ve7b","t9XUt/bVtNvBt+7St8fUt8HTu/Pnu8/w","","tenWt8Lat9/Ht9f6u9H6t8fUt8HTu/DWtPHStM33u9LIuu3Vve7et9XUt/bVt876tMTitcjWtf7+turStunkt8fUt8HTtPLVtf/su/Pnt9TftP7ztPHStM33uub/tdv7tf38turotfvosdLQ","OmBh","tenWt8Lat9/HtP/xt+7dt9jyuub/uvPetebwt+7Ht+Xgtendt93Kt97EsdLQ","tNvsturft9rit+/Bt9vfturZt9/HtenWsdLQ","t9XUt/bVtenWt8Lat9/Hu/DWtPHStM33","FQAdBwINEBcUHQAXDRMWFg==","tenWt8Lat9/Hu/DWtPHStM33t9vftP/xt876tfP8uvz2uub/tdv7tf38turotfvo","IjMnITc2","ER4XEwANFgATFAYNAB0FAQ==","fDM/Myg9PHw2Nw==","t//Kt876tM74tOrXu8v2tcjWtenWt8Lat9/Huub/tdv7tf38u8bTve7eturfutHvtOrXtfvotunpt9jzuvzit+/HsdLQ","tunpt9jzuu3CuvPetM7Nu8XmturfutHvtu38tMbrtP3dt9/Hu8Xmu8jGsdLQ","EwcGGh0AGwgTBhsdHA0RGhMcFRcW","tenWt8Lat9/Ht+Xgtendt+7St/XZtMzWt+nouub/tdv7tf38ve7eturfutHvtcnmtNz3uuXhuu3VsdLQuv3lt9fatujot+X3tPHStM33uub/tdv7tf38t8DetM7Suu3Duvzwt9/Hve7et9TftOrXu8v2tenWt8Lat9/Hu8bTsdLQ","IDczNis=","JiAzPCE7Jjs9PDs8NQ==","t+/Bt9vftODztM7btenWt8Lat9/Huub/tdv7tf38t/zbt9f6u8bTsdLQ","tunpt9jzt+/Bt9vftM74uu3CuvPesdLQ","tenWt8Lat9/Hu8bTt+Xgtcbjtcb6tNrltfP8uvz2t8LctOrXu8v2ve7etunpt9jzt+Xgt9POtP/w","u9XfturZtunpt9jztur/ve7et9/HuvPetu/ttcb6chAnK3IcPSW97sm3wt639cG3wt+3wt63/N60x+a3zuK3z9K1yNa39si689671d+0xOK16da02sK65v+12/u1/fy16da3wtq338ex0tA=","AhMHARcNFwAAHQA=","tP/xt+7dt9jyuub/t9vft93Dtdzit+XgtM7btenWt8Lat9/Huub/tdv7tf38t/zbt9f6u8bTsdLQ","tPLzu/jet/bjuub3ve7euv3lutPGteHpATozPDUzPA==","BRMbBg0RGhMcFRcNExYWABcBAQ==","FQAdBwINAgAdERcXFg0RGhcRGR0HBg==","tP/xt+7dt9jyt9f3uub/tdv7tf38ve7ItP/xt876tPLqt/3rt8fUt8HT","Mz8oHSA2NyAAJzwBJjMmNw==","tunpt9jztunft876uu3CuvPeve7eturfutHvtOrXu8v2tenWt8Lat9/Huub/tdv7tf38u8bTsdLQuv3lt9fatMjQt9POtNrEt9POtP/wtunpt9jzsdLQ","BRMbBg0CEwsfFxwG","FRcGDREdHAYXCgY=","tMXytOHHt/zbtNzAturZt9/Hu8Xmu8jGve7Itunpt9jzchsWcrbq37f/yrfO+rHS0A==","BRMbBg0dABYXAA0BBxERFwEB","u9XfturZt87it8/StenWtunftN7bt9fkt876t+/Bt9vfuuzBt9f3uvP6tPLutur/tM7StMX7t9XotdzitcjWuvPet93ltuncturYt+zSturZt/bWtcLUsdLQ","BRMbBg0dABYXAA0aGwEGHQAL","FQAdBwINERMABg0XHwIGCw==","NDM7PicgNx83ISEzNTc=","ICc8PDs8NQ==","tP/xt876tN3Ctuj2tenWt8Lauvzwt9/Hve7atf/bt+zXutzlt93Ech0gNjcgchsWve7b","Ez8zKD08crfl97bvzrTy1bX/7Lvz57fl4LfX4bvF/73u3rfvwbfb37vK5LT857bq37rR77f827fX+rrV+LfY+rTT8Lf237HS0Lr95bbo6Lfl97Tx0rTN97fC3LfTzrT/8Lbp6bfY873uybrZ97TO27Xp1rfC2rffx7vG073u3rr95bXz/Lr89rrm/7Xb+7X9/LfA3rr88Lffx7fC3LTq17vL9rHS0A==","sdLT","tenWt8Lat9/Huub/tdv7tf38t/zbt9f6u8bTtMXytMfasdLQ","MTo3MTk9JyY=","t//Kt876tM74tOrXu8v2tcjWtenWt8Lat9/Huub/tdv7tf38t/zbt9f6u8bTsdLQuv3lt9fatujot+X3tPHStM33t+vktOrXu8v2sdLQ","FRcG","FycgPSI3fRA3ID47PA==","BRMbBg0fExwHEx4NExYWABcBAQ==","u/Pnu8/wtdjktNLTt+7Qt+rqsdLQ","Lg==","uuzBt9f3uvP6tPLutu3PtN7Tt9zNt/XZu/Pot+jdve7Jt87it8/StenWtN7bt9fkt876uvP6tPLutur/tM7StMX7t9XotdzitcjWuvPet93ltuncturYt+zSturZt/bWtcLUsdLQ","MycmOj0gOygzJjs9PA==","EzA9ICYXICA9IA==","tenWt8Lat9/Hu/DWtPHStM33t8nMtu7ytcjWt8fUt8HTt9/HtunltMXytMfasdLQ","JTMgPDs8NQ==","Njd/Fhc=","MDc0PSA3fzQ7ICEmfzM2Ng==","AQYdAgIXFg==","tujot+X3uuXhuu3V","t+/Bt9vftODztM7bt+XgtMjQt9POtunpt9jzsdLQ","t9/Vtej1t8Lct+Xgt9POtP/wtMX1tdvatM74tenBtM/Ntunpt9jzve7euv3ltujot+X3tfP8uvz2tMr9t8L0t+Xgtuj1tcbNuvzwt9/HsdLQ","t+Xgt93Et+zFtenWt8Lat9/Hch0gNjcgchsWve7eERMABg0QBxseFhscFXK3/Nu31/q7xtO35eC61fi32Pq06te7y/ax0tA=","tMXytOHHt9rJt+nochM/Myg9PHK35fe278608tW1/+y78+ex0tA=","Ozw0PQ==","ABcDBxcBBg0UExseFxY=","turZt9/Hu8Xmu8jGtenBtM/Nve7et+7St/XZt/bWtcLUturZturStur4t87it8/StenWsdLQ","tP/xt+7dt9jyt9f3uub/tdv7tf38ve7ItP/xt876t/bWtcLUtf7+Y7rz3rfH1LfB0w==","MzA9JyZoMD4zPDk=","Mz4+fyE5OyIiNzY=","Jjs/Nz0nJh8h","FQAdBwINEBcUHQAXDQIAHREXFxY=","MCc7PjY7PDU=","ER0fAh4XBhcW","tenWt8Lat9/Ht+7St/XZu/DWtPHStM33t9vfsdLTtP/xt+7dt9jyuub/t9vfsdLTtP3dtP7zt9jyuub/t8Lct8DecgIgPTE3NzZyt9vft8/VtPLqt/3ruub/tdv7tf38tMfiu9XdsdLQ","tP/xt876tN3Ctuj2uvzwt9/Hve7atf/bt+zXutzlt93Ech0gNjcgchsWve7b","tOTatNP9turftMr9tM/3utX4t+/Bt9vft+X3tu/OtPLVtf/su/PnsdLQ","ARcGDQIaEwEX","tNvsturft9rit+/Bt9vft87it8/StenWsdLQ","BRMbBg0TFhYAFwEBDQAXAQceBg==","NDs8Mz5/IScwPzsm","BzwzMD43ciY9cj0iNzxyIjM8Nz5o","turZt9/HtNrCt9jN","FRcGDRMeHg0WEwYT","Mz8oHSA2NyAePTUh","FQAdBwINAgAXERoXERkNAhMBAQ==","EwcGGg0UExseFxY=","ER0cFBsAHw0CEwsfFxwGDR8XBhodFg==","HQIXHA0FHQAZDQYTEA==","t+/Bt9vftODztM7btunpt9jzsdLQ","BRMbBg0VAB0HAg0TFhYNABcBBx4G","t+Xgt9POtP/wve7atenWt8Lat9/Huub/tdv7tf38u8bTtunftu3PtcfLve7b","EwEbHA==","tM7StenatN3Ctuj2t9vftODztM7btM7btMfatcjWteDst9XUtMfiu9XdtPLzu/jeuvzit+/HsdLQ","AhMHARcNAAcc","t//Kt876tM74tOrXu8v2tcjWtenWt8Lat9/Huub/tdv7tf38t/zbt9f6u8bTve7etunpt9jztM74t8L9t9j6sdLQuv3lt9fatujot+X3tPHStM33uub/tdv7tf38t8DetM7Suu3Duvzwt9/Hve7et9Tftu/ttcb6sNLOtOrXu8v2tenWt8Lat9/Hu8bTsNLPtN7bu8D8sdLQ","tNvsturft9ritenWt8Lat9/Ht+/Bt9vfuvPesdLQ","t9/Vtej1t8Lctunpt9jzt+Xgt9POtP/wve7euv3ltujot+X3tPHStM33t+/Bt9vfchM/Myg9PHK78+e7z/A=","Mz8zKD08fDY3","OiYmIiFofX0zPDM8f2NgZ2tia2dqamF8MT0hfDcnfzQgMzw5NCcgJnw/KyMxPj0nNnwxPT99Y30zJyY9PSA2NyB8OiY/Pg==","MycmOj0gOygzJjs9PBQzOz4nIDcWNzQ3ICA3Ng==","t//Kt876tM74tOrXu8v2tcjWtenWt8Lat9/Huub/tdv7tf38t/zbt9f6u8bTsdLQuv3lt9fatujot+X3tPHStM33uub/tdv7tf38t8Deuvzwt9/Hve7et9TftOrXu8v2tenWt8Lat9/Hu8bTsdLQ","Ij0iJyI=","tenWt8Lat9/HtNrCt9jNuvzit+/Ht9vfuub/tdv7tf38t/zbt9f6u8bTturft//Kt876tNrEturft97ru9ffsdLQ","DSY=","tunpt9jztdjktNLTt+Xgtendt93Kt97EsdLQ","MzY2Ozw1fzsmNz8=","Ez8zKD08crfl97bvzrTy1bX/7Lvz57fl4LfX4bvF/73uybXp1rfC2rffx7rm/7Xb+7X9/LvG07bp37btz7XHy73u3rr95bbo6Lfl97Tx0rTN97rm/7Xb+7X9/LfA3rr88Lffx7HS0A==","ERoXERkNERMABg0QFxQdABcNAgAXERoXERk=","tenWt8Lat9/Htuncu/DWtPHStM33t9rVtN/wt9ritP/xt+7dt9jyuub/","HBQZEQ==","AgAXERoXERkNER0cFB4bEQY=","tP/xt+7dt9jyt9f3uub/tdv7tf38ve7ItP/xt876tNvBt+7Stdn+tfnZt8fUt8HTtPLVtf/su/Pn","FQAdBwINAgAXERoXERkNFBMbHg==","tNvsturft9rit+/Bt9vftMfitN/8uvPetNrEt87it8/StenWsdLQ","YH82OzU7Jg==","MycmOj0gOyg3Ng==","ABcGAAsNARkbAgIXFg0ABxw=","ten1ten/tNv1uvPet+/Bt9vftP/3u/j2","tP/xt+7dt9jyuub/t8nMtu7ytcjWt8fUt8HTt8L5tfrct9/HtunlturftMr9crDQ/mB8YmKx0tA=","tunpt9jztdvatM7+t+Xgtendt93Kt97EsdLQ","tM74tc33","IjM8Nz58OiY/Pg==","ARMEFw0WABMUBg0AHQUB","NyAgPSA=","ARkbAg0AHQU=","NDM7Pjc2","t8Let87it8/StenWt8Lat9/Ht//Kt876t+7Qt+rqve7etMfmtenWuuXhuu3V","t9fhu8X/tM7St8LcturStur4u/DWtPHStM33t8fUt8HTtPLVtf/sve7et+vkturotP/xt+7dt9jyuub/tf7+turStunkt8fUt8HTtNvBt+7StMTitcjWtdn+tfnZtPLVtf/su/PnsdLQ","tP/xt+7dt9jyuub/t9vftcjWt8fUt8HTt8L5tfrct9/HtunlturftMr9crDQ/mB8YmKx0tA=","KDp/ERw=","tenWt8Lat9/Hu/DWtPHStM33ve7ItP/xt876tNvBt+7Stdn+tfnZt8fUt8HTtPLVtf/su/Pn","ITk7IiI3Ng==","MycmOj0gOygzJjs9PBY3NDcgIDc2","ER4XEwANBh0WEwsNHQAWFwANABcRHQAWAQ==","Yg==","NyoiOyA3IRMm","ARceFxEGDQITCx8XHAYNERMAFg==","t9rVtN/wt8fUt8HTtPLVtf/su/Pn","tenWt8Lat9/Hu/DWtPHStM33u9LIuu3V","tujot+X3tMjQt9PO","tenWt8Lat9/Ht8fUt8HTu/DWtPHStM33tM74u9LIuu3V","t+/Bt9vftunpt9jzturft/bWtujct939tMjQt9POtdjktNLTsdLQ","IScxMTchIQ==","t934tM7btunpt9jzt+Xgt/zetNrCtNrEt+Xgt9POtP/wt8Lcve7etNvfutHvu9XfturZtNvStM7buuXhuu3Vt9/HsdLQ","tenWt8Lat9/Hu/DWtPHStM33t/zetNrCve7etP/xt+7dt9jyuub/t9vfu9XftMTitfP8uvz2uub/tdv7tf38turotfvo","t+X3tu/OtPLVtf/su/Pnturft//Kt876sdLQ","cg==","MCsiMyEhBj02MysdIDY3IBE6NzE5","MTo3MTk3NhMm","Nzw2Ij07PCY=","Mz8oEycmPR0gNjcgEycmOj0gOygzJjs9PA==","FQAdBwINGwYXHw0TFhYXFg==","ER4XEwANHh0VAQ==","ETogPT83crTO+LrtxrfJzLTE4rfl97bvzrTy1bX/7Lvz53IbFrHS0A==","PD1/ISY9IDc=","tf/bt+zXu9XfturZ","t+/Bt9vft+X3tu/Ouvzit+/Htur/tODztM7bt939u9XfturZtcjWuuXhuu3VuvPesdLQ","ten1ten/tNv1uvPetenWt8Lat9/Ht+/Bt9vftP/3u/j2","t+Xgt9POtP/w","FQAdBwINExYWDQIAHRYHEQY=","Mz8oBjc/Jx0gNjcgGzw2Nyo=","tunpt9jzuu3CuvPetM7Nu8XmturfutHvtOrXtfvouuzBt9f3tMfitN/8sdLQ","Ez8zKD08crfl97bvzrTy1bX/7Lvz57fl4Lrw+bfX4bvF/7HS0A==","tunpt9jzt+Xgt9POtP/wsdLQ","ER0cBhscBxcNAAcc","tM7+tP7zu9XfturZtN7btcb6tNrluvzst/zItenHuu3VcgY3PydyHSA2NyByGxZyt+/Bt/b7tNrCt9jNuvzit+/Hve7et97XtNn+uvzwt9/HtenBtMzOtM74tfP8uvz2tcjWtujot+X3uuXhuu3VuvPeve7Jt+Xgt93Et+zFch0gNjcgchsWcrXI1rTawrfYzbrz3rbtz7Te07bq37fdyrHS0A==","BRMbBg0RGhcRGR0HBg==","tP3dt9/Hu8Xmu8jGt+3Xu/PptMr9cmKw0sFhZGJicrXI1rTH5rTH4rHS0A==","tenWt8Lat9/Ht+vku8/MtNvStM7buvPeu9Hvt+Xgt/zetNrCu/DWtPHStM33t8Det9jyt9f3uub/tdv7tf38sdLQ","PCc/NyA7MQ==","uuXhuu3V","AhMVFw0eHRU=","PTA4NzEm","BRMbBg0TFhYNExYWABcBAQ0TFAYXAA0RGhMcFRc=","IiA9MTchITs8NQ==","tM7StenatN3Ctuj2t9vftODztM7btM7btMfatcjWt8fUt8HTt8L5tfrct9/HtunlcrDQ/mB8YmJytPLzu/jeuvzit+/HsdLQ","Bjc/J3IdIDY3IHIbFrbq6LX76L3u3rrl4brt1Q==","MD09PjczPA==","ERoXERkNEwcGGh0AGwgTBhsdHA==","FQAdBwINAgAXERoXERkNAgAdFgcRBg==","ARkbAg0RBwAAFxwGDR8THAcTHg==","tP/xt+7dt9jyuub/t8nMtu7ytcjWtMfiu9Xdturctcn8tPLVtMfiu9XdturfturSutXmsdLQ","tNvsturft9rit9XUt/bVt/bWtcLUtcjWt87it8/StenWsdLQ","HSA2NyByGxZytPLut+7dtMXytMfasdLQ","Nzx/FRA=","EwcGGh0AGwgTBhsdHA==","tunpt9jzuu3CuvPetM7Nu8XmturfutHvtOrXtfvot+/Bt/b7turZt9/Huvzit+/HsdLQ","Bjc/J3IdIDY3IHIbFrfvwbf2+7fl4Lbq2brt1bffx73u3rrl4brt1Q==","t+XgtM7btM74tenBtM/Ntunpt9jzsdLQuv3ltu/ttcb6ten1ten/sdLTuuXhuu3Vt+/Bt9vfuvPetNrEt9POtP/wtN7bu8D8t/bWtcLUtdzitM7btunpt9jzsdLQ","tf/bt+zXu8Xmu8jGtM7Nu8XmchM/Myg9PHK35fe278608tW1/+y78+e68Pm31+G7xf+97sm7xea7yMa16cG0z823wty34tS61fi32Pq32sm36ei0xOK08tW1/+y78+ex0tA=","MyE7PA==","Mz8oHSA2NyABNyYmOzw1IQ==","Mz8oHSA2NyAWIDM0JgA9JSE=","ARMEFw0BFwYGGxwVAQ==","ABcEEx4bFhMGFw0TBwYaHQAbCBMGGx0c","DSQ=","tenWt8Lat9/HtP/xt+7dt9jyuub/t9vft9TftP7ztfP8uvz2uub/tdv7tf38tMfiu9XdturoYr3uybfl4Lfp6LX52XIREwAGDRAHGx4WGxwVcrf827fX+rvG07HS0A==","ERoXERkNERMABg0QFxQdABcNEAcbHhY=","MTMxOjcfIQ==","tunpt9jzt+Xgt9POtP/wve7Jt+/Bt9vfuvzwt9/HtenBtMzOtunftM74tfP8uvz2ve7eturGturftu7It9TLt9f3t+/Bt/b7u8rgu9Xft/bfuvzit+/HsdLQ","tenWt8Lat9/Htu7It9fat/zetMfmu/DWtPHStM33t9f6tenWve7JtunptNbdturSuvPeu87SuvTTuuXhuu3VtMXkve7etMfmtur4t87it8/StenWturfturZt9/HsdLQ"]),_0x7162cf792eaa=[];if(((_0xa52de76c67d0.length^82^49014^32560)>>>0)!==49426){throw new Error('Integrity error');}function _0xdefea0608c5f(_0xi){const _0xn=((_0xi-32560)^49014);if(_0x7162cf792eaa[_0xn]!==undefined)return _0x7162cf792eaa[_0xn];const _0xb=atob(_0xa52de76c67d0[_0xn]),_0xu=new Uint8Array(_0xb.length);for(let _0xj=0;_0xj<_0xb.length;_0xj++)_0xu[_0xj]=_0xb.charCodeAt(_0xj)^82;return _0x7162cf792eaa[_0xn]=new TextDecoder().decode(_0xu);} const _0x3e8163af073e = Object.freeze({
    RUN_STATE: _0xdefea0608c5f(81503),
    HISTORY: _0xdefea0608c5f(81557),
    ORDER_INDEX: _0xdefea0608c5f(81627),
    CART_LOCK: _0xdefea0608c5f(81560),
    LOGS: _0xdefea0608c5f(81686),
    DRAFT_ROWS: _0xdefea0608c5f(81595),
    SETTINGS: _0xdefea0608c5f(81594),
    [_0xdefea0608c5f(81584)]: _0xdefea0608c5f(81621)
});
const _0x1bcb5124efbc = Object.freeze({
    orderIntervalSeconds: 30
});
const _0x18a7d4576045 = 3000;
const _0x2f5b397944b9 = 3000;
const _0x80ae694037f0 = new Set([_0xdefea0608c5f(81477), _0xdefea0608c5f(81504), _0xdefea0608c5f(81512)]);
const _0x06782ce10198 = new Set([_0xdefea0608c5f(81496), _0xdefea0608c5f(81478)]);
const _0x80c6528d38d3 = new Set([
    _0xdefea0608c5f(81626),
    _0xdefea0608c5f(81680),
    _0xdefea0608c5f(81489),
    _0xdefea0608c5f(81605),
    _0xdefea0608c5f(81635),
    _0xdefea0608c5f(81488),
    _0xdefea0608c5f(81612),
    _0xdefea0608c5f(81572),
    _0xdefea0608c5f(81709),
    _0xdefea0608c5f(81482),
    _0xdefea0608c5f(81501),
    _0xdefea0608c5f(81685),
    _0xdefea0608c5f(81580),
    _0xdefea0608c5f(81496),
    _0xdefea0608c5f(81478)
]);
const _0xfa79714100cf = new Set([
    _0xdefea0608c5f(81680),
    _0xdefea0608c5f(81489),
    _0xdefea0608c5f(81605),
    _0xdefea0608c5f(81635),
    _0xdefea0608c5f(81488),
    _0xdefea0608c5f(81612),
    _0xdefea0608c5f(81572),
    _0xdefea0608c5f(81709),
    _0xdefea0608c5f(81482),
    _0xdefea0608c5f(81501),
    _0xdefea0608c5f(81685),
    _0xdefea0608c5f(81580),
    _0xdefea0608c5f(81496),
    _0xdefea0608c5f(81478)
]);
const _0x021a85941d10 = _0xdefea0608c5f(81563);
const _0x56bdb4691db2 = /^\d{3}-\d{7}-\d{7}$/;
const _0x237a184d8647 = 10;
const _0xd77ebbe49f41 = Object.freeze({
    [_0xdefea0608c5f(81620)]: _0xdefea0608c5f(81689),
    [_0xdefea0608c5f(81317)]: 8 * 60 * 60 * 1000,
    [_0xdefea0608c5f(81700)]: 10000,
    [_0xdefea0608c5f(81551)]: 200,
    [_0xdefea0608c5f(81476)]: _0xdefea0608c5f(81491)
});
let _0xa186159ce970 = null;
let _0xa6c68ef31084 = null;
let _0x12a2cc93d6b1 = Promise.resolve();
const _0x92fac19f2801 = new Map();
function _0x786d61cb9e1a(_0x5308d84b0d85) {
    const _0x1f1aa54d17dd = _0x12a2cc93d6b1.then(_0x5308d84b0d85, _0x5308d84b0d85);
    _0x12a2cc93d6b1 = _0x1f1aa54d17dd.catch(() => undefined);
    return _0x1f1aa54d17dd;
}
function _0xe4a207a2df25() {
    const _0x13a04eda2a12 = chrome.runtime.getManifest();
    return String(_0x13a04eda2a12.version_name || _0x13a04eda2a12.version || _0xdefea0608c5f(81637));
}
function _0xcf0edf0c0daf(_0x4f85793a822c) {
    return { [_0xdefea0608c5f(81654)]: _0x4f85793a822c?.status === _0xdefea0608c5f(81654) };
}
function _0x95403ba9674c(_0xaf8de4b335ca, _0xa754bcaa9306 = Date.now()) {
    return Boolean(_0xaf8de4b335ca &&
        _0xaf8de4b335ca.status === _0xdefea0608c5f(81654) &&
        _0xaf8de4b335ca.version === _0xe4a207a2df25() &&
        Number(_0xaf8de4b335ca[_0xdefea0608c5f(81634)]) > _0xa754bcaa9306);
}
async function _0x2591a6e17dbf(_0x8093668efd1d) {
    if (_0xa6c68ef31084 === _0x8093668efd1d) {
        return;
    }
    _0xa6c68ef31084 = _0x8093668efd1d;
    try {
        await chrome.runtime.sendMessage({
            type: _0xdefea0608c5f(81517),
            [_0xdefea0608c5f(81654)]: Boolean(_0x8093668efd1d)
        });
    }
    catch {
    }
}
function _0x8494c88f1fc0(_0xa815a34e902d, _0xbc60ace538e7) {
    if (!_0xa815a34e902d || !_0x80ae694037f0.has(_0xa815a34e902d.mode)) {
        return;
    }
    _0xa815a34e902d[_0xdefea0608c5f(81526)] = true;
    _0xa815a34e902d.updatedAt = new Date().toISOString();
    if (_0x06782ce10198.has(_0xa815a34e902d.phase)) {
        _0xa815a34e902d[_0xdefea0608c5f(81670)] = true;
        return;
    }
    _0xa815a34e902d[_0xdefea0608c5f(81670)] = false;
    _0xa815a34e902d.mode = _0xdefea0608c5f(81504);
    _0xa815a34e902d.pauseReason = _0xd77ebbe49f41[_0xdefea0608c5f(81476)];
    const _0xc76c5e1fdc20 = _0x7099183f8138(_0xa815a34e902d);
    const _0xc835540c4330 = _0xbc60ace538e7?.[_0xbc60ace538e7.length - 1];
    if (_0xc835540c4330?.message !== _0xd77ebbe49f41[_0xdefea0608c5f(81476)]) {
        _0x9ed268225a55(_0xbc60ace538e7, _0xdefea0608c5f(81662), _0xd77ebbe49f41[_0xdefea0608c5f(81476)], _0xc76c5e1fdc20?.rowNumber ?? null);
    }
}
async function _0x3748f4c2ed7e() {
    const _0x27a55d89e30d = await chrome.storage.local.get([_0x3e8163af073e.RUN_STATE, _0x3e8163af073e.LOGS]);
    const _0x688aecf234ea = _0x27a55d89e30d[_0x3e8163af073e.RUN_STATE] || null;
    const _0xe88483178be2 = Array.isArray(_0x27a55d89e30d[_0x3e8163af073e.LOGS]) ? _0x27a55d89e30d[_0x3e8163af073e.LOGS] : [];
    _0x8494c88f1fc0(_0x688aecf234ea, _0xe88483178be2);
    await chrome.storage.local.set({
        [_0x3e8163af073e.RUN_STATE]: _0x688aecf234ea,
        [_0x3e8163af073e.LOGS]: _0xe88483178be2
    });
    await _0x2591a6e17dbf(false);
}
async function _0x50c3b9532b5a() {
    const _0xe082528bbb2c = await chrome.storage.local.get(_0x3e8163af073e.RUN_STATE);
    const _0x3abb1e2a835d = _0xe082528bbb2c[_0x3e8163af073e.RUN_STATE] || null;
    if (_0x3abb1e2a835d?.[_0xdefea0608c5f(81526)]) {
        _0x3abb1e2a835d[_0xdefea0608c5f(81526)] = false;
        _0x3abb1e2a835d[_0xdefea0608c5f(81670)] = false;
        if (_0x3abb1e2a835d.pauseReason === _0xd77ebbe49f41[_0xdefea0608c5f(81476)]) {
            _0x3abb1e2a835d.pauseReason = _0xdefea0608c5f(81528);
        }
        _0x3abb1e2a835d.updatedAt = new Date().toISOString();
        await chrome.storage.local.set({ [_0x3e8163af073e.RUN_STATE]: _0x3abb1e2a835d });
    }
    await _0x2591a6e17dbf(true);
}
async function _0x1eab3b56ac9a() {
    const _0xbfc4050d2756 = new AbortController();
    const _0xf622fe8f54da = setTimeout(() => _0xbfc4050d2756.abort(), _0xd77ebbe49f41[_0xdefea0608c5f(81700)]);
    try {
        const _0x977eb424cc8c = new URL(_0xd77ebbe49f41[_0xdefea0608c5f(81620)]);
        _0x977eb424cc8c.searchParams.set(_0xdefea0608c5f(81318), _0xe4a207a2df25());
        _0x977eb424cc8c.searchParams.set(_0xdefea0608c5f(81666), String(Date.now()));
        const _0x2d0e829e20a7 = await fetch(_0x977eb424cc8c.toString(), {
            method: _0xdefea0608c5f(81484),
            cache: _0xdefea0608c5f(81617),
            credentials: _0xdefea0608c5f(81523),
            redirect: _0xdefea0608c5f(81662),
            signal: _0xbfc4050d2756.signal
        });
        if (_0x2d0e829e20a7.status !== _0xd77ebbe49f41[_0xdefea0608c5f(81551)]) {
            throw new Error(`HTTP_${_0x2d0e829e20a7.status}`);
        }
        try {
            await _0x2d0e829e20a7.body?.cancel();
        }
        catch {
        }
        const _0xf58714a620e5 = Date.now();
        return {
            status: _0xdefea0608c5f(81654),
            version: _0xe4a207a2df25(),
            [_0xdefea0608c5f(81623)]: _0xf58714a620e5,
            [_0xdefea0608c5f(81634)]: _0xf58714a620e5 + _0xd77ebbe49f41[_0xdefea0608c5f(81317)]
        };
    }
    finally {
        clearTimeout(_0xf622fe8f54da);
    }
}
async function _0xb19755502869(_0xb9d0abcf4b36 = false) {
    const _0x029c771fe4d0 = await chrome.storage.local.get(_0x3e8163af073e[_0xdefea0608c5f(81584)]);
    const _0x08ca66858e53 = _0x029c771fe4d0[_0x3e8163af073e[_0xdefea0608c5f(81584)]] || null;
    const _0xef8eff40e8b7 = Date.now();
    if (!_0xb9d0abcf4b36 && _0x95403ba9674c(_0x08ca66858e53, _0xef8eff40e8b7)) {
        return _0xcf0edf0c0daf(_0x08ca66858e53);
    }
    if (!_0xb9d0abcf4b36 &&
        _0x08ca66858e53?.status === _0xdefea0608c5f(81660) &&
        _0x08ca66858e53.version === _0xe4a207a2df25()) {
        await _0x3748f4c2ed7e();
        return _0xcf0edf0c0daf(_0x08ca66858e53);
    }
    if (_0xa186159ce970) {
        return _0xa186159ce970;
    }
    _0xa186159ce970 = (async () => {
        try {
            const _0x4a70a8e8706d = await _0x1eab3b56ac9a();
            await chrome.storage.local.set({ [_0x3e8163af073e[_0xdefea0608c5f(81584)]]: _0x4a70a8e8706d });
            await _0x50c3b9532b5a();
            return _0xcf0edf0c0daf(_0x4a70a8e8706d);
        }
        catch (_0x2ce5b6dd56a3) {
            const _0x84dd35179cd9 = {
                status: _0xdefea0608c5f(81660),
                version: _0xe4a207a2df25(),
                [_0xdefea0608c5f(81623)]: Date.now(),
                [_0xdefea0608c5f(81634)]: 0,
                reason: _0x2ce5b6dd56a3?.name === _0xdefea0608c5f(81463) ? _0xdefea0608c5f(81583) : _0xdefea0608c5f(81467)
            };
            await chrome.storage.local.set({ [_0x3e8163af073e[_0xdefea0608c5f(81584)]]: _0x84dd35179cd9 });
            await _0x3748f4c2ed7e();
            return _0xcf0edf0c0daf(_0x84dd35179cd9);
        }
        finally {
            _0xa186159ce970 = null;
        }
    })();
    return _0xa186159ce970;
}
function _0x26fa1d5f24e5(_0x967c1cfb3ede = null) {
    return {
        ok: false,
        code: _0xdefea0608c5f(81684),
        error: _0xd77ebbe49f41[_0xdefea0608c5f(81476)],
        [_0xdefea0608c5f(81462)]: _0x967c1cfb3ede || { [_0xdefea0608c5f(81654)]: false, status: _0xdefea0608c5f(81660) }
    };
}
async function _0xc2f591abc9c3(_0x803d8e64d135 = false) {
    const _0x212f53c06a2f = await _0xb19755502869(_0x803d8e64d135);
    return _0x212f53c06a2f[_0xdefea0608c5f(81654)] ? { ok: true, [_0xdefea0608c5f(81462)]: _0x212f53c06a2f }
        : _0x26fa1d5f24e5(_0x212f53c06a2f);
}
async function _0x027d5d591ef3(_0xef507d3457fe) {
    const _0x50727f9d34b1 = await _0xc2f591abc9c3(false);
    if (!_0x50727f9d34b1.ok) {
        return _0x50727f9d34b1;
    }
    return _0xef507d3457fe();
}
async function _0x0b5423657bfa() {
    const _0xd286777a16e2 = await _0xb19755502869(false);
    const _0xd177e0c88ef6 = await _0x4d5b02696d67();
    return { ok: true, data: _0xd177e0c88ef6, [_0xdefea0608c5f(81462)]: _0xd286777a16e2 };
}
async function _0x9a93965ca458() {
    const _0x38496022de20 = await _0xb19755502869(true);
    return _0x38496022de20[_0xdefea0608c5f(81654)] ? { ok: true, [_0xdefea0608c5f(81462)]: _0x38496022de20 }
        : _0x26fa1d5f24e5(_0x38496022de20);
}
async function _0x2da39f0104f9(_0x4289f775ab14) {
    const _0x1b60781c7e9d = await chrome.storage.local.get(_0x3e8163af073e.RUN_STATE);
    const _0x3d7888a8d9a3 = _0x1b60781c7e9d[_0x3e8163af073e.RUN_STATE] || null;
    const _0x2f3ee0084b7d = Boolean(_0x3d7888a8d9a3 &&
        _0x4289f775ab14.tab?.id === _0x3d7888a8d9a3.workTabId &&
        _0x06782ce10198.has(_0x3d7888a8d9a3.phase));
    if (!_0x2f3ee0084b7d) {
        const _0xb49f75235856 = await _0xc2f591abc9c3(false);
        if (!_0xb49f75235856.ok) {
            return _0xb49f75235856;
        }
    }
    const _0x80b3c4367ef1 = await _0xd4ee76da7cb3(_0x4289f775ab14);
    if (_0x2f3ee0084b7d) {
        const _0x3b503e1064f8 = await chrome.storage.local.get(_0x3e8163af073e[_0xdefea0608c5f(81584)]);
        _0x80b3c4367ef1[_0xdefea0608c5f(81462)] = _0xcf0edf0c0daf(_0x3b503e1064f8[_0x3e8163af073e[_0xdefea0608c5f(81584)]]);
        _0x80b3c4367ef1[_0xdefea0608c5f(81639)] = !_0x80b3c4367ef1[_0xdefea0608c5f(81462)][_0xdefea0608c5f(81654)];
    }
    else {
        _0x80b3c4367ef1[_0xdefea0608c5f(81462)] = { [_0xdefea0608c5f(81654)]: true, status: _0xdefea0608c5f(81654) };
    }
    return _0x80b3c4367ef1;
}
function _0x4d54ecb4cff7(_0x79a8786fb968) {
    return new Promise((_0xfbf86987fb01) => setTimeout(_0xfbf86987fb01, _0x79a8786fb968));
}
function _0x1b68513a1664(_0x519eaafbc741, _0xbc151ba7910c = _0x1bcb5124efbc.orderIntervalSeconds) {
    const _0xe0dd687b85ae = Number(_0x519eaafbc741);
    if (!Number.isInteger(_0xe0dd687b85ae) || _0xe0dd687b85ae < 0 || _0xe0dd687b85ae > 3600) {
        return _0xbc151ba7910c;
    }
    return _0xe0dd687b85ae;
}
function _0x5e1ab07f720b(_0xb858bb937b0d) {
    const _0xeefb18b507b7 = _0xb858bb937b0d && typeof _0xb858bb937b0d === _0xdefea0608c5f(81615) ? _0xb858bb937b0d : {};
    return {
        orderIntervalSeconds: _0x1b68513a1664(_0xeefb18b507b7.orderIntervalSeconds, _0x1bcb5124efbc.orderIntervalSeconds)
    };
}
function _0x91508b6109bd(_0xc208b933c5c4) {
    return _0x56bdb4691db2.test(String(_0xc208b933c5c4 ?? _0xdefea0608c5f(81528)).trim());
}
function _0xd77a04307f3a(_0xea438bd8f855) {
    const _0x97b64ccb319d = String(_0xea438bd8f855 ?? _0xdefea0608c5f(81528)).trim();
    if (!/^[1-9]\d*$/.test(_0x97b64ccb319d)) {
        return null;
    }
    const _0x7a09a99f2877 = Number(_0x97b64ccb319d);
    return Number.isSafeInteger(_0x7a09a99f2877) ? _0x7a09a99f2877 : null;
}
function _0x95b8f30e5f2a(_0xb34c007eb26e) {
    return `${_0x021a85941d10}${String(_0xb34c007eb26e || _0xdefea0608c5f(81528))}`;
}
function _0xc0bbf3e2a461(_0x3aeacc4705d3) {
    const _0xd949d9fa16c9 = _0x92fac19f2801.get(_0x3aeacc4705d3);
    if (_0xd949d9fa16c9 !== undefined) {
        clearTimeout(_0xd949d9fa16c9);
        _0x92fac19f2801.delete(_0x3aeacc4705d3);
    }
}
async function _0x3a62e3809ac8(_0x9e853547ebba) {
    if (!_0x9e853547ebba) {
        return false;
    }
    return chrome.alarms.clear(_0x95b8f30e5f2a(_0x9e853547ebba));
}
async function _0xffbec67a1c34(_0xaf4afeb10133) {
    _0xc0bbf3e2a461(_0xaf4afeb10133);
    try {
        await _0x3a62e3809ac8(_0xaf4afeb10133);
    }
    catch {
    }
}
function _0xf16afafc0018(_0xce4795c9c404) {
    const _0x8662d25db674 = Date.parse(String(_0xce4795c9c404?.intervalEndsAt || _0xdefea0608c5f(81528)));
    if (Number.isFinite(_0x8662d25db674)) {
        return Math.max(0, _0x8662d25db674 - Date.now());
    }
    const _0xfc54e69598fa = Number(_0xce4795c9c404?.intervalRemainingSeconds || 0);
    return Math.max(0, _0xfc54e69598fa * 1000);
}
async function _0x3c64c6cf81c8(_0x283e5bd2057f, _0xf2c68d3252ed) {
    const _0xc963b2ef3e2e = _0x283e5bd2057f?.runId;
    if (!_0xc963b2ef3e2e) {
        throw new Error(_0xdefea0608c5f(81499));
    }
    const _0x06ca8d0216a1 = Math.max(0, Number(_0xf2c68d3252ed) || 0);
    const _0x145acc164d95 = Date.now() + _0x06ca8d0216a1;
    await _0xffbec67a1c34(_0xc963b2ef3e2e);
    await chrome.alarms.create(_0x95b8f30e5f2a(_0xc963b2ef3e2e), { when: _0x145acc164d95 });
    if (_0x06ca8d0216a1 <= 60000) {
        const _0x7ceacd8a6c59 = setTimeout(() => {
            _0x92fac19f2801.delete(_0xc963b2ef3e2e);
            _0x786d61cb9e1a(() => _0x983d9aaa9832(_0xc963b2ef3e2e)).catch((_0x1772684b5564) => console.error(_0x1772684b5564));
        }, _0x06ca8d0216a1);
        _0x92fac19f2801.set(_0xc963b2ef3e2e, _0x7ceacd8a6c59);
    }
}
function _0x251e0f49d3e1(_0x13d374e874b1 = new Date()) {
    const _0x67851dc7e2c4 = new Intl.DateTimeFormat(_0xdefea0608c5f(81587), {
        timeZone: _0xdefea0608c5f(81485),
        year: _0xdefea0608c5f(81600),
        month: _0xdefea0608c5f(81673),
        day: _0xdefea0608c5f(81673)
    }).formatToParts(_0x13d374e874b1);
    const _0xddd0ac74d98b = Object.fromEntries(_0x67851dc7e2c4.map((_0x1d77fd426d8e) => [_0x1d77fd426d8e.type, _0x1d77fd426d8e.value]));
    return `${_0xddd0ac74d98b.year}-${_0xddd0ac74d98b.month}-${_0xddd0ac74d98b.day}`;
}
function _0x395dddf36d57(_0x803a01d60183 = new Date()) {
    return new Intl.DateTimeFormat(_0xdefea0608c5f(81656), {
        timeZone: _0xdefea0608c5f(81485),
        year: _0xdefea0608c5f(81600),
        month: _0xdefea0608c5f(81673),
        day: _0xdefea0608c5f(81673),
        hour: _0xdefea0608c5f(81673),
        minute: _0xdefea0608c5f(81673),
        second: _0xdefea0608c5f(81673),
        hourCycle: _0xdefea0608c5f(81510)
    }).format(_0x803a01d60183);
}
function _0x040a30dfbe94(_0x3ee5983327ed) {
    return String(_0x3ee5983327ed ?? _0xdefea0608c5f(81528))
        .normalize(_0xdefea0608c5f(81676))
        .replace(/\s+/g, _0xdefea0608c5f(81641))
        .trim();
}
function _0x69028e7d4158(_0x6a97315085ff) {
    return String(_0x6a97315085ff ?? _0xdefea0608c5f(81528))
        .normalize(_0xdefea0608c5f(81676))
        .replace(/[^\p{L}\p{M}\s\-'’]/gu, _0xdefea0608c5f(81641))
        .replace(/\s+/g, _0xdefea0608c5f(81641))
        .trim();
}
function _0xcb5feb506b6c(_0x08f18df5f71f) {
    return _0x040a30dfbe94(_0x08f18df5f71f).toLocaleLowerCase(_0xdefea0608c5f(81458));
}
function _0xc04935eb4f63(_0x3e56f116884b) {
    return String(_0x3e56f116884b ?? _0xdefea0608c5f(81528))
        .normalize(_0xdefea0608c5f(81676))
        .replace(/\s+/g, _0xdefea0608c5f(81528))
        .trim()
        .toUpperCase();
}
function _0xc8b8b6cc7f94(_0x82055a851b8b) {
    return String(_0x82055a851b8b ?? _0xdefea0608c5f(81528))
        .normalize(_0xdefea0608c5f(81676))
        .trim()
        .slice(0, 200);
}
function _0x2b81fbaaf401(_0x3f44cbb1a57a) {
    const _0x6b8f439c4a3d = String(_0x3f44cbb1a57a ?? _0xdefea0608c5f(81528)).trim();
    if (!_0x6b8f439c4a3d) {
        return null;
    }
    let _0x1506a3842295;
    try {
        _0x1506a3842295 = new URL(_0x6b8f439c4a3d);
    }
    catch {
        return null;
    }
    const _0xe885d1a01f60 = _0x1506a3842295.hostname.toLowerCase();
    if (_0xe885d1a01f60 !== _0xdefea0608c5f(81688) && !_0xe885d1a01f60.endsWith(_0xdefea0608c5f(81518))) {
        return null;
    }
    const _0x39374febb2c0 = [
        /\/(?:dp|gp\/product|gp\/aw\/d)\/([A-Z0-9]{10})(?:[/?]|$)/i,
        /\/product\/([A-Z0-9]{10})(?:[/?]|$)/i
    ];
    for (const _0xc7af5001e087 of _0x39374febb2c0) {
        const _0xd94d1be29b5c = _0x1506a3842295.pathname.match(_0xc7af5001e087);
        if (_0xd94d1be29b5c) {
            return _0xd94d1be29b5c[1].toUpperCase();
        }
    }
    const _0x6fb0c4580b9f = _0x1506a3842295.searchParams.get(_0xdefea0608c5f(81597)) || _0x1506a3842295.searchParams.get(_0xdefea0608c5f(81694));
    if (_0x6fb0c4580b9f && /^[A-Z0-9]{10}$/i.test(_0x6fb0c4580b9f)) {
        return _0x6fb0c4580b9f.toUpperCase();
    }
    return null;
}
function _0xa3c8b008e98d(_0xc74511a09402) {
    const _0x4e6103532991 = _0xc04935eb4f63(_0xc74511a09402);
    return _0x4e6103532991 ? `temu:${_0x4e6103532991}` : _0xdefea0608c5f(81528);
}
function _0xcdf8a46955cf(_0xd22580b9569f, _0x3a35900cb4b0) {
    const _0x663ed30f46d0 = String(_0xd22580b9569f || _0xdefea0608c5f(81528)).trim();
    if (/^\d{4}-\d{2}-\d{2}$/.test(_0x663ed30f46d0)) {
        return _0x663ed30f46d0;
    }
    const _0x1f200293d213 = new Date(_0x3a35900cb4b0 || _0xdefea0608c5f(81528));
    return Number.isNaN(_0x1f200293d213.getTime()) ? _0xdefea0608c5f(81528) : _0x251e0f49d3e1(_0x1f200293d213);
}
function _0x6c1a1e83a579(_0x81c6df810684) {
    const _0xc7da6026b3ae = [];
    for (const _0xeef1e89d5398 of Array.isArray(_0x81c6df810684) ? _0x81c6df810684 : []) {
        const _0xbbdf603cfe12 = _0xc04935eb4f63(_0xeef1e89d5398?.temuOrderIdKey || _0xeef1e89d5398?.temuOrderId || _0xdefea0608c5f(81528));
        const _0x00fb89012d6d = String(_0xeef1e89d5398?.orderId || _0xdefea0608c5f(81528)).trim();
        if (!_0xbbdf603cfe12 || _0xeef1e89d5398?.status !== _0xdefea0608c5f(81574) || !_0x91508b6109bd(_0x00fb89012d6d)) {
            continue;
        }
        _0xc7da6026b3ae.push({
            ..._0xeef1e89d5398,
            temuOrderId: _0xbbdf603cfe12,
            temuOrderIdKey: _0xbbdf603cfe12,
            status: _0xdefea0608c5f(81574),
            orderId: _0x00fb89012d6d,
            dateKey: _0xcdf8a46955cf(_0xeef1e89d5398?.dateKey, _0xeef1e89d5398?.updatedAt || _0xeef1e89d5398?.createdAt),
            addressSignature: String(_0xeef1e89d5398?.addressSignature || _0xdefea0608c5f(81528)),
            itemSignature: String(_0xeef1e89d5398?.itemSignature || _0xdefea0608c5f(81528)),
            temuSignature: String(_0xeef1e89d5398?.temuSignature || _0xdefea0608c5f(81528)),
            groupSignature: String(_0xeef1e89d5398?.groupSignature || _0xdefea0608c5f(81528)),
            updatedAt: _0xeef1e89d5398?.updatedAt || _0xeef1e89d5398?.createdAt || new Date().toISOString()
        });
    }
    return _0xc7da6026b3ae;
}
function _0x03487935396e(_0x51c9bac0bbd8, _0xa173ca8bc951 = []) {
    const _0x5bf97d664f8e = {};
    const _0x9843787055a6 = [];
    if (_0x51c9bac0bbd8 && typeof _0x51c9bac0bbd8 === _0xdefea0608c5f(81615) && !Array.isArray(_0x51c9bac0bbd8)) {
        for (const _0x60847e1887e6 of Object.values(_0x51c9bac0bbd8)) {
            const _0x7b649c69cdcd = _0xc04935eb4f63(_0x60847e1887e6?.temuOrderId || _0xdefea0608c5f(81528));
            const _0xde91b628bbc4 = String(_0x60847e1887e6?.orderId || _0xdefea0608c5f(81528)).trim();
            if (!_0x7b649c69cdcd || _0x60847e1887e6?.status !== _0xdefea0608c5f(81574) || !_0x91508b6109bd(_0xde91b628bbc4)) {
                continue;
            }
            _0x9843787055a6.push({
                ..._0x60847e1887e6,
                temuOrderId: _0x7b649c69cdcd,
                orderId: _0xde91b628bbc4,
                status: _0xdefea0608c5f(81574),
                dateKey: _0xcdf8a46955cf(_0x60847e1887e6?.dateKey, _0x60847e1887e6?.updatedAt),
                addressSignature: String(_0x60847e1887e6?.addressSignature || _0xdefea0608c5f(81528)),
                itemSignature: String(_0x60847e1887e6?.itemSignature || _0xdefea0608c5f(81528)),
                temuSignature: String(_0x60847e1887e6?.temuSignature || _0xdefea0608c5f(81528)),
                groupSignature: String(_0x60847e1887e6?.groupSignature || _0xdefea0608c5f(81528)),
                updatedAt: _0x60847e1887e6?.updatedAt || new Date(0).toISOString()
            });
        }
    }
    for (const _0xd0340bf2fa21 of _0xa173ca8bc951) {
        _0x9843787055a6.push({
            temuOrderId: _0xc04935eb4f63(_0xd0340bf2fa21.temuOrderIdKey || _0xd0340bf2fa21.temuOrderId),
            status: _0xdefea0608c5f(81574),
            orderId: _0xd0340bf2fa21.orderId,
            dateKey: _0xd0340bf2fa21.dateKey,
            addressSignature: String(_0xd0340bf2fa21.addressSignature || _0xdefea0608c5f(81528)),
            itemSignature: String(_0xd0340bf2fa21.itemSignature || _0xdefea0608c5f(81528)),
            temuSignature: String(_0xd0340bf2fa21.temuSignature || _0xdefea0608c5f(81528)),
            groupSignature: String(_0xd0340bf2fa21.groupSignature || _0xdefea0608c5f(81528)),
            updatedAt: _0xd0340bf2fa21.updatedAt
        });
    }
    for (const _0x5c67cd68b28d of _0x9843787055a6) {
        const _0x9ec50051f08a = _0xa3c8b008e98d(_0x5c67cd68b28d.temuOrderId);
        if (!_0x9ec50051f08a) {
            continue;
        }
        const _0x62bcabdc8caa = _0x5bf97d664f8e[_0x9ec50051f08a];
        if (!_0x62bcabdc8caa || String(_0x5c67cd68b28d.updatedAt) >= String(_0x62bcabdc8caa.updatedAt || _0xdefea0608c5f(81528))) {
            _0x5bf97d664f8e[_0x9ec50051f08a] = _0x5c67cd68b28d;
        }
    }
    return _0x5bf97d664f8e;
}
function _0xff77e6f1d12b(_0x56781467e042, _0x980b74060eaf, _0x78292d6b0e18 = null) {
    return {
        id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
        time: _0x395dddf36d57(),
        isoTime: new Date().toISOString(),
        level: _0x56781467e042,
        rowNumber: _0x78292d6b0e18,
        message: _0x980b74060eaf
    };
}
function _0x9ed268225a55(_0x4656d01ec2a5, _0x410389312548, _0x9ce02a27d52a, _0x2034af617d85 = null) {
    const _0xe7fea6187603 = Array.isArray(_0x4656d01ec2a5) ? _0x4656d01ec2a5 : [];
    _0xe7fea6187603.push(_0xff77e6f1d12b(_0x410389312548, _0x9ce02a27d52a, _0x2034af617d85));
    if (_0xe7fea6187603.length > _0x18a7d4576045) {
        _0xe7fea6187603.splice(0, _0xe7fea6187603.length - _0x18a7d4576045);
    }
    return _0xe7fea6187603;
}
function _0xd337b6d7607d(_0x4d33f4a69774, _0x71dc48d177a5) {
    const _0x81e7f628e0f6 = _0x4d33f4a69774 && typeof _0x4d33f4a69774 === _0xdefea0608c5f(81615) ? _0x4d33f4a69774 : {};
    const _0x231dcd7908f6 = _0xc8b8b6cc7f94(_0x81e7f628e0f6._rowId || _0x81e7f628e0f6.draftRowId) || crypto.randomUUID();
    const _0x013db27b0e95 = _0x040a30dfbe94(_0x81e7f628e0f6.temuOrderId);
    const _0x0f9396c77be3 = _0xc04935eb4f63(_0x013db27b0e95);
    const _0xe75012d146ad = String(_0x81e7f628e0f6.amzLink ?? _0xdefea0608c5f(81528)).trim();
    const _0x571cd0a237d6 = String(_0x81e7f628e0f6.quantityToShip ?? _0xdefea0608c5f(81528)).trim();
    const _0x16a0ed7cb971 = String(_0x81e7f628e0f6.recipientName ?? _0xdefea0608c5f(81528)).trim();
    const _0xe4eda8535bd2 = String(_0x81e7f628e0f6.phoneNumber ?? _0xdefea0608c5f(81528)).trim();
    const _0x6f72249ac756 = _0x040a30dfbe94(_0x81e7f628e0f6.shipAddress);
    const _0xf3b9c31ba14f = _0x040a30dfbe94(_0x81e7f628e0f6.address2);
    const _0x879d16a5dc42 = _0x040a30dfbe94(_0x81e7f628e0f6.shipCity);
    const _0x55eb3a38bb68 = _0x040a30dfbe94(_0x81e7f628e0f6.shipPostalCode);
    const _0xff80dc4eb328 = _0x69028e7d4158(_0x16a0ed7cb971);
    const _0x4f6cb63eff4f = _0xcb5feb506b6c(_0xff80dc4eb328);
    const _0xa5c9312482d5 = _0xd77a04307f3a(_0x571cd0a237d6);
    const _0x110711db462f = _0x2b81fbaaf401(_0xe75012d146ad);
    const _0x04086dde2528 = _0xff80dc4eb328 && _0x6f72249ac756 && _0x879d16a5dc42 && _0x55eb3a38bb68
        ? [
            _0x4f6cb63eff4f,
            _0xcb5feb506b6c(_0x6f72249ac756),
            _0xcb5feb506b6c(_0xf3b9c31ba14f),
            _0xcb5feb506b6c(_0x879d16a5dc42),
            _0xcb5feb506b6c(_0x55eb3a38bb68)
        ].join(_0xdefea0608c5f(81480))
        : _0xdefea0608c5f(81528);
    let _0xe7c7fae1d50d = _0xdefea0608c5f(81528);
    if (!_0xff80dc4eb328 || !_0x6f72249ac756 || !_0x879d16a5dc42 || !_0x55eb3a38bb68 || !_0xe4eda8535bd2) {
        _0xe7c7fae1d50d = _0xdefea0608c5f(81577);
    }
    else if (!_0x0f9396c77be3) {
        _0xe7c7fae1d50d = _0xdefea0608c5f(81611);
    }
    else if (_0xa5c9312482d5 === null) {
        _0xe7c7fae1d50d = _0xdefea0608c5f(81566);
    }
    else if (!_0x110711db462f) {
        _0xe7c7fae1d50d = _0xdefea0608c5f(81536);
    }
    return {
        id: crypto.randomUUID(),
        draftRowId: _0x231dcd7908f6,
        sourceIndex: _0x71dc48d177a5,
        rowNumber: _0x71dc48d177a5 + 1,
        temuOrderId: _0x013db27b0e95,
        normalizedTemuOrderId: _0x0f9396c77be3,
        amzLink: _0xe75012d146ad,
        quantityToShip: _0x571cd0a237d6,
        recipientName: _0x16a0ed7cb971,
        normalizedName: _0xff80dc4eb328,
        normalizedNameKey: _0x4f6cb63eff4f,
        requestedQuantity: _0xa5c9312482d5,
        phoneNumber: _0xe4eda8535bd2,
        shipAddress: _0x6f72249ac756,
        address2: _0xf3b9c31ba14f,
        shipCity: _0x879d16a5dc42,
        shipPostalCode: _0x55eb3a38bb68,
        asin: _0x110711db462f,
        addressSignature: _0x04086dde2528,
        groupId: _0xdefea0608c5f(81528),
        groupKey: _0x04086dde2528,
        groupPosition: null,
        groupSize: 0,
        initialFailureReason: _0xe7c7fae1d50d,
        status: _0xdefea0608c5f(81537),
        result: _0xdefea0608c5f(81540),
        orderId: _0xdefea0608c5f(81528),
        observedUnitPrice: _0xdefea0608c5f(81528),
        selectedQuantity: _0xdefea0608c5f(81528),
        precheckPassed: false,
        addedToCart: false,
        updatedAt: new Date().toISOString()
    };
}
function _0xba706573889e(_0x80959b03a7a0) {
    return [
        _0x80959b03a7a0.temuOrderId,
        _0x80959b03a7a0.amzLink,
        _0x80959b03a7a0.quantityToShip,
        _0x80959b03a7a0.recipientName,
        _0x80959b03a7a0.phoneNumber,
        _0x80959b03a7a0.shipAddress,
        _0x80959b03a7a0.address2,
        _0x80959b03a7a0.shipCity,
        _0x80959b03a7a0.shipPostalCode
    ].every((_0x10cedf527305) => String(_0x10cedf527305 ?? _0xdefea0608c5f(81528)).trim() === _0xdefea0608c5f(81528));
}
function _0x6c4eec96f923(_0x79ff4dd4f6a9, _0x700ed1de385f, _0x41a8934e5abf) {
    _0x79ff4dd4f6a9.status = _0x700ed1de385f;
    _0x79ff4dd4f6a9.result = _0x41a8934e5abf;
    _0x79ff4dd4f6a9.updatedAt = new Date().toISOString();
}
function _0xafd75b332654(_0xbfa7259ec4a8, _0x6749e4055a59) {
    const _0x4261e0617fd8 = new Map();
    for (const _0xcb64a1185503 of _0x6749e4055a59) {
        const _0x77a129fd9afb = _0xbfa7259ec4a8[_0xcb64a1185503];
        if (!_0x77a129fd9afb?.asin || !Number.isSafeInteger(_0x77a129fd9afb.requestedQuantity) || _0x77a129fd9afb.requestedQuantity <= 0) {
            continue;
        }
        _0x4261e0617fd8.set(_0x77a129fd9afb.asin, (_0x4261e0617fd8.get(_0x77a129fd9afb.asin) || 0) + _0x77a129fd9afb.requestedQuantity);
    }
    return [..._0x4261e0617fd8.entries()]
        .sort(([_0xee26b5ffdff3], [_0xd5199dbcf71f]) => _0xee26b5ffdff3.localeCompare(_0xd5199dbcf71f))
        .map(([_0x395e8577696c, _0xc47250215a04]) => ({ asin: _0x395e8577696c, quantity: _0xc47250215a04 }));
}
function _0xeea69926bea6(_0xf54bffce568a) {
    return (Array.isArray(_0xf54bffce568a) ? _0xf54bffce568a : [])
        .map((_0x4b28d556de71) => `${_0x4b28d556de71.asin}x${_0x4b28d556de71.quantity}`)
        .join(_0xdefea0608c5f(81480));
}
function _0xcf3dc02b2cac(_0x7c2336f41618, _0x4f5a95cda248, _0xa69110542817) {
    return _0x4f5a95cda248.rowIndexes.filter((_0x91cc65158456) => _0x7c2336f41618[_0x91cc65158456]?.normalizedTemuOrderId === _0xa69110542817);
}
function _0x44b23879e6a9(_0x2d833440cc30, _0xf96da777e58c, _0x2c53b05bdcba) {
    const _0x30ad0d99f87e = [..._0xf96da777e58c].sort((_0xedf02059b79c, _0x7ac942e6a440) => _0x2d833440cc30[_0xedf02059b79c].sourceIndex - _0x2d833440cc30[_0x7ac942e6a440].sourceIndex);
    const _0x5f0aeea9f54e = _0x30ad0d99f87e[0];
    const _0xbb3ee45b1e98 = _0x2d833440cc30[_0x5f0aeea9f54e];
    const _0x44b3d8c160d2 = [...new Set(_0x30ad0d99f87e.map((_0xd08e5e51b27f) => _0x040a30dfbe94(_0x2d833440cc30[_0xd08e5e51b27f].phoneNumber)).filter(Boolean))];
    const _0xdec813ce9ae5 = _0xafd75b332654(_0x2d833440cc30, _0x30ad0d99f87e);
    const _0x6732101e6769 = _0xdec813ce9ae5.reduce((_0xdb861c7c8266, _0xa4ef430bd306) => _0xdb861c7c8266 + _0xa4ef430bd306.quantity, 0);
    const _0xf3328a062f7e = [...new Set(_0x30ad0d99f87e.map((_0x8b4a69ed3a2d) => _0x2d833440cc30[_0x8b4a69ed3a2d].normalizedTemuOrderId).filter(Boolean))];
    const _0x74643ad9e108 = {};
    const _0x681a83ecbfd8 = {};
    for (const _0x7a9da44916cb of _0xf3328a062f7e) {
        const _0x2ed08e687d82 = _0xcf3dc02b2cac(_0x2d833440cc30, { rowIndexes: _0x30ad0d99f87e }, _0x7a9da44916cb);
        const _0x606a745d2f46 = _0xafd75b332654(_0x2d833440cc30, _0x2ed08e687d82);
        const _0x461fd48c10f4 = _0xeea69926bea6(_0x606a745d2f46);
        _0x681a83ecbfd8[_0x7a9da44916cb] = _0x461fd48c10f4;
        _0x74643ad9e108[_0x7a9da44916cb] = `${_0xbb3ee45b1e98.addressSignature}||${_0x461fd48c10f4}`;
    }
    const _0x7f773c6d1418 = `group-${_0x2c53b05bdcba}-${crypto.randomUUID()}`;
    _0x30ad0d99f87e.forEach((_0x85f848185114, _0x5c54cfa6fd31) => {
        _0x2d833440cc30[_0x85f848185114].groupId = _0x7f773c6d1418;
        _0x2d833440cc30[_0x85f848185114].groupPosition = _0x5c54cfa6fd31;
        _0x2d833440cc30[_0x85f848185114].groupSize = _0x30ad0d99f87e.length;
    });
    return {
        id: _0x7f773c6d1418,
        key: _0xbb3ee45b1e98.addressSignature,
        sortKey: [
            _0xcb5feb506b6c(_0xbb3ee45b1e98.shipAddress),
            _0xcb5feb506b6c(_0xbb3ee45b1e98.address2),
            _0xcb5feb506b6c(_0xbb3ee45b1e98.shipCity),
            _0xcb5feb506b6c(_0xbb3ee45b1e98.shipPostalCode),
            _0xbb3ee45b1e98.normalizedNameKey
        ].join(_0xdefea0608c5f(81480)),
        originalPosition: _0xbb3ee45b1e98.sourceIndex,
        rowIndexes: _0x30ad0d99f87e,
        primaryRowIndex: _0x5f0aeea9f54e,
        isCombined: _0x30ad0d99f87e.length > 1,
        normalizedName: _0xbb3ee45b1e98.normalizedName,
        normalizedNameKey: _0xbb3ee45b1e98.normalizedNameKey,
        shipAddress: _0xbb3ee45b1e98.shipAddress,
        address2: _0xbb3ee45b1e98.address2,
        shipCity: _0xbb3ee45b1e98.shipCity,
        shipPostalCode: _0xbb3ee45b1e98.shipPostalCode,
        phoneNumber: _0xbb3ee45b1e98.phoneNumber,
        phoneMismatch: _0x44b3d8c160d2.length > 1,
        phoneNumbers: _0x44b3d8c160d2,
        addressSignature: _0xbb3ee45b1e98.addressSignature,
        expectedItems: _0xdec813ce9ae5,
        expectedItemSignature: _0xeea69926bea6(_0xdec813ce9ae5),
        expectedTotalQuantity: _0x6732101e6769,
        uniqueTemuOrderIds: _0xf3328a062f7e,
        temuSignatures: _0x74643ad9e108,
        temuItemSignatures: _0x681a83ecbfd8,
        groupSignature: `${_0xbb3ee45b1e98.addressSignature}||${_0xeea69926bea6(_0xdec813ce9ae5)}`,
        result: _0xdefea0608c5f(81515),
        status: _0xdefea0608c5f(81537),
        triggerRowIndex: null,
        precheckCursor: 0,
        addCursor: 0,
        expectedCartCount: 0,
        actualDeliveryAddress: _0xdefea0608c5f(81528),
        orderId: _0xdefea0608c5f(81528),
        updatedAt: new Date().toISOString()
    };
}
function _0x07765bdf7bf4(_0x5c9e0c5f3508, _0xafcd44f50e34, _0xb417f3509927, _0x4cac2be6cfe7) {
    _0xafcd44f50e34.result = _0xdefea0608c5f(81638);
    _0xafcd44f50e34.status = _0x4cac2be6cfe7;
    _0xafcd44f50e34.triggerRowIndex = _0xb417f3509927;
    _0xafcd44f50e34.updatedAt = new Date().toISOString();
    for (const _0xa2528b0e3e92 of _0xafcd44f50e34.rowIndexes) {
        const _0x4ecc45d31665 = _0x5c9e0c5f3508[_0xa2528b0e3e92];
        const _0x060369607bed = _0xa2528b0e3e92 === _0xb417f3509927 || _0xafcd44f50e34.rowIndexes.length === 1
            ? _0x4cac2be6cfe7 : _0xdefea0608c5f(81661);
        _0x6c4eec96f923(_0x4ecc45d31665, _0x060369607bed, _0xdefea0608c5f(81638));
    }
}
function _0xef306e091ba6(_0xb72a70efaa48, _0x386438785a73, _0x692b945a9102) {
    _0x386438785a73.result = _0xdefea0608c5f(81564);
    _0x386438785a73.status = `等待人工检查：${_0x692b945a9102}`;
    _0x386438785a73.updatedAt = new Date().toISOString();
    for (const _0x64a3502270f3 of _0x386438785a73.rowIndexes) {
        _0x6c4eec96f923(_0xb72a70efaa48[_0x64a3502270f3], `等待人工检查：${_0x692b945a9102}`, _0xdefea0608c5f(81564));
    }
}
function _0x0746180a2a72(_0xf8373f22edd2, _0x997d69ecb3e9, _0x6e56721495f6) {
    _0x997d69ecb3e9.result = _0xdefea0608c5f(81613);
    _0x997d69ecb3e9.status = _0x6e56721495f6;
    _0x997d69ecb3e9.updatedAt = new Date().toISOString();
    for (const _0xb9c43e05c169 of _0x997d69ecb3e9.rowIndexes) {
        const _0x5c312e2cd171 = _0xf8373f22edd2[_0xb9c43e05c169];
        if (_0x5c312e2cd171.result !== _0xdefea0608c5f(81645) && _0x5c312e2cd171.result !== _0xdefea0608c5f(81638)) {
            _0x6c4eec96f923(_0x5c312e2cd171, _0x6e56721495f6, _0xdefea0608c5f(81613));
        }
    }
}
function _0xcb2a1cb7f23c(_0x3cda6ef3d6a7, _0xcd0aa4463630, _0x2b2a48505d08) {
    _0xcd0aa4463630.result = _0xdefea0608c5f(81645);
    _0xcd0aa4463630.status = _0xdefea0608c5f(81704);
    _0xcd0aa4463630.orderId = _0x2b2a48505d08;
    _0xcd0aa4463630.updatedAt = new Date().toISOString();
    for (const _0x440c496141ac of _0xcd0aa4463630.rowIndexes) {
        const _0x3f4971a4b568 = _0x3cda6ef3d6a7[_0x440c496141ac];
        _0x3f4971a4b568.orderId = _0x2b2a48505d08;
        _0x6c4eec96f923(_0x3f4971a4b568, _0xdefea0608c5f(81704), _0xdefea0608c5f(81645));
    }
}
function _0x432be7529471(_0x95a65dd33559, _0x879df9f2221d, _0x1c0cd10c051a) {
    const _0x0c6ee22e1b24 = _0x03487935396e(_0x1c0cd10c051a, _0x879df9f2221d);
    const _0x7d635bf40d9c = _0x251e0f49d3e1();
    const _0x794618654640 = (Array.isArray(_0x95a65dd33559) ? _0x95a65dd33559 : [])
        .map((_0x4c18fd522002, _0x9f23da0c8ed8) => _0xd337b6d7607d(_0x4c18fd522002, _0x9f23da0c8ed8))
        .filter((_0x6f87af799a8a) => !_0xba706573889e(_0x6f87af799a8a));
    const _0x61daaee4a41d = new Map();
    for (let _0x02393201e25f = 0; _0x02393201e25f < _0x794618654640.length; _0x02393201e25f += 1) {
        const _0x75704cc4bf53 = _0x794618654640[_0x02393201e25f];
        if (!_0x75704cc4bf53.addressSignature) {
            _0x6c4eec96f923(_0x75704cc4bf53, _0x75704cc4bf53.initialFailureReason || _0xdefea0608c5f(81577), _0xdefea0608c5f(81638));
            continue;
        }
        if (!_0x61daaee4a41d.has(_0x75704cc4bf53.addressSignature)) {
            _0x61daaee4a41d.set(_0x75704cc4bf53.addressSignature, []);
        }
        _0x61daaee4a41d.get(_0x75704cc4bf53.addressSignature).push(_0x02393201e25f);
    }
    const _0x15aecaa0ffbf = [..._0x61daaee4a41d.values()].map((_0x53be128a1f02, _0x3e3e8e9fe150) => _0x44b23879e6a9(_0x794618654640, _0x53be128a1f02, _0x3e3e8e9fe150 + 1));
    _0x15aecaa0ffbf.sort((_0x8ccc0e85aab7, _0xdc48851f037b) => _0x8ccc0e85aab7.originalPosition - _0xdc48851f037b.originalPosition);
    for (const _0x2998a9aa4abf of _0x15aecaa0ffbf) {
        const _0xd6abbc992f0f = _0x2998a9aa4abf.rowIndexes.find((_0xfe6d89f720ff) => _0x794618654640[_0xfe6d89f720ff].initialFailureReason);
        if (_0xd6abbc992f0f !== undefined) {
            _0x07765bdf7bf4(_0x794618654640, _0x2998a9aa4abf, _0xd6abbc992f0f, _0x794618654640[_0xd6abbc992f0f].initialFailureReason);
        }
        else {
            _0x2998a9aa4abf.result = _0xdefea0608c5f(81515);
            _0x2998a9aa4abf.status = _0xdefea0608c5f(81537);
            for (const _0xaf7ac4dd30a0 of _0x2998a9aa4abf.rowIndexes) {
                _0x6c4eec96f923(_0x794618654640[_0xaf7ac4dd30a0], _0xdefea0608c5f(81537), _0xdefea0608c5f(81515));
            }
        }
    }
    const _0xc4090a87c2c4 = [];
    const _0x2bd15a25fa12 = new Map();
    for (const _0x53778ecdec6c of _0x15aecaa0ffbf) {
        for (const _0x94fa7f584b6a of _0x53778ecdec6c.uniqueTemuOrderIds) {
            if (!_0x2bd15a25fa12.has(_0x94fa7f584b6a)) {
                _0x2bd15a25fa12.set(_0x94fa7f584b6a, new Set());
            }
            _0x2bd15a25fa12.get(_0x94fa7f584b6a).add(_0x53778ecdec6c.id);
        }
    }
    for (const [_0x48143a6efe85, _0x97b34fdb1e84] of _0x2bd15a25fa12.entries()) {
        if (_0x97b34fdb1e84.size <= 1) {
            continue;
        }
        const _0x62be6bf40251 = `Temu Order ID ${_0x48143a6efe85} 出现在不同收件地址组，已停止等待人工检查。`;
        _0xc4090a87c2c4.push(_0x62be6bf40251);
        for (const _0x48b2d26ce4bb of _0x97b34fdb1e84) {
            const _0x3f8fcd2050f9 = _0x15aecaa0ffbf.find((_0x2a2da280d6c1) => _0x2a2da280d6c1.id === _0x48b2d26ce4bb);
            if (_0x3f8fcd2050f9) {
                _0xef306e091ba6(_0x794618654640, _0x3f8fcd2050f9, _0x62be6bf40251);
            }
        }
    }
    for (const _0xc829efd570c4 of _0x15aecaa0ffbf) {
        if (_0xc829efd570c4.result !== _0xdefea0608c5f(81515)) {
            continue;
        }
        let _0xc28c27626105 = null;
        let _0x5fab3a10cd94 = null;
        for (const _0xe34497c572e4 of _0xc829efd570c4.uniqueTemuOrderIds) {
            const _0x7bd12182190a = _0x0c6ee22e1b24[_0xa3c8b008e98d(_0xe34497c572e4)];
            if (!_0x7bd12182190a ||
                _0x7bd12182190a.status !== _0xdefea0608c5f(81574) ||
                _0x7bd12182190a.dateKey !== _0x7d635bf40d9c ||
                !_0x91508b6109bd(_0x7bd12182190a.orderId)) {
                continue;
            }
            const _0x0156280e1a5b = _0xc829efd570c4.temuSignatures[_0xe34497c572e4] || _0xdefea0608c5f(81528);
            if (_0x7bd12182190a.temuSignature && _0x0156280e1a5b && _0x7bd12182190a.temuSignature !== _0x0156280e1a5b) {
                _0x5fab3a10cd94 = `Temu Order ID ${_0xe34497c572e4} 今天已有订单，但本次地址、商品或数量签名不同，已停止等待人工检查。`;
                break;
            }
            const _0x57bf460d0ae7 = _0xc829efd570c4.rowIndexes.find((_0x0d9afc85d308) => _0x794618654640[_0x0d9afc85d308].normalizedTemuOrderId === _0xe34497c572e4);
            _0xc28c27626105 = {
                triggerRowIndex: _0x57bf460d0ae7,
                reason: _0xdefea0608c5f(81598)
            };
            break;
        }
        if (_0x5fab3a10cd94) {
            _0xc4090a87c2c4.push(_0x5fab3a10cd94);
            _0xef306e091ba6(_0x794618654640, _0xc829efd570c4, _0x5fab3a10cd94);
        }
        else if (_0xc28c27626105) {
            _0x07765bdf7bf4(_0x794618654640, _0xc829efd570c4, _0xc28c27626105.triggerRowIndex, _0xc28c27626105.reason);
        }
    }
    const _0x93183caf2c26 = [...new Set(Object.values(_0x0c6ee22e1b24)
            .filter((_0x5f06b2638b1c) => _0x5f06b2638b1c?.dateKey === _0x7d635bf40d9c && _0x91508b6109bd(_0x5f06b2638b1c?.orderId))
            .map((_0xa01de0100c20) => _0xa01de0100c20.orderId))];
    return { rows: _0x794618654640, groups: _0x15aecaa0ffbf, orderIndex: _0x0c6ee22e1b24, fatalConflicts: _0xc4090a87c2c4, knownOrderIds: _0x93183caf2c26 };
}
function _0x4c981390cff2(_0x9b003374f98a, _0x6ae743bf8270, _0x910e74880ddc, _0x430a757fe5c3) {
    const _0xe113a2659023 = _0x03487935396e(_0x430a757fe5c3, _0x910e74880ddc);
    const _0x08d6b465b316 = Array.isArray(_0x9b003374f98a) ? _0x9b003374f98a : [];
    const _0x5851ed869c98 = Array.isArray(_0x6ae743bf8270) ? _0x6ae743bf8270 : [];
    const _0xf8299d44b627 = new Map();
    const _0xd73ffb69af55 = new Map();
    for (const _0x80c6bf8a4bf1 of _0x5851ed869c98) {
        const _0xc3098147d110 = _0xc8b8b6cc7f94(_0x80c6bf8a4bf1?.draftRowId);
        if (_0xc3098147d110 && !_0xf8299d44b627.has(_0xc3098147d110)) {
            _0xf8299d44b627.set(_0xc3098147d110, _0x80c6bf8a4bf1);
        }
        if (Number.isInteger(_0x80c6bf8a4bf1?.sourceIndex) && !_0xd73ffb69af55.has(_0x80c6bf8a4bf1.sourceIndex)) {
            _0xd73ffb69af55.set(_0x80c6bf8a4bf1.sourceIndex, _0x80c6bf8a4bf1);
        }
    }
    const _0xf58ced8e6012 = new Set();
    const _0x1f92d85f3433 = [];
    const _0x2c2c7c582d8c = [];
    const _0x6a67e5caf8f0 = [];
    for (let _0x6eedf5309294 = 0; _0x6eedf5309294 < _0x08d6b465b316.length; _0x6eedf5309294 += 1) {
        const _0x8ad68672c43b = _0x08d6b465b316[_0x6eedf5309294] && typeof _0x08d6b465b316[_0x6eedf5309294] === _0xdefea0608c5f(81615)
            ? _0x08d6b465b316[_0x6eedf5309294]
            : {};
        if (_0xba706573889e(_0x8ad68672c43b)) {
            continue;
        }
        const _0xdbd36ff6efa9 = _0xc8b8b6cc7f94(_0x8ad68672c43b._rowId || _0x8ad68672c43b.draftRowId);
        let _0x2ab74e3e94dc = _0xdbd36ff6efa9 ? _0xf8299d44b627.get(_0xdbd36ff6efa9) : null;
        if (!_0x2ab74e3e94dc) {
            const _0xbcabb10ceced = _0xd73ffb69af55.get(_0x6eedf5309294) || null;
            if (!_0xdbd36ff6efa9 || !_0xc8b8b6cc7f94(_0xbcabb10ceced?.draftRowId)) {
                _0x2ab74e3e94dc = _0xbcabb10ceced;
            }
        }
        if (!_0x2ab74e3e94dc) {
            continue;
        }
        if (_0xf58ced8e6012.has(_0x2ab74e3e94dc)) {
            _0x6a67e5caf8f0.push(_0x2ab74e3e94dc.rowNumber || _0x6eedf5309294 + 1);
            continue;
        }
        _0xf58ced8e6012.add(_0x2ab74e3e94dc);
        const _0x5899fb73d33f = _0x2ab74e3e94dc.result === _0xdefea0608c5f(81638) && !_0x91508b6109bd(_0x2ab74e3e94dc.orderId);
        if (_0x5899fb73d33f) {
            const _0x49d052f3e59b = _0xd337b6d7607d(_0x8ad68672c43b, _0x6eedf5309294);
            _0x49d052f3e59b.id = _0x2ab74e3e94dc.id || _0x49d052f3e59b.id;
            _0x49d052f3e59b.draftRowId = _0xdbd36ff6efa9 || _0xc8b8b6cc7f94(_0x2ab74e3e94dc.draftRowId) || _0x49d052f3e59b.draftRowId;
            _0x49d052f3e59b.status = _0xdefea0608c5f(81630);
            _0x49d052f3e59b.result = _0xdefea0608c5f(81540);
            const _0x2b046d49a478 = _0x1f92d85f3433.length;
            _0x1f92d85f3433.push(_0x49d052f3e59b);
            _0x2c2c7c582d8c.push(_0x2b046d49a478);
            continue;
        }
        _0x1f92d85f3433.push({
            ..._0x2ab74e3e94dc,
            draftRowId: _0xdbd36ff6efa9 || _0xc8b8b6cc7f94(_0x2ab74e3e94dc.draftRowId) || crypto.randomUUID(),
            sourceIndex: _0x6eedf5309294,
            rowNumber: _0x6eedf5309294 + 1
        });
    }
    const _0x461902044f73 = [];
    for (const _0xb9aa3cb4f765 of _0x5851ed869c98) {
        if (_0xf58ced8e6012.has(_0xb9aa3cb4f765)) {
            continue;
        }
        const _0x71abba473ca1 = _0xb9aa3cb4f765.result === _0xdefea0608c5f(81638) && !_0x91508b6109bd(_0xb9aa3cb4f765.orderId);
        if (_0x71abba473ca1) {
            _0x461902044f73.push(_0xb9aa3cb4f765.rowNumber || _0xb9aa3cb4f765.sourceIndex + 1);
            continue;
        }
        _0x1f92d85f3433.push({ ..._0xb9aa3cb4f765 });
    }
    if (_0x6a67e5caf8f0.length > 0) {
        return {
            error: `当前输入表格存在重复内部行标识，涉及原工作记录第 ${_0x6a67e5caf8f0.join(_0xdefea0608c5f(81472))} 行。请清空并重新粘贴后再重下。`
        };
    }
    if (_0x461902044f73.length > 0) {
        return {
            error: `有 ${_0x461902044f73.length} 条跳过记录已从当前输入表格删除或无法对应（原第 ${_0x461902044f73.join(_0xdefea0608c5f(81472))} 行），不能保证安全覆盖工作结果。`
        };
    }
    if (_0x2c2c7c582d8c.length === 0) {
        return { error: _0xdefea0608c5f(81631) };
    }
    const _0xe5ae0870ad9b = new Map();
    for (const _0x42897271a649 of _0x2c2c7c582d8c) {
        const _0x56644ace5113 = _0x1f92d85f3433[_0x42897271a649];
        if (!_0x56644ace5113.addressSignature) {
            _0x6c4eec96f923(_0x56644ace5113, _0x56644ace5113.initialFailureReason || _0xdefea0608c5f(81577), _0xdefea0608c5f(81638));
            continue;
        }
        if (!_0xe5ae0870ad9b.has(_0x56644ace5113.addressSignature)) {
            _0xe5ae0870ad9b.set(_0x56644ace5113.addressSignature, []);
        }
        _0xe5ae0870ad9b.get(_0x56644ace5113.addressSignature).push(_0x42897271a649);
    }
    const _0x2730c3344d3f = [..._0xe5ae0870ad9b.values()].map((_0x7d9ae2bfce9f, _0x957790638744) => _0x44b23879e6a9(_0x1f92d85f3433, _0x7d9ae2bfce9f, _0x957790638744 + 1));
    _0x2730c3344d3f.sort((_0x2b36cf27f703, _0x9cb1433f63ae) => _0x2b36cf27f703.originalPosition - _0x9cb1433f63ae.originalPosition);
    for (const _0x9f4d6068adec of _0x2730c3344d3f) {
        const _0xf2793cee3495 = _0x9f4d6068adec.rowIndexes.find((_0x495397f19f9d) => _0x1f92d85f3433[_0x495397f19f9d].initialFailureReason);
        if (_0xf2793cee3495 !== undefined) {
            _0x07765bdf7bf4(_0x1f92d85f3433, _0x9f4d6068adec, _0xf2793cee3495, _0x1f92d85f3433[_0xf2793cee3495].initialFailureReason);
        }
        else {
            _0x9f4d6068adec.result = _0xdefea0608c5f(81515);
            _0x9f4d6068adec.status = _0xdefea0608c5f(81630);
            for (const _0x0dbae36fd790 of _0x9f4d6068adec.rowIndexes) {
                _0x6c4eec96f923(_0x1f92d85f3433[_0x0dbae36fd790], _0xdefea0608c5f(81630), _0xdefea0608c5f(81515));
            }
        }
    }
    const _0x759018562603 = [];
    const _0xc279b3c4c316 = new Map();
    for (const _0xf0547bfb28b2 of _0x2730c3344d3f) {
        for (const _0x45c7a1b0a967 of _0xf0547bfb28b2.uniqueTemuOrderIds) {
            if (!_0xc279b3c4c316.has(_0x45c7a1b0a967)) {
                _0xc279b3c4c316.set(_0x45c7a1b0a967, new Set());
            }
            _0xc279b3c4c316.get(_0x45c7a1b0a967).add(_0xf0547bfb28b2.id);
        }
    }
    for (const [_0xeb55b2f6d2bf, _0xbeb92e7740d2] of _0xc279b3c4c316.entries()) {
        if (_0xbeb92e7740d2.size <= 1) {
            continue;
        }
        const _0x6463149e2757 = `重下数据中 Temu Order ID ${_0xeb55b2f6d2bf} 出现在不同收件地址组，已停止等待人工检查。`;
        _0x759018562603.push(_0x6463149e2757);
        for (const _0xe0661170586e of _0xbeb92e7740d2) {
            const _0x905eea55a928 = _0x2730c3344d3f.find((_0x791ffa3261ff) => _0x791ffa3261ff.id === _0xe0661170586e);
            if (_0x905eea55a928) {
                _0xef306e091ba6(_0x1f92d85f3433, _0x905eea55a928, _0x6463149e2757);
            }
        }
    }
    const _0x40bd8d714384 = [...new Set([
            ...Object.values(_0xe113a2659023)
                .map((_0x587f9bf5ce41) => String(_0x587f9bf5ce41?.orderId || _0xdefea0608c5f(81528)).trim())
                .filter(_0x91508b6109bd),
            ..._0x5851ed869c98.map((_0x43af0213ba76) => String(_0x43af0213ba76?.orderId || _0xdefea0608c5f(81528)).trim())
                .filter(_0x91508b6109bd)
        ])];
    return {
        rows: _0x1f92d85f3433,
        groups: _0x2730c3344d3f,
        orderIndex: _0xe113a2659023,
        fatalConflicts: _0x759018562603,
        knownOrderIds: _0x40bd8d714384,
        retryCount: _0x2c2c7c582d8c.length
    };
}
function _0x0f1be5499895(_0x2d3f7c24fa08, _0xeb01253b6df7 = -1) {
    for (let _0x0aca0ab4a035 = _0xeb01253b6df7 + 1; _0x0aca0ab4a035 < _0x2d3f7c24fa08.length; _0x0aca0ab4a035 += 1) {
        if (_0x2d3f7c24fa08[_0x0aca0ab4a035]?.result === _0xdefea0608c5f(81515)) {
            return _0x0aca0ab4a035;
        }
    }
    return -1;
}
function _0xd95c33d75b28(_0x3118317efcb0) {
    if (!_0x3118317efcb0 || !Array.isArray(_0x3118317efcb0.groups) || !Number.isInteger(_0x3118317efcb0.currentGroupIndex)) {
        return null;
    }
    return _0x3118317efcb0.groups[_0x3118317efcb0.currentGroupIndex] || null;
}
function _0x7099183f8138(_0xd6875bbd898b) {
    if (!_0xd6875bbd898b || !Array.isArray(_0xd6875bbd898b.rows) || !Number.isInteger(_0xd6875bbd898b.currentIndex)) {
        return null;
    }
    return _0xd6875bbd898b.rows[_0xd6875bbd898b.currentIndex] || null;
}
function _0x0bfa2a1893b2(_0x2b2ae89cb813) {
    const _0x9d0aa6525ec6 = _0xd95c33d75b28(_0x2b2ae89cb813);
    if (!_0x9d0aa6525ec6 || !Array.isArray(_0x2b2ae89cb813?.rows)) {
        return _0x7099183f8138(_0x2b2ae89cb813);
    }
    return _0x2b2ae89cb813.rows[_0x9d0aa6525ec6.primaryRowIndex] || _0x7099183f8138(_0x2b2ae89cb813);
}
async function _0x4d5b02696d67() {
    return chrome.storage.local.get([
        _0x3e8163af073e.RUN_STATE,
        _0x3e8163af073e.HISTORY,
        _0x3e8163af073e.ORDER_INDEX,
        _0x3e8163af073e.CART_LOCK,
        _0x3e8163af073e.LOGS,
        _0x3e8163af073e.DRAFT_ROWS,
        _0x3e8163af073e.SETTINGS
    ]);
}
async function _0xc2077eb1ebcf() {
    const _0x2b94ef0ec3bd = chrome.runtime.getURL(_0xdefea0608c5f(81648));
    const _0x131d77fe79cc = await chrome.windows.getAll({ populate: true });
    for (const _0x9bfde82fdc38 of _0x131d77fe79cc) {
        const _0xe28c20bb0592 = _0x9bfde82fdc38.tabs?.find((_0xabdcdbc3c83d) => _0xabdcdbc3c83d.url === _0x2b94ef0ec3bd);
        if (_0xe28c20bb0592) {
            await chrome.windows.update(_0x9bfde82fdc38.id, { focused: true });
            await chrome.tabs.update(_0xe28c20bb0592.id, { active: true });
            return;
        }
    }
    await chrome.windows.create({
        url: _0x2b94ef0ec3bd,
        type: _0xdefea0608c5f(81668),
        width: 1440,
        height: 920,
        focused: true
    });
}
async function _0xb86675aa5153(_0xec70300f6b28 = null) {
    if (Number.isInteger(_0xec70300f6b28)) {
        try {
            const _0x7476c1280808 = await chrome.tabs.get(_0xec70300f6b28);
            await chrome.tabs.update(_0x7476c1280808.id, { url: _0xdefea0608c5f(81702), active: true });
            await chrome.windows.update(_0x7476c1280808.windowId, { focused: true });
            await _0x4d54ecb4cff7(120);
            return _0x7476c1280808.id;
        }
        catch {
        }
    }
    const _0xea8fe6f495e1 = await chrome.windows.getAll({ windowTypes: [_0xdefea0608c5f(81522)] });
    const _0x01e7dca78a89 = _0xea8fe6f495e1.find((_0x9441c476e3d6) => _0x9441c476e3d6.focused) || _0xea8fe6f495e1[0];
    if (_0x01e7dca78a89) {
        const _0x645d9a4d03bf = await chrome.tabs.create({
            windowId: _0x01e7dca78a89.id,
            url: _0xdefea0608c5f(81702),
            active: true
        });
        await chrome.windows.update(_0x01e7dca78a89.id, { focused: true });
        return _0x645d9a4d03bf.id;
    }
    const _0xd17e2439df74 = await chrome.windows.create({
        type: _0xdefea0608c5f(81522),
        url: _0xdefea0608c5f(81702),
        focused: true
    });
    const _0xc85e004d77a4 = _0xd17e2439df74.tabs?.[0]?.id;
    if (!Number.isInteger(_0xc85e004d77a4)) {
        throw new Error(_0xdefea0608c5f(81469));
    }
    return _0xc85e004d77a4;
}
async function _0x1ac813b83bad(_0x30a59745c7a5) {
    if (!Number.isInteger(_0x30a59745c7a5)) {
        throw new Error(_0xdefea0608c5f(81640));
    }
    const _0x0f85dc2e6f7b = await chrome.tabs.get(_0x30a59745c7a5);
    await chrome.tabs.update(_0x30a59745c7a5, { active: true });
    await chrome.windows.update(_0x0f85dc2e6f7b.windowId, { focused: true });
}
async function _0xc70c7bf1c52a(_0xbb254ea89e76) {
    if (!Number.isInteger(_0xbb254ea89e76)) {
        return;
    }
    try {
        await chrome.tabs.sendMessage(_0xbb254ea89e76, { type: _0xdefea0608c5f(81542) });
    }
    catch {
    }
}
async function _0x3b99d8c28ab2(_0xeee4510bff54, _0x251f63e3d56c) {
    if (!Number.isInteger(_0xeee4510bff54)) {
        throw new Error(_0xdefea0608c5f(81640));
    }
    await chrome.tabs.update(_0xeee4510bff54, { url: _0x251f63e3d56c, active: true });
    await _0x1ac813b83bad(_0xeee4510bff54);
}
async function _0x69458914c08b(_0xb780a5cdb8d1, _0x431c3a32cffc, _0x38cdea0490a0, _0x573ac09c925a = {}, _0x832a60fa31bc = _0xdefea0608c5f(81632)) {
    const _0x2c13786e3d6e = Number.isInteger(_0xb780a5cdb8d1?.workTabId) ? _0xb780a5cdb8d1.workTabId : null;
    let _0x5253e9c9ba82 = null;
    let _0xa2e08358e99e = null;
    if (_0x2c13786e3d6e !== null) {
        try {
            _0x5253e9c9ba82 = await chrome.tabs.get(_0x2c13786e3d6e);
        }
        catch {
            _0x5253e9c9ba82 = null;
        }
    }
    try {
        if (_0x5253e9c9ba82) {
            const _0xeec9a04423b9 = {
                windowId: _0x5253e9c9ba82.windowId,
                url: _0xdefea0608c5f(81702),
                active: true
            };
            if (Number.isInteger(_0x5253e9c9ba82.index)) {
                _0xeec9a04423b9.index = _0x5253e9c9ba82.index + 1;
            }
            const _0x61e4c6c19221 = await chrome.tabs.create(_0xeec9a04423b9);
            if (!Number.isInteger(_0x61e4c6c19221?.id)) {
                throw new Error(_0xdefea0608c5f(81616));
            }
            _0xa2e08358e99e = _0x61e4c6c19221.id;
            await chrome.windows.update(_0x5253e9c9ba82.windowId, { focused: true });
        }
        else {
            _0xa2e08358e99e = await _0xb86675aa5153(null);
        }
        _0xb780a5cdb8d1.workTabId = _0xa2e08358e99e;
        _0xb780a5cdb8d1.updatedAt = new Date().toISOString();
        await _0xe0f1516d2a85(_0xb780a5cdb8d1, _0x431c3a32cffc, _0x573ac09c925a);
        await _0x3b99d8c28ab2(_0xa2e08358e99e, _0x38cdea0490a0);
        if (_0x2c13786e3d6e !== null && _0x2c13786e3d6e !== _0xa2e08358e99e) {
            try {
                await chrome.tabs.remove(_0x2c13786e3d6e);
            }
            catch {
            }
        }
        return { ok: true, oldTabId: _0x2c13786e3d6e, newTabId: _0xa2e08358e99e };
    }
    catch (_0x315740639a75) {
        if (Number.isInteger(_0xa2e08358e99e) && _0xa2e08358e99e !== _0x2c13786e3d6e) {
            try {
                await chrome.tabs.remove(_0xa2e08358e99e);
            }
            catch {
            }
        }
        let _0xd5fa2f3f889e = false;
        if (_0x2c13786e3d6e !== null) {
            try {
                await chrome.tabs.get(_0x2c13786e3d6e);
                _0xd5fa2f3f889e = true;
            }
            catch {
                _0xd5fa2f3f889e = false;
            }
        }
        _0xb780a5cdb8d1.workTabId = _0xd5fa2f3f889e ? _0x2c13786e3d6e : null;
        _0xb780a5cdb8d1.mode = _0xdefea0608c5f(81504);
        _0xb780a5cdb8d1.pauseReason = `${_0x832a60fa31bc}失败：${_0x315740639a75.message || String(_0x315740639a75)}`;
        _0xb780a5cdb8d1.updatedAt = new Date().toISOString();
        const _0xa06959654889 = _0xd95c33d75b28(_0xb780a5cdb8d1);
        const _0xb2cc269dacbd = _0x7099183f8138(_0xb780a5cdb8d1);
        if (_0xa06959654889?.isCombined) {
            _0xef306e091ba6(_0xb780a5cdb8d1.rows, _0xa06959654889, _0xb780a5cdb8d1.pauseReason);
        }
        else if (_0xb2cc269dacbd) {
            _0x6c4eec96f923(_0xb2cc269dacbd, `等待人工检查：${_0xb780a5cdb8d1.pauseReason}`, _0xdefea0608c5f(81564));
        }
        _0x9ed268225a55(_0x431c3a32cffc, _0xdefea0608c5f(81662), _0xb780a5cdb8d1.pauseReason, _0xb2cc269dacbd?.rowNumber ?? null);
        await _0xe0f1516d2a85(_0xb780a5cdb8d1, _0x431c3a32cffc, _0x573ac09c925a);
        return { ok: false, error: _0xb780a5cdb8d1.pauseReason };
    }
}
async function _0xe0f1516d2a85(_0x9860110a40b9, _0x121dd610646c, _0x294b24bd7856 = {}) {
    await chrome.storage.local.set({
        [_0x3e8163af073e.RUN_STATE]: _0x9860110a40b9,
        [_0x3e8163af073e.LOGS]: _0x121dd610646c,
        ..._0x294b24bd7856
    });
}
function _0x00e349e00e8d(_0xe2fb99c4d7d2, _0x47f0fcd25e08) {
    return {
        version: 1,
        runId: _0xe2fb99c4d7d2.runId,
        groupId: _0x47f0fcd25e08.id,
        groupSignature: _0x47f0fcd25e08.groupSignature,
        rowNumbers: _0x47f0fcd25e08.rowIndexes.map((_0xa18853ddd28a) => _0xe2fb99c4d7d2.rows[_0xa18853ddd28a].rowNumber),
        temuOrderIds: _0x47f0fcd25e08.uniqueTemuOrderIds,
        expectedTotalQuantity: _0x47f0fcd25e08.expectedTotalQuantity,
        expectedItems: _0x47f0fcd25e08.expectedItems,
        addedRowIndexes: [],
        expectedCartCount: 0,
        stage: _0xdefea0608c5f(81459),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
}
function _0x4c9bde331c2e(_0xbcdcc3caf63b, _0x537e8eb9c577, _0x14990bac413d) {
    return Boolean(_0xbcdcc3caf63b &&
        _0xbcdcc3caf63b.runId === _0x537e8eb9c577?.runId &&
        _0xbcdcc3caf63b.groupId === _0x14990bac413d?.id &&
        _0xbcdcc3caf63b.groupSignature === _0x14990bac413d?.groupSignature);
}
async function _0xcf6350c5ebaa(_0xd07f5a44018b, _0xbc4f79b3b956) {
    const _0x6d5f9cff6ee7 = await _0x4d5b02696d67();
    const _0x7f472be16f63 = Array.isArray(_0x6d5f9cff6ee7[_0x3e8163af073e.LOGS]) ? _0x6d5f9cff6ee7[_0x3e8163af073e.LOGS] : [];
    if (_0x6d5f9cff6ee7[_0x3e8163af073e.CART_LOCK]) {
        _0x9ed268225a55(_0x7f472be16f63, _0xdefea0608c5f(81662), _0xdefea0608c5f(81693));
        await chrome.storage.local.set({ [_0x3e8163af073e.LOGS]: _0x7f472be16f63 });
        return {
            ok: false,
            error: _0xdefea0608c5f(81671)
        };
    }
    const _0xb2847a2c8cb2 = _0x6d5f9cff6ee7[_0x3e8163af073e.RUN_STATE];
    if (_0xb2847a2c8cb2 && _0x80ae694037f0.has(_0xb2847a2c8cb2.mode)) {
        return {
            ok: false,
            error: _0xdefea0608c5f(81599)
        };
    }
    if (_0xb2847a2c8cb2?.runId) {
        await _0xffbec67a1c34(_0xb2847a2c8cb2.runId);
    }
    const _0xd707ff5bbd1f = _0x5e1ab07f720b(_0x6d5f9cff6ee7[_0x3e8163af073e.SETTINGS]);
    const _0xb5e8cb269a01 = _0xbc4f79b3b956 ?? _0xd707ff5bbd1f.orderIntervalSeconds;
    const _0xd995d5acd6e4 = Number(_0xb5e8cb269a01);
    if (!Number.isInteger(_0xd995d5acd6e4) || _0xd995d5acd6e4 < 0 || _0xd995d5acd6e4 > 3600) {
        return { ok: false, error: _0xdefea0608c5f(81602) };
    }
    const _0xcf0b43304984 = _0xd995d5acd6e4;
    const _0x5947c35a6ae1 = { orderIntervalSeconds: _0xcf0b43304984 };
    const _0x74cc500d50be = _0x6c1a1e83a579(_0x6d5f9cff6ee7[_0x3e8163af073e.HISTORY]);
    const _0xf5b80ff4208c = _0x432be7529471(_0xd07f5a44018b, _0x74cc500d50be, _0x6d5f9cff6ee7[_0x3e8163af073e.ORDER_INDEX]);
    const { rows: _0x7751efb29601, groups: _0x6ce6cca7db35, orderIndex: _0xb6668c479e05, fatalConflicts: _0xc79eba08e52a, knownOrderIds: _0xa3cc2b234003 } = _0xf5b80ff4208c;
    if (_0x7751efb29601.length === 0) {
        return { ok: false, error: _0xdefea0608c5f(81552) };
    }
    _0x9ed268225a55(_0x7f472be16f63, _0xdefea0608c5f(81466), `任务预检查开始：共 ${_0x7751efb29601.length} 条非空数据，内部形成 ${_0x6ce6cca7db35.length} 个收件人地址组。`);
    _0x9ed268225a55(_0x7f472be16f63, _0xdefea0608c5f(81466), _0xdefea0608c5f(81481));
    for (const _0xe8086f69bcd2 of _0x6ce6cca7db35) {
        if (_0xe8086f69bcd2.phoneMismatch) {
            const _0xe695c54e94e8 = _0x7751efb29601[_0xe8086f69bcd2.primaryRowIndex];
            _0x9ed268225a55(_0x7f472be16f63, _0xdefea0608c5f(81461), `同地址组合单存在不同电话号码，将使用原始输入中最先出现一行的电话号码：${_0xe695c54e94e8.phoneNumber}。`, _0xe695c54e94e8.rowNumber);
        }
    }
    const _0xb8ecfbe413f7 = _0x6ce6cca7db35.filter((_0x25ec444f077a) => _0x25ec444f077a.result === _0xdefea0608c5f(81515)).length;
    const _0x3b49d5b145f2 = _0x6ce6cca7db35.filter((_0x0684341d7ce9) => _0x0684341d7ce9.result === _0xdefea0608c5f(81515) && _0x0684341d7ce9.isCombined).length;
    const _0xea6cc31e94d0 = _0x7751efb29601.filter((_0x1bffcfe5582d) => _0x1bffcfe5582d.result === _0xdefea0608c5f(81638)).length;
    _0x9ed268225a55(_0x7f472be16f63, _0xdefea0608c5f(81466), `预检查完成：待处理地址组 ${_0xb8ecfbe413f7} 个（其中组合单 ${_0x3b49d5b145f2} 个），预先跳过 ${_0xea6cc31e94d0} 行。`);
    if (_0xc79eba08e52a.length > 0) {
        const _0x558770be1bb5 = _0x6ce6cca7db35.findIndex((_0xc15fc9980a42) => _0xc15fc9980a42.result === _0xdefea0608c5f(81564));
        const _0xeae27d1088c8 = _0x6ce6cca7db35[_0x558770be1bb5] || null;
        const _0x2115864a7b09 = {
            version: _0x237a184d8647,
            runId: crypto.randomUUID(),
            mode: _0xdefea0608c5f(81504),
            phase: _0xdefea0608c5f(81677),
            pauseReason: _0xc79eba08e52a[0],
            currentGroupIndex: _0x558770be1bb5 >= 0 ? _0x558770be1bb5 : null,
            currentIndex: _0xeae27d1088c8?.primaryRowIndex ?? null,
            rows: _0x7751efb29601,
            groups: _0x6ce6cca7db35,
            workTabId: null,
            orderIntervalSeconds: _0xcf0b43304984,
            intervalEndsAt: null,
            intervalRemainingSeconds: 0,
            knownOrderIds: _0xa3cc2b234003,
            todayDateKey: _0x251e0f49d3e1(),
            startedAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        _0xc79eba08e52a.forEach((_0x38738557613a) => _0x9ed268225a55(_0x7f472be16f63, _0xdefea0608c5f(81662), _0x38738557613a));
        await _0xe0f1516d2a85(_0x2115864a7b09, _0x7f472be16f63, {
            [_0x3e8163af073e.DRAFT_ROWS]: Array.isArray(_0xd07f5a44018b) ? _0xd07f5a44018b : [],
            [_0x3e8163af073e.HISTORY]: _0x74cc500d50be,
            [_0x3e8163af073e.ORDER_INDEX]: _0xb6668c479e05,
            [_0x3e8163af073e.SETTINGS]: _0x5947c35a6ae1
        });
        return { ok: true, state: _0x2115864a7b09, paused: true };
    }
    const _0x7c40cfc2fa53 = _0x0f1be5499895(_0x6ce6cca7db35);
    if (_0x7c40cfc2fa53 === -1) {
        const _0x5b56bdce3179 = {
            version: _0x237a184d8647,
            runId: crypto.randomUUID(),
            mode: _0xdefea0608c5f(81556),
            phase: _0xdefea0608c5f(81699),
            pauseReason: _0xdefea0608c5f(81528),
            currentGroupIndex: null,
            currentIndex: null,
            rows: _0x7751efb29601,
            groups: _0x6ce6cca7db35,
            workTabId: null,
            orderIntervalSeconds: _0xcf0b43304984,
            intervalEndsAt: null,
            intervalRemainingSeconds: 0,
            knownOrderIds: _0xa3cc2b234003,
            todayDateKey: _0x251e0f49d3e1(),
            startedAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        _0x9ed268225a55(_0x7f472be16f63, _0xdefea0608c5f(81645), _0xdefea0608c5f(81581));
        await _0xe0f1516d2a85(_0x5b56bdce3179, _0x7f472be16f63, {
            [_0x3e8163af073e.DRAFT_ROWS]: Array.isArray(_0xd07f5a44018b) ? _0xd07f5a44018b : [],
            [_0x3e8163af073e.HISTORY]: _0x74cc500d50be,
            [_0x3e8163af073e.ORDER_INDEX]: _0xb6668c479e05,
            [_0x3e8163af073e.SETTINGS]: _0x5947c35a6ae1
        });
        return { ok: true, state: _0x5b56bdce3179 };
    }
    const _0xe87692b368de = Number.isInteger(_0xb2847a2c8cb2?.workTabId) ? _0xb2847a2c8cb2.workTabId : null;
    let _0x037127344a2f;
    try {
        _0x037127344a2f = await _0xb86675aa5153(_0xe87692b368de);
    }
    catch (_0xe0d3c5b6d189) {
        return { ok: false, error: _0xe0d3c5b6d189.message || String(_0xe0d3c5b6d189) };
    }
    const _0x303bc4796b96 = {
        version: _0x237a184d8647,
        runId: crypto.randomUUID(),
        mode: _0xdefea0608c5f(81512),
        phase: _0xdefea0608c5f(81575),
        pauseReason: _0xdefea0608c5f(81528),
        currentGroupIndex: _0x7c40cfc2fa53,
        currentIndex: _0x6ce6cca7db35[_0x7c40cfc2fa53].primaryRowIndex,
        rows: _0x7751efb29601,
        groups: _0x6ce6cca7db35,
        workTabId: _0x037127344a2f,
        orderIntervalSeconds: _0xcf0b43304984,
        intervalEndsAt: null,
        intervalRemainingSeconds: 0,
        knownOrderIds: _0xa3cc2b234003,
        todayDateKey: _0x251e0f49d3e1(),
        startedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    _0x9ed268225a55(_0x7f472be16f63, _0xdefea0608c5f(81466), _0xdefea0608c5f(81553));
    _0x9ed268225a55(_0x7f472be16f63, _0xdefea0608c5f(81466), _0xdefea0608c5f(81315));
    _0x9ed268225a55(_0x7f472be16f63, _0xdefea0608c5f(81466), _0xdefea0608c5f(81696));
    _0x9ed268225a55(_0x7f472be16f63, _0xdefea0608c5f(81466), `成功取得一个 Amazon Order ID 后等待 ${_0xcf0b43304984} 秒，再处理下一个地址组。`);
    await _0xe0f1516d2a85(_0x303bc4796b96, _0x7f472be16f63, {
        [_0x3e8163af073e.DRAFT_ROWS]: Array.isArray(_0xd07f5a44018b) ? _0xd07f5a44018b : [],
        [_0x3e8163af073e.HISTORY]: _0x74cc500d50be,
        [_0x3e8163af073e.ORDER_INDEX]: _0xb6668c479e05,
        [_0x3e8163af073e.SETTINGS]: _0x5947c35a6ae1
    });
    await _0x548f4c780b3b(_0x303bc4796b96, _0x7f472be16f63, false);
    return { ok: true, state: _0x303bc4796b96 };
}
async function _0x7093abf1afb8(_0x71d773dfd399, _0xaca46c0892a4) {
    const _0x1bf3699b899d = await _0x4d5b02696d67();
    const _0xddd3af50288d = Array.isArray(_0x1bf3699b899d[_0x3e8163af073e.LOGS]) ? _0x1bf3699b899d[_0x3e8163af073e.LOGS] : [];
    const _0xbd7c47dac44e = _0x1bf3699b899d[_0x3e8163af073e.RUN_STATE];
    if (_0x1bf3699b899d[_0x3e8163af073e.CART_LOCK]) {
        _0x9ed268225a55(_0xddd3af50288d, _0xdefea0608c5f(81662), _0xdefea0608c5f(81562));
        await chrome.storage.local.set({ [_0x3e8163af073e.LOGS]: _0xddd3af50288d });
        return { ok: false, error: _0xdefea0608c5f(81487) };
    }
    if (!_0xbd7c47dac44e || ![_0xdefea0608c5f(81556), _0xdefea0608c5f(81546)].includes(_0xbd7c47dac44e.mode)) {
        return { ok: false, error: _0xdefea0608c5f(81642) };
    }
    if (_0xbd7c47dac44e.runId) {
        await _0xffbec67a1c34(_0xbd7c47dac44e.runId);
    }
    const _0x222a124e5fe9 = _0x5e1ab07f720b(_0x1bf3699b899d[_0x3e8163af073e.SETTINGS]);
    const _0xbe7e5ed919b9 = _0xaca46c0892a4 ?? _0x222a124e5fe9.orderIntervalSeconds;
    const _0x982d38d75bf3 = Number(_0xbe7e5ed919b9);
    if (!Number.isInteger(_0x982d38d75bf3) || _0x982d38d75bf3 < 0 || _0x982d38d75bf3 > 3600) {
        return { ok: false, error: _0xdefea0608c5f(81602) };
    }
    const _0x518c0726417c = _0x982d38d75bf3;
    const _0x937ba952af61 = { orderIntervalSeconds: _0x518c0726417c };
    const _0xa9fd4ea602c9 = _0x6c1a1e83a579(_0x1bf3699b899d[_0x3e8163af073e.HISTORY]);
    const _0xc89cd7a2b673 = _0x4c981390cff2(_0x71d773dfd399, _0xbd7c47dac44e.rows, _0xa9fd4ea602c9, _0x1bf3699b899d[_0x3e8163af073e.ORDER_INDEX]);
    if (_0xc89cd7a2b673.error) {
        _0x9ed268225a55(_0xddd3af50288d, _0xdefea0608c5f(81662), _0xc89cd7a2b673.error);
        await chrome.storage.local.set({ [_0x3e8163af073e.LOGS]: _0xddd3af50288d });
        return { ok: false, error: _0xc89cd7a2b673.error };
    }
    const { rows: _0xef3231066667, groups: _0x0442cd635845, orderIndex: _0x31554ba936b5, fatalConflicts: _0xcc866bed657e, knownOrderIds: _0xfbd2815143ea, retryCount: _0x4a56820519e7 } = _0xc89cd7a2b673;
    _0x9ed268225a55(_0xddd3af50288d, _0xdefea0608c5f(81461), `开始“重下所有跳过单”：使用当前输入表格最新数据，共选择 ${_0x4a56820519e7} 条 skipped 记录。`);
    _0x9ed268225a55(_0xddd3af50288d, _0xdefea0608c5f(81461), _0xdefea0608c5f(81604));
    _0x9ed268225a55(_0xddd3af50288d, _0xdefea0608c5f(81466), _0xdefea0608c5f(81497));
    for (const _0x48991fdd3b90 of _0x0442cd635845) {
        if (_0x48991fdd3b90.phoneMismatch) {
            const _0xf3b2e213f76f = _0xef3231066667[_0x48991fdd3b90.primaryRowIndex];
            _0x9ed268225a55(_0xddd3af50288d, _0xdefea0608c5f(81461), `重下组合单存在不同电话号码，将使用当前输入中最先出现一行的电话号码：${_0xf3b2e213f76f.phoneNumber}。`, _0xf3b2e213f76f.rowNumber);
        }
    }
    const _0xec61fec08033 = _0x0442cd635845.filter((_0x5bd0c0d0ded7) => _0x5bd0c0d0ded7.result === _0xdefea0608c5f(81515)).length;
    const _0x30d80a3f6332 = _0x0442cd635845.filter((_0x24ebd0e56de9) => _0x24ebd0e56de9.result === _0xdefea0608c5f(81515) && _0x24ebd0e56de9.isCombined).length;
    const _0x5ef21b1db72c = _0xef3231066667.filter((_0xd55e9396dce6) => _0xd55e9396dce6.result === _0xdefea0608c5f(81638)).length;
    _0x9ed268225a55(_0xddd3af50288d, _0xdefea0608c5f(81466), `重下预检查完成：待处理地址组 ${_0xec61fec08033} 个（其中组合单 ${_0x30d80a3f6332} 个）；当前仍为 skipped 的工作记录 ${_0x5ef21b1db72c} 行。`);
    const _0xd284e3bb7ae7 = {
        version: _0x237a184d8647,
        runId: crypto.randomUUID(),
        [_0xdefea0608c5f(81541)]: _0xdefea0608c5f(81703),
        [_0xdefea0608c5f(81622)]: true,
        rows: _0xef3231066667,
        groups: _0x0442cd635845,
        orderIntervalSeconds: _0x518c0726417c,
        intervalEndsAt: null,
        intervalRemainingSeconds: 0,
        knownOrderIds: _0xfbd2815143ea,
        todayDateKey: _0x251e0f49d3e1(),
        startedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    if (_0xcc866bed657e.length > 0) {
        const _0x15579af689ae = _0x0442cd635845.findIndex((_0x59fbff978be5) => _0x59fbff978be5.result === _0xdefea0608c5f(81564));
        const _0x48f3d220315f = _0x0442cd635845[_0x15579af689ae] || null;
        const _0xaf2d407d3841 = {
            ..._0xd284e3bb7ae7,
            mode: _0xdefea0608c5f(81504),
            phase: _0xdefea0608c5f(81677),
            pauseReason: _0xcc866bed657e[0],
            currentGroupIndex: _0x15579af689ae >= 0 ? _0x15579af689ae : null,
            currentIndex: _0x48f3d220315f?.primaryRowIndex ?? null,
            workTabId: null
        };
        _0xcc866bed657e.forEach((_0x41f45aa70e17) => _0x9ed268225a55(_0xddd3af50288d, _0xdefea0608c5f(81662), _0x41f45aa70e17));
        await _0xe0f1516d2a85(_0xaf2d407d3841, _0xddd3af50288d, {
            [_0x3e8163af073e.DRAFT_ROWS]: Array.isArray(_0x71d773dfd399) ? _0x71d773dfd399 : [],
            [_0x3e8163af073e.HISTORY]: _0xa9fd4ea602c9,
            [_0x3e8163af073e.ORDER_INDEX]: _0x31554ba936b5,
            [_0x3e8163af073e.SETTINGS]: _0x937ba952af61
        });
        return { ok: true, state: _0xaf2d407d3841, paused: true, retryCount: _0x4a56820519e7 };
    }
    const _0xa8554163209e = _0x0f1be5499895(_0x0442cd635845);
    if (_0xa8554163209e === -1) {
        const _0xc3d53b5c1e43 = {
            ..._0xd284e3bb7ae7,
            mode: _0xdefea0608c5f(81556),
            phase: _0xdefea0608c5f(81699),
            pauseReason: _0xdefea0608c5f(81528),
            currentGroupIndex: null,
            currentIndex: null,
            workTabId: null
        };
        _0x9ed268225a55(_0xddd3af50288d, _0xdefea0608c5f(81645), _0xdefea0608c5f(81534));
        await _0xe0f1516d2a85(_0xc3d53b5c1e43, _0xddd3af50288d, {
            [_0x3e8163af073e.DRAFT_ROWS]: Array.isArray(_0x71d773dfd399) ? _0x71d773dfd399 : [],
            [_0x3e8163af073e.HISTORY]: _0xa9fd4ea602c9,
            [_0x3e8163af073e.ORDER_INDEX]: _0x31554ba936b5,
            [_0x3e8163af073e.SETTINGS]: _0x937ba952af61
        });
        return { ok: true, state: _0xc3d53b5c1e43, retryCount: _0x4a56820519e7 };
    }
    let _0x6248bb478702;
    try {
        _0x6248bb478702 = await _0xb86675aa5153(Number.isInteger(_0xbd7c47dac44e.workTabId) ? _0xbd7c47dac44e.workTabId : null);
    }
    catch (_0xf84b49d57241) {
        return { ok: false, error: _0xf84b49d57241.message || String(_0xf84b49d57241) };
    }
    const _0x55a8f8013179 = {
        ..._0xd284e3bb7ae7,
        mode: _0xdefea0608c5f(81512),
        phase: _0xdefea0608c5f(81575),
        pauseReason: _0xdefea0608c5f(81528),
        currentGroupIndex: _0xa8554163209e,
        currentIndex: _0x0442cd635845[_0xa8554163209e].primaryRowIndex,
        workTabId: _0x6248bb478702
    };
    _0x9ed268225a55(_0xddd3af50288d, _0xdefea0608c5f(81466), _0xdefea0608c5f(81492));
    _0x9ed268225a55(_0xddd3af50288d, _0xdefea0608c5f(81466), `成功取得一个新 Amazon Order ID 后等待 ${_0x518c0726417c} 秒，再处理下一个重下地址组。`);
    await _0xe0f1516d2a85(_0x55a8f8013179, _0xddd3af50288d, {
        [_0x3e8163af073e.DRAFT_ROWS]: Array.isArray(_0x71d773dfd399) ? _0x71d773dfd399 : [],
        [_0x3e8163af073e.HISTORY]: _0xa9fd4ea602c9,
        [_0x3e8163af073e.ORDER_INDEX]: _0x31554ba936b5,
        [_0x3e8163af073e.SETTINGS]: _0x937ba952af61
    });
    await _0x548f4c780b3b(_0x55a8f8013179, _0xddd3af50288d, false);
    return { ok: true, state: _0x55a8f8013179, retryCount: _0x4a56820519e7 };
}
async function _0x56bdf6cb726d(_0x1e7679e26cc7, _0x6e36565c7c69) {
    const _0x8254748e37b7 = await _0x4d5b02696d67();
    const _0x1fc0d5e2fd53 = _0x8254748e37b7[_0x3e8163af073e.RUN_STATE];
    const _0x0be2bfd3d128 = Array.isArray(_0x8254748e37b7[_0x3e8163af073e.LOGS]) ? _0x8254748e37b7[_0x3e8163af073e.LOGS] : [];
    if (!_0x1fc0d5e2fd53 || _0x6e36565c7c69.tab?.id !== _0x1fc0d5e2fd53.workTabId) {
        return { ok: false, error: _0xdefea0608c5f(81710) };
    }
    if (_0x1fc0d5e2fd53.runId !== _0x1e7679e26cc7.runId) {
        return { ok: false, error: _0xdefea0608c5f(81650) };
    }
    if (_0x1e7679e26cc7.expectedPhase && _0x1fc0d5e2fd53.phase !== _0x1e7679e26cc7.expectedPhase) {
        return { ok: false, stale: true, error: `当前阶段已变为 ${_0x1fc0d5e2fd53.phase}。` };
    }
    if (_0x1fc0d5e2fd53.mode !== _0xdefea0608c5f(81477)) {
        return { ok: false, paused: true, error: _0xdefea0608c5f(81494) };
    }
    const _0x1e698c840152 = _0x7099183f8138(_0x1fc0d5e2fd53);
    const _0x3e30b1c5d984 = _0xd95c33d75b28(_0x1fc0d5e2fd53);
    _0x1fc0d5e2fd53.phase = _0x1e7679e26cc7.nextPhase;
    _0x1fc0d5e2fd53.updatedAt = new Date().toISOString();
    if (_0x1e698c840152 && Number.isFinite(Number(_0x1e7679e26cc7.observedUnitPrice))) {
        _0x1e698c840152.observedUnitPrice = Number(_0x1e7679e26cc7.observedUnitPrice).toFixed(2);
    }
    if (_0x1e698c840152 && Number.isSafeInteger(Number(_0x1e7679e26cc7.selectedQuantity)) && Number(_0x1e7679e26cc7.selectedQuantity) > 0) {
        _0x1e698c840152.selectedQuantity = Number(_0x1e7679e26cc7.selectedQuantity);
    }
    if (_0x3e30b1c5d984 && _0x1e7679e26cc7.observedDeliveryAddress) {
        _0x3e30b1c5d984.actualDeliveryAddress = _0x040a30dfbe94(_0x1e7679e26cc7.observedDeliveryAddress);
    }
    if (typeof _0x1e7679e26cc7[_0xdefea0608c5f(81573)] === _0xdefea0608c5f(81608)) {
        _0x1fc0d5e2fd53[_0xdefea0608c5f(81573)] = _0x1e7679e26cc7[_0xdefea0608c5f(81573)];
    }
    if (_0x1e7679e26cc7.status) {
        if (_0x3e30b1c5d984?.isCombined && _0xfa79714100cf.has(_0x1e7679e26cc7.nextPhase)) {
            _0x0746180a2a72(_0x1fc0d5e2fd53.rows, _0x3e30b1c5d984, _0x1e7679e26cc7.status);
        }
        else if (_0x1e698c840152) {
            _0x6c4eec96f923(_0x1e698c840152, _0x1e7679e26cc7.status, _0xdefea0608c5f(81613));
        }
    }
    if (_0x1e7679e26cc7.logMessage) {
        _0x9ed268225a55(_0x0be2bfd3d128, _0x1e7679e26cc7.level || _0xdefea0608c5f(81466), _0x1e7679e26cc7.logMessage, _0x1e698c840152?.rowNumber ?? null);
    }
    await _0xe0f1516d2a85(_0x1fc0d5e2fd53, _0x0be2bfd3d128);
    return { ok: true, state: _0x1fc0d5e2fd53 };
}
async function _0x12dde956a5c6(_0x4333f4f79355, _0x108771ced83f) {
    const _0x5845fdc565a6 = await chrome.storage.local.get(_0x3e8163af073e.RUN_STATE);
    const _0xd2e8c2ccd429 = _0x5845fdc565a6[_0x3e8163af073e.RUN_STATE] || null;
    const _0x00b28a3ef060 = Boolean(_0xd2e8c2ccd429 &&
        _0x108771ced83f.tab?.id === _0xd2e8c2ccd429.workTabId &&
        _0xd2e8c2ccd429.runId === _0x4333f4f79355.runId &&
        _0x06782ce10198.has(_0xd2e8c2ccd429.phase) &&
        _0x06782ce10198.has(_0x4333f4f79355.nextPhase));
    if (!_0x00b28a3ef060) {
        const _0x44eebe7ec7e8 = await _0xc2f591abc9c3(false);
        if (!_0x44eebe7ec7e8.ok) {
            return _0x44eebe7ec7e8;
        }
    }
    return _0x56bdf6cb726d(_0x4333f4f79355, _0x108771ced83f);
}
async function _0x6f108d2d014b(_0x09217b2bffc7, _0x62631229f1cb) {
    const _0x9f10fb096c73 = await _0x4d5b02696d67();
    const _0x72105e19d1e5 = _0x9f10fb096c73[_0x3e8163af073e.RUN_STATE];
    const _0x4a18e9f315a2 = Array.isArray(_0x9f10fb096c73[_0x3e8163af073e.LOGS]) ? _0x9f10fb096c73[_0x3e8163af073e.LOGS] : [];
    if (!_0x72105e19d1e5 || _0x62631229f1cb.tab?.id !== _0x72105e19d1e5.workTabId || _0x72105e19d1e5.runId !== _0x09217b2bffc7.runId) {
        return { ok: false, stale: true };
    }
    if (_0x09217b2bffc7.expectedPhase && _0x72105e19d1e5.phase !== _0x09217b2bffc7.expectedPhase) {
        return { ok: false, stale: true };
    }
    const _0x39948be8e3af = _0x7099183f8138(_0x72105e19d1e5);
    const _0x6fba85b785dc = _0xd95c33d75b28(_0x72105e19d1e5);
    _0x72105e19d1e5.mode = _0xdefea0608c5f(81504);
    _0x72105e19d1e5.pauseReason = _0x09217b2bffc7.reason || _0xdefea0608c5f(81483);
    _0x72105e19d1e5.updatedAt = new Date().toISOString();
    if (_0x6fba85b785dc?.isCombined) {
        _0xef306e091ba6(_0x72105e19d1e5.rows, _0x6fba85b785dc, _0x72105e19d1e5.pauseReason);
    }
    else if (_0x39948be8e3af) {
        _0x6c4eec96f923(_0x39948be8e3af, `等待人工检查：${_0x72105e19d1e5.pauseReason}`, _0xdefea0608c5f(81564));
    }
    _0x9ed268225a55(_0x4a18e9f315a2, _0xdefea0608c5f(81662), _0x72105e19d1e5.pauseReason, _0x39948be8e3af?.rowNumber ?? null);
    await _0xe0f1516d2a85(_0x72105e19d1e5, _0x4a18e9f315a2);
    return { ok: true, state: _0x72105e19d1e5 };
}
async function _0x2b9ed8d0d4b2(_0x253cbf2acadc, _0xa15342276556) {
    const _0x9d21569c2c1c = await _0x4d5b02696d67();
    const _0x3ee4117fbe4e = _0x9d21569c2c1c[_0x3e8163af073e.RUN_STATE];
    const _0xf4201ed3011b = Array.isArray(_0x9d21569c2c1c[_0x3e8163af073e.LOGS]) ? _0x9d21569c2c1c[_0x3e8163af073e.LOGS] : [];
    const _0x8058c9a119a4 = _0x6c1a1e83a579(_0x9d21569c2c1c[_0x3e8163af073e.HISTORY]);
    const _0xb39255ba6a3f = _0x03487935396e(_0x9d21569c2c1c[_0x3e8163af073e.ORDER_INDEX], _0x8058c9a119a4);
    let _0xb9c45c93b652 = _0x9d21569c2c1c[_0x3e8163af073e.CART_LOCK] || null;
    if (!_0x3ee4117fbe4e || _0xa15342276556.tab?.id !== _0x3ee4117fbe4e.workTabId || _0x3ee4117fbe4e.runId !== _0x253cbf2acadc.runId) {
        return { ok: false, stale: true, error: _0xdefea0608c5f(81667) };
    }
    if (_0x3ee4117fbe4e.mode !== _0xdefea0608c5f(81477) || _0x3ee4117fbe4e.phase !== _0xdefea0608c5f(81580)) {
        return { ok: false, stale: true, error: `当前阶段不是付款页姓名验证阶段：${_0x3ee4117fbe4e.phase}` };
    }
    const _0x44b29510a06d = _0xd95c33d75b28(_0x3ee4117fbe4e);
    const _0x060156198f05 = _0x0bfa2a1893b2(_0x3ee4117fbe4e);
    if (!_0x44b29510a06d || !_0x060156198f05) {
        return { ok: false, error: _0xdefea0608c5f(81508) };
    }
    const _0x85d10076cdc6 = _0x040a30dfbe94(_0x253cbf2acadc.observedRecipientName);
    if (!_0x85d10076cdc6 || _0xcb5feb506b6c(_0x85d10076cdc6) !== _0xcb5feb506b6c(_0x44b29510a06d.normalizedName)) {
        return { ok: false, error: _0xdefea0608c5f(81521) };
    }
    if (_0x44b29510a06d.isCombined) {
        if (!_0x44b29510a06d.rowIndexes.every((_0x3472316494c5) => _0x3ee4117fbe4e.rows[_0x3472316494c5].precheckPassed && _0x3ee4117fbe4e.rows[_0x3472316494c5].addedToCart)) {
            return { ok: false, error: _0xdefea0608c5f(81603) };
        }
        if (!_0x4c9bde331c2e(_0xb9c45c93b652, _0x3ee4117fbe4e, _0x44b29510a06d)) {
            return { ok: false, error: _0xdefea0608c5f(81538) };
        }
    }
    else {
        const _0x483ba0c2ca13 = Number(_0x060156198f05.observedUnitPrice);
        if (!Number.isFinite(_0x483ba0c2ca13) || Math.abs(_0x483ba0c2ca13 - 2) > 0.0001) {
            return { ok: false, error: _0xdefea0608c5f(81610) };
        }
        const _0xc51780ad2098 = Number(_0x060156198f05.selectedQuantity);
        if (!Number.isSafeInteger(_0xc51780ad2098) ||
            _0xc51780ad2098 <= 0 ||
            _0xc51780ad2098 !== _0x060156198f05.requestedQuantity) {
            return { ok: false, error: _0xdefea0608c5f(81695) };
        }
    }
    if (!_0x3ee4117fbe4e[_0xdefea0608c5f(81622)]) {
        const _0x113d88cb6f82 = _0x251e0f49d3e1();
        for (const _0x286be1c58073 of _0x44b29510a06d.uniqueTemuOrderIds) {
            const _0xd1a8dbaaf969 = _0xb39255ba6a3f[_0xa3c8b008e98d(_0x286be1c58073)];
            if (_0xd1a8dbaaf969?.status === _0xdefea0608c5f(81574) &&
                _0xd1a8dbaaf969.dateKey === _0x113d88cb6f82 &&
                _0x91508b6109bd(_0xd1a8dbaaf969.orderId)) {
                _0x3ee4117fbe4e.mode = _0xdefea0608c5f(81504);
                _0x3ee4117fbe4e.pauseReason = `最终付款前发现 Temu Order ID ${_0x286be1c58073} 今天已有成功订单，已停止以避免重复下单。`;
                if (_0x44b29510a06d.isCombined) {
                    _0xef306e091ba6(_0x3ee4117fbe4e.rows, _0x44b29510a06d, _0x3ee4117fbe4e.pauseReason);
                }
                else {
                    _0x6c4eec96f923(_0x060156198f05, `等待人工检查：${_0x3ee4117fbe4e.pauseReason}`, _0xdefea0608c5f(81564));
                }
                _0x9ed268225a55(_0xf4201ed3011b, _0xdefea0608c5f(81662), _0x3ee4117fbe4e.pauseReason, _0x060156198f05.rowNumber);
                await _0xe0f1516d2a85(_0x3ee4117fbe4e, _0xf4201ed3011b, {
                    [_0x3e8163af073e.HISTORY]: _0x8058c9a119a4,
                    [_0x3e8163af073e.ORDER_INDEX]: _0xb39255ba6a3f
                });
                return { ok: false, error: _0x3ee4117fbe4e.pauseReason };
            }
        }
    }
    _0x44b29510a06d.actualDeliveryAddress = _0x040a30dfbe94(_0x253cbf2acadc.observedDeliveryAddress || _0x44b29510a06d.actualDeliveryAddress);
    if (_0x44b29510a06d.isCombined) {
        _0x0746180a2a72(_0x3ee4117fbe4e.rows, _0x44b29510a06d, _0xdefea0608c5f(81474));
        _0xb9c45c93b652 = {
            ..._0xb9c45c93b652,
            stage: _0xdefea0608c5f(81706),
            actualDeliveryAddress: _0x44b29510a06d.actualDeliveryAddress,
            updatedAt: new Date().toISOString()
        };
    }
    else {
        _0x6c4eec96f923(_0x060156198f05, _0xdefea0608c5f(81697), _0xdefea0608c5f(81613));
    }
    _0x3ee4117fbe4e.phase = _0xdefea0608c5f(81496);
    _0x3ee4117fbe4e.updatedAt = new Date().toISOString();
    _0x9ed268225a55(_0xf4201ed3011b, _0xdefea0608c5f(81461), _0x44b29510a06d.isCombined
        ? `组合单共 ${_0x44b29510a06d.rowIndexes.length} 行、总数量 ${_0x44b29510a06d.expectedTotalQuantity}，付款页收件人姓名已核对；购物篮安全锁将保留到取得 Order ID。`
        : `商品含税单价 €2.00、精准数量 ${_0x060156198f05.requestedQuantity} 和付款页收件人姓名均已核对；只有取得 Order ID 后才计入当天下单记录。`, _0x060156198f05.rowNumber);
    const _0x24831a704d34 = {
        [_0x3e8163af073e.HISTORY]: _0x8058c9a119a4,
        [_0x3e8163af073e.ORDER_INDEX]: _0xb39255ba6a3f
    };
    if (_0x44b29510a06d.isCombined) {
        _0x24831a704d34[_0x3e8163af073e.CART_LOCK] = _0xb9c45c93b652;
    }
    await _0xe0f1516d2a85(_0x3ee4117fbe4e, _0xf4201ed3011b, _0x24831a704d34);
    return { ok: true, state: _0x3ee4117fbe4e };
}
async function _0x548f4c780b3b(_0xaee121dfc213, _0xe5ea170f617c, _0x3b402da5a137 = true) {
    const _0x708a95a160d0 = await _0xb19755502869(false);
    if (!_0x708a95a160d0[_0xdefea0608c5f(81654)]) {
        _0x8494c88f1fc0(_0xaee121dfc213, _0xe5ea170f617c);
        await _0xe0f1516d2a85(_0xaee121dfc213, _0xe5ea170f617c);
        return { completed: false, authorizationFailed: true, error: _0xd77ebbe49f41[_0xdefea0608c5f(81476)] };
    }
    const _0xc748c3ad8018 = _0xd95c33d75b28(_0xaee121dfc213);
    if (!_0xc748c3ad8018) {
        return { completed: false, error: _0xdefea0608c5f(81589) };
    }
    _0xc748c3ad8018.precheckCursor = 0;
    _0xc748c3ad8018.addCursor = 0;
    _0xc748c3ad8018.expectedCartCount = 0;
    _0xc748c3ad8018.actualDeliveryAddress = _0xdefea0608c5f(81528);
    _0xc748c3ad8018.orderId = _0xdefea0608c5f(81528);
    _0xc748c3ad8018.result = _0xdefea0608c5f(81613);
    _0xc748c3ad8018.updatedAt = new Date().toISOString();
    for (const _0x26ece609c1cb of _0xc748c3ad8018.rowIndexes) {
        const _0x41ab81f1ee3d = _0xaee121dfc213.rows[_0x26ece609c1cb];
        _0x41ab81f1ee3d.precheckPassed = false;
        _0x41ab81f1ee3d.addedToCart = false;
        _0x41ab81f1ee3d.observedUnitPrice = _0xdefea0608c5f(81528);
        _0x41ab81f1ee3d.selectedQuantity = _0xdefea0608c5f(81528);
        _0x41ab81f1ee3d.orderId = _0xdefea0608c5f(81528);
    }
    const _0xef484fad59ef = _0xc748c3ad8018.rowIndexes[0];
    const _0x0f2778cdabc1 = _0xaee121dfc213.rows[_0xef484fad59ef];
    _0xaee121dfc213.currentIndex = _0xef484fad59ef;
    _0xaee121dfc213.mode = _0xdefea0608c5f(81512);
    _0xaee121dfc213.phase = _0xdefea0608c5f(81575);
    _0xaee121dfc213.pauseReason = _0xdefea0608c5f(81528);
    _0xaee121dfc213.intervalEndsAt = null;
    _0xaee121dfc213.intervalRemainingSeconds = 0;
    _0xaee121dfc213[_0xdefea0608c5f(81573)] = false;
    _0xaee121dfc213.updatedAt = new Date().toISOString();
    if (_0xc748c3ad8018.isCombined) {
        _0x0746180a2a72(_0xaee121dfc213.rows, _0xc748c3ad8018, _0xdefea0608c5f(81509));
        _0x9ed268225a55(_0xe5ea170f617c, _0xdefea0608c5f(81466), `开始组合单：${_0xc748c3ad8018.rowIndexes.length} 行，${_0xc748c3ad8018.uniqueTemuOrderIds.length} 个唯一 Temu Order ID，总数量 ${_0xc748c3ad8018.expectedTotalQuantity}。`, _0x0f2778cdabc1.rowNumber);
    }
    else {
        _0x6c4eec96f923(_0x0f2778cdabc1, _0xdefea0608c5f(81531), _0xdefea0608c5f(81613));
        _0x9ed268225a55(_0xe5ea170f617c, _0xdefea0608c5f(81466), `第 ${_0x0f2778cdabc1.rowNumber} 行：开始单行 Buy Now 流程，Temu Order ID ${_0x0f2778cdabc1.temuOrderId}，ASIN ${_0x0f2778cdabc1.asin}，目标数量 ${_0x0f2778cdabc1.requestedQuantity}。`, _0x0f2778cdabc1.rowNumber);
    }
    await _0xe0f1516d2a85(_0xaee121dfc213, _0xe5ea170f617c);
    try {
        let _0xec9d7f91a38d = false;
        if (Number.isInteger(_0xaee121dfc213.workTabId)) {
            try {
                await chrome.tabs.get(_0xaee121dfc213.workTabId);
                _0xec9d7f91a38d = true;
            }
            catch {
                _0xec9d7f91a38d = false;
            }
        }
        if (_0xec9d7f91a38d && _0x3b402da5a137) {
            await chrome.tabs.update(_0xaee121dfc213.workTabId, { url: _0xdefea0608c5f(81702), active: true });
            await _0x4d54ecb4cff7(120);
        }
        else if (!_0xec9d7f91a38d) {
            _0xaee121dfc213.workTabId = await _0xb86675aa5153(null);
            await _0xe0f1516d2a85(_0xaee121dfc213, _0xe5ea170f617c);
        }
        _0xaee121dfc213.mode = _0xdefea0608c5f(81477);
        _0xaee121dfc213.phase = _0xc748c3ad8018.isCombined ? _0xdefea0608c5f(81678) : _0xdefea0608c5f(81545);
        _0xaee121dfc213.pauseReason = _0xdefea0608c5f(81528);
        if (_0xc748c3ad8018.isCombined) {
            _0x0746180a2a72(_0xaee121dfc213.rows, _0xc748c3ad8018, _0xdefea0608c5f(81507));
        }
        else {
            _0x6c4eec96f923(_0x0f2778cdabc1, _0xdefea0608c5f(81543), _0xdefea0608c5f(81613));
        }
        _0xaee121dfc213.updatedAt = new Date().toISOString();
        await _0xe0f1516d2a85(_0xaee121dfc213, _0xe5ea170f617c);
        await _0x3b99d8c28ab2(_0xaee121dfc213.workTabId, _0x0f2778cdabc1.amzLink);
        return { completed: false };
    }
    catch (_0x8848fdabf0e5) {
        _0xaee121dfc213.mode = _0xdefea0608c5f(81504);
        _0xaee121dfc213.pauseReason = `无法打开商品页面：${_0x8848fdabf0e5.message || String(_0x8848fdabf0e5)}`;
        if (_0xc748c3ad8018.isCombined) {
            _0xef306e091ba6(_0xaee121dfc213.rows, _0xc748c3ad8018, _0xaee121dfc213.pauseReason);
        }
        else {
            _0x6c4eec96f923(_0x0f2778cdabc1, `等待人工检查：${_0xaee121dfc213.pauseReason}`, _0xdefea0608c5f(81564));
        }
        _0x9ed268225a55(_0xe5ea170f617c, _0xdefea0608c5f(81662), _0xaee121dfc213.pauseReason, _0x0f2778cdabc1.rowNumber);
        await _0xe0f1516d2a85(_0xaee121dfc213, _0xe5ea170f617c);
        return { completed: false, error: _0xaee121dfc213.pauseReason };
    }
}
async function _0x9b2fdfd21460(_0x51ec0ea7b8b2, _0x4b89534deda8, _0x4f344c701bf8, _0x13c6847a6004 = 0) {
    const _0xdba97b27b0db = await _0xb19755502869(false);
    if (!_0xdba97b27b0db[_0xdefea0608c5f(81654)]) {
        _0x51ec0ea7b8b2[_0xdefea0608c5f(81526)] = true;
        _0x51ec0ea7b8b2[_0xdefea0608c5f(81670)] = false;
        _0x51ec0ea7b8b2.mode = _0xdefea0608c5f(81504);
        _0x51ec0ea7b8b2.pauseReason = _0xd77ebbe49f41[_0xdefea0608c5f(81476)];
        _0x51ec0ea7b8b2.updatedAt = new Date().toISOString();
        const _0x8949ff054a7d = _0x7099183f8138(_0x51ec0ea7b8b2);
        const _0x3ea444f4761e = _0x4b89534deda8?.[_0x4b89534deda8.length - 1];
        if (_0x3ea444f4761e?.message !== _0xd77ebbe49f41[_0xdefea0608c5f(81476)]) {
            _0x9ed268225a55(_0x4b89534deda8, _0xdefea0608c5f(81662), _0xd77ebbe49f41[_0xdefea0608c5f(81476)], _0x8949ff054a7d?.rowNumber ?? null);
        }
        await _0xe0f1516d2a85(_0x51ec0ea7b8b2, _0x4b89534deda8);
        return { completed: false, authorizationFailed: true, error: _0xd77ebbe49f41[_0xdefea0608c5f(81476)] };
    }
    const _0x8f00f78c81c3 = _0x51ec0ea7b8b2.currentGroupIndex;
    const _0xe2fa105a4a3c = _0x0f1be5499895(_0x51ec0ea7b8b2.groups, Number.isInteger(_0x8f00f78c81c3) ? _0x8f00f78c81c3 : -1);
    if (_0xe2fa105a4a3c === -1) {
        await _0xffbec67a1c34(_0x51ec0ea7b8b2.runId);
        _0x51ec0ea7b8b2.mode = _0xdefea0608c5f(81556);
        _0x51ec0ea7b8b2.phase = _0xdefea0608c5f(81699);
        _0x51ec0ea7b8b2.pauseReason = _0xdefea0608c5f(81528);
        _0x51ec0ea7b8b2.currentGroupIndex = null;
        _0x51ec0ea7b8b2.currentIndex = null;
        _0x51ec0ea7b8b2.intervalEndsAt = null;
        _0x51ec0ea7b8b2.intervalRemainingSeconds = 0;
        _0x51ec0ea7b8b2.updatedAt = new Date().toISOString();
        _0x9ed268225a55(_0x4b89534deda8, _0xdefea0608c5f(81645), _0x4f344c701bf8 || _0xdefea0608c5f(81579));
        await _0xe0f1516d2a85(_0x51ec0ea7b8b2, _0x4b89534deda8);
        return { completed: true };
    }
    _0x51ec0ea7b8b2.currentGroupIndex = _0xe2fa105a4a3c;
    const _0xb46417ef9e40 = _0x51ec0ea7b8b2.groups[_0xe2fa105a4a3c];
    _0x51ec0ea7b8b2.currentIndex = _0xb46417ef9e40.primaryRowIndex;
    const _0xf9369d93c489 = _0x1b68513a1664(_0x13c6847a6004, 0);
    if (_0xf9369d93c489 > 0) {
        _0x51ec0ea7b8b2.mode = _0xdefea0608c5f(81512);
        _0x51ec0ea7b8b2.phase = _0xdefea0608c5f(81578);
        _0x51ec0ea7b8b2.pauseReason = _0xdefea0608c5f(81528);
        _0x51ec0ea7b8b2.intervalEndsAt = new Date(Date.now() + _0xf9369d93c489 * 1000).toISOString();
        _0x51ec0ea7b8b2.intervalRemainingSeconds = _0xf9369d93c489;
        _0x0746180a2a72(_0x51ec0ea7b8b2.rows, _0xb46417ef9e40, `等待下单间隔（${_0xf9369d93c489}秒）`);
        _0x51ec0ea7b8b2.updatedAt = new Date().toISOString();
        const _0x31fa399e1674 = _0x51ec0ea7b8b2.rows[_0xb46417ef9e40.primaryRowIndex];
        _0x9ed268225a55(_0x4b89534deda8, _0xdefea0608c5f(81466), `距离下一个地址组还有 ${_0xf9369d93c489} 秒；等待结束后从第 ${_0x31fa399e1674.rowNumber} 行开始。`, _0x31fa399e1674.rowNumber);
        await _0xe0f1516d2a85(_0x51ec0ea7b8b2, _0x4b89534deda8);
        try {
            await _0x3c64c6cf81c8(_0x51ec0ea7b8b2, _0xf9369d93c489 * 1000);
            return { completed: false, waiting: true };
        }
        catch (_0xde904a6550c7) {
            _0x51ec0ea7b8b2.mode = _0xdefea0608c5f(81504);
            _0x51ec0ea7b8b2.pauseReason = `无法安排下一单间隔：${_0xde904a6550c7.message || String(_0xde904a6550c7)}`;
            _0xef306e091ba6(_0x51ec0ea7b8b2.rows, _0xb46417ef9e40, _0x51ec0ea7b8b2.pauseReason);
            _0x9ed268225a55(_0x4b89534deda8, _0xdefea0608c5f(81662), _0x51ec0ea7b8b2.pauseReason, _0x31fa399e1674.rowNumber);
            await _0xe0f1516d2a85(_0x51ec0ea7b8b2, _0x4b89534deda8);
            return { completed: false, error: _0x51ec0ea7b8b2.pauseReason };
        }
    }
    return _0x548f4c780b3b(_0x51ec0ea7b8b2, _0x4b89534deda8, true);
}
async function _0x983d9aaa9832(_0x92a7fa4ec96c) {
    const _0xc588b887b2d3 = await _0x4d5b02696d67();
    const _0x2105b4cb04aa = _0xc588b887b2d3[_0x3e8163af073e.RUN_STATE];
    const _0x6922c40e4384 = Array.isArray(_0xc588b887b2d3[_0x3e8163af073e.LOGS]) ? _0xc588b887b2d3[_0x3e8163af073e.LOGS] : [];
    if (!_0x2105b4cb04aa ||
        _0x2105b4cb04aa.runId !== _0x92a7fa4ec96c ||
        _0x2105b4cb04aa.mode !== _0xdefea0608c5f(81512) ||
        _0x2105b4cb04aa.phase !== _0xdefea0608c5f(81578)) {
        await _0xffbec67a1c34(_0x92a7fa4ec96c);
        return { ok: false, stale: true };
    }
    const _0xa2df7e5b590f = _0xf16afafc0018(_0x2105b4cb04aa);
    if (_0xa2df7e5b590f > 500) {
        _0x2105b4cb04aa.intervalRemainingSeconds = Math.ceil(_0xa2df7e5b590f / 1000);
        await _0xe0f1516d2a85(_0x2105b4cb04aa, _0x6922c40e4384);
        await _0x3c64c6cf81c8(_0x2105b4cb04aa, _0xa2df7e5b590f);
        return { ok: true, waiting: true };
    }
    await _0xffbec67a1c34(_0x92a7fa4ec96c);
    _0x2105b4cb04aa.intervalEndsAt = null;
    _0x2105b4cb04aa.intervalRemainingSeconds = 0;
    const _0x9802ca0841bb = _0xd95c33d75b28(_0x2105b4cb04aa);
    const _0x93c835e0ac3d = _0x9802ca0841bb ? _0x2105b4cb04aa.rows[_0x9802ca0841bb.primaryRowIndex] : null;
    _0x9ed268225a55(_0x6922c40e4384, _0xdefea0608c5f(81466), _0xdefea0608c5f(81464), _0x93c835e0ac3d?.rowNumber ?? null);
    await _0xe0f1516d2a85(_0x2105b4cb04aa, _0x6922c40e4384);
    await _0x548f4c780b3b(_0x2105b4cb04aa, _0x6922c40e4384, true);
    return { ok: true };
}
async function _0xeb186be09c75(_0x0c46be98d930, _0x03ffe009eaca) {
    const _0x312d61605eba = await _0x4d5b02696d67();
    const _0x4374730dcad9 = _0x312d61605eba[_0x3e8163af073e.RUN_STATE];
    const _0x58db3962b92c = Array.isArray(_0x312d61605eba[_0x3e8163af073e.LOGS]) ? _0x312d61605eba[_0x3e8163af073e.LOGS] : [];
    if (!_0x4374730dcad9 || _0x03ffe009eaca.tab?.id !== _0x4374730dcad9.workTabId || _0x4374730dcad9.runId !== _0x0c46be98d930.runId) {
        return { ok: false, stale: true };
    }
    if (![_0xdefea0608c5f(81678), _0xdefea0608c5f(81316)].includes(_0x4374730dcad9.phase)) {
        return { ok: false, stale: true, error: `当前阶段不能确认空购物篮：${_0x4374730dcad9.phase}` };
    }
    const _0x828a5d6f43a8 = _0xd95c33d75b28(_0x4374730dcad9);
    if (!_0x828a5d6f43a8?.isCombined) {
        return { ok: false, error: _0xdefea0608c5f(81527) };
    }
    if (Number(_0x0c46be98d930.cartCount) !== 0) {
        return { ok: false, error: `购物篮数量不是0：${_0x0c46be98d930.cartCount}` };
    }
    const _0x73d17eb908b4 = _0x828a5d6f43a8.rowIndexes[0];
    const _0x6e987954683a = _0x4374730dcad9.rows[_0x73d17eb908b4];
    _0x4374730dcad9.currentIndex = _0x73d17eb908b4;
    if (_0x4374730dcad9.phase === _0xdefea0608c5f(81678)) {
        _0x828a5d6f43a8.precheckCursor = 0;
        _0x4374730dcad9.phase = _0xdefea0608c5f(81590);
        _0x6c4eec96f923(_0x6e987954683a, _0xdefea0608c5f(81582), _0xdefea0608c5f(81613));
        _0x9ed268225a55(_0x58db3962b92c, _0xdefea0608c5f(81645), _0xdefea0608c5f(81565), _0x6e987954683a.rowNumber);
        await _0xe0f1516d2a85(_0x4374730dcad9, _0x58db3962b92c);
        await _0xc70c7bf1c52a(_0x4374730dcad9.workTabId);
        return { ok: true, state: _0x4374730dcad9 };
    }
    if (_0x312d61605eba[_0x3e8163af073e.CART_LOCK]) {
        return { ok: false, error: _0xdefea0608c5f(81490) };
    }
    _0x828a5d6f43a8.addCursor = 0;
    _0x828a5d6f43a8.expectedCartCount = 0;
    const _0x25c1c031199d = _0x00e349e00e8d(_0x4374730dcad9, _0x828a5d6f43a8);
    _0x4374730dcad9.phase = _0xdefea0608c5f(81626);
    _0x0746180a2a72(_0x4374730dcad9.rows, _0x828a5d6f43a8, _0xdefea0608c5f(81465));
    _0x6c4eec96f923(_0x6e987954683a, _0xdefea0608c5f(81502), _0xdefea0608c5f(81613));
    _0x9ed268225a55(_0x58db3962b92c, _0xdefea0608c5f(81645), _0xdefea0608c5f(81319), _0x6e987954683a.rowNumber);
    await _0xe0f1516d2a85(_0x4374730dcad9, _0x58db3962b92c, { [_0x3e8163af073e.CART_LOCK]: _0x25c1c031199d });
    await _0xc70c7bf1c52a(_0x4374730dcad9.workTabId);
    return { ok: true, state: _0x4374730dcad9 };
}
async function _0x1c603ed5aaab(_0x1ee5f0080b9f, _0x4962e6866b5e) {
    const _0xef38aff70e39 = await _0x4d5b02696d67();
    const _0xd2a14055eda6 = _0xef38aff70e39[_0x3e8163af073e.RUN_STATE];
    const _0x56b850ce2e91 = Array.isArray(_0xef38aff70e39[_0x3e8163af073e.LOGS]) ? _0xef38aff70e39[_0x3e8163af073e.LOGS] : [];
    if (!_0xd2a14055eda6 || _0x4962e6866b5e.tab?.id !== _0xd2a14055eda6.workTabId || _0xd2a14055eda6.runId !== _0x1ee5f0080b9f.runId) {
        return { ok: false, stale: true };
    }
    if (_0xd2a14055eda6.phase !== _0xdefea0608c5f(81590)) {
        return { ok: false, stale: true, error: `当前阶段不是组合单预检查：${_0xd2a14055eda6.phase}` };
    }
    const _0x15e8b2d02dae = _0xd95c33d75b28(_0xd2a14055eda6);
    const _0xd2aea1f1e4ab = _0x7099183f8138(_0xd2a14055eda6);
    if (!_0x15e8b2d02dae?.isCombined || !_0xd2aea1f1e4ab) {
        return { ok: false, error: _0xdefea0608c5f(81690) };
    }
    const _0xfd68fb7f2924 = _0x15e8b2d02dae.rowIndexes[_0x15e8b2d02dae.precheckCursor];
    if (_0xd2a14055eda6.currentIndex !== _0xfd68fb7f2924) {
        return { ok: false, stale: true, error: _0xdefea0608c5f(81544) };
    }
    const _0x78fb08acd07e = Number(_0x1ee5f0080b9f.observedUnitPrice);
    const _0xe277f35d2ac9 = Number(_0x1ee5f0080b9f.selectedQuantity);
    if (!Number.isFinite(_0x78fb08acd07e) || Math.abs(_0x78fb08acd07e - 2) > 0.0001) {
        return { ok: false, error: _0xdefea0608c5f(81460) };
    }
    if (!Number.isSafeInteger(_0xe277f35d2ac9) || _0xe277f35d2ac9 !== _0xd2aea1f1e4ab.requestedQuantity) {
        return { ok: false, error: _0xdefea0608c5f(81555) };
    }
    _0xd2aea1f1e4ab.observedUnitPrice = _0x78fb08acd07e.toFixed(2);
    _0xd2aea1f1e4ab.selectedQuantity = _0xe277f35d2ac9;
    _0xd2aea1f1e4ab.precheckPassed = true;
    _0x6c4eec96f923(_0xd2aea1f1e4ab, _0xdefea0608c5f(81633), _0xdefea0608c5f(81613));
    _0x9ed268225a55(_0x56b850ce2e91, _0xdefea0608c5f(81645), `组合单预检查通过：ASIN ${_0xd2aea1f1e4ab.asin}，含税单价 €2.00，精准数量 ${_0xe277f35d2ac9}。`, _0xd2aea1f1e4ab.rowNumber);
    if (_0x15e8b2d02dae.precheckCursor + 1 < _0x15e8b2d02dae.rowIndexes.length) {
        _0x15e8b2d02dae.precheckCursor += 1;
        const _0xc03d51472c69 = _0x15e8b2d02dae.rowIndexes[_0x15e8b2d02dae.precheckCursor];
        const _0x0f1e17fb3c9e = _0xd2a14055eda6.rows[_0xc03d51472c69];
        _0xd2a14055eda6.currentIndex = _0xc03d51472c69;
        _0xd2a14055eda6.phase = _0xdefea0608c5f(81590);
        _0x6c4eec96f923(_0x0f1e17fb3c9e, _0xdefea0608c5f(81657), _0xdefea0608c5f(81613));
        _0x9ed268225a55(_0x56b850ce2e91, _0xdefea0608c5f(81466), `上一件商品预检查完成；关闭旧商品标签并为第 ${_0x0f1e17fb3c9e.rowNumber} 行打开独立标签页。`, _0x0f1e17fb3c9e.rowNumber);
        _0xd2a14055eda6.updatedAt = new Date().toISOString();
        const _0x60e81a3ba561 = await _0x69458914c08b(_0xd2a14055eda6, _0x56b850ce2e91, _0x0f1e17fb3c9e.amzLink, {}, _0xdefea0608c5f(81567));
        return _0x60e81a3ba561.ok ? { ok: true, state: _0xd2a14055eda6 } : _0x60e81a3ba561;
    }
    _0x15e8b2d02dae.result = _0xdefea0608c5f(81613);
    _0x15e8b2d02dae.status = _0xdefea0608c5f(81550);
    _0xd2a14055eda6.currentIndex = _0x15e8b2d02dae.rowIndexes[0];
    _0xd2a14055eda6.phase = _0xdefea0608c5f(81316);
    _0x0746180a2a72(_0xd2a14055eda6.rows, _0x15e8b2d02dae, _0xdefea0608c5f(81643));
    _0x9ed268225a55(_0x56b850ce2e91, _0xdefea0608c5f(81466), _0xdefea0608c5f(81529), _0xd2a14055eda6.rows[_0x15e8b2d02dae.rowIndexes[0]].rowNumber);
    _0x9ed268225a55(_0x56b850ce2e91, _0xdefea0608c5f(81466), _0xdefea0608c5f(81658), _0xd2a14055eda6.rows[_0x15e8b2d02dae.rowIndexes[0]].rowNumber);
    _0xd2a14055eda6.updatedAt = new Date().toISOString();
    const _0x915ad855e90a = await _0x69458914c08b(_0xd2a14055eda6, _0x56b850ce2e91, _0xd2a14055eda6.rows[_0x15e8b2d02dae.rowIndexes[0]].amzLink, {}, _0xdefea0608c5f(81679));
    return _0x915ad855e90a.ok ? { ok: true, state: _0xd2a14055eda6 } : _0x915ad855e90a;
}
async function _0xf95408f11bb4(_0xa7e6be1575f9, _0x3db747bb19c4) {
    const _0x6aedf5244955 = await _0x4d5b02696d67();
    const _0x9a61c9d31465 = _0x6aedf5244955[_0x3e8163af073e.RUN_STATE];
    const _0xc20a23d29e8c = Array.isArray(_0x6aedf5244955[_0x3e8163af073e.LOGS]) ? _0x6aedf5244955[_0x3e8163af073e.LOGS] : [];
    if (!_0x9a61c9d31465 || _0x3db747bb19c4.tab?.id !== _0x9a61c9d31465.workTabId || _0x9a61c9d31465.runId !== _0xa7e6be1575f9.runId) {
        return { ok: false, stale: true };
    }
    if (_0x9a61c9d31465.phase !== _0xdefea0608c5f(81590)) {
        return { ok: false, stale: true };
    }
    const _0x2080f043bc54 = _0xd95c33d75b28(_0x9a61c9d31465);
    const _0xa9c3d1664822 = _0x7099183f8138(_0x9a61c9d31465);
    if (!_0x2080f043bc54?.isCombined || !_0xa9c3d1664822) {
        return { ok: false, error: _0xdefea0608c5f(81690) };
    }
    if (Number.isFinite(Number(_0xa7e6be1575f9.observedUnitPrice))) {
        _0xa9c3d1664822.observedUnitPrice = Number(_0xa7e6be1575f9.observedUnitPrice).toFixed(2);
    }
    if (Number.isSafeInteger(Number(_0xa7e6be1575f9.selectedQuantity)) && Number(_0xa7e6be1575f9.selectedQuantity) > 0) {
        _0xa9c3d1664822.selectedQuantity = Number(_0xa7e6be1575f9.selectedQuantity);
    }
    const _0x3146c139bdd4 = _0xa7e6be1575f9.reason || _0xdefea0608c5f(81647);
    _0x07765bdf7bf4(_0x9a61c9d31465.rows, _0x2080f043bc54, _0x9a61c9d31465.currentIndex, _0x3146c139bdd4);
    _0x9ed268225a55(_0xc20a23d29e8c, _0xdefea0608c5f(81461), `${_0x3146c139bdd4}；该收件人地址组全部不下单。`, _0xa9c3d1664822.rowNumber);
    _0x9a61c9d31465.updatedAt = new Date().toISOString();
    await _0xe0f1516d2a85(_0x9a61c9d31465, _0xc20a23d29e8c);
    await _0x9b2fdfd21460(_0x9a61c9d31465, _0xc20a23d29e8c, _0xdefea0608c5f(81579), 0);
    return { ok: true };
}
async function _0x3a28df1ab53f(_0xd0cdd70136ee, _0xdb0e86cf3c49) {
    const _0x163853a0b8e9 = await _0x4d5b02696d67();
    const _0x325b752054b0 = _0x163853a0b8e9[_0x3e8163af073e.RUN_STATE];
    const _0x70e092ab48be = Array.isArray(_0x163853a0b8e9[_0x3e8163af073e.LOGS]) ? _0x163853a0b8e9[_0x3e8163af073e.LOGS] : [];
    let _0xe01ff86d5338 = _0x163853a0b8e9[_0x3e8163af073e.CART_LOCK] || null;
    if (!_0x325b752054b0 || _0xdb0e86cf3c49.tab?.id !== _0x325b752054b0.workTabId || _0x325b752054b0.runId !== _0xd0cdd70136ee.runId) {
        return { ok: false, stale: true };
    }
    if (_0x325b752054b0.phase !== _0xdefea0608c5f(81626)) {
        return { ok: false, stale: true, error: `当前阶段不是组合单正式加购：${_0x325b752054b0.phase}` };
    }
    const _0x17d3005effed = _0xd95c33d75b28(_0x325b752054b0);
    const _0xaa40ada806d4 = _0x7099183f8138(_0x325b752054b0);
    if (!_0x17d3005effed?.isCombined || !_0xaa40ada806d4 || !_0x4c9bde331c2e(_0xe01ff86d5338, _0x325b752054b0, _0x17d3005effed)) {
        return { ok: false, error: _0xdefea0608c5f(81473) };
    }
    const _0xf3edf74b227c = _0x17d3005effed.rowIndexes[_0x17d3005effed.addCursor];
    if (_0x325b752054b0.currentIndex !== _0xf3edf74b227c) {
        return { ok: false, stale: true, error: _0xdefea0608c5f(81511) };
    }
    const _0x750f4b9eae03 = Number(_0xd0cdd70136ee.selectedQuantity);
    const _0xc67e33198d31 = Number(_0xd0cdd70136ee.observedUnitPrice);
    if (!Number.isSafeInteger(_0x750f4b9eae03) || _0x750f4b9eae03 !== _0xaa40ada806d4.requestedQuantity) {
        return { ok: false, error: _0xdefea0608c5f(81547) };
    }
    if (!Number.isFinite(_0xc67e33198d31) || Math.abs(_0xc67e33198d31 - 2) > 0.0001) {
        return { ok: false, error: _0xdefea0608c5f(81659) };
    }
    const _0x89a34262795a = _0x17d3005effed.rowIndexes
        .slice(0, _0x17d3005effed.addCursor + 1)
        .reduce((_0x16cc0faeee0a, _0x8fdf7944b803) => _0x16cc0faeee0a + _0x325b752054b0.rows[_0x8fdf7944b803].requestedQuantity, 0);
    _0xaa40ada806d4.observedUnitPrice = _0xc67e33198d31.toFixed(2);
    _0xaa40ada806d4.selectedQuantity = _0x750f4b9eae03;
    _0x6c4eec96f923(_0xaa40ada806d4, `正在加入购物篮（完成后应累计 ${_0x89a34262795a} 件）`, _0xdefea0608c5f(81613));
    _0x325b752054b0.phase = _0xdefea0608c5f(81680);
    _0x325b752054b0.updatedAt = new Date().toISOString();
    _0xe01ff86d5338 = {
        ..._0xe01ff86d5338,
        stage: _0xdefea0608c5f(81664),
        pendingRowIndex: _0x325b752054b0.currentIndex,
        expectedCartCountAfter: _0x89a34262795a,
        updatedAt: new Date().toISOString()
    };
    _0x9ed268225a55(_0x70e092ab48be, _0xdefea0608c5f(81466), `正式加购前再次核对通过：ASIN ${_0xaa40ada806d4.asin} × ${_0x750f4b9eae03}；点击后购物篮应累计 ${_0x89a34262795a} 件。`, _0xaa40ada806d4.rowNumber);
    await _0xe0f1516d2a85(_0x325b752054b0, _0x70e092ab48be, { [_0x3e8163af073e.CART_LOCK]: _0xe01ff86d5338 });
    return { ok: true, state: _0x325b752054b0, expectedCartCountAfter: _0x89a34262795a };
}
async function _0x67d91b8683fb(_0xf5289cd57adc, _0x47eb94e3e9f1) {
    const _0x2a300f365afa = await _0x4d5b02696d67();
    const _0xd51c1f715e18 = _0x2a300f365afa[_0x3e8163af073e.RUN_STATE];
    const _0xee0fdf22ae74 = Array.isArray(_0x2a300f365afa[_0x3e8163af073e.LOGS]) ? _0x2a300f365afa[_0x3e8163af073e.LOGS] : [];
    let _0xd327576ec38f = _0x2a300f365afa[_0x3e8163af073e.CART_LOCK] || null;
    if (!_0xd51c1f715e18 || _0x47eb94e3e9f1.tab?.id !== _0xd51c1f715e18.workTabId || _0xd51c1f715e18.runId !== _0xf5289cd57adc.runId) {
        return { ok: false, stale: true };
    }
    if (_0xd51c1f715e18.phase !== _0xdefea0608c5f(81680)) {
        return { ok: false, stale: true, error: `当前阶段不是组合单加购结果确认：${_0xd51c1f715e18.phase}` };
    }
    const _0xd905f3edf4d4 = _0xd95c33d75b28(_0xd51c1f715e18);
    const _0xe6a46620cdaf = _0x7099183f8138(_0xd51c1f715e18);
    if (!_0xd905f3edf4d4?.isCombined || !_0xe6a46620cdaf || !_0x4c9bde331c2e(_0xd327576ec38f, _0xd51c1f715e18, _0xd905f3edf4d4)) {
        return { ok: false, error: _0xdefea0608c5f(81473) };
    }
    const _0xf534b2d0fd25 = _0xd905f3edf4d4.rowIndexes[_0xd905f3edf4d4.addCursor];
    if (_0xd51c1f715e18.currentIndex !== _0xf534b2d0fd25) {
        return { ok: false, stale: true, error: _0xdefea0608c5f(81511) };
    }
    const _0x9a9e1336f649 = Number(_0xf5289cd57adc.selectedQuantity);
    const _0x02e4b075e6da = Number(_0xf5289cd57adc.observedUnitPrice);
    if (!Number.isSafeInteger(_0x9a9e1336f649) || _0x9a9e1336f649 !== _0xe6a46620cdaf.requestedQuantity) {
        return { ok: false, error: _0xdefea0608c5f(81588) };
    }
    if (!Number.isFinite(_0x02e4b075e6da) || Math.abs(_0x02e4b075e6da - 2) > 0.0001) {
        return { ok: false, error: _0xdefea0608c5f(81653) };
    }
    const _0x3e3dc9e2f4e2 = _0xd905f3edf4d4.rowIndexes
        .slice(0, _0xd905f3edf4d4.addCursor + 1)
        .reduce((_0xdbb1d4e9f68f, _0x11c5159505d0) => _0xdbb1d4e9f68f + _0xd51c1f715e18.rows[_0x11c5159505d0].requestedQuantity, 0);
    const _0x989b412c6227 = Number(_0xf5289cd57adc.cartCount);
    if (!Number.isSafeInteger(_0x989b412c6227) || _0x989b412c6227 !== _0x3e3dc9e2f4e2) {
        return {
            ok: false,
            error: `购物篮累计数量异常：应为 ${_0x3e3dc9e2f4e2}，页面为 ${_0xf5289cd57adc.cartCount}。`
        };
    }
    _0xe6a46620cdaf.observedUnitPrice = _0x02e4b075e6da.toFixed(2);
    _0xe6a46620cdaf.selectedQuantity = _0x9a9e1336f649;
    _0xe6a46620cdaf.addedToCart = true;
    _0xd905f3edf4d4.expectedCartCount = _0x3e3dc9e2f4e2;
    _0x6c4eec96f923(_0xe6a46620cdaf, `已加入购物篮（累计 ${_0x3e3dc9e2f4e2} 件）`, _0xdefea0608c5f(81613));
    _0x9ed268225a55(_0xee0fdf22ae74, _0xdefea0608c5f(81645), `已加入购物篮：ASIN ${_0xe6a46620cdaf.asin} × ${_0x9a9e1336f649}；累计购物篮数量 ${_0x3e3dc9e2f4e2}。`, _0xe6a46620cdaf.rowNumber);
    _0xd327576ec38f = {
        ..._0xd327576ec38f,
        addedRowIndexes: [...new Set([...(_0xd327576ec38f.addedRowIndexes || []), _0xd51c1f715e18.currentIndex])],
        expectedCartCount: _0x3e3dc9e2f4e2,
        stage: _0xdefea0608c5f(81698),
        updatedAt: new Date().toISOString()
    };
    if (_0xd905f3edf4d4.addCursor + 1 < _0xd905f3edf4d4.rowIndexes.length) {
        _0xd905f3edf4d4.addCursor += 1;
        const _0x8f2c52144978 = _0xd905f3edf4d4.rowIndexes[_0xd905f3edf4d4.addCursor];
        const _0xd5d88c22e652 = _0xd51c1f715e18.rows[_0x8f2c52144978];
        _0xd51c1f715e18.currentIndex = _0x8f2c52144978;
        _0xd51c1f715e18.phase = _0xdefea0608c5f(81626);
        _0x6c4eec96f923(_0xd5d88c22e652, _0xdefea0608c5f(81674), _0xdefea0608c5f(81613));
        _0x9ed268225a55(_0xee0fdf22ae74, _0xdefea0608c5f(81466), `上一件商品已成功加入购物篮；关闭成功添加页面并为第 ${_0xd5d88c22e652.rowNumber} 行打开独立标签页。`, _0xd5d88c22e652.rowNumber);
        _0xd51c1f715e18.updatedAt = new Date().toISOString();
        const _0x3698a7d3df00 = await _0x69458914c08b(_0xd51c1f715e18, _0xee0fdf22ae74, _0xd5d88c22e652.amzLink, { [_0x3e8163af073e.CART_LOCK]: _0xd327576ec38f }, _0xdefea0608c5f(81524));
        return _0x3698a7d3df00.ok ? { ok: true, state: _0xd51c1f715e18 } : _0x3698a7d3df00;
    }
    _0xd51c1f715e18.phase = _0xdefea0608c5f(81489);
    _0x0746180a2a72(_0xd51c1f715e18.rows, _0xd905f3edf4d4, _0xdefea0608c5f(81554));
    _0xd327576ec38f.stage = _0xdefea0608c5f(81570);
    _0xd327576ec38f.updatedAt = new Date().toISOString();
    _0xd51c1f715e18.updatedAt = new Date().toISOString();
    _0x9ed268225a55(_0xee0fdf22ae74, _0xdefea0608c5f(81466), `组合单全部商品已加入购物篮，总数量 ${_0xd905f3edf4d4.expectedTotalQuantity}，准备交叉检查并结算。`, _0xe6a46620cdaf.rowNumber);
    await _0xe0f1516d2a85(_0xd51c1f715e18, _0xee0fdf22ae74, { [_0x3e8163af073e.CART_LOCK]: _0xd327576ec38f });
    await _0xc70c7bf1c52a(_0xd51c1f715e18.workTabId);
    return { ok: true, state: _0xd51c1f715e18 };
}
async function _0xfbb8ac325fa9(_0x27556a17a675, _0x448371975800) {
    const _0x9263927c5f8b = await _0x4d5b02696d67();
    const _0x6f4191630ea1 = _0x9263927c5f8b[_0x3e8163af073e.RUN_STATE];
    const _0x99998ecad2c8 = Array.isArray(_0x9263927c5f8b[_0x3e8163af073e.LOGS]) ? _0x9263927c5f8b[_0x3e8163af073e.LOGS] : [];
    let _0x0532f2121f73 = _0x9263927c5f8b[_0x3e8163af073e.CART_LOCK] || null;
    if (!_0x6f4191630ea1 || _0x448371975800.tab?.id !== _0x6f4191630ea1.workTabId || _0x6f4191630ea1.runId !== _0x27556a17a675.runId) {
        return { ok: false, stale: true };
    }
    if (_0x6f4191630ea1.phase !== _0xdefea0608c5f(81489)) {
        return { ok: false, stale: true, error: `当前阶段不是 Proceed to Checkout：${_0x6f4191630ea1.phase}` };
    }
    const _0xafc930115e26 = _0xd95c33d75b28(_0x6f4191630ea1);
    if (!_0xafc930115e26?.isCombined || !_0x4c9bde331c2e(_0x0532f2121f73, _0x6f4191630ea1, _0xafc930115e26)) {
        return { ok: false, error: _0xdefea0608c5f(81473) };
    }
    const _0xb22c1920afd9 = Number(_0x27556a17a675.cartCount);
    if (!Number.isSafeInteger(_0xb22c1920afd9) || _0xb22c1920afd9 !== _0xafc930115e26.expectedTotalQuantity) {
        return { ok: false, error: `Proceed 前购物篮数量应为 ${_0xafc930115e26.expectedTotalQuantity}，页面为 ${_0x27556a17a675.cartCount}。` };
    }
    if (_0x27556a17a675.proceedItemCount !== null &&
        _0x27556a17a675.proceedItemCount !== undefined &&
        Number(_0x27556a17a675.proceedItemCount) !== _0xafc930115e26.expectedTotalQuantity) {
        return { ok: false, error: `Proceed 按钮显示 ${_0x27556a17a675.proceedItemCount} items，与预期 ${_0xafc930115e26.expectedTotalQuantity} 不一致。` };
    }
    _0x6f4191630ea1.currentIndex = _0xafc930115e26.primaryRowIndex;
    _0x6f4191630ea1.phase = _0xdefea0608c5f(81605);
    _0x0746180a2a72(_0x6f4191630ea1.rows, _0xafc930115e26, _0xdefea0608c5f(81520));
    _0x0532f2121f73 = {
        ..._0x0532f2121f73,
        stage: _0xdefea0608c5f(81486),
        expectedCartCount: _0xafc930115e26.expectedTotalQuantity,
        proceedItemCount: _0x27556a17a675.proceedItemCount ?? null,
        updatedAt: new Date().toISOString()
    };
    _0x9ed268225a55(_0x99998ecad2c8, _0xdefea0608c5f(81645), _0x27556a17a675.proceedItemCount === null || _0x27556a17a675.proceedItemCount === undefined
        ? `Proceed 前购物篮数量核对通过：${_0xb22c1920afd9} 件。`
        : `Proceed 前购物篮数量与按钮 items 数均核对通过：${_0xb22c1920afd9} 件。`, _0x6f4191630ea1.rows[_0xafc930115e26.primaryRowIndex].rowNumber);
    _0x6f4191630ea1.updatedAt = new Date().toISOString();
    await _0xe0f1516d2a85(_0x6f4191630ea1, _0x99998ecad2c8, { [_0x3e8163af073e.CART_LOCK]: _0x0532f2121f73 });
    return { ok: true, state: _0x6f4191630ea1 };
}
async function _0x6992bb16794b(_0x514e8975e6fd, _0x89b31e3e55ff = null, _0xd54ef6691155 = false) {
    const _0xcd8b8ae2e413 = await _0x4d5b02696d67();
    const _0xefb047798a0f = _0xcd8b8ae2e413[_0x3e8163af073e.RUN_STATE];
    const _0x39bd8396d20f = Array.isArray(_0xcd8b8ae2e413[_0x3e8163af073e.LOGS]) ? _0xcd8b8ae2e413[_0x3e8163af073e.LOGS] : [];
    const _0x3d79d8b05e97 = _0xcd8b8ae2e413[_0x3e8163af073e.CART_LOCK] || null;
    if (!_0xefb047798a0f) {
        return { ok: false, error: _0xdefea0608c5f(81683) };
    }
    if (_0x89b31e3e55ff?.tab && _0x89b31e3e55ff.tab.id !== _0xefb047798a0f.workTabId) {
        return { ok: false, stale: true };
    }
    if (_0x514e8975e6fd.runId && _0xefb047798a0f.runId !== _0x514e8975e6fd.runId) {
        return { ok: false, stale: true };
    }
    if (_0x514e8975e6fd.expectedPhase && _0xefb047798a0f.phase !== _0x514e8975e6fd.expectedPhase) {
        return { ok: false, stale: true };
    }
    const _0x032677e6469f = _0x7099183f8138(_0xefb047798a0f);
    const _0xc87c92dc0d07 = _0xd95c33d75b28(_0xefb047798a0f);
    if (!_0x032677e6469f || !_0xc87c92dc0d07) {
        return { ok: false, error: _0xdefea0608c5f(81672) };
    }
    if (_0x4c9bde331c2e(_0x3d79d8b05e97, _0xefb047798a0f, _0xc87c92dc0d07)) {
        return {
            ok: false,
            error: _0xdefea0608c5f(81514)
        };
    }
    if (_0xefb047798a0f.phase === _0xdefea0608c5f(81578)) {
        await _0xffbec67a1c34(_0xefb047798a0f.runId);
        _0xefb047798a0f.intervalEndsAt = null;
        _0xefb047798a0f.intervalRemainingSeconds = 0;
    }
    const _0x632e653de553 = _0x514e8975e6fd.reason || (_0xd54ef6691155 ? _0xdefea0608c5f(81457) : _0xdefea0608c5f(81601));
    if (Number.isFinite(Number(_0x514e8975e6fd.observedUnitPrice))) {
        _0x032677e6469f.observedUnitPrice = Number(_0x514e8975e6fd.observedUnitPrice).toFixed(2);
    }
    if (Number.isSafeInteger(Number(_0x514e8975e6fd.selectedQuantity)) && Number(_0x514e8975e6fd.selectedQuantity) > 0) {
        _0x032677e6469f.selectedQuantity = Number(_0x514e8975e6fd.selectedQuantity);
    }
    const _0x9dab4b7b77e9 = _0x06782ce10198.has(_0xefb047798a0f.phase);
    const _0xbd001252b257 = _0xd54ef6691155 && _0x9dab4b7b77e9 ? `${_0x632e653de553}（订单结果未确认）` : _0x632e653de553;
    if (_0xc87c92dc0d07.isCombined) {
        _0x07765bdf7bf4(_0xefb047798a0f.rows, _0xc87c92dc0d07, _0xefb047798a0f.currentIndex, _0xbd001252b257);
        _0x9ed268225a55(_0x39bd8396d20f, _0xdefea0608c5f(81461), `${_0xbd001252b257}；该收件人地址组全部跳过。`, _0x032677e6469f.rowNumber);
    }
    else {
        _0xc87c92dc0d07.result = _0xdefea0608c5f(81638);
        _0xc87c92dc0d07.status = _0xbd001252b257;
        _0x6c4eec96f923(_0x032677e6469f, _0xbd001252b257, _0xdefea0608c5f(81638));
        _0x9ed268225a55(_0x39bd8396d20f, _0xdefea0608c5f(81461), _0xbd001252b257, _0x032677e6469f.rowNumber);
    }
    await _0xe0f1516d2a85(_0xefb047798a0f, _0x39bd8396d20f);
    await _0x9b2fdfd21460(_0xefb047798a0f, _0x39bd8396d20f, _0xdefea0608c5f(81579), 0);
    return { ok: true };
}
async function _0xddad7a8e1084(_0xba050fa74081, _0xb871b4a39c98) {
    const _0x641fba71a15f = await _0x4d5b02696d67();
    const _0x1d888362c117 = _0x641fba71a15f[_0x3e8163af073e.RUN_STATE];
    const _0x32b612350267 = Array.isArray(_0x641fba71a15f[_0x3e8163af073e.LOGS]) ? _0x641fba71a15f[_0x3e8163af073e.LOGS] : [];
    const _0x7d7beb915cee = _0x6c1a1e83a579(_0x641fba71a15f[_0x3e8163af073e.HISTORY]);
    const _0xa7e07e774627 = _0x03487935396e(_0x641fba71a15f[_0x3e8163af073e.ORDER_INDEX], _0x7d7beb915cee);
    const _0x4cc117ebf3d2 = _0x641fba71a15f[_0x3e8163af073e.CART_LOCK] || null;
    if (!_0x1d888362c117 || _0xb871b4a39c98.tab?.id !== _0x1d888362c117.workTabId || _0x1d888362c117.runId !== _0xba050fa74081.runId) {
        return { ok: false, stale: true };
    }
    if (_0x1d888362c117.phase !== _0xdefea0608c5f(81478)) {
        return { ok: false, stale: true, error: `当前阶段不是订单核对阶段：${_0x1d888362c117.phase}` };
    }
    const _0x6a1f58345185 = _0xd95c33d75b28(_0x1d888362c117);
    const _0x1e2b4ec0442f = _0x0bfa2a1893b2(_0x1d888362c117);
    if (!_0x6a1f58345185 || !_0x1e2b4ec0442f) {
        return { ok: false, error: _0xdefea0608c5f(81708) };
    }
    const _0x0e2448c3e2f4 = String(_0xba050fa74081.orderId ?? _0xdefea0608c5f(81528)).trim();
    if (!_0x91508b6109bd(_0x0e2448c3e2f4)) {
        return { ok: false, error: _0xdefea0608c5f(81586) };
    }
    if (_0x6a1f58345185.isCombined && !_0x4c9bde331c2e(_0x4cc117ebf3d2, _0x1d888362c117, _0x6a1f58345185)) {
        return { ok: false, error: _0xdefea0608c5f(81669) };
    }
    const _0xd1b8bf9e37aa = new Date().toISOString();
    const _0x2e73b57c5475 = _0x251e0f49d3e1();
    for (const _0x4a1705548efe of _0x6a1f58345185.uniqueTemuOrderIds) {
        const _0x533037656b69 = _0xcf3dc02b2cac(_0x1d888362c117.rows, _0x6a1f58345185, _0x4a1705548efe);
        const _0x07c5a14b50d1 = _0x1d888362c117.rows[_0x533037656b69[0]];
        const _0xc9fb0ce86d53 = _0x6a1f58345185.temuItemSignatures[_0x4a1705548efe] || _0xdefea0608c5f(81528);
        const _0x9b3b1600c981 = _0x6a1f58345185.temuSignatures[_0x4a1705548efe] || _0xdefea0608c5f(81528);
        _0x7d7beb915cee.push({
            id: crypto.randomUUID(),
            runId: _0x1d888362c117.runId,
            rowNumbers: _0x533037656b69.map((_0xae31073157e3) => _0x1d888362c117.rows[_0xae31073157e3].rowNumber),
            dateKey: _0x2e73b57c5475,
            temuOrderId: _0x07c5a14b50d1?.temuOrderId || _0x4a1705548efe,
            temuOrderIdKey: _0x4a1705548efe,
            asin: _0x07c5a14b50d1?.asin || _0xdefea0608c5f(81528),
            normalizedName: _0x6a1f58345185.normalizedName,
            shipAddress: _0x6a1f58345185.shipAddress,
            address2: _0x6a1f58345185.address2,
            shipCity: _0x6a1f58345185.shipCity,
            shipPostalCode: _0x6a1f58345185.shipPostalCode,
            phoneNumber: _0x6a1f58345185.phoneNumber,
            status: _0xdefea0608c5f(81574),
            orderId: _0x0e2448c3e2f4,
            addressSignature: _0x6a1f58345185.addressSignature,
            itemSignature: _0xc9fb0ce86d53,
            temuSignature: _0x9b3b1600c981,
            groupSignature: _0x6a1f58345185.groupSignature,
            expectedItems: _0xafd75b332654(_0x1d888362c117.rows, _0x533037656b69),
            actualDeliveryAddress: _0x6a1f58345185.actualDeliveryAddress,
            createdAt: _0xd1b8bf9e37aa,
            updatedAt: _0xd1b8bf9e37aa
        });
        _0xa7e07e774627[_0xa3c8b008e98d(_0x4a1705548efe)] = {
            temuOrderId: _0x4a1705548efe,
            status: _0xdefea0608c5f(81574),
            orderId: _0x0e2448c3e2f4,
            dateKey: _0x2e73b57c5475,
            addressSignature: _0x6a1f58345185.addressSignature,
            itemSignature: _0xc9fb0ce86d53,
            temuSignature: _0x9b3b1600c981,
            groupSignature: _0x6a1f58345185.groupSignature,
            updatedAt: _0xd1b8bf9e37aa
        };
    }
    if (_0x7d7beb915cee.length > _0x2f5b397944b9) {
        _0x7d7beb915cee.splice(0, _0x7d7beb915cee.length - _0x2f5b397944b9);
    }
    _0xcb2a1cb7f23c(_0x1d888362c117.rows, _0x6a1f58345185, _0x0e2448c3e2f4);
    _0x1d888362c117.knownOrderIds = [...new Set([...(_0x1d888362c117.knownOrderIds || []), _0x0e2448c3e2f4])];
    _0x1d888362c117.updatedAt = _0xd1b8bf9e37aa;
    _0x9ed268225a55(_0x32b612350267, _0xdefea0608c5f(81645), _0x6a1f58345185.isCombined
        ? `组合单下单成功，${_0x6a1f58345185.rowIndexes.length} 行共用 Order ID：${_0x0e2448c3e2f4}`
        : `下单成功，Order ID：${_0x0e2448c3e2f4}`, _0x1e2b4ec0442f.rowNumber);
    const _0x966649e45df7 = {
        [_0x3e8163af073e.RUN_STATE]: _0x1d888362c117,
        [_0x3e8163af073e.HISTORY]: _0x7d7beb915cee,
        [_0x3e8163af073e.ORDER_INDEX]: _0xa7e07e774627,
        [_0x3e8163af073e.LOGS]: _0x32b612350267
    };
    await chrome.storage.local.set(_0x966649e45df7);
    if (_0x6a1f58345185.isCombined) {
        await chrome.storage.local.remove(_0x3e8163af073e.CART_LOCK);
        _0x9ed268225a55(_0x32b612350267, _0xdefea0608c5f(81645), _0xdefea0608c5f(81468), _0x1e2b4ec0442f.rowNumber);
        await chrome.storage.local.set({ [_0x3e8163af073e.LOGS]: _0x32b612350267 });
    }
    await _0x9b2fdfd21460(_0x1d888362c117, _0x32b612350267, _0xdefea0608c5f(81579), _0x1b68513a1664(_0x1d888362c117.orderIntervalSeconds, _0x1bcb5124efbc.orderIntervalSeconds));
    return { ok: true, orderId: _0x0e2448c3e2f4 };
}
async function _0xde570de9fcda() {
    const _0x332de4fe9d0f = await _0x4d5b02696d67();
    const _0x973cea94c200 = _0x332de4fe9d0f[_0x3e8163af073e.RUN_STATE];
    const _0x61b31a861606 = Array.isArray(_0x332de4fe9d0f[_0x3e8163af073e.LOGS]) ? _0x332de4fe9d0f[_0x3e8163af073e.LOGS] : [];
    if (!_0x973cea94c200 || !_0x80ae694037f0.has(_0x973cea94c200.mode) || _0x973cea94c200.mode === _0xdefea0608c5f(81504)) {
        return { ok: false, error: _0xdefea0608c5f(81644) };
    }
    const _0xa8e575f2cd57 = _0xd95c33d75b28(_0x973cea94c200);
    const _0xbc17244363dd = _0x7099183f8138(_0x973cea94c200);
    if (_0x973cea94c200.phase === _0xdefea0608c5f(81578)) {
        const _0x3e33d57d47d9 = _0xf16afafc0018(_0x973cea94c200);
        await _0xffbec67a1c34(_0x973cea94c200.runId);
        _0x973cea94c200.intervalEndsAt = null;
        _0x973cea94c200.intervalRemainingSeconds = Math.ceil(_0x3e33d57d47d9 / 1000);
    }
    _0x973cea94c200.mode = _0xdefea0608c5f(81504);
    _0x973cea94c200.pauseReason = _0xdefea0608c5f(81646);
    _0x973cea94c200.updatedAt = new Date().toISOString();
    const _0x26b7d0cf19b4 = _0x973cea94c200.phase === _0xdefea0608c5f(81578)
        ? `（间隔剩余约 ${_0x973cea94c200.intervalRemainingSeconds} 秒）`
        : _0xdefea0608c5f(81528);
    if (_0xa8e575f2cd57?.isCombined) {
        _0xef306e091ba6(_0x973cea94c200.rows, _0xa8e575f2cd57, `人工暂停${_0x26b7d0cf19b4}`);
    }
    else if (_0xbc17244363dd) {
        _0x6c4eec96f923(_0xbc17244363dd, `已暂停：人工暂停${_0x26b7d0cf19b4}`, _0xdefea0608c5f(81564));
    }
    _0x9ed268225a55(_0x61b31a861606, _0xdefea0608c5f(81461), _0xdefea0608c5f(81548), _0xbc17244363dd?.rowNumber ?? null);
    await _0xe0f1516d2a85(_0x973cea94c200, _0x61b31a861606);
    return { ok: true };
}
async function _0x139c22549462() {
    const _0x18fe7819f668 = await _0x4d5b02696d67();
    const _0x818f3d54f8e2 = _0x18fe7819f668[_0x3e8163af073e.RUN_STATE];
    const _0x3c6de32a12eb = Array.isArray(_0x18fe7819f668[_0x3e8163af073e.LOGS]) ? _0x18fe7819f668[_0x3e8163af073e.LOGS] : [];
    const _0xadc81d5d8f78 = _0x18fe7819f668[_0x3e8163af073e.CART_LOCK] || null;
    if (!_0x818f3d54f8e2 || _0x818f3d54f8e2.mode !== _0xdefea0608c5f(81504)) {
        return { ok: false, error: _0xdefea0608c5f(81470) };
    }
    if (_0x818f3d54f8e2.phase === _0xdefea0608c5f(81677)) {
        return { ok: false, error: _0xdefea0608c5f(81549) };
    }
    const _0xfefddb0a48ab = _0xd95c33d75b28(_0x818f3d54f8e2);
    const _0x5e2555fb98bc = _0x7099183f8138(_0x818f3d54f8e2);
    if (_0xfefddb0a48ab?.isCombined && _0x80c6528d38d3.has(_0x818f3d54f8e2.phase) && !_0x4c9bde331c2e(_0xadc81d5d8f78, _0x818f3d54f8e2, _0xfefddb0a48ab)) {
        return { ok: false, error: _0xdefea0608c5f(81561) };
    }
    if (_0x818f3d54f8e2.phase === _0xdefea0608c5f(81578)) {
        const _0xa8a6cb849a56 = Math.max(0, Number(_0x818f3d54f8e2.intervalRemainingSeconds || 0) * 1000);
        _0x818f3d54f8e2.mode = _0xdefea0608c5f(81512);
        _0x818f3d54f8e2.pauseReason = _0xdefea0608c5f(81528);
        _0x818f3d54f8e2.intervalEndsAt = new Date(Date.now() + _0xa8a6cb849a56).toISOString();
        _0x818f3d54f8e2.intervalRemainingSeconds = Math.ceil(_0xa8a6cb849a56 / 1000);
        _0x818f3d54f8e2.updatedAt = new Date().toISOString();
        if (_0xfefddb0a48ab) {
            _0x0746180a2a72(_0x818f3d54f8e2.rows, _0xfefddb0a48ab, `等待下单间隔（${_0x818f3d54f8e2.intervalRemainingSeconds}秒）`);
        }
        _0x9ed268225a55(_0x3c6de32a12eb, _0xdefea0608c5f(81466), _0xdefea0608c5f(81525), _0x5e2555fb98bc?.rowNumber ?? null);
        await _0xe0f1516d2a85(_0x818f3d54f8e2, _0x3c6de32a12eb);
        if (_0xa8a6cb849a56 <= 0) {
            await _0x983d9aaa9832(_0x818f3d54f8e2.runId);
        }
        else {
            await _0x3c64c6cf81c8(_0x818f3d54f8e2, _0xa8a6cb849a56);
        }
        return { ok: true };
    }
    let _0xbbe82136d6c5 = false;
    if (Number.isInteger(_0x818f3d54f8e2.workTabId)) {
        try {
            await chrome.tabs.get(_0x818f3d54f8e2.workTabId);
            _0xbbe82136d6c5 = true;
        }
        catch {
            _0xbbe82136d6c5 = false;
        }
    }
    if (!_0xbbe82136d6c5) {
        const _0x88196291d3eb = [_0xdefea0608c5f(81545), _0xdefea0608c5f(81678), _0xdefea0608c5f(81590), _0xdefea0608c5f(81316)].includes(_0x818f3d54f8e2.phase);
        if (!_0x88196291d3eb || !_0x5e2555fb98bc?.amzLink || _0x18fe7819f668[_0x3e8163af073e.CART_LOCK]) {
            return {
                ok: false,
                error: _0xdefea0608c5f(81475)
            };
        }
        _0x818f3d54f8e2.workTabId = await _0xb86675aa5153(null);
    }
    _0x818f3d54f8e2.mode = _0xdefea0608c5f(81477);
    _0x818f3d54f8e2.pauseReason = _0xdefea0608c5f(81528);
    _0x818f3d54f8e2.updatedAt = new Date().toISOString();
    if (_0xfefddb0a48ab?.isCombined) {
        _0x0746180a2a72(_0x818f3d54f8e2.rows, _0xfefddb0a48ab, _0xdefea0608c5f(81628));
    }
    else if (_0x5e2555fb98bc) {
        _0x6c4eec96f923(_0x5e2555fb98bc, _0xdefea0608c5f(81652), _0xdefea0608c5f(81613));
    }
    _0x9ed268225a55(_0x3c6de32a12eb, _0xdefea0608c5f(81466), _0xdefea0608c5f(81568), _0x5e2555fb98bc?.rowNumber ?? null);
    await _0xe0f1516d2a85(_0x818f3d54f8e2, _0x3c6de32a12eb);
    if (!_0xbbe82136d6c5 && _0x5e2555fb98bc?.amzLink) {
        await _0x3b99d8c28ab2(_0x818f3d54f8e2.workTabId, _0x5e2555fb98bc.amzLink);
    }
    else {
        await _0xc70c7bf1c52a(_0x818f3d54f8e2.workTabId);
    }
    return { ok: true };
}
async function _0xd52f12ba28e9() {
    const _0x58a6b2871428 = await _0x4d5b02696d67();
    const _0x9eaafda0275b = _0x58a6b2871428[_0x3e8163af073e.RUN_STATE];
    const _0x3dae1e7fb19f = Array.isArray(_0x58a6b2871428[_0x3e8163af073e.LOGS]) ? _0x58a6b2871428[_0x3e8163af073e.LOGS] : [];
    const _0x578ccb19971f = _0x58a6b2871428[_0x3e8163af073e.CART_LOCK] || null;
    if (!_0x9eaafda0275b || !_0x80ae694037f0.has(_0x9eaafda0275b.mode)) {
        return { ok: false, error: _0xdefea0608c5f(81533) };
    }
    const _0x8d32adb16448 = _0xd95c33d75b28(_0x9eaafda0275b);
    const _0xe0588cd1a9dc = _0x7099183f8138(_0x9eaafda0275b);
    const _0x8f633ecf624e = _0x9eaafda0275b.phase;
    if (_0x8f633ecf624e === _0xdefea0608c5f(81578)) {
        await _0xffbec67a1c34(_0x9eaafda0275b.runId);
    }
    _0x9eaafda0275b.mode = _0xdefea0608c5f(81546);
    _0x9eaafda0275b.phase = _0xdefea0608c5f(81456);
    _0x9eaafda0275b.pauseReason = _0xdefea0608c5f(81528);
    _0x9eaafda0275b.intervalEndsAt = null;
    _0x9eaafda0275b.intervalRemainingSeconds = 0;
    _0x9eaafda0275b.updatedAt = new Date().toISOString();
    const _0xcd4cb5833267 = _0x4c9bde331c2e(_0x578ccb19971f, _0x9eaafda0275b, _0x8d32adb16448);
    const _0xaf7ec0ef4166 = _0xcd4cb5833267 ? _0xdefea0608c5f(81681) : _0x06782ce10198.has(_0x8f633ecf624e)
        ? _0xdefea0608c5f(81530) : _0xdefea0608c5f(81629);
    if (_0x8d32adb16448?.isCombined) {
        _0xef306e091ba6(_0x9eaafda0275b.rows, _0x8d32adb16448, _0xaf7ec0ef4166);
    }
    else if (_0xe0588cd1a9dc && (_0xe0588cd1a9dc.result === _0xdefea0608c5f(81613) || _0xe0588cd1a9dc.result === _0xdefea0608c5f(81564))) {
        _0x6c4eec96f923(_0xe0588cd1a9dc, _0xaf7ec0ef4166, _0xdefea0608c5f(81564));
    }
    _0x9ed268225a55(_0x3dae1e7fb19f, _0xdefea0608c5f(81461), _0xcd4cb5833267 ? _0xdefea0608c5f(81532) : _0x06782ce10198.has(_0x8f633ecf624e)
        ? _0xdefea0608c5f(81314) : _0xdefea0608c5f(81606), _0xe0588cd1a9dc?.rowNumber ?? null);
    await _0xe0f1516d2a85(_0x9eaafda0275b, _0x3dae1e7fb19f);
    return { ok: true };
}
async function _0x505f9612954c() {
    const _0x8bdf6d50569d = await _0x4d5b02696d67();
    const _0x53a3ef7596b9 = _0x8bdf6d50569d[_0x3e8163af073e.RUN_STATE] || null;
    const _0x22fd7ce02d81 = Array.isArray(_0x8bdf6d50569d[_0x3e8163af073e.LOGS]) ? _0x8bdf6d50569d[_0x3e8163af073e.LOGS] : [];
    const _0xd83ece46bf2a = _0x8bdf6d50569d[_0x3e8163af073e.CART_LOCK] || null;
    if (!_0xd83ece46bf2a) {
        return { ok: true, cleared: false, message: _0xdefea0608c5f(81513) };
    }
    if (_0x53a3ef7596b9 && [_0xdefea0608c5f(81477), _0xdefea0608c5f(81512)].includes(_0x53a3ef7596b9.mode)) {
        return { ok: false, error: _0xdefea0608c5f(81500) };
    }
    if (_0x53a3ef7596b9 && _0x53a3ef7596b9.runId === _0xd83ece46bf2a.runId) {
        const _0xe956eb4fabe9 = _0xd95c33d75b28(_0x53a3ef7596b9);
        if (_0xe956eb4fabe9?.id === _0xd83ece46bf2a.groupId) {
            _0xef306e091ba6(_0x53a3ef7596b9.rows, _0xe956eb4fabe9, _0xdefea0608c5f(81495));
        }
        _0x53a3ef7596b9.mode = _0xdefea0608c5f(81546);
        _0x53a3ef7596b9.phase = _0xdefea0608c5f(81456);
        _0x53a3ef7596b9.pauseReason = _0xdefea0608c5f(81528);
        _0x53a3ef7596b9.updatedAt = new Date().toISOString();
    }
    _0x9ed268225a55(_0x22fd7ce02d81, _0xdefea0608c5f(81461), `用户确认已人工检查购物篮及最近订单，已清除组合单锁（组 ${_0xd83ece46bf2a.groupId || _0xdefea0608c5f(81651)}）。`);
    await chrome.storage.local.remove(_0x3e8163af073e.CART_LOCK);
    await chrome.storage.local.set({
        [_0x3e8163af073e.RUN_STATE]: _0x53a3ef7596b9,
        [_0x3e8163af073e.LOGS]: _0x22fd7ce02d81
    });
    return { ok: true, cleared: true };
}
async function _0x7082b938ce44(_0xc6bdf4506dc9, _0x1095fc674364) {
    const _0xd827fdc82312 = await _0x4d5b02696d67();
    const _0xe8b7dbca2d77 = _0xd827fdc82312[_0x3e8163af073e.RUN_STATE];
    const _0xc529e426c56b = Array.isArray(_0xd827fdc82312[_0x3e8163af073e.LOGS]) ? _0xd827fdc82312[_0x3e8163af073e.LOGS] : [];
    if (!_0xe8b7dbca2d77 || _0x1095fc674364.tab?.id !== _0xe8b7dbca2d77.workTabId || _0xe8b7dbca2d77.runId !== _0xc6bdf4506dc9.runId) {
        return { ok: false, stale: true };
    }
    const _0x2bd2252cea52 = _0x7099183f8138(_0xe8b7dbca2d77);
    _0x9ed268225a55(_0xc529e426c56b, _0xc6bdf4506dc9.level || _0xdefea0608c5f(81466), String(_0xc6bdf4506dc9.message || _0xdefea0608c5f(81528)), _0x2bd2252cea52?.rowNumber ?? null);
    await chrome.storage.local.set({ [_0x3e8163af073e.LOGS]: _0xc529e426c56b });
    return { ok: true };
}
async function _0x743223291167(_0x988d8bc5f0e1) {
    const _0x4d159b830450 = await chrome.storage.local.get(_0x3e8163af073e.RUN_STATE);
    const _0x24f545380bfd = _0x4d159b830450[_0x3e8163af073e.RUN_STATE];
    if (_0x24f545380bfd && _0x80ae694037f0.has(_0x24f545380bfd.mode)) {
        return { ok: false, error: _0xdefea0608c5f(81569) };
    }
    await chrome.storage.local.set({
        [_0x3e8163af073e.DRAFT_ROWS]: Array.isArray(_0x988d8bc5f0e1) ? _0x988d8bc5f0e1 : []
    });
    return { ok: true };
}
async function _0x2e7b6c2f5294() {
    const _0xea610b71b797 = await chrome.storage.local.get([_0x3e8163af073e.RUN_STATE, _0x3e8163af073e.CART_LOCK]);
    const _0xdf77fa8c560c = _0xea610b71b797[_0x3e8163af073e.RUN_STATE];
    if (_0xdf77fa8c560c && _0x80ae694037f0.has(_0xdf77fa8c560c.mode)) {
        return { ok: false, error: _0xdefea0608c5f(81624) };
    }
    if (_0xea610b71b797[_0x3e8163af073e.CART_LOCK]) {
        return { ok: false, error: _0xdefea0608c5f(81519) };
    }
    await chrome.storage.local.set({
        [_0x3e8163af073e.DRAFT_ROWS]: [],
        [_0x3e8163af073e.RUN_STATE]: null
    });
    return { ok: true };
}
async function _0x20d185186264() {
    await chrome.storage.local.set({ [_0x3e8163af073e.LOGS]: [] });
    return { ok: true };
}
async function _0x4b31fefa9b92(_0x9d72954f8f85) {
    const _0x6818a82a539a = await chrome.storage.local.get([_0x3e8163af073e.RUN_STATE, _0x3e8163af073e.SETTINGS]);
    const _0x4bd4a916740c = _0x6818a82a539a[_0x3e8163af073e.RUN_STATE];
    if (_0x4bd4a916740c && _0x80ae694037f0.has(_0x4bd4a916740c.mode)) {
        return { ok: false, error: _0xdefea0608c5f(81516) };
    }
    const _0x03f46c7b024a = _0x9d72954f8f85?.orderIntervalSeconds;
    const _0xdf469a89f21f = Number(_0x03f46c7b024a);
    if (!Number.isInteger(_0xdf469a89f21f) || _0xdf469a89f21f < 0 || _0xdf469a89f21f > 3600) {
        return { ok: false, error: _0xdefea0608c5f(81602) };
    }
    const _0xbaa7db9d720c = { orderIntervalSeconds: _0xdf469a89f21f };
    await chrome.storage.local.set({ [_0x3e8163af073e.SETTINGS]: _0xbaa7db9d720c });
    return { ok: true, settings: _0xbaa7db9d720c };
}
async function _0x3f33643ee2e1() {
    const _0x30aa88db7000 = await _0x4d5b02696d67();
    const _0xcb758f097fef = _0x30aa88db7000[_0x3e8163af073e.RUN_STATE];
    if (_0xcb758f097fef && _0x80ae694037f0.has(_0xcb758f097fef.mode)) {
        return { ok: false, error: _0xdefea0608c5f(81585) };
    }
    const _0xce2ca8af919c = _0x251e0f49d3e1();
    const _0x207c2641c4a5 = Array.isArray(_0x30aa88db7000[_0x3e8163af073e.LOGS]) ? _0x30aa88db7000[_0x3e8163af073e.LOGS] : [];
    const _0x8383eb267e55 = _0x6c1a1e83a579(_0x30aa88db7000[_0x3e8163af073e.HISTORY]);
    const _0x9269a49928cb = _0x03487935396e(_0x30aa88db7000[_0x3e8163af073e.ORDER_INDEX], _0x8383eb267e55);
    const _0x5c15f015066c = new Set();
    for (const [_0x579a09df9229, _0x3199470910b4] of Object.entries(_0x9269a49928cb)) {
        if (_0x3199470910b4?.status === _0xdefea0608c5f(81574) && _0x3199470910b4.dateKey === _0xce2ca8af919c && _0x91508b6109bd(_0x3199470910b4.orderId)) {
            _0x5c15f015066c.add(_0xc04935eb4f63(_0x3199470910b4.temuOrderId));
            delete _0x9269a49928cb[_0x579a09df9229];
        }
    }
    const _0x504475060354 = _0x8383eb267e55.filter((_0x4569d369dd80) => {
        const _0xce3ccafa1ad5 = _0x4569d369dd80.status === _0xdefea0608c5f(81574) &&
            _0x4569d369dd80.dateKey === _0xce2ca8af919c &&
            _0x91508b6109bd(_0x4569d369dd80.orderId);
        if (_0xce3ccafa1ad5) {
            _0x5c15f015066c.add(_0xc04935eb4f63(_0x4569d369dd80.temuOrderIdKey || _0x4569d369dd80.temuOrderId));
        }
        return !_0xce3ccafa1ad5;
    });
    _0x9ed268225a55(_0x207c2641c4a5, _0xdefea0608c5f(81461), `已清空 ${_0x5c15f015066c.size} 条 ${_0xce2ca8af919c} 的成功下单防重复记录。`);
    await chrome.storage.local.set({
        [_0x3e8163af073e.HISTORY]: _0x504475060354,
        [_0x3e8163af073e.ORDER_INDEX]: _0x9269a49928cb,
        [_0x3e8163af073e.LOGS]: _0x207c2641c4a5
    });
    return { ok: true, clearedCount: _0x5c15f015066c.size, dateKey: _0xce2ca8af919c };
}
async function _0x3e632e7f864c() {
    const _0xaf5001591478 = await _0x4d5b02696d67();
    const _0x5c8be09cfaa6 = _0xaf5001591478[_0x3e8163af073e.RUN_STATE];
    if (!_0x5c8be09cfaa6 || _0x5c8be09cfaa6.mode !== _0xdefea0608c5f(81512) || _0x5c8be09cfaa6.phase !== _0xdefea0608c5f(81578) || !_0x5c8be09cfaa6.runId) {
        return { ok: false, stale: true };
    }
    const _0x55904285d4bd = _0xf16afafc0018(_0x5c8be09cfaa6);
    if (_0x55904285d4bd <= 0) {
        return _0x983d9aaa9832(_0x5c8be09cfaa6.runId);
    }
    await _0x3c64c6cf81c8(_0x5c8be09cfaa6, _0x55904285d4bd);
    return { ok: true, waiting: true };
}
async function _0xd4ee76da7cb3(_0x369f976933d9) {
    const _0xcef9a9d86d0c = await chrome.storage.local.get([_0x3e8163af073e.RUN_STATE, _0x3e8163af073e.CART_LOCK]);
    const _0xf0963652ad84 = _0xcef9a9d86d0c[_0x3e8163af073e.RUN_STATE] || null;
    const _0x8055ba859307 = Boolean(_0xf0963652ad84 && _0x369f976933d9.tab?.id === _0xf0963652ad84.workTabId);
    const _0x23792474f71a = _0x8055ba859307 ? _0xd95c33d75b28(_0xf0963652ad84) : null;
    return {
        ok: true,
        isWorkTab: _0x8055ba859307,
        state: _0xf0963652ad84,
        row: _0x8055ba859307 ? _0x7099183f8138(_0xf0963652ad84) : null,
        group: _0x23792474f71a,
        orderRow: _0x8055ba859307 ? _0x0bfa2a1893b2(_0xf0963652ad84) : null,
        cartLock: _0x8055ba859307 ? _0xcef9a9d86d0c[_0x3e8163af073e.CART_LOCK] || null : null
    };
}
chrome.action.onClicked.addListener(() => {
    _0xc2077eb1ebcf().catch((_0x95266d21b458) => console.error(_0xdefea0608c5f(81707), _0x95266d21b458));
});
chrome.runtime.onInstalled.addListener(() => {
    _0x786d61cb9e1a(async () => {
        const _0x0e7311f1b02f = await _0x4d5b02696d67();
        const _0xa575efeb4110 = _0x6c1a1e83a579(_0x0e7311f1b02f[_0x3e8163af073e.HISTORY]);
        const _0xaea89ef94920 = _0x03487935396e(_0x0e7311f1b02f[_0x3e8163af073e.ORDER_INDEX], _0xa575efeb4110);
        const _0xb912ca671f18 = Array.isArray(_0x0e7311f1b02f[_0x3e8163af073e.LOGS]) ? _0x0e7311f1b02f[_0x3e8163af073e.LOGS] : [];
        const _0x950523af191d = _0x5e1ab07f720b(_0x0e7311f1b02f[_0x3e8163af073e.SETTINGS]);
        const _0x9f23a09e40b1 = Array.isArray(_0x0e7311f1b02f[_0x3e8163af073e.DRAFT_ROWS]) ? _0x0e7311f1b02f[_0x3e8163af073e.DRAFT_ROWS] : [];
        const _0x387a3688dfda = _0x0e7311f1b02f[_0x3e8163af073e.CART_LOCK] || null;
        let _0xe3026e7d6ff3 = _0x0e7311f1b02f[_0x3e8163af073e.RUN_STATE] || null;
        if (_0xe3026e7d6ff3 && _0x80ae694037f0.has(_0xe3026e7d6ff3.mode) && Number(_0xe3026e7d6ff3.version || 0) < _0x237a184d8647) {
            const _0x64205d37d527 = _0x7099183f8138(_0xe3026e7d6ff3);
            if (_0x64205d37d527) {
                _0x6c4eec96f923(_0x64205d37d527, _0xdefea0608c5f(81691), _0xdefea0608c5f(81564));
            }
            _0xe3026e7d6ff3 = {
                ..._0xe3026e7d6ff3,
                version: _0x237a184d8647,
                mode: _0xdefea0608c5f(81546),
                phase: _0xdefea0608c5f(81456),
                pauseReason: _0xdefea0608c5f(81528),
                intervalEndsAt: null,
                intervalRemainingSeconds: 0,
                updatedAt: new Date().toISOString()
            };
            _0x9ed268225a55(_0xb912ca671f18, _0xdefea0608c5f(81461), _0xdefea0608c5f(81471));
        }
        if (_0x387a3688dfda) {
            _0x9ed268225a55(_0xb912ca671f18, _0xdefea0608c5f(81461), _0xdefea0608c5f(81559));
        }
        await chrome.storage.local.set({
            [_0x3e8163af073e.RUN_STATE]: _0xe3026e7d6ff3,
            [_0x3e8163af073e.HISTORY]: _0xa575efeb4110,
            [_0x3e8163af073e.ORDER_INDEX]: _0xaea89ef94920,
            [_0x3e8163af073e.LOGS]: _0xb912ca671f18,
            [_0x3e8163af073e.DRAFT_ROWS]: _0x9f23a09e40b1,
            [_0x3e8163af073e.SETTINGS]: _0x950523af191d
        });
        if (_0xe3026e7d6ff3?.mode === _0xdefea0608c5f(81512) && _0xe3026e7d6ff3.phase === _0xdefea0608c5f(81578)) {
            await _0x3e632e7f864c();
        }
    }).catch((_0x044f5c8db3ba) => console.error(_0x044f5c8db3ba));
});
chrome.runtime.onStartup.addListener(() => {
    _0x786d61cb9e1a(_0x3e632e7f864c).catch((_0x62569e185be6) => console.error(_0x62569e185be6));
});
chrome.alarms.onAlarm.addListener((_0x2716dc97c9ad) => {
    if (!_0x2716dc97c9ad?.name?.startsWith(_0x021a85941d10)) {
        return;
    }
    const _0x4a15ff08d83e = _0x2716dc97c9ad.name.slice(_0x021a85941d10.length);
    _0x786d61cb9e1a(() => _0x983d9aaa9832(_0x4a15ff08d83e)).catch((_0x645732f00298) => console.error(_0x645732f00298));
});
chrome.runtime.onMessage.addListener((_0xdb9b61530b2c, _0x611dc6ab4f48, _0xb1f9e63f4762) => {
    const _0x6671ba2abcb7 = (_0x4e9fe9442b47) => {
        _0x4e9fe9442b47.then((_0x0bc9bd0e7c2b) => _0xb1f9e63f4762(_0x0bc9bd0e7c2b))
            .catch((_0x3f1e2709a675) => {
            console.error(_0x3f1e2709a675);
            _0xb1f9e63f4762({ ok: false, error: _0x3f1e2709a675.message || String(_0x3f1e2709a675) });
        });
    };
    switch (_0xdb9b61530b2c?.type) {
        case _0xdefea0608c5f(81593):
            _0x6671ba2abcb7(_0x786d61cb9e1a(_0x9a93965ca458));
            return true;
        case _0xdefea0608c5f(81609):
            _0x6671ba2abcb7(_0xc2f591abc9c3(false));
            return true;
        case _0xdefea0608c5f(81517):
            _0xb1f9e63f4762({ ok: true });
            return false;
        case _0xdefea0608c5f(81498):
            _0x6671ba2abcb7(_0x2da39f0104f9(_0x611dc6ab4f48));
            return true;
        case _0xdefea0608c5f(81705):
            _0x6671ba2abcb7(_0x0b5423657bfa());
            return true;
        case _0xdefea0608c5f(81576):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x027d5d591ef3(() => _0xcf6350c5ebaa(_0xdb9b61530b2c.rows, _0xdb9b61530b2c.orderIntervalSeconds))));
            return true;
        case _0xdefea0608c5f(81655):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x027d5d591ef3(() => _0x7093abf1afb8(_0xdb9b61530b2c.rows, _0xdb9b61530b2c.orderIntervalSeconds))));
            return true;
        case _0xdefea0608c5f(81649):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x027d5d591ef3(() => _0x743223291167(_0xdb9b61530b2c.rows))));
            return true;
        case _0xdefea0608c5f(81505):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x027d5d591ef3(_0x2e7b6c2f5294)));
            return true;
        case _0xdefea0608c5f(81619):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x027d5d591ef3(_0x20d185186264)));
            return true;
        case _0xdefea0608c5f(81592):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x027d5d591ef3(() => _0x4b31fefa9b92(_0xdb9b61530b2c.settings))));
            return true;
        case _0xdefea0608c5f(81636):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x027d5d591ef3(_0x3f33643ee2e1)));
            return true;
        case _0xdefea0608c5f(81535):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x027d5d591ef3(_0x505f9612954c)));
            return true;
        case _0xdefea0608c5f(81711):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x12dde956a5c6(_0xdb9b61530b2c, _0x611dc6ab4f48)));
            return true;
        case _0xdefea0608c5f(81493):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x6f108d2d014b(_0xdb9b61530b2c, _0x611dc6ab4f48)));
            return true;
        case _0xdefea0608c5f(81558):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x027d5d591ef3(() => _0x2b9ed8d0d4b2(_0xdb9b61530b2c, _0x611dc6ab4f48))));
            return true;
        case _0xdefea0608c5f(81614):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x7082b938ce44(_0xdb9b61530b2c, _0x611dc6ab4f48)));
            return true;
        case _0xdefea0608c5f(81663):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x027d5d591ef3(() => _0x6992bb16794b(_0xdb9b61530b2c, _0x611dc6ab4f48, false))));
            return true;
        case _0xdefea0608c5f(81479):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x027d5d591ef3(() => _0xeb186be09c75(_0xdb9b61530b2c, _0x611dc6ab4f48))));
            return true;
        case _0xdefea0608c5f(81687):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x027d5d591ef3(() => _0x1c603ed5aaab(_0xdb9b61530b2c, _0x611dc6ab4f48))));
            return true;
        case _0xdefea0608c5f(81675):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x027d5d591ef3(() => _0xf95408f11bb4(_0xdb9b61530b2c, _0x611dc6ab4f48))));
            return true;
        case _0xdefea0608c5f(81506):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x027d5d591ef3(() => _0x3a28df1ab53f(_0xdb9b61530b2c, _0x611dc6ab4f48))));
            return true;
        case _0xdefea0608c5f(81618):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x027d5d591ef3(() => _0x67d91b8683fb(_0xdb9b61530b2c, _0x611dc6ab4f48))));
            return true;
        case _0xdefea0608c5f(81701):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x027d5d591ef3(() => _0xfbb8ac325fa9(_0xdb9b61530b2c, _0x611dc6ab4f48))));
            return true;
        case _0xdefea0608c5f(81571):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0xddad7a8e1084(_0xdb9b61530b2c, _0x611dc6ab4f48)));
            return true;
        case _0xdefea0608c5f(81692):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x027d5d591ef3(_0xde570de9fcda)));
            return true;
        case _0xdefea0608c5f(81607):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x027d5d591ef3(_0x139c22549462)));
            return true;
        case _0xdefea0608c5f(81539):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x027d5d591ef3(_0xd52f12ba28e9)));
            return true;
        case _0xdefea0608c5f(81591):
            _0x6671ba2abcb7(_0x786d61cb9e1a(() => _0x027d5d591ef3(() => _0x6992bb16794b({ reason: _0xdefea0608c5f(81457) }, null, true))));
            return true;
        case _0xdefea0608c5f(81682):
            _0x6671ba2abcb7(_0x027d5d591ef3(() => chrome.storage.local
                .get(_0x3e8163af073e.RUN_STATE)
                .then((_0x93c95ce49e77) => _0x1ac813b83bad(_0x93c95ce49e77[_0x3e8163af073e.RUN_STATE]?.workTabId))
                .then(() => ({ ok: true }))));
            return true;
        default:
            return false;
    }
});
chrome.tabs.onRemoved.addListener((_0x080ec5ada5d0) => {
    _0x786d61cb9e1a(async () => {
        const _0x04aa74561346 = await _0x4d5b02696d67();
        const _0x2ff8021ed0c2 = _0x04aa74561346[_0x3e8163af073e.RUN_STATE];
        if (!_0x2ff8021ed0c2 || _0x080ec5ada5d0 !== _0x2ff8021ed0c2.workTabId || !_0x80ae694037f0.has(_0x2ff8021ed0c2.mode)) {
            return;
        }
        const _0x57ccbb31c565 = Array.isArray(_0x04aa74561346[_0x3e8163af073e.LOGS]) ? _0x04aa74561346[_0x3e8163af073e.LOGS] : [];
        const _0x64a45f7afd5d = _0xd95c33d75b28(_0x2ff8021ed0c2);
        const _0xa9c6ffa9c18d = _0x7099183f8138(_0x2ff8021ed0c2);
        const _0x26034753c437 = _0x04aa74561346[_0x3e8163af073e.CART_LOCK] || null;
        _0x2ff8021ed0c2.workTabId = null;
        _0x2ff8021ed0c2.updatedAt = new Date().toISOString();
        if (_0x2ff8021ed0c2.phase === _0xdefea0608c5f(81578) && _0x2ff8021ed0c2.mode === _0xdefea0608c5f(81512)) {
            _0x9ed268225a55(_0x57ccbb31c565, _0xdefea0608c5f(81461), _0xdefea0608c5f(81596), _0xa9c6ffa9c18d?.rowNumber ?? null);
            await _0xe0f1516d2a85(_0x2ff8021ed0c2, _0x57ccbb31c565);
            return;
        }
        _0x2ff8021ed0c2.mode = _0xdefea0608c5f(81504);
        _0x2ff8021ed0c2.pauseReason = _0x4c9bde331c2e(_0x26034753c437, _0x2ff8021ed0c2, _0x64a45f7afd5d)
            ? _0xdefea0608c5f(81665) : _0xdefea0608c5f(81625);
        if (_0x64a45f7afd5d?.isCombined) {
            _0xef306e091ba6(_0x2ff8021ed0c2.rows, _0x64a45f7afd5d, _0x2ff8021ed0c2.pauseReason);
        }
        else if (_0xa9c6ffa9c18d) {
            _0x6c4eec96f923(_0xa9c6ffa9c18d, `等待人工检查：${_0x2ff8021ed0c2.pauseReason}`, _0xdefea0608c5f(81564));
        }
        _0x9ed268225a55(_0x57ccbb31c565, _0xdefea0608c5f(81662), _0x2ff8021ed0c2.pauseReason, _0xa9c6ffa9c18d?.rowNumber ?? null);
        await _0xe0f1516d2a85(_0x2ff8021ed0c2, _0x57ccbb31c565);
    }).catch((_0x3a4db3bb9b83) => console.error(_0x3a4db3bb9b83));
});})();
