(()=>{'use strict';const _0x03b03563cdb5=Object.freeze(["39zUnsHcxJ7dxt7R1sE=","1t7Dx8qe0Nbf3w==","x9bLx5zQwMWI0NvSwcDWx47Gx9Weiw==","39zUnt/Wxdbf","VQESVS86VjwcVhwPVjQJVCk3VgQWVw4vWx0DVg4mUDMx","VgQWVw4vVSQWVgwkVgQBVQs2VBoJUDMx","WwwjWxI/Vwse","wNvaw/Dax8o=","VTogVg8zViY1ViAyWhIGVgoFWxw1VjsYVws4Vj4mVRsSVi4k","9sbB3MPWnPHWwd/a3Q==","0t7J/MHX1sH72sDH3MHK","VSkxVSQTVgQWVw4vWx0DVg4m","39zQ0t8=","kMHW3tzF1vHf0t3Y8cfd","2t3Dxsfo19LH0p7V2tbf1+4=","/OP2/ezk/OH47Ofy8Q==","w9zAx9Lfk9Dc19Y=","VRMLVhwKVTMIVSYDWjQ8VgoFk+PB3NDW1teTx9yT8NvW0Njcxsc=","VBIdVh0pVQs2VBoJVwg5VhcaVgQBVTsjVjksWz0EVjwlk/zB19bBk/r3k1QpN5Pn1t7Gk/zB19bBk/r3k1orAVo0PlYXPlsdA1YOJlYjJFwPLLm5VQs2VBoJViM9XA8/WwwqVwkok+fW3saT/MHX1sGT+veTVwg5VhcaVjwcVwgWVjU+VR8SVws4Vj4mUDMxVgQWVw4vWx0DVg4mUDMyWw0gVjYWVSYDVT4dViE/VgQWVw4vVSQWVgwkVws+Vw8pWxEYVQs2WioXUDMx","VB46Vg02Vws4VwszVj4mVws4Vj4mWiQHWikn","0t7J/MHX1sH/3NTA","0g==","wsbS3cfax8qTx9yTwNvaww==","kNDGwcHW3cfj29LA1g==","wNjaw8PW1w==","VgQWVw4vWx0DVg4mVgQBVhc+VjsFUDMx","8P/28uHs8PLh5+zx5vr/9/r99Oz//PD4","0t7J/MHX1sHhxt3gx9LH1g==","w9LGwNbX","VS8ZVCwW","VAg3ViM7Vj4mWhE3VRAzVSwWVjo+VBIdWx0XWwceVDoaVBwdVwsJVBoJ","WjM6VTgaVAENVjQ1WwceVwoDVSYDWjQ8","VTozVS86k8HWwMbfx47A2NrDw9bXk1QpN1sSP1owDlcPKVo0PlUlA1cLOFY+JlwPP1Y/NlU4H1EzL+fW3saT/MHX1sGT+vdWDiBWFxpWBAFXCzhbDDRWPiZRMy5WIT9RMy9XCQlWBBZbBABbDDRcDztbHRFWPiZUCCBVLS9VLxlUEh1bHRdcDzpRMy5QMzE=","gZ7X2tTaxw==","VR4QVg88VjkTWwceVjo+VjU+VR8SVBIdWx0XWwceVDoaVBwdVwsJVBoJ","UTMn","VB46Vg02Vws4Vj4mVTsjVjksWhIGWi4R","19rF","4fbl8v/69/Ln9uzy5uf7/OH66fLn+vz9","wdbQ2sPa1t3H/dLe1g==","Vg4gVjo+Wx0RVj4mVjwcWzAOVgQBVAg8VTwjVwkXVw41VgMpVS8ZVjwlVg0kk/zB19bBk/r3UDMxWwQAWww0ViM9Vws+Vw8pVjUqVjYWVg4gVhcaVws4Vj4mWx0DVg4mXA8/WjQ+VSUDWwwjWxI/VCgLViM/k+fW3saT/MHX1sGT+veTVjwcWzAOWjMTVTsjWjQ+Vhc+Vws4Vj4mUDMxVBIdVh0pWwQAWww0Vg4gVjo+WxI/ViMkXA8s","kQ==","0cbHx9zdn5Pa3cPGxw==","Vg4gVjo+Wx0RVj4mVjwcWzAOVgQBVAg8VTwjVwkXVw41VgMpVS8ZVjwlVg0kk/zB19bBk/r3UDMxVjIvVR4RViM9Vws+Vw8pVjUqVjYWVg4gVhcaVws4Vj4mWx0DVg4mXA8/WjQ+VSUDWwwjWxI/VjwcWzAOWjMTVTsjWjQ+Vhc+Vws4Vj4mUDMxVBIdVh0pVjIvVR4RVjYbWjAbVwgIVjkSViMkXA8s","kMHWxdLf2tfSx9byxsfb3MHaydLH2tzd8cfd","8uD6/Q==","VgQWVw4vVAggVS0v","Vg4gVjo+WxI/VgQBWwQAWww0UDMx","Vg4gVjo+VgQWVw4vWx0DVg4mVwseVQESVS86VjwcWjQ+Vws4VCk3WwQAWww0WxI/UDMx","VRMLVhwKVwgrVR8NWhIGVScFVwgFVwkJVhQgViM+","VgQBVSkxVjIv","VgQBVjwlVg0kk/zB19bBk/r3k1QpN1U7I1Y5LFsSP1cLPlcPKVo0PlcLOFAzMVUeF1UgPlcOL1Y8HFswDlozE1U7I1o0PlYXPlsdEVY+JlwPP1scBFQSHVsdF1YEAVcJCVYEFlUQM1UsFlAzMQ==","WhE3VRAzVSwWVjwiVD0DVjUBVBkyXA8/VwgIVjkSVgQBVSkxVjIvVB46Vg02VwkJVgQWVhc3VCM1UDMx","kNDf1tLB+t3Dxsfxx90=","vrk=","4Pj64+zw5uHh9v3n7P7y/eby/w==","Vwg2Vi8bVTEbVgQBVAg8VwkJVgQWVRAzVSwWk/Le0snc3ZNVBwhWORtbBx5UOhpUHB1WIT9VLzNbDCJbHRFWPiZWIz1VOj5bMA5VCzZaKhdQMzG5uVULNloqF1YjPVwPP1YOIFY6PlQIN1YjO1Y+JlcICFY5ElcPKVcMLlU/MlYyL1UeEVQ5BVUzMlwPKFscFlU/OlohHVcLPlcPKVY7E1oqF1sHHlQ6GlQcHVYmNVYgMlwPP1cKLFcLPlcPKVY1KlY2FpP8wdfWwZP691AzMVQSHVYdKVULNloqF5Pw8uHn7PHm+v/3+v30k1QIN1YjO1Y+JlonMlYjJFwPLA==","kNDc3cfa3cbW8cfd","wNvaw5PD3MDH0t+T0NzX1g==","59bexpP8wdfWwZP69w==","VRMLVhwKVB8fVwszVg8TWx0RVj4mVj4SVDo0VhQgViM+ViE/VSUDk/zB19bBk/r3","29rX19bd","WjM6VTgak/Le1sHa0NLdk/bLw8HWwMCT1t3X2t3Uk9rdk4KDg4o=","VgQWVw4vWx0DVg4mVwseVQESVS86VjwcVhc+VjsFVCk3k/zB19bBk/r3UDMx","VBIdVh0pVQs2VBoJVgQWVw4vVSQWVgwkViMkXA8sVgQWVw4vWx0DVg4mViE/Vg4gVhcaVTsjVjksVws4Vj4mWisBWjQ+Vhc+Wx0DVg4mVws+Vw8pWxEYVjsTWioXUDMx","VBIdVh0pVQs2VBoJWw0gVjYWWxIbVRMPViE/Vg4gVjo+VgQBVAggVS4sVwgIVjkSVCk3VgQWVw4vWx0DVg4mViMkXA8sVg4gVhcaVTsjVjksVws4Vj4mWisBWjQ+Vhc+Wx0DVg4mVws+Vw8pWxEYVjsTWioXUDMx","4Ofy4efs4eb9","0Nzew9/Wx9bX","VgQBVh0/VTsj","kN/c1PDc3cfS2t3WwQ==","kNDf1tLB8NLBx//c0Njxx90=","39zUnt7WwMDS1NY=","x9bexvzB19bB+tc=","0N/a0Ng=","VigtWxwIVgoFVRMLVhwKWwceVwoDVSYDWjQ8","kMPSxsDW4dbSwNzd","kNLGx9vcwdrJ0sfa3N310trfxsHW8dLB","VRAzVSwWViY1ViAyViMYVBs9Vj4mVwgEk1ExH4Gdg4M=","wdbQ3MHXnsDG0NDWwMA=","VB46Vg02Vws4Vj4mVTslVwgrVR8NWjM6VTgaWhIGWi4R","0NvS3dTW","kNDf1tLB59zX0sr8wdfWwcDxx90=","wdbQ3MHXnsTSwd3a3dQ=","3NHZ1tDH","5PL65+z6/ef24eXy/w==","wNvaw5PQ2sfK","ug==","VwgIVjkSVAgUVAgeVToUWxI/UDMx","kMfc0sDH","4Of84+zh5v0=","kNbLw9zBx+HW0NzB18DwwMXxx90=","VB46Vg02VS8zVAg7VwgrVR8NWhIGWi4R","Vjs0VT4RVwse","5PL65+z84ff24ez7+uDn/OHq","8ubn+/zh+uny5/r8/ezw+/L99Pb3","VB46Vg02Vi8DVi4zWhk/WxwyVAggVS0v","4fbn4ers4Pj64+P29+zh5v0=","wdbQ3MHXntbBwdzB","0tfXwdbAwA==","8P/28uHs//z04A==","VBIdWx0Xk/LX19bXk8fck9HSwNjWx5NXCz1UBxxbHRJVJgNaNDw=","Vjs0VT4RVjsDVws4VwszVS4SVSYDVT4d","1sHB3ME=","Ww0gVjYWVSYDVT4dVgQBVQs2VBoJXA8oVg4gVhcaVTsjVjksVws4Vj4mWisBWjQ+Vhc+Wx0DVg4mVwg+VwwuVCYqUDMx","VB46Vg02VSUDVggJVi8DVi4zVBkkVjwQ","3cbe1sHa0A==","wdbQ2sPa1t3Hk93S3tY=","4/Lm4Pbs4eb9","kw==","5PL65+z84ff24ezg5vDw9uDg","VB46Vg02VwkJVgQWWjM6VTgaVT0bWz4jVi8DVi4z","0sbH29zB2snSx9rc3Q==","wsbS3cfax8rn3ODb2sM=","VgQBVjIvVR4R","vg==","0t7J/MHX1sH3wdLVx+HcxMA=","wMPS3Q==","kMDY2sPxx90=","kNDGwcHW3cfh3MQ=","VwgIVjkSVh0/VTsj","WjQ+Vws4VwgIVjkSWhE3VRAzVSwWVjwiVD0DVjUBVBkyXA8/VgQBVSkxVjIvVB46Vg02VwkJVgQWVhc3VCM1UDMx","uQ==","kNDcw8r8wdfWwfrXwPHH3Q==","kMHWx8HK4Njaw8PW1/HH3Q==","39zUntbew8fK","kMHG3f7c19Y=","x9c=","kZE=","8Pz99frh/uzj8ur+9v3n7P725/v89w==","Vg4gVjo+Vh4rVi8bk/Dy4efs8eb6//f6/fSTVAg3ViM7Vj4mVh06VjYbWicyUDMxVjIvVR4RVwgIVjkSViM9WicyVwg+Vw8pVwwuVCYqXA8/Vgw2WhIIVjY7VwkJVgQWVRAzVSwWWwceVDoaVBwdViE/VS8zWwwiWx0RVj4mXA8/VjU+Vw4MVCcbUTMvVBIdWx0XVgQBVwkJVgQWVRAzVSwWVgoFVQs2WioXVAg3ViM7Vj4mWicyUTMuUDMxVBIdVh0pVjIvVR4RVjYbWjAbVwgIVjkSViMkXA8s","wMbQ0NbAwA==","VSkxVSQTVSQWVgwk","w9vc3daT3cbe0dbB","39zUnsHcxA==","VgQWVw4vVSQWVgwkVgQBVhc+VjsFUDMx","1t2e9PE=","VB46Vg02Vi8DVi4zWjM6VTgaWhIGWi4RVjkTWw4O","x8HS3cDax9rc3drd1A==","9Pbn7PL//+z38ufy","kNDcw8r/3NTxx90=","VwgIVjkSVgQBVSkxVjIvUDMx","w9bd19rd1A==","8ubn++z18vr/9vc=","Vg4gVjo+VQESVS86VAg3ViM7Vj4mVh06VjYbWicyUDMx","4PLl9uz34fL15+zh/OTg","kMDH3MPxx90=","wcbd3drd1A==","w9LAx9Y=","8Pz95/r95vbs4eb9","VRw8Vj4mVws4Vj4mVSQFWiQHWiQHWiknVgw2WhIIVSsck4NRMyCAhYODk1QpN1UmB1UmA1QUIVAzMQ==","kNDf1tLB/9zU8cfd","wNvaw+PcwMfS3/Dc19Y=","0sbH29zB2snW1w==","Ww0gVjYWWhE3VRAzVSwWVjUBVBkyXA8/VB46Vg02VwkJVgQWVhc3VCM1","wNvaw5PS19fB1sDA","","1dLa39bX","VQESVS86VjwcVhc3VCM1VCk3VSYDVT4dWxI/UDMx","VRMSWhk/VhcCWwcWXA8/WxwEWzInVAAI4NvS3dTS3Q==","w9vc3db9xt7R1sE=","0tfXwdbAwIE=","2t3V3A==","x9bLx5zD39La3Q==","VwgIVjkSVgQBVjIvVR4R","kMHW0NzB18Dn0tHf1vHc18o=","VwgIVjkSVgQBVg8zVhQ4UDMx","4PLl9uzg9ufn+v304A==","39zUnsfa3tY=","kNrdw8bH59LR39bx3NfK","0sHa0p7f0tHW3w==","WjMjWxI/WhE3VRAzVSwWVAg3ViM7Vj4mViY1ViAy","VS8ZVg8zVhQ4","8P/28uHs9+Hy9efs4fzk4A==","0t7J/MHX1sHg1sfH2t3UwA==","kMPSxsDW8cfd","wMfcw8PW1w==","x9bLxw==","kMDH0sHH8cfd","0d/c0NjW1w==","VwgIVjkSVgQBVjIvVR4RUDMx","kNDcw8rh1tDcwdfA8cfd","WjMjWxI/VR4QVg88VjkTVjYWWwceVDoaVBwd","kNDf3MDW5Nrd19zE8cfd","x8E=","0NrHyg==","wNvaw/LX18HWwMA=","8P/28uHs5/z38urs/OH39uHs4fbw/OH34A==","0t7J8NLBx/HG2t/X2t3U/9zQ2A==","3NXV","2t3DxseewdzEnt3G3tHWwQ==","24GA","VDEKVjQIVi8DVi4zVRsSVi4kk/Db0t3U1g==","kNzD1t3n0tHxx90=","Vwg5Vhca","kNLX1+HcxMDxx90=","8v7pk9/a3dg=","0t7J/9rd2A==","iA==","VBIdWx0XVwgrVR8NVSUKVg88VgoFWwwoVjYWVS8zVAg7k/HGypPd3MQ=","kNzB19bB+t3H1sHF0t/g1tDc3dfA","VAg3ViM7Vj4mVh06VjYbWicyVgQBVQs2WioXUDMx","2t3Dxsc="]),_0xa169e34fbbd5=[];if(((_0x03b03563cdb5.length^179^50586^17944)>>>0)!==33787){throw new Error('Integrity error');}function _0x0e490fe6dc37(_0xi){const _0xn=((_0xi-17944)^50586);if(_0xa169e34fbbd5[_0xn]!==undefined)return _0xa169e34fbbd5[_0xn];const _0xb=atob(_0x03b03563cdb5[_0xn]),_0xu=new Uint8Array(_0xb.length);for(let _0xj=0;_0xj<_0xb.length;_0xj++)_0xu[_0xj]=_0xb.charCodeAt(_0xj)^179;return _0xa169e34fbbd5[_0xn]=new TextDecoder().decode(_0xu);} const _0x925584c80755 = Object.freeze({
    RUN_STATE: _0x0e490fe6dc37(68505),
    HISTORY: _0x0e490fe6dc37(68520),
    LOGS: _0x0e490fe6dc37(68518),
    DRAFT_ROWS: _0x0e490fe6dc37(68609),
    SETTINGS: _0x0e490fe6dc37(68431),
    CART_LOCK: _0x0e490fe6dc37(68409)
});
const _0x9bb4d717af41 = Object.freeze([
    { key: _0x0e490fe6dc37(68586), label: _0x0e490fe6dc37(68537) },
    { key: _0x0e490fe6dc37(68470), label: _0x0e490fe6dc37(68465) },
    { key: _0x0e490fe6dc37(68610), label: _0x0e490fe6dc37(68516) },
    { key: _0x0e490fe6dc37(68565), label: _0x0e490fe6dc37(68616) },
    { key: _0x0e490fe6dc37(68381), label: _0x0e490fe6dc37(68406) },
    { key: _0x0e490fe6dc37(68411), label: _0x0e490fe6dc37(68376) },
    { key: _0x0e490fe6dc37(68434), label: _0x0e490fe6dc37(68434) },
    { key: _0x0e490fe6dc37(68533), label: _0x0e490fe6dc37(68583) },
    { key: _0x0e490fe6dc37(68389), label: _0x0e490fe6dc37(68536) }
]);
const _0xe5042edae8a3 = new Set([_0x0e490fe6dc37(68384), _0x0e490fe6dc37(68510), _0x0e490fe6dc37(68395)]);
const _0x06ccb6bdd334 = _0x0e490fe6dc37(68380);
const _0x2ba928a464d6 = Object.freeze({
    PRECHECK_CONFLICT: _0x0e490fe6dc37(68379),
    CHECK_CART_BEFORE_PRECHECK: _0x0e490fe6dc37(68508),
    GROUP_PRECHECK_PRODUCT: _0x0e490fe6dc37(68424),
    CHECK_CART_BEFORE_BUILD: _0x0e490fe6dc37(68560),
    GROUP_ADD_PRODUCT: _0x0e490fe6dc37(68423),
    WAIT_GROUP_ADD_RESULT: _0x0e490fe6dc37(68630),
    GROUP_PROCEED_CHECKOUT: _0x0e490fe6dc37(68515),
    WAIT_PRODUCT: _0x0e490fe6dc37(68522),
    VERIFY_PRODUCT_PRICE: _0x0e490fe6dc37(68591),
    SELECT_QUANTITY: _0x0e490fe6dc37(68509),
    VERIFY_QUANTITY: _0x0e490fe6dc37(68584),
    WAIT_CHECKOUT: _0x0e490fe6dc37(68589),
    SELECT_PAYMENT_CARD: _0x0e490fe6dc37(68540),
    WAIT_CHANGE_ADDRESS: _0x0e490fe6dc37(68413),
    WAIT_ADD_ADDRESS_AFTER_CHANGE: _0x0e490fe6dc37(68394),
    WAIT_ADDRESS_FORM: _0x0e490fe6dc37(68618),
    WAIT_ADDRESS_RESULT: _0x0e490fe6dc37(68573),
    WAIT_MANUAL_ADDRESS: _0x0e490fe6dc37(68620),
    WAIT_PAYMENT: _0x0e490fe6dc37(68569),
    [_0x0e490fe6dc37(68402)]: _0x0e490fe6dc37(68468),
    VERIFY_PAYMENT_NAME: _0x0e490fe6dc37(68547),
    WAIT_ORDER_SUCCESS: _0x0e490fe6dc37(68566),
    WAIT_ORDER_HISTORY: _0x0e490fe6dc37(68542),
    TRANSITIONING: _0x0e490fe6dc37(68631),
    WAIT_INTERVAL: _0x0e490fe6dc37(68513),
    COMPLETED: _0x0e490fe6dc37(68613),
    STOPPED: _0x0e490fe6dc37(68433)
});
const _0x473e75913c77 = Object.freeze({
    running: _0x0e490fe6dc37(68532),
    paused: _0x0e490fe6dc37(68544),
    transitioning: _0x0e490fe6dc37(68574),
    completed: _0x0e490fe6dc37(68598),
    stopped: _0x0e490fe6dc37(68611)
});
let _0xcdb4e378d26c = [];
let _0x87271d686b8f = null;
let _0x33fc584411c8 = [];
let _0xb044acebd3e6 = { orderIntervalSeconds: 30 };
let _0x14e6dfe6c7b0 = null;
let _0xa151b934fa07 = null;
let _0xc8bcb210a9ab = null;
let _0x14ba3e35aac3 = _0x0e490fe6dc37(68399);
let _0xb1e5c932907f = false;
const _0xc4b167c7218c = {
    runMode: document.querySelector(_0x0e490fe6dc37(68607)),
    currentRow: document.querySelector(_0x0e490fe6dc37(68612)),
    currentPhase: document.querySelector(_0x0e490fe6dc37(68517)),
    pauseReason: document.querySelector(_0x0e490fe6dc37(68585)),
    authorizationFailureBar: document.querySelector(_0x0e490fe6dc37(68590)),
    revalidateAuthorizationBtn: document.querySelector(_0x0e490fe6dc37(68558)),
    closeWindowBtn: document.querySelector(_0x0e490fe6dc37(68420)),
    startBtn: document.querySelector(_0x0e490fe6dc37(68419)),
    retrySkippedBtn: document.querySelector(_0x0e490fe6dc37(68601)),
    pauseBtn: document.querySelector(_0x0e490fe6dc37(68428)),
    continueBtn: document.querySelector(_0x0e490fe6dc37(68539)),
    skipBtn: document.querySelector(_0x0e490fe6dc37(68615)),
    stopBtn: document.querySelector(_0x0e490fe6dc37(68387)),
    openTabBtn: document.querySelector(_0x0e490fe6dc37(68466)),
    orderIntervalSeconds: document.querySelector(_0x0e490fe6dc37(68469)),
    clearTodayOrdersBtn: document.querySelector(_0x0e490fe6dc37(68579)),
    clearCartLockBtn: document.querySelector(_0x0e490fe6dc37(68596)),
    addRowsBtn: document.querySelector(_0x0e490fe6dc37(68464)),
    removeBlankBtn: document.querySelector(_0x0e490fe6dc37(68527)),
    clearInputBtn: document.querySelector(_0x0e490fe6dc37(68551)),
    copyOrderIdsBtn: document.querySelector(_0x0e490fe6dc37(68600)),
    exportRecordsCsvBtn: document.querySelector(_0x0e490fe6dc37(68568)),
    copyRecordsBtn: document.querySelector(_0x0e490fe6dc37(68422)),
    copyLogBtn: document.querySelector(_0x0e490fe6dc37(68393)),
    clearLogBtn: document.querySelector(_0x0e490fe6dc37(68388)),
    inputTableBody: document.querySelector(_0x0e490fe6dc37(68426)),
    recordsTableBody: document.querySelector(_0x0e490fe6dc37(68438)),
    logContainer: document.querySelector(_0x0e490fe6dc37(68599)),
    toast: document.querySelector(_0x0e490fe6dc37(68570))
};
function _0x9e08f285000a() {
    return crypto.randomUUID();
}
function _0x1db43332ef02() {
    return {
        _rowId: _0x9e08f285000a(),
        ...Object.fromEntries(_0x9bb4d717af41.map(({ key: _0x1789043e4a19 }) => [_0x1789043e4a19, _0x0e490fe6dc37(68377)]))
    };
}
function _0xcd0b1eb3e16a(_0x585a7a7043f1) {
    const _0xb8d967851359 = _0x585a7a7043f1 && typeof _0x585a7a7043f1 === _0x0e490fe6dc37(68577) ? _0x585a7a7043f1 : {};
    const _0x5a6cb7c8278c = String(_0xb8d967851359._rowId || _0xb8d967851359.draftRowId || _0x0e490fe6dc37(68377)).trim() || _0x9e08f285000a();
    return {
        _rowId: _0x5a6cb7c8278c,
        ...Object.fromEntries(_0x9bb4d717af41.map(({ key: _0xe74a320bb54a }) => [_0xe74a320bb54a, String(_0xb8d967851359[_0xe74a320bb54a] ?? _0x0e490fe6dc37(68377))]))
    };
}
function _0xd35dcbdcd385(_0x7bc21b7390e0, _0xf8c2b931ec0a = 12) {
    const _0xe9bbe391aacc = _0x7bc21b7390e0.map(_0xcd0b1eb3e16a);
    while (_0xe9bbe391aacc.length < _0xf8c2b931ec0a) {
        _0xe9bbe391aacc.push(_0x1db43332ef02());
    }
    return _0xe9bbe391aacc;
}
function _0x11e84734eff6(_0xe467cf764fc9) {
    return _0x9bb4d717af41.every(({ key: _0xefba62481cb5 }) => String(_0xe467cf764fc9?.[_0xefba62481cb5] ?? _0x0e490fe6dc37(68377)).trim() === _0x0e490fe6dc37(68377));
}
function _0xbfcde6d57529(_0xb6eb30f7f40d, _0xf39e8a35aa35 = false) {
    clearTimeout(_0xc8bcb210a9ab);
    _0xc4b167c7218c.toast.textContent = _0xb6eb30f7f40d;
    _0xc4b167c7218c.toast.classList.toggle(_0x0e490fe6dc37(68628), _0xf39e8a35aa35);
    _0xc4b167c7218c.toast.classList.remove(_0x0e490fe6dc37(68543));
    _0xc8bcb210a9ab = setTimeout(() => _0xc4b167c7218c.toast.classList.add(_0x0e490fe6dc37(68543)), 4000);
}
function _0xe5537930e2be(_0x9f4636d8f481, _0xad0ec4aa7968 = true) {
    if (_0x9f4636d8f481?.[_0x0e490fe6dc37(68378)]) {
        _0x14ba3e35aac3 = _0x0e490fe6dc37(68378);
        _0xb1e5c932907f = false;
        _0xc4b167c7218c.authorizationFailureBar.classList.add(_0x0e490fe6dc37(68543));
        _0xd595cbd22506();
        return;
    }
    _0x14ba3e35aac3 = _0x0e490fe6dc37(68382);
    _0xc4b167c7218c.authorizationFailureBar.classList.remove(_0x0e490fe6dc37(68543));
    _0xd595cbd22506();
    if (_0xad0ec4aa7968 && !_0xb1e5c932907f) {
        _0xb1e5c932907f = true;
        window.alert(_0x06ccb6bdd334);
    }
}
function _0x515e6d3ccc7b(_0x8f432da0c1d5) {
    return Boolean(_0x8f432da0c1d5?.code === _0x0e490fe6dc37(68396) ||
        _0x8f432da0c1d5?.[_0x0e490fe6dc37(68621)]?.[_0x0e490fe6dc37(68378)] === false);
}
async function _0x2509c9f74433(_0x54a552b31389, _0x8c96d0a84f3d = {}) {
    try {
        const _0x65407805dceb = await chrome.runtime.sendMessage({ type: _0x54a552b31389, ..._0x8c96d0a84f3d });
        if (_0x65407805dceb?.[_0x0e490fe6dc37(68621)]) {
            _0xe5537930e2be(_0x65407805dceb[_0x0e490fe6dc37(68621)], true);
        }
        if (_0x515e6d3ccc7b(_0x65407805dceb)) {
            _0xe5537930e2be(_0x65407805dceb[_0x0e490fe6dc37(68621)] || { [_0x0e490fe6dc37(68378)]: false }, true);
            return _0x65407805dceb;
        }
        if (!_0x65407805dceb?.ok && _0x65407805dceb?.error) {
            _0xbfcde6d57529(_0x65407805dceb.error, true);
        }
        return _0x65407805dceb;
    }
    catch (_0x0a051741f9f6) {
        _0xbfcde6d57529(_0x0a051741f9f6.message || String(_0x0a051741f9f6), true);
        return { ok: false, error: _0x0a051741f9f6.message || String(_0x0a051741f9f6) };
    }
}
function _0x277ef4322b11() {
    _0xc4b167c7218c.inputTableBody.replaceChildren();
    const _0x12480ebbc134 = document.createDocumentFragment();
    _0xcdb4e378d26c.forEach((_0x0abeafaf04a8, _0x982e74fdfaf7) => {
        const _0x92b05400c3b4 = document.createElement(_0x0e490fe6dc37(68421));
        const _0x93c6c2c518a0 = document.createElement(_0x0e490fe6dc37(68604));
        _0x93c6c2c518a0.className = _0x0e490fe6dc37(68415);
        _0x93c6c2c518a0.textContent = String(_0x982e74fdfaf7 + 1);
        _0x92b05400c3b4.appendChild(_0x93c6c2c518a0);
        _0x9bb4d717af41.forEach(({ key: _0x8c22564f1b9f, label: _0x9605ce340c9b }, _0x5cd62856f10a) => {
            const _0x2736bab4576d = document.createElement(_0x0e490fe6dc37(68604));
            const _0x6ea28a933296 = document.createElement(_0x0e490fe6dc37(68459));
            _0x6ea28a933296.type = _0x0e490fe6dc37(68418);
            _0x6ea28a933296.value = String(_0x0abeafaf04a8[_0x8c22564f1b9f] ?? _0x0e490fe6dc37(68377));
            _0x6ea28a933296.autocomplete = _0x0e490fe6dc37(68414);
            _0x6ea28a933296.spellcheck = false;
            _0x6ea28a933296.setAttribute(_0x0e490fe6dc37(68427), `${_0x9605ce340c9b}，第 ${_0x982e74fdfaf7 + 1} 行`);
            _0x6ea28a933296.dataset.rowIndex = String(_0x982e74fdfaf7);
            _0x6ea28a933296.dataset.columnIndex = String(_0x5cd62856f10a);
            _0x6ea28a933296.dataset.field = _0x8c22564f1b9f;
            _0x6ea28a933296.addEventListener(_0x0e490fe6dc37(68459), () => {
                _0xcdb4e378d26c[_0x982e74fdfaf7][_0x8c22564f1b9f] = _0x6ea28a933296.value;
                _0x7c769fc901d1();
            });
            _0x6ea28a933296.addEventListener(_0x0e490fe6dc37(68385), (_0xa9cfd0e15713) => {
                const _0xf54c0caaaa9b = _0xa9cfd0e15713.clipboardData?.getData(_0x0e490fe6dc37(68432)) || _0x0e490fe6dc37(68377);
                if (!_0xf54c0caaaa9b.includes(_0x0e490fe6dc37(68580)) && !/[\r\n]/.test(_0xf54c0caaaa9b)) {
                    return;
                }
                _0xa9cfd0e15713.preventDefault();
                _0x4ca42aa0f3aa(_0x982e74fdfaf7, _0x5cd62856f10a, _0xf54c0caaaa9b);
            });
            _0x2736bab4576d.appendChild(_0x6ea28a933296);
            _0x92b05400c3b4.appendChild(_0x2736bab4576d);
        });
        _0x12480ebbc134.appendChild(_0x92b05400c3b4);
    });
    _0xc4b167c7218c.inputTableBody.appendChild(_0x12480ebbc134);
    _0xd595cbd22506();
}
function _0x49a713ea131d(_0xa46f713a9bfa) {
    const _0x1116c170e7bf = [];
    let _0x0799b097cda8 = [];
    let _0x8864a9ccc588 = _0x0e490fe6dc37(68377);
    let _0xa609d5a67b78 = false;
    for (let _0x5828e8bf770c = 0; _0x5828e8bf770c < _0xa46f713a9bfa.length; _0x5828e8bf770c += 1) {
        const _0xcd855ac6dcd2 = _0xa46f713a9bfa[_0x5828e8bf770c];
        const _0x228553dc5df1 = _0xa46f713a9bfa[_0x5828e8bf770c + 1];
        if (_0xcd855ac6dcd2 === _0x0e490fe6dc37(68555)) {
            if (_0xa609d5a67b78 && _0x228553dc5df1 === _0x0e490fe6dc37(68555)) {
                _0x8864a9ccc588 += _0x0e490fe6dc37(68555);
                _0x5828e8bf770c += 1;
            }
            else {
                _0xa609d5a67b78 = !_0xa609d5a67b78;
            }
            continue;
        }
        if (!_0xa609d5a67b78 && _0xcd855ac6dcd2 === _0x0e490fe6dc37(68580)) {
            _0x0799b097cda8.push(_0x8864a9ccc588);
            _0x8864a9ccc588 = _0x0e490fe6dc37(68377);
            continue;
        }
        if (!_0xa609d5a67b78 && (_0xcd855ac6dcd2 === _0x0e490fe6dc37(68603) || _0xcd855ac6dcd2 === _0x0e490fe6dc37(68608))) {
            if (_0xcd855ac6dcd2 === _0x0e490fe6dc37(68608) && _0x228553dc5df1 === _0x0e490fe6dc37(68603)) {
                _0x5828e8bf770c += 1;
            }
            _0x0799b097cda8.push(_0x8864a9ccc588);
            _0x1116c170e7bf.push(_0x0799b097cda8);
            _0x0799b097cda8 = [];
            _0x8864a9ccc588 = _0x0e490fe6dc37(68377);
            continue;
        }
        _0x8864a9ccc588 += _0xcd855ac6dcd2;
    }
    _0x0799b097cda8.push(_0x8864a9ccc588);
    _0x1116c170e7bf.push(_0x0799b097cda8);
    while (_0x1116c170e7bf.length > 1 && _0x1116c170e7bf[_0x1116c170e7bf.length - 1].every((_0xb487b24354a7) => _0xb487b24354a7 === _0x0e490fe6dc37(68377))) {
        _0x1116c170e7bf.pop();
    }
    return _0x1116c170e7bf;
}
function _0x4ca42aa0f3aa(_0xcea7b670caa9, _0x9500f602554f, _0xe48da0a07c28) {
    const _0x9054784d3bca = _0x49a713ea131d(_0xe48da0a07c28);
    const _0x583512c78eab = _0x9054784d3bca.some((_0x7f6c21202409) => _0x7f6c21202409.length > 1);
    if (_0x583512c78eab) {
        const _0x3903e162e731 = _0x9054784d3bca.findIndex((_0xfcfa14f68b08) => _0xfcfa14f68b08.length !== _0x9bb4d717af41.length);
        if (_0x3903e162e731 >= 0) {
            _0xbfcde6d57529(`粘贴失败：第 ${_0x3903e162e731 + 1} 行有 ${_0x9054784d3bca[_0x3903e162e731].length} 列，批量数据必须严格为 ${_0x9bb4d717af41.length} 列；address2 为空时也要保留空列。`, true);
            return;
        }
        _0x9500f602554f = 0;
    }
    const _0x2889c9679e65 = _0x9bb4d717af41.length - _0x9500f602554f;
    const _0x294da94ced92 = _0x9054784d3bca.findIndex((_0x5b5598d667d4) => _0x5b5598d667d4.length > _0x2889c9679e65);
    if (_0x294da94ced92 >= 0) {
        _0xbfcde6d57529(`粘贴失败：从当前单元格开始最多还能粘贴 ${_0x2889c9679e65} 列，第 ${_0x294da94ced92 + 1} 行超出输入表格范围。`, true);
        return;
    }
    const _0xe786db5011bc = _0xcea7b670caa9 + _0x9054784d3bca.length;
    while (_0xcdb4e378d26c.length < _0xe786db5011bc) {
        _0xcdb4e378d26c.push(_0x1db43332ef02());
    }
    _0x9054784d3bca.forEach((_0x7363aded598f, _0x4a8f3afe175b) => {
        _0x7363aded598f.forEach((_0xcf57ca8b867e, _0x1f4fbddc73c7) => {
            const _0xf335c8272343 = _0x9500f602554f + _0x1f4fbddc73c7;
            if (_0xf335c8272343 >= _0x9bb4d717af41.length) {
                return;
            }
            const _0xab63009a78b7 = _0x9bb4d717af41[_0xf335c8272343].key;
            _0xcdb4e378d26c[_0xcea7b670caa9 + _0x4a8f3afe175b][_0xab63009a78b7] = _0xcf57ca8b867e;
        });
    });
    _0xcdb4e378d26c = _0xd35dcbdcd385(_0xcdb4e378d26c);
    _0x277ef4322b11();
    _0x7c769fc901d1(0);
    _0xbfcde6d57529(_0x583512c78eab ? `已按九列新格式粘贴 ${_0x9054784d3bca.length} 行数据。`
        : `已粘贴 ${_0x9054784d3bca.length} 行单列数据。`);
}
function _0xda02b5e672e3() {
    const _0x8c21178f7b7d = [..._0xc4b167c7218c.inputTableBody.querySelectorAll(_0x0e490fe6dc37(68524))];
    _0x8c21178f7b7d.forEach((_0x83e615bec68b) => {
        const _0x6b50b866720b = Number(_0x83e615bec68b.dataset.rowIndex);
        const _0xc05ee9294f89 = _0x83e615bec68b.dataset.field;
        if (_0xcdb4e378d26c[_0x6b50b866720b] && _0xc05ee9294f89) {
            _0xcdb4e378d26c[_0x6b50b866720b][_0xc05ee9294f89] = _0x83e615bec68b.value;
        }
    });
    return _0xcdb4e378d26c.map(_0xcd0b1eb3e16a);
}
function _0x7c769fc901d1(_0xcf25c6cb88cf = 450) {
    clearTimeout(_0xa151b934fa07);
    _0xa151b934fa07 = setTimeout(async () => {
        _0xa151b934fa07 = null;
        if (_0x87271d686b8f && _0xe5042edae8a3.has(_0x87271d686b8f.mode)) {
            return;
        }
        _0xda02b5e672e3();
        await _0x2509c9f74433(_0x0e490fe6dc37(68386), { rows: _0xcdb4e378d26c });
    }, _0xcf25c6cb88cf);
}
function _0x584ed5842af4(_0x1af044a2d376) {
    return String(_0x1af044a2d376 ?? _0x0e490fe6dc37(68377)).replace(/[\t\r\n]+/g, _0x0e490fe6dc37(68622)).trim();
}
function _0x2aa9c128cad6(_0xb2cba8e3894e, _0xbedcded639d6, _0xad85bb4775f4 = _0x0e490fe6dc37(68377)) {
    const _0x24f8e19feab0 = document.createElement(_0x0e490fe6dc37(68604));
    _0x24f8e19feab0.textContent = String(_0xbedcded639d6 ?? _0x0e490fe6dc37(68377));
    _0x24f8e19feab0.title = String(_0xbedcded639d6 ?? _0x0e490fe6dc37(68377));
    if (_0xad85bb4775f4) {
        _0x24f8e19feab0.className = _0xad85bb4775f4;
    }
    _0xb2cba8e3894e.appendChild(_0x24f8e19feab0);
}
function _0x964324826639(_0x28ff0f360815) {
    if (_0x28ff0f360815.result === _0x0e490fe6dc37(68400)) {
        return _0x0e490fe6dc37(68588);
    }
    if (_0x28ff0f360815.result === _0x0e490fe6dc37(68416)) {
        return _0x0e490fe6dc37(68627);
    }
    if (_0x28ff0f360815.result === _0x0e490fe6dc37(68506)) {
        return _0x0e490fe6dc37(68576);
    }
    return _0x0e490fe6dc37(68377);
}
function _0xa4cf9d23b5b6(_0x3549e27ddbc1) {
    if (_0x3549e27ddbc1?.result === _0x0e490fe6dc37(68400) && /^\d{3}-\d{7}-\d{7}$/.test(String(_0x3549e27ddbc1?.orderId || _0x0e490fe6dc37(68377)).trim())) {
        return String(_0x3549e27ddbc1.orderId).trim();
    }
    return String(_0x3549e27ddbc1?.status || _0x0e490fe6dc37(68377));
}
function _0x167e9320f910() {
    _0xc4b167c7218c.recordsTableBody.replaceChildren();
    const _0x5276dbecd7d6 = Array.isArray(_0x87271d686b8f?.rows) ? _0x87271d686b8f.rows : [];
    if (_0x5276dbecd7d6.length === 0) {
        const _0xa11c5d056e54 = document.createElement(_0x0e490fe6dc37(68421));
        const _0xaccf0aa13e01 = document.createElement(_0x0e490fe6dc37(68604));
        _0xaccf0aa13e01.colSpan = 7;
        _0xaccf0aa13e01.className = _0x0e490fe6dc37(68531);
        _0xaccf0aa13e01.textContent = _0x0e490fe6dc37(68521);
        _0xa11c5d056e54.appendChild(_0xaccf0aa13e01);
        _0xc4b167c7218c.recordsTableBody.appendChild(_0xa11c5d056e54);
        return;
    }
    const _0xcaa0eaaabbf1 = document.createDocumentFragment();
    _0x5276dbecd7d6.forEach((_0xb61cfece2afc) => {
        const _0x65338717dd8b = document.createElement(_0x0e490fe6dc37(68421));
        _0x2aa9c128cad6(_0x65338717dd8b, _0xb61cfece2afc.temuOrderId || _0x0e490fe6dc37(68377));
        _0x2aa9c128cad6(_0x65338717dd8b, _0xb61cfece2afc.asin || _0x0e490fe6dc37(68377));
        _0x2aa9c128cad6(_0x65338717dd8b, _0xb61cfece2afc.recipientName || _0x0e490fe6dc37(68377));
        _0x2aa9c128cad6(_0x65338717dd8b, _0xb61cfece2afc.shipAddress || _0x0e490fe6dc37(68377));
        _0x2aa9c128cad6(_0x65338717dd8b, _0xb61cfece2afc.shipCity || _0x0e490fe6dc37(68377));
        _0x2aa9c128cad6(_0x65338717dd8b, _0xb61cfece2afc.shipPostalCode || _0x0e490fe6dc37(68377));
        _0x2aa9c128cad6(_0x65338717dd8b, _0xa4cf9d23b5b6(_0xb61cfece2afc), _0x964324826639(_0xb61cfece2afc));
        _0xcaa0eaaabbf1.appendChild(_0x65338717dd8b);
    });
    _0xc4b167c7218c.recordsTableBody.appendChild(_0xcaa0eaaabbf1);
}
function _0xdfc487d136b6() {
    _0xc4b167c7218c.logContainer.replaceChildren();
    if (!Array.isArray(_0x33fc584411c8) || _0x33fc584411c8.length === 0) {
        const _0xe19bfc4e1802 = document.createElement(_0x0e490fe6dc37(68567));
        _0xe19bfc4e1802.className = _0x0e490fe6dc37(68606);
        _0xe19bfc4e1802.textContent = _0x0e490fe6dc37(68401);
        _0xc4b167c7218c.logContainer.appendChild(_0xe19bfc4e1802);
        return;
    }
    const _0x9ae69c50908e = document.createDocumentFragment();
    _0x33fc584411c8.forEach((_0x762d55ebab04) => {
        const _0xda5825fe0c96 = document.createElement(_0x0e490fe6dc37(68567));
        _0xda5825fe0c96.className = _0x0e490fe6dc37(68407);
        _0xda5825fe0c96.dataset.level = _0x762d55ebab04.level || _0x0e490fe6dc37(68435);
        const _0x22e535c6b17b = document.createElement(_0x0e490fe6dc37(68614));
        _0x22e535c6b17b.className = _0x0e490fe6dc37(68437);
        _0x22e535c6b17b.textContent = _0x762d55ebab04.time || _0x0e490fe6dc37(68377);
        const _0x10fa3086fd13 = document.createElement(_0x0e490fe6dc37(68614));
        _0x10fa3086fd13.className = _0x0e490fe6dc37(68529);
        _0x10fa3086fd13.textContent = _0x762d55ebab04.level || _0x0e490fe6dc37(68435);
        const _0xe2717887440a = document.createElement(_0x0e490fe6dc37(68614));
        _0xe2717887440a.className = _0x0e490fe6dc37(68530);
        _0xe2717887440a.textContent = _0x762d55ebab04.rowNumber ? `第${_0x762d55ebab04.rowNumber}行` : _0x0e490fe6dc37(68561);
        const _0x8e4a3865a9b1 = document.createElement(_0x0e490fe6dc37(68614));
        _0x8e4a3865a9b1.className = _0x0e490fe6dc37(68597);
        _0x8e4a3865a9b1.textContent = _0x762d55ebab04.message || _0x0e490fe6dc37(68377);
        _0xda5825fe0c96.append(_0x22e535c6b17b, _0x10fa3086fd13, _0xe2717887440a, _0x8e4a3865a9b1);
        _0x9ae69c50908e.appendChild(_0xda5825fe0c96);
    });
    _0xc4b167c7218c.logContainer.appendChild(_0x9ae69c50908e);
    _0xc4b167c7218c.logContainer.scrollTop = _0xc4b167c7218c.logContainer.scrollHeight;
}
function _0xb8af070ad499() {
    if (!_0x87271d686b8f) {
        _0xc4b167c7218c.runMode.textContent = _0x0e490fe6dc37(68425);
        _0xc4b167c7218c.currentRow.textContent = _0x0e490fe6dc37(68561);
        _0xc4b167c7218c.currentPhase.textContent = _0x0e490fe6dc37(68561);
        _0xc4b167c7218c.pauseReason.classList.add(_0x0e490fe6dc37(68543));
        _0xc4b167c7218c.pauseReason.textContent = _0x0e490fe6dc37(68377);
        return;
    }
    _0xc4b167c7218c.runMode.textContent = _0x473e75913c77[_0x87271d686b8f.mode] || _0x87271d686b8f.mode || _0x0e490fe6dc37(68511);
    const _0x2923fcd30ed7 = Number.isInteger(_0x87271d686b8f.currentIndex) ? _0x87271d686b8f.rows?.[_0x87271d686b8f.currentIndex] : null;
    const _0xe22b84608a20 = Number.isInteger(_0x87271d686b8f.currentGroupIndex) ? _0x87271d686b8f.groups?.[_0x87271d686b8f.currentGroupIndex] : null;
    if (_0x2923fcd30ed7 && _0xe22b84608a20) {
        const _0xb1d69b02c246 = _0x87271d686b8f.currentGroupIndex + 1;
        const _0x462db733eb8c = _0x87271d686b8f.groups?.length || 0;
        _0xc4b167c7218c.currentRow.textContent = _0xe22b84608a20.isCombined
            ? `地址组 ${_0xb1d69b02c246}/${_0x462db733eb8c} · 第 ${_0x2923fcd30ed7.rowNumber} 行 · 组合 ${_0xe22b84608a20.rowIndexes?.length || 0} 行`
            : `地址组 ${_0xb1d69b02c246}/${_0x462db733eb8c} · 第 ${_0x2923fcd30ed7.rowNumber} 行`;
    }
    else {
        _0xc4b167c7218c.currentRow.textContent = _0x2923fcd30ed7 ? `第 ${_0x2923fcd30ed7.rowNumber} 行 / 共 ${_0x87271d686b8f.rows.length} 条`
            : `共 ${_0x87271d686b8f.rows?.length || 0} 条`;
    }
    if (_0x87271d686b8f.phase === _0x0e490fe6dc37(68582)) {
        const _0x1304c796d80c = Date.parse(String(_0x87271d686b8f.intervalEndsAt || _0x0e490fe6dc37(68377)));
        const _0xf1b1dd36c39f = _0x87271d686b8f.mode === _0x0e490fe6dc37(68510)
            ? Math.max(0, Number(_0x87271d686b8f.intervalRemainingSeconds || 0))
            : Math.max(0, Math.ceil((Number.isFinite(_0x1304c796d80c) ? _0x1304c796d80c - Date.now() : 0) / 1000));
        _0xc4b167c7218c.currentPhase.textContent = `等待下一单，剩余约 ${_0xf1b1dd36c39f} 秒`;
    }
    else {
        _0xc4b167c7218c.currentPhase.textContent = _0x2ba928a464d6[_0x87271d686b8f.phase] || _0x87271d686b8f.phase || _0x0e490fe6dc37(68561);
    }
    if (_0x87271d686b8f.pauseReason) {
        _0xc4b167c7218c.pauseReason.textContent = `暂停原因：${_0x87271d686b8f.pauseReason}`;
        _0xc4b167c7218c.pauseReason.classList.remove(_0x0e490fe6dc37(68543));
    }
    else {
        _0xc4b167c7218c.pauseReason.classList.add(_0x0e490fe6dc37(68543));
        _0xc4b167c7218c.pauseReason.textContent = _0x0e490fe6dc37(68377);
    }
}
function _0xd595cbd22506() {
    const _0x635d7645a200 = _0x87271d686b8f?.mode || _0x0e490fe6dc37(68377);
    const _0xeaad4b091262 = _0xe5042edae8a3.has(_0x635d7645a200);
    const _0xd0e36755e704 = _0x635d7645a200 === _0x0e490fe6dc37(68384) || _0x635d7645a200 === _0x0e490fe6dc37(68395);
    const _0x7e7e7004a2df = _0x635d7645a200 === _0x0e490fe6dc37(68510);
    _0xc4b167c7218c.startBtn.disabled = _0xeaad4b091262;
    const _0x7557fe468d67 = Array.isArray(_0x87271d686b8f?.rows) ? _0x87271d686b8f.rows : [];
    const _0xf674de857f7c = _0x7557fe468d67.some((_0x22723b5d7e8c) => _0x22723b5d7e8c?.result === _0x0e490fe6dc37(68506) && !/^\d{3}-\d{7}-\d{7}$/.test(String(_0x22723b5d7e8c?.orderId || _0x0e490fe6dc37(68377)).trim()));
    const _0x05588da4e7d3 = _0x635d7645a200 === _0x0e490fe6dc37(68593) || _0x635d7645a200 === _0x0e490fe6dc37(68429);
    _0xc4b167c7218c.retrySkippedBtn.disabled = !_0x05588da4e7d3 || Boolean(_0x14e6dfe6c7b0) || !_0xf674de857f7c;
    _0xc4b167c7218c.pauseBtn.disabled = !_0xd0e36755e704;
    _0xc4b167c7218c.continueBtn.disabled = !_0x7e7e7004a2df;
    _0xc4b167c7218c.skipBtn.disabled = !_0x7e7e7004a2df || Boolean(_0x14e6dfe6c7b0);
    _0xc4b167c7218c.stopBtn.disabled = !_0xeaad4b091262;
    _0xc4b167c7218c.openTabBtn.disabled = !Number.isInteger(_0x87271d686b8f?.workTabId);
    _0xc4b167c7218c.orderIntervalSeconds.disabled = _0xeaad4b091262;
    _0xc4b167c7218c.clearTodayOrdersBtn.disabled = _0xeaad4b091262 || Boolean(_0x14e6dfe6c7b0);
    _0xc4b167c7218c.clearCartLockBtn.disabled = !_0x14e6dfe6c7b0 || _0xd0e36755e704;
    _0xc4b167c7218c.addRowsBtn.disabled = _0xeaad4b091262;
    _0xc4b167c7218c.removeBlankBtn.disabled = _0xeaad4b091262;
    _0xc4b167c7218c.clearInputBtn.disabled = _0xeaad4b091262;
    const _0xf8f7c92a90a1 = _0x7557fe468d67.some((_0x1c04bc0858af) => _0x1c04bc0858af?.result === _0x0e490fe6dc37(68400) && /^\d{3}-\d{7}-\d{7}$/.test(String(_0x1c04bc0858af?.orderId || _0x0e490fe6dc37(68377)).trim()));
    _0xc4b167c7218c.copyOrderIdsBtn.disabled = !_0xf8f7c92a90a1;
    _0xc4b167c7218c.exportRecordsCsvBtn.disabled = _0x7557fe468d67.length === 0;
    _0xc4b167c7218c.copyRecordsBtn.disabled = _0x7557fe468d67.length === 0;
    _0xc4b167c7218c.inputTableBody.querySelectorAll(_0x0e490fe6dc37(68459)).forEach((_0xd9ce62708194) => {
        _0xd9ce62708194.disabled = _0xeaad4b091262;
    });
    const _0x21dd104710ac = _0x14ba3e35aac3 !== _0x0e490fe6dc37(68378);
    _0xc4b167c7218c.authorizationFailureBar.classList.toggle(_0x0e490fe6dc37(68543), _0x14ba3e35aac3 !== _0x0e490fe6dc37(68382));
    if (_0x21dd104710ac) {
        document.querySelectorAll(_0x0e490fe6dc37(68552)).forEach((_0xbf393c373600) => {
            _0xbf393c373600.disabled = true;
        });
        _0xc4b167c7218c.revalidateAuthorizationBtn.disabled = _0x14ba3e35aac3 !== _0x0e490fe6dc37(68382);
        _0xc4b167c7218c.closeWindowBtn.disabled = _0x14ba3e35aac3 !== _0x0e490fe6dc37(68382);
        _0xc4b167c7218c.copyLogBtn.disabled = false;
        _0xc4b167c7218c.exportRecordsCsvBtn.disabled = _0x7557fe468d67.length === 0;
    }
}
function _0xfc74f966c46f() {
    _0xb8af070ad499();
    _0x167e9320f910();
    _0xd595cbd22506();
}
async function _0x964136e20c9e(_0x4186ce37c896, _0xf7b5a9e1834b) {
    try {
        await navigator.clipboard.writeText(_0x4186ce37c896);
        _0xbfcde6d57529(_0xf7b5a9e1834b);
    }
    catch (_0x0551e6ac7986) {
        _0xbfcde6d57529(`复制失败：${_0x0551e6ac7986.message || String(_0x0551e6ac7986)}`, true);
    }
}
function _0xd48061d447d5() {
    const _0x3e5a9bff3980 = [
        _0x0e490fe6dc37(68537),
        _0x0e490fe6dc37(68559),
        _0x0e490fe6dc37(68616),
        _0x0e490fe6dc37(68624),
        _0x0e490fe6dc37(68410),
        _0x0e490fe6dc37(68514),
        _0x0e490fe6dc37(68556)
    ];
    const _0xfcfb4ab91328 = Array.isArray(_0x87271d686b8f?.rows) ? _0x87271d686b8f.rows : [];
    const _0x245220dc6ce2 = _0xfcfb4ab91328.map((_0x008aac177842) => [
        _0x008aac177842.temuOrderId,
        _0x008aac177842.asin,
        _0x008aac177842.recipientName,
        _0x008aac177842.shipAddress,
        _0x008aac177842.shipCity,
        _0x008aac177842.shipPostalCode,
        _0xa4cf9d23b5b6(_0x008aac177842)
    ].map(_0x584ed5842af4).join(_0x0e490fe6dc37(68580)));
    return [_0x3e5a9bff3980.join(_0x0e490fe6dc37(68580)), ..._0x245220dc6ce2].join(_0x0e490fe6dc37(68603));
}
function _0x1d0a58a5c633() {
    const _0x688ae348b46d = Array.isArray(_0x87271d686b8f?.rows) ? _0x87271d686b8f.rows : [];
    const _0x3227298d456f = [];
    for (const _0x333d47e05776 of _0x688ae348b46d) {
        const _0x3e0cd1e9fb5f = _0x333d47e05776?.result === _0x0e490fe6dc37(68400) ? String(_0x333d47e05776?.orderId || _0x0e490fe6dc37(68377)).trim() : _0x0e490fe6dc37(68377);
        if (!/^\d{3}-\d{7}-\d{7}$/.test(_0x3e0cd1e9fb5f)) {
            continue;
        }
        _0x3227298d456f.push(_0x3e0cd1e9fb5f);
    }
    return _0x3227298d456f;
}
function _0x31da2e0e459a(_0x449b2c0a94d9) {
    const _0x9cebfb57f9bd = String(_0x449b2c0a94d9 ?? _0x0e490fe6dc37(68377)).replace(/\r?\n/g, _0x0e490fe6dc37(68622)).trim();
    return `"${_0x9cebfb57f9bd.replace(/"/g, _0x0e490fe6dc37(68605))}"`;
}
function _0x0f9a4105e9c8() {
    const _0xf659898682a6 = [
        _0x0e490fe6dc37(68537),
        _0x0e490fe6dc37(68559),
        _0x0e490fe6dc37(68616),
        _0x0e490fe6dc37(68624),
        _0x0e490fe6dc37(68410),
        _0x0e490fe6dc37(68514),
        _0x0e490fe6dc37(68556)
    ];
    const _0x64a43d4c068a = Array.isArray(_0x87271d686b8f?.rows) ? _0x87271d686b8f.rows : [];
    const _0x38d7df5309d9 = _0x64a43d4c068a.map((_0x5d4bb94ce8ff) => [
        _0x5d4bb94ce8ff.temuOrderId,
        _0x5d4bb94ce8ff.asin,
        _0x5d4bb94ce8ff.recipientName,
        _0x5d4bb94ce8ff.shipAddress,
        _0x5d4bb94ce8ff.shipCity,
        _0x5d4bb94ce8ff.shipPostalCode,
        _0xa4cf9d23b5b6(_0x5d4bb94ce8ff)
    ].map(_0x31da2e0e459a).join(_0x0e490fe6dc37(68471)));
    return [_0xf659898682a6.map(_0x31da2e0e459a).join(_0x0e490fe6dc37(68471)), ..._0x38d7df5309d9].join(_0x0e490fe6dc37(68548));
}
function _0x646cef240a0a(_0x7e473948db54 = new Date()) {
    const _0x36e362da1b51 = new Intl.DateTimeFormat(_0x0e490fe6dc37(68405), {
        timeZone: _0x0e490fe6dc37(68523),
        year: _0x0e490fe6dc37(68619),
        month: _0x0e490fe6dc37(68563),
        day: _0x0e490fe6dc37(68563),
        hour: _0x0e490fe6dc37(68563),
        minute: _0x0e490fe6dc37(68563),
        second: _0x0e490fe6dc37(68563),
        hourCycle: _0x0e490fe6dc37(68412)
    }).formatToParts(_0x7e473948db54);
    const _0x0e0967ed0c21 = Object.fromEntries(_0x36e362da1b51.map((_0xcb223a569433) => [_0xcb223a569433.type, _0xcb223a569433.value]));
    return `${_0x0e0967ed0c21.year}-${_0x0e0967ed0c21.month}-${_0x0e0967ed0c21.day}_${_0x0e0967ed0c21.hour}-${_0x0e0967ed0c21.minute}-${_0x0e0967ed0c21.second}`;
}
function _0xef4270a9e467() {
    const _0x17b95891caf2 = `\uFEFF${_0x0f9a4105e9c8()}`;
    const _0xc532c3f3eebf = new Blob([_0x17b95891caf2], { type: _0x0e490fe6dc37(68528) });
    const _0xf2955c615b4e = URL.createObjectURL(_0xc532c3f3eebf);
    const _0x5fffbf467c6f = document.createElement(_0x0e490fe6dc37(68519));
    _0x5fffbf467c6f.href = _0xf2955c615b4e;
    _0x5fffbf467c6f.download = `amazon_order_work_records_${_0x646cef240a0a()}.csv`;
    document.body.appendChild(_0x5fffbf467c6f);
    _0x5fffbf467c6f.click();
    _0x5fffbf467c6f.remove();
    setTimeout(() => URL.revokeObjectURL(_0xf2955c615b4e), 1000);
}
function _0x51eb2df3fac6() {
    return (Array.isArray(_0x33fc584411c8) ? _0x33fc584411c8 : [])
        .map((_0xf6e2ac92f375) => [
        _0xf6e2ac92f375.time || _0x0e490fe6dc37(68377),
        String(_0xf6e2ac92f375.level || _0x0e490fe6dc37(68435)).toUpperCase(),
        _0xf6e2ac92f375.rowNumber ? `第${_0xf6e2ac92f375.rowNumber}行` : _0x0e490fe6dc37(68377),
        _0x584ed5842af4(_0xf6e2ac92f375.message)
    ].join(_0x0e490fe6dc37(68580)))
        .join(_0x0e490fe6dc37(68603));
}
_0xc4b167c7218c.revalidateAuthorizationBtn.addEventListener(_0x0e490fe6dc37(68587), async () => {
    _0xb1e5c932907f = false;
    _0xc4b167c7218c.revalidateAuthorizationBtn.disabled = true;
    const _0x6e409e6bf41b = await _0x2509c9f74433(_0x0e490fe6dc37(68564));
    if (_0x6e409e6bf41b?.[_0x0e490fe6dc37(68621)]?.[_0x0e490fe6dc37(68378)]) {
        _0xe5537930e2be(_0x6e409e6bf41b[_0x0e490fe6dc37(68621)], false);
    }
    else {
        _0xe5537930e2be({ [_0x0e490fe6dc37(68378)]: false }, true);
    }
});
_0xc4b167c7218c.closeWindowBtn.addEventListener(_0x0e490fe6dc37(68587), () => {
    window.close();
});
_0xc4b167c7218c.startBtn.addEventListener(_0x0e490fe6dc37(68587), async () => {
    _0xda02b5e672e3();
    const _0x1bbe970417ef = _0xcdb4e378d26c.filter((_0x08d37ef89b9b) => !_0x11e84734eff6(_0x08d37ef89b9b));
    if (_0x1bbe970417ef.length === 0) {
        _0xbfcde6d57529(_0x0e490fe6dc37(68383), true);
        return;
    }
    const _0xfc501b4cdd9d = Number(_0xc4b167c7218c.orderIntervalSeconds.value);
    if (!Number.isInteger(_0xfc501b4cdd9d) || _0xfc501b4cdd9d < 0 || _0xfc501b4cdd9d > 3600) {
        _0xbfcde6d57529(_0x0e490fe6dc37(68391), true);
        _0xc4b167c7218c.orderIntervalSeconds.focus();
        return;
    }
    const _0x09b83d400f5f = await _0x2509c9f74433(_0x0e490fe6dc37(68436), {
        settings: { orderIntervalSeconds: _0xfc501b4cdd9d }
    });
    if (!_0x09b83d400f5f?.ok) {
        return;
    }
    _0xb044acebd3e6 = _0x09b83d400f5f.settings || { orderIntervalSeconds: _0xfc501b4cdd9d };
    const _0xc766d6d8a9e6 = await _0x2509c9f74433(_0x0e490fe6dc37(68592), {
        rows: _0xcdb4e378d26c,
        orderIntervalSeconds: _0xfc501b4cdd9d
    });
    if (_0xc766d6d8a9e6?.ok) {
        _0xbfcde6d57529(_0xc766d6d8a9e6.paused ? _0x0e490fe6dc37(68550) : _0x0e490fe6dc37(68439), Boolean(_0xc766d6d8a9e6.paused));
    }
});
_0xc4b167c7218c.retrySkippedBtn.addEventListener(_0x0e490fe6dc37(68587), async () => {
    _0xda02b5e672e3();
    const _0x003b68d0d3d0 = (Array.isArray(_0x87271d686b8f?.rows) ? _0x87271d686b8f.rows : []).filter((_0x351a862c8901) => _0x351a862c8901?.result === _0x0e490fe6dc37(68506) && !/^\d{3}-\d{7}-\d{7}$/.test(String(_0x351a862c8901?.orderId || _0x0e490fe6dc37(68377)).trim()));
    if (_0x003b68d0d3d0.length === 0) {
        _0xbfcde6d57529(_0x0e490fe6dc37(68546), true);
        return;
    }
    const _0x818e3a8e2805 = Number(_0xc4b167c7218c.orderIntervalSeconds.value);
    if (!Number.isInteger(_0x818e3a8e2805) || _0x818e3a8e2805 < 0 || _0x818e3a8e2805 > 3600) {
        _0xbfcde6d57529(_0x0e490fe6dc37(68391), true);
        _0xc4b167c7218c.orderIntervalSeconds.focus();
        return;
    }
    const _0xaca3124956b3 = window.confirm(`将按当前输入表格的最新数据重新处理 ${_0x003b68d0d3d0.length} 条跳过记录。\n\n` + _0x0e490fe6dc37(68562) + _0x0e490fe6dc37(68545));
    if (!_0xaca3124956b3) {
        return;
    }
    const _0xfa39a7a96acd = await _0x2509c9f74433(_0x0e490fe6dc37(68436), {
        settings: { orderIntervalSeconds: _0x818e3a8e2805 }
    });
    if (!_0xfa39a7a96acd?.ok) {
        return;
    }
    _0xb044acebd3e6 = _0xfa39a7a96acd.settings || { orderIntervalSeconds: _0x818e3a8e2805 };
    const _0x75a0c0d5cecb = await _0x2509c9f74433(_0x0e490fe6dc37(68626), {
        rows: _0xcdb4e378d26c,
        orderIntervalSeconds: _0x818e3a8e2805
    });
    if (_0x75a0c0d5cecb?.ok) {
        _0xbfcde6d57529(_0x75a0c0d5cecb.paused
            ? _0x0e490fe6dc37(68602) : `已开始重下 ${_0x75a0c0d5cecb.retryCount || _0x003b68d0d3d0.length} 条跳过记录。`, Boolean(_0x75a0c0d5cecb.paused));
    }
});
_0xc4b167c7218c.pauseBtn.addEventListener(_0x0e490fe6dc37(68587), async () => {
    const _0xd220e637865d = await _0x2509c9f74433(_0x0e490fe6dc37(68617));
    if (_0xd220e637865d?.ok) {
        _0xbfcde6d57529(_0x0e490fe6dc37(68398));
    }
});
_0xc4b167c7218c.continueBtn.addEventListener(_0x0e490fe6dc37(68587), async () => {
    const _0xbc412a17e385 = await _0x2509c9f74433(_0x0e490fe6dc37(68390));
    if (_0xbc412a17e385?.ok) {
        _0xbfcde6d57529(_0x0e490fe6dc37(68581));
    }
});
_0xc4b167c7218c.skipBtn.addEventListener(_0x0e490fe6dc37(68587), async () => {
    const _0x458a8b0562f4 = [_0x0e490fe6dc37(68623), _0x0e490fe6dc37(68575)].includes(_0x87271d686b8f?.phase);
    if (_0x458a8b0562f4) {
        const _0x6321e0ff11b9 = window.confirm(_0x0e490fe6dc37(68554));
        if (!_0x6321e0ff11b9) {
            return;
        }
    }
    const _0xced100ae72a4 = await _0x2509c9f74433(_0x0e490fe6dc37(68549));
    if (_0xced100ae72a4?.ok) {
        _0xbfcde6d57529(_0x0e490fe6dc37(68557));
    }
});
_0xc4b167c7218c.stopBtn.addEventListener(_0x0e490fe6dc37(68587), async () => {
    const _0x406985810952 = [_0x0e490fe6dc37(68623), _0x0e490fe6dc37(68575)].includes(_0x87271d686b8f?.phase);
    if (_0x14e6dfe6c7b0) {
        const _0x4bc94af0e21b = window.confirm(_0x0e490fe6dc37(68403));
        if (!_0x4bc94af0e21b) {
            return;
        }
    }
    else if (_0x406985810952) {
        const _0xc970fddc5a7a = window.confirm(_0x0e490fe6dc37(68553));
        if (!_0xc970fddc5a7a) {
            return;
        }
    }
    const _0x500f24421422 = await _0x2509c9f74433(_0x0e490fe6dc37(68571));
    if (_0x500f24421422?.ok) {
        _0xbfcde6d57529(_0x0e490fe6dc37(68417));
    }
});
_0xc4b167c7218c.openTabBtn.addEventListener(_0x0e490fe6dc37(68587), () => _0x2509c9f74433(_0x0e490fe6dc37(68525)));
_0xc4b167c7218c.addRowsBtn.addEventListener(_0x0e490fe6dc37(68587), () => {
    _0xda02b5e672e3();
    for (let _0xae8f8268e4c2 = 0; _0xae8f8268e4c2 < 10; _0xae8f8268e4c2 += 1) {
        _0xcdb4e378d26c.push(_0x1db43332ef02());
    }
    _0x277ef4322b11();
    _0x7c769fc901d1(0);
});
_0xc4b167c7218c.removeBlankBtn.addEventListener(_0x0e490fe6dc37(68587), () => {
    _0xda02b5e672e3();
    _0xcdb4e378d26c = _0xd35dcbdcd385(_0xcdb4e378d26c.filter((_0x35251c86034a) => !_0x11e84734eff6(_0x35251c86034a)));
    _0x277ef4322b11();
    _0x7c769fc901d1(0);
});
_0xc4b167c7218c.clearInputBtn.addEventListener(_0x0e490fe6dc37(68587), async () => {
    const _0x9bceda889dc3 = window.confirm(_0x0e490fe6dc37(68595));
    if (!_0x9bceda889dc3) {
        return;
    }
    const _0x5c8f81aaadd3 = await _0x2509c9f74433(_0x0e490fe6dc37(68430));
    if (_0x5c8f81aaadd3?.ok) {
        _0xcdb4e378d26c = _0xd35dcbdcd385([]);
        _0x87271d686b8f = null;
        _0x277ef4322b11();
        _0xfc74f966c46f();
        _0xbfcde6d57529(_0x0e490fe6dc37(68629));
    }
});
_0xc4b167c7218c.orderIntervalSeconds.addEventListener(_0x0e490fe6dc37(68578), async () => {
    const _0xb9da0df37934 = Number(_0xc4b167c7218c.orderIntervalSeconds.value);
    if (!Number.isInteger(_0xb9da0df37934) || _0xb9da0df37934 < 0 || _0xb9da0df37934 > 3600) {
        _0xc4b167c7218c.orderIntervalSeconds.value = String(_0xb044acebd3e6.orderIntervalSeconds ?? 30);
        _0xbfcde6d57529(_0x0e490fe6dc37(68391), true);
        return;
    }
    const _0xc98a7580475d = await _0x2509c9f74433(_0x0e490fe6dc37(68436), {
        settings: { orderIntervalSeconds: _0xb9da0df37934 }
    });
    if (_0xc98a7580475d?.ok) {
        _0xb044acebd3e6 = _0xc98a7580475d.settings || { orderIntervalSeconds: _0xb9da0df37934 };
        _0xbfcde6d57529(`每单下单时间间隔已保存为 ${_0xb9da0df37934} 秒。`);
    }
});
_0xc4b167c7218c.clearCartLockBtn.addEventListener(_0x0e490fe6dc37(68587), async () => {
    const _0x57c635e9c41b = window.confirm(_0x0e490fe6dc37(68538));
    if (!_0x57c635e9c41b) {
        return;
    }
    const _0xd1bae374c425 = await _0x2509c9f74433(_0x0e490fe6dc37(68504));
    if (_0xd1bae374c425?.ok) {
        _0xbfcde6d57529(_0xd1bae374c425.cleared ? _0x0e490fe6dc37(68458) : _0x0e490fe6dc37(68397));
    }
});
_0xc4b167c7218c.clearTodayOrdersBtn.addEventListener(_0x0e490fe6dc37(68587), async () => {
    const _0x00d050e1c877 = window.confirm(_0x0e490fe6dc37(68512));
    if (!_0x00d050e1c877) {
        return;
    }
    const _0xdee6ed0defa8 = await _0x2509c9f74433(_0x0e490fe6dc37(68408));
    if (_0xdee6ed0defa8?.ok) {
        _0xbfcde6d57529(`已清空 ${_0xdee6ed0defa8.clearedCount || 0} 条 ${_0xdee6ed0defa8.dateKey || _0x0e490fe6dc37(68467)} 的成功下单记录。`);
    }
});
_0xc4b167c7218c.copyOrderIdsBtn.addEventListener(_0x0e490fe6dc37(68587), () => {
    const _0x48439a88d764 = _0x1d0a58a5c633();
    if (_0x48439a88d764.length === 0) {
        _0xbfcde6d57529(_0x0e490fe6dc37(68541), true);
        return;
    }
    _0x964136e20c9e(_0x48439a88d764.join(_0x0e490fe6dc37(68603)), `已复制 ${_0x48439a88d764.length} 个 Order ID。`);
});
_0xc4b167c7218c.exportRecordsCsvBtn.addEventListener(_0x0e490fe6dc37(68587), () => {
    const _0x927dde073896 = Array.isArray(_0x87271d686b8f?.rows) ? _0x87271d686b8f.rows : [];
    if (_0x927dde073896.length === 0) {
        _0xbfcde6d57529(_0x0e490fe6dc37(68534), true);
        return;
    }
    _0xef4270a9e467();
    _0xbfcde6d57529(`已导出 ${_0x927dde073896.length} 条工作记录。`);
});
_0xc4b167c7218c.copyRecordsBtn.addEventListener(_0x0e490fe6dc37(68587), () => {
    _0x964136e20c9e(_0xd48061d447d5(), _0x0e490fe6dc37(68507));
});
_0xc4b167c7218c.copyLogBtn.addEventListener(_0x0e490fe6dc37(68587), () => {
    _0x964136e20c9e(_0x51eb2df3fac6(), _0x0e490fe6dc37(68404));
});
_0xc4b167c7218c.clearLogBtn.addEventListener(_0x0e490fe6dc37(68587), async () => {
    const _0x991e0eab4a88 = window.confirm(_0x0e490fe6dc37(68594));
    if (!_0x991e0eab4a88) {
        return;
    }
    const _0x5333d5dc58c8 = await _0x2509c9f74433(_0x0e490fe6dc37(68625));
    if (_0x5333d5dc58c8?.ok) {
        _0x33fc584411c8 = [];
        _0xdfc487d136b6();
        _0xbfcde6d57529(_0x0e490fe6dc37(68535));
    }
});
chrome.runtime.onMessage.addListener((_0xbc536403f5fa) => {
    if (_0xbc536403f5fa?.type !== _0x0e490fe6dc37(68572)) {
        return;
    }
    _0xe5537930e2be({ [_0x0e490fe6dc37(68378)]: Boolean(_0xbc536403f5fa[_0x0e490fe6dc37(68378)]) }, !_0xbc536403f5fa[_0x0e490fe6dc37(68378)]);
});
chrome.storage.onChanged.addListener((_0x42dc6b1d4d02, _0x988235bbd026) => {
    if (_0x988235bbd026 !== _0x0e490fe6dc37(68526)) {
        return;
    }
    if (_0x42dc6b1d4d02[_0x925584c80755.RUN_STATE]) {
        _0x87271d686b8f = _0x42dc6b1d4d02[_0x925584c80755.RUN_STATE].newValue || null;
        _0xfc74f966c46f();
    }
    if (_0x42dc6b1d4d02[_0x925584c80755.LOGS]) {
        _0x33fc584411c8 = Array.isArray(_0x42dc6b1d4d02[_0x925584c80755.LOGS].newValue)
            ? _0x42dc6b1d4d02[_0x925584c80755.LOGS].newValue
            : [];
        _0xdfc487d136b6();
    }
    if (_0x42dc6b1d4d02[_0x925584c80755.SETTINGS]) {
        _0xb044acebd3e6 = _0x42dc6b1d4d02[_0x925584c80755.SETTINGS].newValue || { orderIntervalSeconds: 30 };
        if (!(_0x87271d686b8f && _0xe5042edae8a3.has(_0x87271d686b8f.mode))) {
            _0xc4b167c7218c.orderIntervalSeconds.value = String(_0xb044acebd3e6.orderIntervalSeconds ?? 30);
        }
    }
    if (_0x42dc6b1d4d02[_0x925584c80755.CART_LOCK]) {
        _0x14e6dfe6c7b0 = _0x42dc6b1d4d02[_0x925584c80755.CART_LOCK].newValue || null;
        _0xd595cbd22506();
    }
});
async function _0x0fd67596a060() {
    const _0xc68ae2b9a84c = await _0x2509c9f74433(_0x0e490fe6dc37(68392));
    const _0x8cb35835367d = _0xc68ae2b9a84c?.data || {};
    _0x87271d686b8f = _0x8cb35835367d[_0x925584c80755.RUN_STATE] || null;
    _0x33fc584411c8 = Array.isArray(_0x8cb35835367d[_0x925584c80755.LOGS]) ? _0x8cb35835367d[_0x925584c80755.LOGS] : [];
    _0xb044acebd3e6 = _0x8cb35835367d[_0x925584c80755.SETTINGS] && typeof _0x8cb35835367d[_0x925584c80755.SETTINGS] === _0x0e490fe6dc37(68577)
        ? _0x8cb35835367d[_0x925584c80755.SETTINGS]
        : { orderIntervalSeconds: 30 };
    _0x14e6dfe6c7b0 = _0x8cb35835367d[_0x925584c80755.CART_LOCK] || null;
    _0xc4b167c7218c.orderIntervalSeconds.value = String(_0xb044acebd3e6.orderIntervalSeconds ?? 30);
    _0xcdb4e378d26c = _0xd35dcbdcd385(Array.isArray(_0x8cb35835367d[_0x925584c80755.DRAFT_ROWS]) ? _0x8cb35835367d[_0x925584c80755.DRAFT_ROWS] : []);
    _0x277ef4322b11();
    _0xfc74f966c46f();
    _0xdfc487d136b6();
    _0xe5537930e2be(_0xc68ae2b9a84c?.[_0x0e490fe6dc37(68621)] || { [_0x0e490fe6dc37(68378)]: false }, true);
}
setInterval(() => {
    if (_0x87271d686b8f?.phase === _0x0e490fe6dc37(68582)) {
        _0xb8af070ad499();
    }
}, 1000);
_0x0fd67596a060().catch((_0x3661d3259c51) => _0xbfcde6d57529(_0x3661d3259c51.message || String(_0x3661d3259c51), true));})();
