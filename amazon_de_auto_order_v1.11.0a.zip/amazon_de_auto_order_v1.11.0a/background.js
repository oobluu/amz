(()=>{'use strict';const _0x49c2345bccaa=Object.freeze(["/aGe/4qS/5eP87ie/Lma/IW//5Kd/Je4/4+c/4mb/Lqd/bek87uv","/Le5/6aV/5C68q63/5OX/5WL/ZSq/62o/IaT/aGe/4qS/5eP8q63/ZOz/bW0/7ST/5+y846b+ZqY","/qGh/5C7/62o/5uG/Le49aaBWVtITkVYT1NWXlNUXTr/tJP/n7Lzjpv+oZf+pYf9j4P5mpjyta3+oKD/rb/8uZr8hb/yrrf9k7P9tbT8koz8hprypYvytLj/l4//ipT1ppb+p6X9jrL4mob9ob39obf/p4n/k5f8t7/zsL74mof8op/zg77zm439j4Pzjpv5mpg=","/62o/Lqi/7Wj8q63/ZOz/bW0/Jqh/I+q852V9aaW/Le5/4ay8qWB/5+//qKR/5eP87uv84e4","8qSJ/5+/8ruy/Lqm/qWH/Jab/5SF/72R87ug/6CV9aaB/4aq/4ea/aGe/JaT/5+s/4ay8ruy/Lqm/qK3/Iaa/I2z/52g/ZSq/YCe8ruW/5Wt/qGU/qKQ/6Sa/qKR/76e/Yqc+ZqY","/6eJ/5OX/Ki7/IaT/62o/ICY/5uG/qGh/5C7+ZqY","/Le5/6aV/5C6/5+/8q63/ZOz/bW09aaA/Le5/4ay/JOJ/6aa/ZG2/bGR/4+c/4mb/Lqd/bek87uv","dXdzbg==","WVVUXFNIV0VKW0NXX1RORVdfTlJVXg==","/7eC/4ay/Iaw/KKf84O+/YCe/aGe/4qS/5eP8q63/ZOz/bW0/7ST/5+y846b9aaW/qKX8pmn/4q1/5Cy852X/qKR/qGh/5C7+ZqY8rWt/5+S/qCg/62//Lma/IW//4qU/qel/Y6y+JqG/aG9/aG3/6eJ/5OX/Le/87C++JqH/KKf84O+85uN/Y+D846b+ZqY","/aGe/4qS/5eP87ie/Lma/IW//5OX/Le5/4ay/bu08rS+8q63/ZOz/bW0/qKg/bOg","/Le5/6aV/5C68q63/5OX/YCe/4+c/4mb/4qx/bKU/5eP/qGt/qKX/IK1OviYtig0Kir5mpg=","/JOk/qKX/5Kq/52c/76d/76e/Yqc/YCe/4aq/4ea/aGe+ZqY","SF9MW1ZTXltOX0VbT05SVUhTQFtOU1VU","T3R7eHZ/Om51OnVqf3Q6ant0f3Yg","bXtodHN0fQ==","/beT/6Sf852X/qKR","SU5VSkVIT1Q=","/aGe/4qS/5eP/4+c/4mb87ie/Lma/IW//Iaw85qA8qWd","WVJfWVFFWVtITkVYX1xVSF9FSkhfWVJfWVE=","f2hodWg=","cigp","SVtMX0VJX05OU1RdSQ==","TVtTTkVKSFVeT1lO","WF9cVUhfRVxTVFtWRUlPWFdTTg==","SF9OSENFSVFTSkpfXkVIT1Q=","W0lTVA==","/qKR/5eP842u84CO/aGJ/IeF9aaW/6aa/72R/76e/Yqc/qKR/qKa/qKw/4aq/4ea/aGe+ZqY","852X/qKR/I+q/Je0/qK3/Ki7/IaT/5W1/aG9/aG3/qKR/5eP/YCe/IaT/I+S/4aq/4ea/aGe9aaW/qGh/5C7/aGJ/IeF+ZqY","e3d7YHV0NH5/","/Le5/6aV/5C6/5+/8q63/ZOz/bW09aaA/Le5/4ay/76e/Yqc/ba2K/K7lv+PnP+Jmw==","/6Sf/76e/Yqc","/aGe/4qS/5eP/6Os84eE/JOa/IaT8ruW85mn/62o/7SW/JKK87ie/Lma/IW//4iW/5C6/5+/8q63/ZOz/bW0+ZqY","X29odWp/NVh/aHZzdA==","/aGe/4qS/5eP87ie/Lma/IW//4GE/qa6/YCe/I+q852V/I26/I+S+ZqY","/Le5/6aV/5C68q63/4GE/qa6/YCe/I+q852V/qKU/YG0/Lqd/I+q852V/qKX/qKa8p2u+ZqY","/qCg/62//ICY/5uG","SVFTSkVZT0hIX1RORVdbVE9bVg==","/6eJ/5OX/qKX/IK1/aGe/4qS/5eP+ZqY","eXJ/eXF1b24=","SF9ZVUxfSEVZW0hORVhPU1ZeU1RdRVZVWVE=","/62o/5uG/Le49aaS/aGe/4qS/5eP8q63/ZOz/bW0846b/qGX/qWH/Y+D9aaT","aH97fmM3bnU3eXJ/eXF1b24=","SU5bSE5FSE9U","/7eC/4ay/Iaw/KKf84O+/YCe/aGe/4qS/5eP8q63/ZOz/bW0/7ST/5+y846b+ZqY8rWt/5+S/qCg/62//Lma/IW//4qU/qel/Y6y+JqG/aG9/aG3/6eJ/5OX/Le/87C++JqH/KKf84O+85uN/Y+D846b+ZqY","SVtMX0VeSFtcTkVIVU1J","/aGe/4qS/5eP87ie/Lma/IW//5OX/bu08rS+8q63/ZOz/bW0/I+q852V/qKgKvmamA==","/5Ww/IaT/qGh/5C7/62o/7SW/JKK/JKM/62o/5uG/Le4/4qU9aaW/JOX8pmn852X/qKR/JOa/IaT8q2p8qWd/5eP+ZqY","eG9zdn5zdH0=","e3Z2N2lxc2pqf34=","e29ucnVoc2B/fg==","/Le5/4ay/JOJ/6aa/4+c/4mb87uv84e4","XUhVT0pFSkhfWVJfWVFFSkhVXk9ZTg==","/6eJ/5OX/Ki7/IaT/5W1/5uG/Le4/YCe/qGh/5C7+ZqY","/Iaw/YW/","TVtTTkVdSFVPSkVbXl5FSF9JT1ZO","/JOk/qKX/5Kq/6eJ/5OX/4aq/4ea/aGe+ZqY","fn83Xl8=","W09OUlVIU0BbTlNVVEVZUltUXV9e","XUhVT0pFSkhVWV9fXkVZUl9ZUVVPTg==","TVtTTkVZUltUXV9FW15eSF9JSQ==","Kg==","/Iaa/aGS/JWK/qC+/5OX/Ki7/IaT/IaT/I+S/YCe/aik/52c/I+q852V/Lq787CW8rSq/6eP+ZqY","/Y6y/JKt/62o/qCg/62//Lma/IW//Iaa8qWL8rS4/5eP/6Os/KKf84O+/aGe/4qS/5eP846b9aaW/qGh/5C7/qWH/Jab/5uG/Le4","/Ki7/IaT84aa8ryb/qKR/5eP/YCe/IaT/I+S/4aq/4ea/aGe9aaW/qGh/5C7/aGJ/IeF+ZqY","/62//qeG/Lqd/bek87uv/qKX/7eC/4ay+ZqY","/aGe/4qS/5eP/Le5/6aV/5C68q638ruW/a64/6aP/62o/aGV/5WC/5aM+ZqY","/5Kd/Je4/5Kq/qKR/qKa/qKw/4aq/4ea/aGe/Lqd/bek87uv","/Lma/K+R/5Kq/qKU/6eJ/5OX/4aq/4ea/aGe/qKX/5aj85+X/YCe/aGe/4qS/5eP/7ST/5+y846b9aaW/qKX8pmn8p2w/5Cy8q2p8qWd+ZqY8rWt/5uG/Le4/qGh/5C7/6Os/qCg/62//Lma/IW//4qU/qel/Y6y+JqG/aG9/aG3/6eJ/5OX/Le/87C++JqH/KKf84O+846b+ZqY","W3h1aG5faGh1aA==","eH98dWh/N3xzaGluN3t+fg==","anVqb2o=","/7eC/4ay/Iaw/KKf84O+/YCe/aGe/4qS/5eP8q63/ZOz/bW0/7ST/5+y846b+ZqY8rWt/5+S/qCg/62//Lma/IW/8q63/ZOz/bW0/JKM/Iaa8qWL8rS4/5eP9aaW/5yX/qel/Y6y+JqG/aG9/aG3/6eJ/5OX/Le/87C++JqH/KKf84O+85uN/Y+D846b+ZqY","/Iaa/aGS/JWK/qC+/5OX/Ki7/IaT/IaT/I+S/YCe/4+c/4mb/4qx/bKU/5eP/qGtOviYtig0Kio6/Lq787CW8rSq/6eP+ZqY","WVZfW0hFVlVdSQ==","/qCg/62/8q2p8qWd","TkhbVElTTlNVVFNUXQ==","e3dgN3Vofn9oN3N0bn9obHt2IA==","TF9IU1xDRUpbQ1dfVE5FVFtXXw==","/Le5/6aV/5C68q63/4GE/qa6/YCe/4+c/4mb/4qx/bKU/5eP/qGt/qKX/IK1OviYtig0Kir5mpg=","/qGh/5C78qWK8ruW/IaF842u/qKX8pmn/qW0/I6j8qSJ/5+//I+q/Je0+ZqY","XV9O","/Le5/4ay/JWK/qC+8rS4/5eP9aaS/beT/6Sf8pSt/5WMOlVofn9oOlNe9aaT","Zg==","/JOa/IaT/IaT/I+S/4aq/4ea/aGe/76e/Yqc/7SW/JKK+ZqY","/aGe/4qS/5eP87ie/Lma/IW/85qA8qWd","+Zqb","SF9LT19JTkVcW1NWX14=","Og==","/5eP8ruW/4aq/4ea/aGe/aG9/aG3/qel/Y6yOlhvYzpUdW31poH/ipb/vYn/ipf+oo7/tJb8j67/hqr/h5r9gaL/ipb9gJ7/voDyu5b/hqr/h5r9oZ7+p6X9jrI6W35+Om51Onh7aXF/bjr/ipL/o6z+opH/l4/5mpg=","87ie/Lma/IW//7eC/4ayOk5/d286VWh+f2g6U146/4aq/4ea/JKM/bek/4qX/5yo/bCb9aaW/qKX8pmn/YGu/JS//aG9/aG3+ZqY8rWt/5uG/Le4/qGh/5C7/6Os/qW0/I6j8qSJ/5+//I+q/Je0+ZqY","TVtTTkVTVE5fSExbVg==","/qGh/5C78qWK8ruW/IaF842u/qKX8pmn/KKf/bOg8qSJ/5+//I+q/Je0+ZqY","/7eC/4ay/Iaw/KKf84O+/YCe/aGe/4qS/5eP8q63/ZOz/bW0/7ST/5+y846b9aaW/qGh/5C7/Iaw/4q1/5Cy+ZqY8rWt/5+S/qCg/62//Lma/IW/8q63/ZOz/bW0/JKM/Iaa8qWL8rS4/5eP9aaW/5yX/qel/Y6y+JqG/aG9/aG3/6eJ/5OX/Le/87C++JqH/KKf84O+85uN/Y+D846b+ZqY","/Ki7/IaT/5W1/76e/Yqc/YCe/I+q/Je08ruW+ZqY","/aGe/4qS/5eP87ie/Lma/IW/9aaA/Le5/4ay/Lqi/7Wj/4+c/4mb","Tn93bzpVaH5/aDpTXv+nif++s/+tqP6ikfKlnf+Xj/WmlvKtqfKlnQ==","/qGh/5C7/62o/5uG/Le49aaB/6eJ/5OX8rS4/5eP/aGJ/ISG/qGX/Iaw/bu08rS+9aaW/qKO/qKX/qaA/5yD/5+//6eJ/76z84Ko852X/76X8rSq/6eP+ZqY","TVtTTkVbXl5IX0lJRVxVSFc=","eHZ1eXF/fg==","XUhVT0pFSkhfWVJfWVFFXFtTVg==","dXhwf3lu","/qGh/5C78qWK8ruW/IaF842u/qKX8pmn/KKf/bOg/6eJ/76z/qKR/5eP8rSq/6eP+ZqY","/Le5/4ay/qKg/qKR/qKa/qKw/4aq/4ea/aGe/5KB/6Gg/ZG2/bGR/62//qeG/Lqd/bek87uv9aaB/4qU/5Wq/aGL/7SA/Iyq/Lqd/bek/4qU/5+p8423/qKQ/qKa/aGe/Lqd/bek87uv+ZqY","/aGe/4qS/5eP/Le5/6aV/5C68q63/5OX/5yX/La7/bu08rS+8q63/ZOz/bW0/I+q852V/qKgKvWmgf+tqP+hoP2xkTpZW0hORVhPU1ZeU1RdOv+0k/+fsvOOm/mamA==","/qGh/5C7/aG9/aG3/JO98ruW+ZqY","XV9ORVlVVE5fQk4=","VWh+f2g6U146/Lqm/6aV/I26/I+S+ZqY","/qGh/5C7/ZOS/Ia2/62o/aGV/5WC/5aM+ZqY","KDd+c31zbg==","f3Q3XVg=","aG90dHN0fQ==","SltdX0VWVV0=","/62o/5uG/Le49aaS8rS4/5eP/aGJ/ISG/Iaw/bu08rS+9aaT","/aGe/4qS/5eP/6aa/72R87ie/Lma/IW//5OX+Zqb/Le5/6aV/5C68q63/5OX+Zqb/LWV/La7/5C68q63/4qU/4iWOkpodXl/f346/5OX/4ed/Lqi/7Wj8q63/ZOz/bW0/I+q852V+ZqY","XUhVT0pFU05fV0VbXl5fXg==","/7eC/4ay/Iaw/KKf84O+/YCe/aGe/4qS/5eP8q63/ZOz/bW0846b9aaW/qKX8pmn/KKf/bOg/qGh/5C78rSq/6eP+ZqY","852X/qKR/qGh/5C7/qK39aaW/5eP8ruW/qel/Y6yOlhvYzpUdW31poH/ipb/vYn/ipf/ipb/tJb8j67/hqr/h5r9gJ7/voDyu5bznZf8jKr9oZ78koryrrf9k7P9tbT9oZ7/ipL/l4/5mpg=","/4qW/4aq/4ea/aGe/4qS/5eP/7eC/4ay/6aY/6Ki9aaW/I+u/aGe8q2p8qWd","W3d7YHV0Ov+tv/6nhvy6nf23pPO7r/+tqP+fqfONt/Wmgf2hnv+Kkv+Xj/Kut/2Ts/21tPOOm/6hl/6lh/2Pg/WmlvK1rf6goP+tv/y5mvyFv/Kut/2Ts/21tP+IlvK0uP+Xj/mamA==","eXV3anZ/bn9+","/Y6y/JKt/62o/qCg/62//Lma/IW/8q63/ZOz/bW0/6Os/KKf84O+/aGe/4qS/5eP846b9aaW/qGh/5C7/qWH/Jab/5uG/Le4","SltPSV9FX0hIVUg=","/62o/5WM/6SN/aGe/4qS/5ePOlVofn9oOlNe9aaWWVtITkVYT1NWXlNUXTr/tJP/n7Lzjpv/rajynbD/kLL8op/zg775mpg=","/6eJ/5OX/62//qeG8rSq/6eP/qK3/Ki7/IaT/5W1852X/qKR/YCe8q2p8qWd8ruW+ZqY","/6eJ/5OX/qGh/5C7/qKX/76e/qCU/5W1/ICY/5uG/ZCs/Jqb+ZqY","/aGe/4qS/5eP/qaA/5+S/7SW/I+u87ie/Lma/IW//5+y/aGe9aaB/qGh/J6V/qKa8ruW84aa8ryb8q2p8qWd/I2s9aaW/I+u/qKw/4aq/4ea/aGe/qKX/qKR/5eP+ZqY","TVtTTkVKW0NXX1RO","SltPSV9FSE9U","/Ia2/La7852X/qKR/JaT/Y6y/JKt8rSk/7SA/aGP8qWdOk5/d286VWh+f2g6U146/6eJ/76z/JKK/5CF8rSq/6eP9aaW/5af/JG28rS4/5eP/aGJ/ISG/Iaw/bu08rS+/YCe/qCg/62/8q2p8qWd8ruW9aaB/62o/5WM/6SNOlVofn9oOlNeOv2AnvySiv+QhfK7lv6lh/yWm/6il/+VgvmamA==","dHU3aW51aH8=","dWh+f2g3aH9sc39t","fHtzdn9+","cm5uamkgNTV7dHt0NysoLyMqIy8iIik0eXVpNH9vN3xoe3RxfG9objR3Y2t5dnVvfjR5dXc1KzV7b251dWh+f2g0cm53dg==","/5ed/aC9/4qU/62o/5uG/Le4/I29/ZOS/Iaw/aGJ/IeF/qGh/5C79aaW8rWt/qCg/62//bu08rS+/IK1/4q8/62o/qC9/Y6F8rS4/5eP+ZqY","XV9ORVtWVkVeW05b","antvaX9+","aW51amp/fg==","87uv84e4/ZCs/Jqb/6aY/6Ki+ZqY","/aGe/4qS/5eP87ie/Lma/IW/8ruW/a64/6aP/62o/aGV/5WC/5aM+ZqY","SkhfWVJfWVFFWVVUXFZTWU4=","/aGe/4qS/5eP87ie/Lma/IW/9aaA/Le5/4ay/JOJ/6aa/ZG2/bGR/4+c/4mb/Lqd/bek87uv","/aGe/4qS/5eP/Le5/6aV/5C68q63/5Kd/Je4/4+c/4mb/Lqd/bek87uv","8q2p8qWd","VUheX0hfXg==","eXtobjdof2xzf20=","e3dgW29udVVofn9oW29ucnVoc2B7bnN1dA==","ant0f3Y0cm53dg==","bmh7dGlzbnN1dHN0fQ==","W1dAOnZzdHH8jbr8j5L1ppbyranypZ0=","/62o/5uG/Le4","/aGe/4qS/5eP/5+y85my/4+c/4mb87ie/Lma/IW/85qA8qWd9aaW/52c/76d/4ay/Iyq/YCe/ba2/qKa/qGs/4+c/4mb/Lqd/bek87uv/5yX/La7/Lma/IW/8q63/ZOz/bW0/qKg/bOg+ZqY","WXJodXd/OvyGsPKljv+BhPyMqv+tv/6nhvy6nf23pPO7rzpTXvmamA==","/KyS/Ju1/qKX/IK1/Ie/8p2w/6eJ/5OX/62//qeG/Lqd/bek87uv+ZqY","/aG9/aG3/JO98ruW/aGe/4qS/5eP/6eJ/5OX/Le/87C+","/aGe/4qS/5eP8q63/ZOz/bW0/7ST/5+y846b/I26/I+S+ZqY","/aGe/4qS/5eP8q63/ZOz/bW0/7ST/5+y846b/62o/qKX/7eC/4ay9aaW/qKX8pmn/aG9/aG3/6eJ/5OX/qGh/5C7+ZqY8rWt/5uG/Le4/4qU852X/Iyq/6aa/72R+ZqY","e3h1b24geHZ7dHE=","WVJfWVFFW09OUlVIU0BbTlNVVA==","VFxRWQ==","/qGh/5C7/aG9/aG3/JO98ruW9aaW/qKR/5eP842u84CO8rS7/I2s/Ju4/76X+ZqY","/5+p8423/Iaa/4qU/qKa/qKw87ie/Lma/IW//4+c/4mb/Lqd/bek9aaW/6Os/qKg/Le5/6aV/5C68q63/ba2/qKa/qGs/4+c/4mb/JOJ/6aa/Iyq/YCe/ZG2/bGR/Lqd/bek87uv+ZqY","XUhVT0pFW15eRUpIVV5PWU4=","WVVXSlZfTl9e","W3d7YHV0Ov+tv/6nhvy6nf23pPO7r/+tqP+fqfONt/Wmlv+nif+Tl/OCrPy0r/6il/KZp/+0k/+fsvKdsP+QsvybuP++l/mamPK1rf6goP+tv/y5mvyFv/+KlP+bhvy3uP6hof+Qu/WmgfKRv/yGk/2hnv+Kkv+Xj/OOm/WmlvK1rf27tPK0vvKut/2Ts/21tP+IlvK0uP+Xj/+KlPyin/ODvvmamA==","TVtRX0VbT05VV1tOU1VU","TVtTTkVbXl5IX0lJRUhfSU9WTg==","amh1eX9paXN0fQ==","/aG9/aG3/JO98ruW/6eJ/5OX/Le/87C+","aH97fmM=","SV9WX1lORUpbQ1dfVE5FWVtIXg==","/Le5/4ay/JWK/qC+/aGe/4qS8rS4/5eP9aaS/beT/6Sf8pSt/5WMOlVofn9oOlNe9aaT","","/Iaa/aGS/JWK/qC+/5OX/YCe/I6s/qGs/qCg/72J/4qX/qKU/6eJ/5OX/4aq/4ea/aGe/qKX/qKa8p2u+ZqY","SVFTSkVIVU0=","e3dgWXtoblhvc3Z+c3R9VnV5cQ==","/5Kd/Je4/5Kq/qKR/qKa/qKw/4aq/4ea/aGe/Lqd/bek87uv/76r8q6/+ZqY","/6eJ/5OX/qGh/5C7/qGX/76e/qCU/ICY/5uG/ZCs/Jqb+ZqY84aa8ryb/aG9/aG3/5SF/Le/87C+8rWt/YGu/JS//aG9/aG39aaB84aa8ryb/I6k/6aZ/6eJ/5OX/aGe/4qS/5eP8rWt/Zij/52h+JqG8q2p8qWd/6eJ/5OX8ruW+JqH9aaB84aa8ryb/qGf/KKf84O+85uN/Y+D846b8rWt/5+S/5uG/Le4/qGh/5C7+ZqY","/qGh/5C7/62o/qCg/62//ICY/5uG+ZqY","/JOk/qKX/5Kq/6eJ/5OX/I+q/Je08ruW/JKM/4aq/4ea/aGe+ZqY","dG93f2hzeQ==","W09OUkVcW1NWX14=","XUhVT0pFWVtITkVfV0pOQw==","fHN0e3Y3aW94d3Nu","e3dgVWh+f2hSc2ludWhj","/aGe/4qS/5eP87ie/Lma/IW//7SW/JKK","/qW7/Ju1/qKX/7SW/I+u9aaW8q2p8qWd","WVZfW0hFTlVeW0NFVUheX0hFSF9ZVUheSQ==","WVVUTlNUT19FSE9U","/6eJ/5OX/Ki7/IaT/aGe/4qS/5eP8q63/ZOz/bW0/7ST/5+y846b+ZqY","NHt3e2B1dDR+fw==","eHV1dn97dA==","/I26/KmP/7ST/JSI/qKR/5eP842u84CO9aaA/qGh/5C7OlNeOv6il/+3gv+GsvmamA==","/aGe/4qS/5eP87ie/Lma/IW//4GE/qa6/YCe/4+c/4mb/5eP/qGt/I26/I+S+ZqY","TVtTTkVXW1RPW1ZFW15eSF9JSQ==","SV9ORUpSW0lf","/qGh/5C7/ZCs/Jqb/62o/aGV/5WC/5aM+ZqY","YHI3WVQ=","aW95eX9paQ==","W3d7YHV0Ov+tv/6nhvy6nf23pPO7r/+tqPK4sf+fqfONt/mamA==","/Le5/6aV/5C6/5+/8q63/ZOz/bW09aaA/Le5/4ay/Lqi/7Wj/4+c/4mb","an90fnN0fQ==","/6eJ/5OX/Ki7/IaT/qGh/5C7+ZqY","852X/qKR/4aq/4ea/aGe/qGX/JaT/5+s/4ay/6eJ/5OX8qSJ/5+/8ruy/Lqm/qK3/Iaa/I2z/52g/ZSq/YCe8ruW/5Wt/qGU/qKQ/6Sa/qKR/76e/Yqc+ZqY","/5Kd/Je4/4+c/4mb/Lqd/bek87uv","/Lq787CW/76r8q6/9aaW8rWt8puO/amhSXJ7dH17dA==","e3dgVWh+f2hWdX1p","/JOk/qKX/5Kq/aGe/4qS/5eP/6eJ/5OX8ruW+ZqY","TVtTTkVZUl9ZUVVPTg==","c3R8dQ==","/I+q852V/Lqm/6aV846D8rW19aaW8q2p8qWd","XUhVT0pFWF9cVUhfRVteXg==","dHVod3t2","Tn93bzpVaH5/aDpTXv6ioP2zoPWmlvKtqfKlnQ==","/aGe/4qS/5eP/4+c/4mb/62o/5+y85my/5C6/5+/8q63/ZOz/bW09aaW/52c/76dOkpodXl/f346bnU6WXJ/eXF1b24=","RWw=","WVZfW0hFXkhbXE5FSFVNSQ==","e3dgTn93b1Vofn9oU3R+f2I=","e3dgVWh+f2heaHt8bkh1bWk=","/aGe/4qS/5eP8q63/ZOz/bW0/7ST/5+y846b/qKX/7eC/4ay/JKM/qKU/6eJ/5OX/4aq/4ea/aGe/qKX/qKa8p2u+ZqY","/beT/6Sf842u84CO/IaF842uOlt3e2B1dDr/rb/+p4b8up39t6Tzu6/yuLH/n6nzjbf1poHzja7zgI79oYn8h4X/ipT/qpzynbD/kLL/koH/oaD8jKr8up39t6Tzu6/5mpg=","e3dgVWh+f2hIb3RJbntufw==","/5ed/aC9/4qU/qGh/5C7/62o/5uG/Le49aaW8rWt/qCg/62//Lma/IW//6eJ/5OXOlt3e2B1dDrzu6/zh7g=","/JOk/qKX/5Kq/6eJ/5OX/qKR/5eP/aGe+ZqY","/qGh/5C7/62o/5uG/Le4+ZqY","/Le5/6aV/5C68q63/5OX/YCe/I+q852V/qKU/YG0/Lqd/I+q852V/qKX/qKa8p2u+ZqY","RW4=","e3dgVWh+f2hJf25uc3R9aQ==","TlNXX1VPTg==","VUheX0hFSU9ZWV9JSQ==","SU5VSkpfXg==","/qKR/5eP/JKK/5CF","/I26/KmP/5KB/6GgOlt3e2B1dDr/rb/+p4b8up39t6Tzu6/5mpg=","/62o/IaT/Iaw/aGJ/IeF/qGh/5C7+ZqY8rWt/qel/Y6y/aG9/aG3+Zqb8q2p8qWd/6eJ/5OX8ruW/JKM/5uG/Le4/JaT84i0/76e/Yqc/ZSq/IaT/qGh/5C7+ZqY","/5Ww/IaT/qGh/5C7/76e/qCU/ICY/5uG/ZCs/Jqb/I2s9aaW/JOX/5+b8rSi/qCg/62/8q2p8qWd/6eJ/5OX8ruW+ZqY","WVJfWVFFWVtITkVYX1xVSF9FWE9TVl4=","/LWV/5eP842u84CO/6Wf87uh/IK1Oir4mokpLCoqOv2AnvyPrvyPqvmamA==","/qGh/5C7/6eJ/5OX/Iaw8qWK8ruW+ZqY","aXFzamp/fg==","TVtTTkVVSF5fSEVJT1lZX0lJ","/aGe/4qS/5eP87ie/Lma/IW//7SW/JKK9aaW/Le5/6aV/5C68q63/5OX852X/Iyq/bu08rS+8q63/ZOz/bW0/qKg/bOg","TVtTTkVVSF5fSEVSU0lOVUhD","XUhVT0pFWF9cVUhfRUpIVVlfX14=","e35+c3R9N3Nuf3c=","/Lma/K+R/5Kq/Iaw/KKf84O+/YCe/aGe/4qS/5eP8q63/ZOz/bW0846b9aaB/Iyq/qGh/5C7/qaA8rix84Kh/Le49aaW/YGu/5Kq/qCg/62//Lma/IW//6Os/KKf84O+8rW/846b+ZqY","e2lzdA==","TVtTTkVbXl5FW15eSF9JSUVbXE5fSEVZUltUXV8=","/qGh/5C7/qGX/4ay8qWK8ruW9aaW/qKX8pmn/KKf84O+/aGe/4qS/5eP8q63/ZOz/bW0846b+ZqY8rWt/5+S/ICY/5uG/JKM/5uG/Le4/qGh/5C7+ZqY","/aGe/4qS/5eP/62o/aGV/6aa/72R/ISe/6Gg8q63/ZOz/bW09aaW8p2w/5Cy/K+b/bKR/qKX8pmn/YGu/JS/8q2p8qWd9aaB8rWt/ICY/5uG/4qU/qCg/62//Zij/52h+JqG8q2p8qWd/6eJ/5OX8ruW+JqH+ZqY","/aGe/4qS/5eP/JKK/5CF8rSq/6eP/5OX8q63/ZOz/bW0/7ST/5+y846b/qKX/7eC/4ay/JKM/qKX/5aj85+X+ZqY","/aGe/4qS/5eP/qGU87ie/Lma/IW//5Kd/Je4/5Kq/Le5/6aV/5C68q63","XUhVT0pFSkhfWVJfWVFFSltJSQ=="]);const _0xc3e73de7c78c=[];const _0xe35052e1b716=26;let _0xda87c8d76b6e=_0xe35052e1b716>>>0;for(const _0xv of _0x49c2345bccaa)_0xda87c8d76b6e=(((_0xda87c8d76b6e*131)>>>0)+_0xv.length)>>>0;const _0x8f7f743a3ed0=1280198082>>>0;if(_0xda87c8d76b6e!==_0x8f7f743a3ed0)throw 0;function _0x7a039088cb40(_0xi){if(_0xc3e73de7c78c[_0xi]!==undefined)return _0xc3e73de7c78c[_0xi];const _0xb=atob(_0x49c2345bccaa[_0xi]);const _0xu=new Uint8Array(_0xb.length);for(let _0xj=0;_0xj<_0xb.length;_0xj++)_0xu[_0xj]=_0xb.charCodeAt(_0xj)^_0xe35052e1b716;return _0xc3e73de7c78c[_0xi]=new TextDecoder().decode(_0xu);}
'use strict';
const _0xcaf96649348b = Object.freeze({
    RUN_STATE: _0x7a039088cb40(221),
    HISTORY: _0x7a039088cb40(184),
    ORDER_INDEX: _0x7a039088cb40(217),
    CART_LOCK: _0x7a039088cb40(175),
    LOGS: _0x7a039088cb40(206),
    DRAFT_ROWS: _0x7a039088cb40(218),
    SETTINGS: _0x7a039088cb40(227),
    AUTHORIZATION: _0x7a039088cb40(146)
});
const _0xf0715585cf3d = Object.freeze({
    orderIntervalSeconds: 30
});
const _0xe49f547ce0e9 = 3000;
const _0xa44b032669e9 = 3000;
const _0x2098732dc69d = new Set([_0x7a039088cb40(111), _0x7a039088cb40(136), _0x7a039088cb40(148)]);
const _0x8c713513dd6a = new Set([_0x7a039088cb40(239), _0x7a039088cb40(241)]);
const _0xf1737035e986 = new Set([
    _0x7a039088cb40(162),
    _0x7a039088cb40(55),
    _0x7a039088cb40(59),
    _0x7a039088cb40(208),
    _0x7a039088cb40(170),
    _0x7a039088cb40(60),
    _0x7a039088cb40(246),
    _0x7a039088cb40(98),
    _0x7a039088cb40(166),
    _0x7a039088cb40(194),
    _0x7a039088cb40(127),
    _0x7a039088cb40(8),
    _0x7a039088cb40(78),
    _0x7a039088cb40(239),
    _0x7a039088cb40(241)
]);
const _0x07566f65198c = new Set([
    _0x7a039088cb40(55),
    _0x7a039088cb40(59),
    _0x7a039088cb40(208),
    _0x7a039088cb40(170),
    _0x7a039088cb40(60),
    _0x7a039088cb40(246),
    _0x7a039088cb40(98),
    _0x7a039088cb40(166),
    _0x7a039088cb40(194),
    _0x7a039088cb40(127),
    _0x7a039088cb40(8),
    _0x7a039088cb40(78),
    _0x7a039088cb40(239),
    _0x7a039088cb40(241)
]);
const _0xef695cb59b4e = _0x7a039088cb40(77);
const _0xf35c9f1e6c78 = /^\d{3}-\d{7}-\d{7}$/;
const _0x72caa2d2f815 = 12;
const _0x58ad35219aee = Object.freeze({
    endpoint: _0x7a039088cb40(133),
    cacheMs: 8 * 60 * 60 * 1000,
    timeoutMs: 10000,
    expectedStatus: 200,
    failureMessage: _0x7a039088cb40(205)
});
let _0x05770b7b7df8 = null;
let _0x19be163329fb = null;
let _0x0e349d74e58a = Promise.resolve();
const _0xd416afc168a8 = new Map();
function _0x349a83340562(_0xca2600a70d23) {
    const _0x47d8a4ab841c = _0x0e349d74e58a.then(_0xca2600a70d23, _0xca2600a70d23);
    _0x0e349d74e58a = _0x47d8a4ab841c.catch(() => undefined);
    return _0x47d8a4ab841c;
}
function _0x683e37adebc3() {
    const _0xd99122daf551 = chrome.runtime.getManifest();
    return String(_0xd99122daf551.version_name || _0xd99122daf551.version || _0x7a039088cb40(61));
}
function _0x91c146735fd9(_0xd4a378db8985) {
    return { authorized: _0xd4a378db8985?.status === _0x7a039088cb40(50) };
}
function _0xf44bed8d3ead(_0xd5aa1e89417a, _0x263e5740d3b1 = Date.now()) {
    return Boolean(_0xd5aa1e89417a &&
        _0xd5aa1e89417a.status === _0x7a039088cb40(50) &&
        _0xd5aa1e89417a.version === _0x683e37adebc3() &&
        Number(_0xd5aa1e89417a.expiresAt) > _0x263e5740d3b1);
}
async function _0xc7b5985553f5(_0x4977d0f9a9f2) {
    if (_0x19be163329fb === _0x4977d0f9a9f2) {
        return;
    }
    _0x19be163329fb = _0x4977d0f9a9f2;
    try {
        await chrome.runtime.sendMessage({
            type: _0x7a039088cb40(58),
            authorized: Boolean(_0x4977d0f9a9f2)
        });
    }
    catch {
    }
}
function _0x43e4f44b3f3c(_0xd66cf942c7b8, _0x0c8d95dfc14f) {
    if (!_0xd66cf942c7b8 || !_0x2098732dc69d.has(_0xd66cf942c7b8.mode)) {
        return;
    }
    _0xd66cf942c7b8.authorizationBlocked = true;
    _0xd66cf942c7b8.updatedAt = new Date().toISOString();
    if (_0x8c713513dd6a.has(_0xd66cf942c7b8.phase)) {
        _0xd66cf942c7b8.authorizationFailureDeferred = true;
        return;
    }
    _0xd66cf942c7b8.authorizationFailureDeferred = false;
    _0xd66cf942c7b8.mode = _0x7a039088cb40(136);
    _0xd66cf942c7b8.pauseReason = _0x58ad35219aee.failureMessage;
    const _0x9dfa58b7f2f1 = _0x9ee79768b312(_0xd66cf942c7b8);
    const _0xfe786a2cef58 = _0x0c8d95dfc14f?.[_0x0c8d95dfc14f.length - 1];
    if (_0xfe786a2cef58?.message !== _0x58ad35219aee.failureMessage) {
        _0x8d616eca1a29(_0x0c8d95dfc14f, _0x7a039088cb40(20), _0x58ad35219aee.failureMessage, _0x9dfa58b7f2f1?.rowNumber ?? null);
    }
}
async function _0x49b0eebf08ec() {
    const _0xeef154fcb45b = await chrome.storage.local.get([_0xcaf96649348b.RUN_STATE, _0xcaf96649348b.LOGS]);
    const _0xac6279b28ab8 = _0xeef154fcb45b[_0xcaf96649348b.RUN_STATE] || null;
    const _0x72432b3e32db = Array.isArray(_0xeef154fcb45b[_0xcaf96649348b.LOGS]) ? _0xeef154fcb45b[_0xcaf96649348b.LOGS] : [];
    _0x43e4f44b3f3c(_0xac6279b28ab8, _0x72432b3e32db);
    await chrome.storage.local.set({
        [_0xcaf96649348b.RUN_STATE]: _0xac6279b28ab8,
        [_0xcaf96649348b.LOGS]: _0x72432b3e32db
    });
    await _0xc7b5985553f5(false);
}
async function _0xbd267ca75399() {
    const _0xdecb88819d71 = await chrome.storage.local.get(_0xcaf96649348b.RUN_STATE);
    const _0x80e714fc6c93 = _0xdecb88819d71[_0xcaf96649348b.RUN_STATE] || null;
    if (_0x80e714fc6c93?.authorizationBlocked) {
        _0x80e714fc6c93.authorizationBlocked = false;
        _0x80e714fc6c93.authorizationFailureDeferred = false;
        if (_0x80e714fc6c93.pauseReason === _0x58ad35219aee.failureMessage) {
            _0x80e714fc6c93.pauseReason = _0x7a039088cb40(172);
        }
        _0x80e714fc6c93.updatedAt = new Date().toISOString();
        await chrome.storage.local.set({ [_0xcaf96649348b.RUN_STATE]: _0x80e714fc6c93 });
    }
    await _0xc7b5985553f5(true);
}
async function _0x9d690a0f8b92() {
    const _0xd929eb7bf039 = new AbortController();
    const _0xa42617c8ed95 = setTimeout(() => _0xd929eb7bf039.abort(), _0x58ad35219aee.timeoutMs);
    try {
        const _0xe9ecc7265f46 = new URL(_0x58ad35219aee.endpoint);
        _0xe9ecc7265f46.searchParams.set(_0x7a039088cb40(215), _0x683e37adebc3());
        _0xe9ecc7265f46.searchParams.set(_0x7a039088cb40(226), String(Date.now()));
        const _0x1eb9b3df9b0d = await fetch(_0xe9ecc7265f46.toString(), {
            method: _0x7a039088cb40(81),
            cache: _0x7a039088cb40(130),
            credentials: _0x7a039088cb40(7),
            redirect: _0x7a039088cb40(20),
            signal: _0xd929eb7bf039.signal
        });
        if (_0x1eb9b3df9b0d.status !== _0x58ad35219aee.expectedStatus) {
            throw new Error(`HTTP_${_0x1eb9b3df9b0d.status}`);
        }
        try {
            await _0x1eb9b3df9b0d.body?.cancel();
        }
        catch {
        }
        const _0x5095b78e7cc6 = Date.now();
        return {
            status: _0x7a039088cb40(50),
            version: _0x683e37adebc3(),
            checkedAt: _0x5095b78e7cc6,
            expiresAt: _0x5095b78e7cc6 + _0x58ad35219aee.cacheMs
        };
    }
    finally {
        clearTimeout(_0xa42617c8ed95);
    }
}
async function _0x8e689ed9b70e(_0x455f38f9d63d = false) {
    const _0xa16d2b167045 = await chrome.storage.local.get(_0xcaf96649348b.AUTHORIZATION);
    const _0x11f6fa2a4589 = _0xa16d2b167045[_0xcaf96649348b.AUTHORIZATION] || null;
    const _0x3a8217c9c7fd = Date.now();
    if (!_0x455f38f9d63d && _0xf44bed8d3ead(_0x11f6fa2a4589, _0x3a8217c9c7fd)) {
        return _0x91c146735fd9(_0x11f6fa2a4589);
    }
    if (!_0x455f38f9d63d &&
        _0x11f6fa2a4589?.status === _0x7a039088cb40(132) &&
        _0x11f6fa2a4589.version === _0x683e37adebc3()) {
        await _0x49b0eebf08ec();
        return _0x91c146735fd9(_0x11f6fa2a4589);
    }
    if (_0x05770b7b7df8) {
        return _0x05770b7b7df8;
    }
    _0x05770b7b7df8 = (async () => {
        try {
            const _0x36e1b78bfa90 = await _0x9d690a0f8b92();
            await chrome.storage.local.set({ [_0xcaf96649348b.AUTHORIZATION]: _0x36e1b78bfa90 });
            await _0xbd267ca75399();
            return _0x91c146735fd9(_0x36e1b78bfa90);
        }
        catch (_0x8c33b6533e1b) {
            const _0x65919accec68 = {
                status: _0x7a039088cb40(132),
                version: _0x683e37adebc3(),
                checkedAt: Date.now(),
                expiresAt: 0,
                reason: _0x8c33b6533e1b?.name === _0x7a039088cb40(69) ? _0x7a039088cb40(228) : _0x7a039088cb40(87)
            };
            await chrome.storage.local.set({ [_0xcaf96649348b.AUTHORIZATION]: _0x65919accec68 });
            await _0x49b0eebf08ec();
            return _0x91c146735fd9(_0x65919accec68);
        }
        finally {
            _0x05770b7b7df8 = null;
        }
    })();
    return _0x05770b7b7df8;
}
function _0x8236793d8da9(_0xb8a98d8c51d7 = null) {
    return {
        ok: false,
        code: _0x7a039088cb40(181),
        error: _0x58ad35219aee.failureMessage,
        authorization: _0xb8a98d8c51d7 || { authorized: false, status: _0x7a039088cb40(132) }
    };
}
async function _0x911a8739ff3b(_0x39808b7bdc39 = false) {
    const _0x2d6cf031b0fd = await _0x8e689ed9b70e(_0x39808b7bdc39);
    return _0x2d6cf031b0fd.authorized
        ? { ok: true, authorization: _0x2d6cf031b0fd }
        : _0x8236793d8da9(_0x2d6cf031b0fd);
}
async function _0xaad0ccf27d63(_0x64aa4c9a90f4) {
    const _0x1dd222c3ead9 = await _0x911a8739ff3b(false);
    if (!_0x1dd222c3ead9.ok) {
        return _0x1dd222c3ead9;
    }
    return _0x64aa4c9a90f4();
}
async function _0x436078b5b72f() {
    const _0x39c3f184f4de = await _0x8e689ed9b70e(false);
    const _0xfc0d676fec6c = await _0x6fe49eb4993c();
    return { ok: true, data: _0xfc0d676fec6c, authorization: _0x39c3f184f4de };
}
async function _0xf861bc103e1e() {
    const _0xab6e4e9bee1a = await _0x8e689ed9b70e(true);
    return _0xab6e4e9bee1a.authorized
        ? { ok: true, authorization: _0xab6e4e9bee1a }
        : _0x8236793d8da9(_0xab6e4e9bee1a);
}
async function _0x33ffaa921fa0(_0x4adbc69b40f2) {
    const _0xb23b2b737394 = await chrome.storage.local.get(_0xcaf96649348b.RUN_STATE);
    const _0x6682a09c3bc4 = _0xb23b2b737394[_0xcaf96649348b.RUN_STATE] || null;
    const _0x1155ba9ea7d3 = Boolean(_0x6682a09c3bc4 &&
        _0x4adbc69b40f2.tab?.id === _0x6682a09c3bc4.workTabId &&
        _0x8c713513dd6a.has(_0x6682a09c3bc4.phase));
    if (!_0x1155ba9ea7d3) {
        const _0xde5a0d0f9946 = await _0x911a8739ff3b(false);
        if (!_0xde5a0d0f9946.ok) {
            return _0xde5a0d0f9946;
        }
    }
    const _0xd9273988c9df = await _0x7829643f5bfc(_0x4adbc69b40f2);
    if (_0x1155ba9ea7d3) {
        const _0x1d58d60c42c4 = await chrome.storage.local.get(_0xcaf96649348b.AUTHORIZATION);
        _0xd9273988c9df.authorization = _0x91c146735fd9(_0x1d58d60c42c4[_0xcaf96649348b.AUTHORIZATION]);
        _0xd9273988c9df.authorizationDeferred = !_0xd9273988c9df.authorization.authorized;
    }
    else {
        _0xd9273988c9df.authorization = { authorized: true, status: _0x7a039088cb40(50) };
    }
    return _0xd9273988c9df;
}
function _0xd54f82b58d09(_0x022bc54a1eaa) {
    return new Promise((_0xa6aabc2745fe) => setTimeout(_0xa6aabc2745fe, _0x022bc54a1eaa));
}
function _0x135106ccd004(_0x1f2c59fdbbd2, _0x35670af0d995 = _0xf0715585cf3d.orderIntervalSeconds) {
    const _0xc15a4431a6b8 = Number(_0x1f2c59fdbbd2);
    if (!Number.isInteger(_0xc15a4431a6b8) || _0xc15a4431a6b8 < 0 || _0xc15a4431a6b8 > 3600) {
        return _0x35670af0d995;
    }
    return _0xc15a4431a6b8;
}
function _0x7a411f09453c(_0x5c602572651f) {
    const _0x41e00272492b = _0x5c602572651f && typeof _0x5c602572651f === _0x7a039088cb40(101) ? _0x5c602572651f : {};
    return {
        orderIntervalSeconds: _0x135106ccd004(_0x41e00272492b.orderIntervalSeconds, _0xf0715585cf3d.orderIntervalSeconds)
    };
}
function _0x7d58e108a4a5(_0x8a2126d7422d) {
    return _0xf35c9f1e6c78.test(String(_0x8a2126d7422d ?? _0x7a039088cb40(172)).trim());
}
function _0x84a2b832222e(_0x5d576f8acc80) {
    const _0xb5584dfc7bfc = String(_0x5d576f8acc80 ?? _0x7a039088cb40(172)).trim();
    if (!/^[1-9]\d*$/.test(_0xb5584dfc7bfc)) {
        return null;
    }
    const _0x159502d9549e = Number(_0xb5584dfc7bfc);
    return Number.isSafeInteger(_0x159502d9549e) ? _0x159502d9549e : null;
}
function _0x5a344b3c8c8c(_0x84df9881ff83) {
    return `${_0xef695cb59b4e}${String(_0x84df9881ff83 || _0x7a039088cb40(172))}`;
}
function _0x05d08ef9d941(_0x22b8227fbf1a) {
    const _0x7d2e671e4693 = _0xd416afc168a8.get(_0x22b8227fbf1a);
    if (_0x7d2e671e4693 !== undefined) {
        clearTimeout(_0x7d2e671e4693);
        _0xd416afc168a8.delete(_0x22b8227fbf1a);
    }
}
async function _0xa2121b32b299(_0x0006f2b0c09c) {
    if (!_0x0006f2b0c09c) {
        return false;
    }
    return chrome.alarms.clear(_0x5a344b3c8c8c(_0x0006f2b0c09c));
}
async function _0xc413dbf4d41b(_0x7e2ef488029e) {
    _0x05d08ef9d941(_0x7e2ef488029e);
    try {
        await _0xa2121b32b299(_0x7e2ef488029e);
    }
    catch {
    }
}
function _0x9999f9481c0c(_0xca6c36d515f7) {
    const _0x0e5304ca7124 = Date.parse(String(_0xca6c36d515f7?.intervalEndsAt || _0x7a039088cb40(172)));
    if (Number.isFinite(_0x0e5304ca7124)) {
        return Math.max(0, _0x0e5304ca7124 - Date.now());
    }
    const _0x7d9acb1a2819 = Number(_0xca6c36d515f7?.intervalRemainingSeconds || 0);
    return Math.max(0, _0x7d9acb1a2819 * 1000);
}
async function _0x5f674b8d9edd(_0xbefe4cd447ef, _0x2c82c9a958e1) {
    const _0x70aba61b834c = _0xbefe4cd447ef?.runId;
    if (!_0x70aba61b834c) {
        throw new Error(_0x7a039088cb40(192));
    }
    const _0x1e52fca9f101 = Math.max(0, Number(_0x2c82c9a958e1) || 0);
    const _0x5ffa88ec9c5f = Date.now() + _0x1e52fca9f101;
    await _0xc413dbf4d41b(_0x70aba61b834c);
    await chrome.alarms.create(_0x5a344b3c8c8c(_0x70aba61b834c), { when: _0x5ffa88ec9c5f });
    if (_0x1e52fca9f101 <= 60000) {
        const _0x0aa801cdd586 = setTimeout(() => {
            _0xd416afc168a8.delete(_0x70aba61b834c);
            _0x349a83340562(() => _0x77f68b192075(_0x70aba61b834c)).catch((_0x31e2d1241dd5) => console.error(_0x31e2d1241dd5));
        }, _0x1e52fca9f101);
        _0xd416afc168a8.set(_0x70aba61b834c, _0x0aa801cdd586);
    }
}
function _0xa5552c751906(_0x3147eeec5cf9 = new Date()) {
    const _0x9bc4691a2fc7 = new Intl.DateTimeFormat(_0x7a039088cb40(110), {
        timeZone: _0x7a039088cb40(33),
        year: _0x7a039088cb40(180),
        month: _0x7a039088cb40(109),
        day: _0x7a039088cb40(109)
    }).formatToParts(_0x3147eeec5cf9);
    const _0xeff013c4caf2 = Object.fromEntries(_0x9bc4691a2fc7.map((_0x94f320a7cf6b) => [_0x94f320a7cf6b.type, _0x94f320a7cf6b.value]));
    return `${_0xeff013c4caf2.year}-${_0xeff013c4caf2.month}-${_0xeff013c4caf2.day}`;
}
function _0x9109d0a93092(_0x43236cce3dc4 = new Date()) {
    return new Intl.DateTimeFormat(_0x7a039088cb40(197), {
        timeZone: _0x7a039088cb40(33),
        year: _0x7a039088cb40(180),
        month: _0x7a039088cb40(109),
        day: _0x7a039088cb40(109),
        hour: _0x7a039088cb40(109),
        minute: _0x7a039088cb40(109),
        second: _0x7a039088cb40(109),
        hourCycle: _0x7a039088cb40(21)
    }).format(_0x43236cce3dc4);
}
function _0x1afacc1c0905(_0x6a261e692da5) {
    return String(_0x6a261e692da5 ?? _0x7a039088cb40(172))
        .normalize(_0x7a039088cb40(159))
        .replace(/\s+/g, _0x7a039088cb40(88))
        .trim();
}
function _0xf1e4b7947c01(_0x2bd286832b28) {
    return String(_0x2bd286832b28 ?? _0x7a039088cb40(172))
        .normalize(_0x7a039088cb40(159))
        .replace(/[^\p{L}\p{M}\s\-'’]/gu, _0x7a039088cb40(88))
        .replace(/\s+/g, _0x7a039088cb40(88))
        .trim();
}
function _0xc4a6acb37df9(_0xa0777b1a5195) {
    return _0x1afacc1c0905(_0xa0777b1a5195).toLocaleLowerCase(_0x7a039088cb40(57));
}
function _0x19c8aef802df(_0xd6ef605a75d1) {
    return String(_0xd6ef605a75d1 ?? _0x7a039088cb40(172))
        .normalize(_0x7a039088cb40(159))
        .replace(/\s+/g, _0x7a039088cb40(172))
        .trim()
        .toUpperCase();
}
function _0xcc4c5febdd97(_0xeee969f1bb3e) {
    return String(_0xeee969f1bb3e ?? _0x7a039088cb40(172))
        .normalize(_0x7a039088cb40(159))
        .trim()
        .slice(0, 200);
}
function _0xcb5098b629bd(_0x51887474957d) {
    const _0x88a697d8f006 = String(_0x51887474957d ?? _0x7a039088cb40(172)).trim();
    if (!_0x88a697d8f006) {
        return null;
    }
    let _0xd985dd3956c7;
    try {
        _0xd985dd3956c7 = new URL(_0x88a697d8f006);
    }
    catch {
        return null;
    }
    const _0x5933afb2b7ce = _0xd985dd3956c7.hostname.toLowerCase();
    if (_0x5933afb2b7ce !== _0x7a039088cb40(29) && !_0x5933afb2b7ce.endsWith(_0x7a039088cb40(190))) {
        return null;
    }
    const _0x11e82c4b6995 = [
        /\/(?:dp|gp\/product|gp\/aw\/d)\/([A-Z0-9]{10})(?:[/?]|$)/i,
        /\/product\/([A-Z0-9]{10})(?:[/?]|$)/i
    ];
    for (const _0xab7edd531819 of _0x11e82c4b6995) {
        const _0x3e5de4b8e750 = _0xd985dd3956c7.pathname.match(_0xab7edd531819);
        if (_0x3e5de4b8e750) {
            return _0x3e5de4b8e750[1].toUpperCase();
        }
    }
    const _0x0324e83f1063 = _0xd985dd3956c7.searchParams.get(_0x7a039088cb40(245)) || _0xd985dd3956c7.searchParams.get(_0x7a039088cb40(26));
    if (_0x0324e83f1063 && /^[A-Z0-9]{10}$/i.test(_0x0324e83f1063)) {
        return _0x0324e83f1063.toUpperCase();
    }
    return null;
}
function _0x47588c686c5f(_0x61e70d891c71) {
    const _0x3e69118e74cb = _0x19c8aef802df(_0x61e70d891c71);
    return _0x3e69118e74cb ? `temu:${_0x3e69118e74cb}` : _0x7a039088cb40(172);
}
function _0x6a2118134929(_0xd0092391652c, _0xf5c4caecbd30) {
    const _0xee6860752251 = String(_0xd0092391652c || _0x7a039088cb40(172)).trim();
    if (/^\d{4}-\d{2}-\d{2}$/.test(_0xee6860752251)) {
        return _0xee6860752251;
    }
    const _0xaa7ec1b716e1 = new Date(_0xf5c4caecbd30 || _0x7a039088cb40(172));
    return Number.isNaN(_0xaa7ec1b716e1.getTime()) ? _0x7a039088cb40(172) : _0xa5552c751906(_0xaa7ec1b716e1);
}
function _0xa2248a8b28d3(_0x3a0498678c4d) {
    const _0x50bf10fff3e7 = [];
    for (const _0x7b29f009aad4 of Array.isArray(_0x3a0498678c4d) ? _0x3a0498678c4d : []) {
        const _0xe42fa2c249fe = _0x19c8aef802df(_0x7b29f009aad4?.temuOrderIdKey || _0x7b29f009aad4?.temuOrderId || _0x7a039088cb40(172));
        const _0xa6db4aa40c15 = String(_0x7b29f009aad4?.orderId || _0x7a039088cb40(172)).trim();
        if (!_0xe42fa2c249fe || _0x7b29f009aad4?.status !== _0x7a039088cb40(144) || !_0x7d58e108a4a5(_0xa6db4aa40c15)) {
            continue;
        }
        _0x50bf10fff3e7.push({
            ..._0x7b29f009aad4,
            temuOrderId: _0xe42fa2c249fe,
            temuOrderIdKey: _0xe42fa2c249fe,
            status: _0x7a039088cb40(144),
            orderId: _0xa6db4aa40c15,
            dateKey: _0x6a2118134929(_0x7b29f009aad4?.dateKey, _0x7b29f009aad4?.updatedAt || _0x7b29f009aad4?.createdAt),
            addressSignature: String(_0x7b29f009aad4?.addressSignature || _0x7a039088cb40(172)),
            itemSignature: String(_0x7b29f009aad4?.itemSignature || _0x7a039088cb40(172)),
            temuSignature: String(_0x7b29f009aad4?.temuSignature || _0x7a039088cb40(172)),
            groupSignature: String(_0x7b29f009aad4?.groupSignature || _0x7a039088cb40(172)),
            updatedAt: _0x7b29f009aad4?.updatedAt || _0x7b29f009aad4?.createdAt || new Date().toISOString()
        });
    }
    return _0x50bf10fff3e7;
}
function _0x5927bc040c8e(_0xed67dca4fcd4, _0x81e12014df3c = []) {
    const _0xe7d936092590 = {};
    const _0xedb03687754a = [];
    if (_0xed67dca4fcd4 && typeof _0xed67dca4fcd4 === _0x7a039088cb40(101) && !Array.isArray(_0xed67dca4fcd4)) {
        for (const _0x05348e1b0e29 of Object.values(_0xed67dca4fcd4)) {
            const _0x1bbeacf8825e = _0x19c8aef802df(_0x05348e1b0e29?.temuOrderId || _0x7a039088cb40(172));
            const _0xb876959b567f = String(_0x05348e1b0e29?.orderId || _0x7a039088cb40(172)).trim();
            if (!_0x1bbeacf8825e || _0x05348e1b0e29?.status !== _0x7a039088cb40(144) || !_0x7d58e108a4a5(_0xb876959b567f)) {
                continue;
            }
            _0xedb03687754a.push({
                ..._0x05348e1b0e29,
                temuOrderId: _0x1bbeacf8825e,
                orderId: _0xb876959b567f,
                status: _0x7a039088cb40(144),
                dateKey: _0x6a2118134929(_0x05348e1b0e29?.dateKey, _0x05348e1b0e29?.updatedAt),
                addressSignature: String(_0x05348e1b0e29?.addressSignature || _0x7a039088cb40(172)),
                itemSignature: String(_0x05348e1b0e29?.itemSignature || _0x7a039088cb40(172)),
                temuSignature: String(_0x05348e1b0e29?.temuSignature || _0x7a039088cb40(172)),
                groupSignature: String(_0x05348e1b0e29?.groupSignature || _0x7a039088cb40(172)),
                updatedAt: _0x05348e1b0e29?.updatedAt || new Date(0).toISOString()
            });
        }
    }
    for (const _0x9b7cb27d1b24 of _0x81e12014df3c) {
        _0xedb03687754a.push({
            temuOrderId: _0x19c8aef802df(_0x9b7cb27d1b24.temuOrderIdKey || _0x9b7cb27d1b24.temuOrderId),
            status: _0x7a039088cb40(144),
            orderId: _0x9b7cb27d1b24.orderId,
            dateKey: _0x9b7cb27d1b24.dateKey,
            addressSignature: String(_0x9b7cb27d1b24.addressSignature || _0x7a039088cb40(172)),
            itemSignature: String(_0x9b7cb27d1b24.itemSignature || _0x7a039088cb40(172)),
            temuSignature: String(_0x9b7cb27d1b24.temuSignature || _0x7a039088cb40(172)),
            groupSignature: String(_0x9b7cb27d1b24.groupSignature || _0x7a039088cb40(172)),
            updatedAt: _0x9b7cb27d1b24.updatedAt
        });
    }
    for (const _0x3ae4402045ee of _0xedb03687754a) {
        const _0xcc6a71c17acc = _0x47588c686c5f(_0x3ae4402045ee.temuOrderId);
        if (!_0xcc6a71c17acc) {
            continue;
        }
        const _0xcdbd07ef0750 = _0xe7d936092590[_0xcc6a71c17acc];
        if (!_0xcdbd07ef0750 || String(_0x3ae4402045ee.updatedAt) >= String(_0xcdbd07ef0750.updatedAt || _0x7a039088cb40(172))) {
            _0xe7d936092590[_0xcc6a71c17acc] = _0x3ae4402045ee;
        }
    }
    return _0xe7d936092590;
}
function _0xce02b5402e6d(_0xbda8e4823466, _0x2f451a7d9015, _0x45d368eeed4d = null) {
    return {
        id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
        time: _0x9109d0a93092(),
        isoTime: new Date().toISOString(),
        level: _0xbda8e4823466,
        rowNumber: _0x45d368eeed4d,
        message: _0x2f451a7d9015
    };
}
function _0x8d616eca1a29(_0x6e1b6f169615, _0x1297ecd12e1f, _0x687f05c69b44, _0xc657d2b32c01 = null) {
    const _0x81dd1a6a0927 = Array.isArray(_0x6e1b6f169615) ? _0x6e1b6f169615 : [];
    _0x81dd1a6a0927.push(_0xce02b5402e6d(_0x1297ecd12e1f, _0x687f05c69b44, _0xc657d2b32c01));
    if (_0x81dd1a6a0927.length > _0xe49f547ce0e9) {
        _0x81dd1a6a0927.splice(0, _0x81dd1a6a0927.length - _0xe49f547ce0e9);
    }
    return _0x81dd1a6a0927;
}
function _0xedfa3a2d2989(_0x9951d3f61b97, _0x91a521d67e81) {
    const _0x48e3b2a5c529 = _0x9951d3f61b97 && typeof _0x9951d3f61b97 === _0x7a039088cb40(101) ? _0x9951d3f61b97 : {};
    const _0x12bade895465 = _0xcc4c5febdd97(_0x48e3b2a5c529._rowId || _0x48e3b2a5c529.draftRowId) || crypto.randomUUID();
    const _0x8d9013c3e88f = _0x1afacc1c0905(_0x48e3b2a5c529.temuOrderId);
    const _0xcb6f29343804 = _0x19c8aef802df(_0x8d9013c3e88f);
    const _0xfac73beebbde = String(_0x48e3b2a5c529.amzLink ?? _0x7a039088cb40(172)).trim();
    const _0xafa6c36b8a1e = String(_0x48e3b2a5c529.quantityToShip ?? _0x7a039088cb40(172)).trim();
    const _0xe2feda0c0672 = String(_0x48e3b2a5c529.recipientName ?? _0x7a039088cb40(172)).trim();
    const _0x7eeb3f33b6ae = String(_0x48e3b2a5c529.phoneNumber ?? _0x7a039088cb40(172)).trim();
    const _0x5556ae032ea6 = _0x1afacc1c0905(_0x48e3b2a5c529.shipAddress);
    const _0xf61fc645dab0 = _0x1afacc1c0905(_0x48e3b2a5c529.address2);
    const _0xc3b562b41654 = _0x1afacc1c0905(_0x48e3b2a5c529.shipCity);
    const _0x0b20d0d3f739 = _0x1afacc1c0905(_0x48e3b2a5c529.shipPostalCode);
    const _0x75e1a5b5ab8f = _0xf1e4b7947c01(_0xe2feda0c0672);
    const _0xdf369b160e60 = _0xc4a6acb37df9(_0x75e1a5b5ab8f);
    const _0x4add5db61098 = _0x84a2b832222e(_0xafa6c36b8a1e);
    const _0x46c89460b625 = _0xcb5098b629bd(_0xfac73beebbde);
    const _0xa4601019ab5c = _0x75e1a5b5ab8f && _0x5556ae032ea6 && _0xc3b562b41654 && _0x0b20d0d3f739
        ? [
            _0xdf369b160e60,
            _0xc4a6acb37df9(_0x5556ae032ea6),
            _0xc4a6acb37df9(_0xf61fc645dab0),
            _0xc4a6acb37df9(_0xc3b562b41654),
            _0xc4a6acb37df9(_0x0b20d0d3f739)
        ].join(_0x7a039088cb40(83))
        : _0x7a039088cb40(172);
    let _0x4dab860b13cb = _0x7a039088cb40(172);
    if (!_0x75e1a5b5ab8f || !_0x5556ae032ea6 || !_0xc3b562b41654 || !_0x0b20d0d3f739 || !_0x7eeb3f33b6ae) {
        _0x4dab860b13cb = _0x7a039088cb40(186);
    }
    else if (!_0xcb6f29343804) {
        _0x4dab860b13cb = _0x7a039088cb40(213);
    }
    else if (_0x4add5db61098 === null) {
        _0x4dab860b13cb = _0x7a039088cb40(210);
    }
    else if (!_0x46c89460b625) {
        _0x4dab860b13cb = _0x7a039088cb40(149);
    }
    return {
        id: crypto.randomUUID(),
        draftRowId: _0x12bade895465,
        sourceIndex: _0x91a521d67e81,
        rowNumber: _0x91a521d67e81 + 1,
        temuOrderId: _0x8d9013c3e88f,
        normalizedTemuOrderId: _0xcb6f29343804,
        amzLink: _0xfac73beebbde,
        quantityToShip: _0xafa6c36b8a1e,
        recipientName: _0xe2feda0c0672,
        normalizedName: _0x75e1a5b5ab8f,
        normalizedNameKey: _0xdf369b160e60,
        requestedQuantity: _0x4add5db61098,
        phoneNumber: _0x7eeb3f33b6ae,
        shipAddress: _0x5556ae032ea6,
        address2: _0xf61fc645dab0,
        shipCity: _0xc3b562b41654,
        shipPostalCode: _0x0b20d0d3f739,
        asin: _0x46c89460b625,
        addressSignature: _0xa4601019ab5c,
        groupId: _0x7a039088cb40(172),
        groupKey: _0xa4601019ab5c,
        groupPosition: null,
        groupSize: 0,
        initialFailureReason: _0x4dab860b13cb,
        status: _0x7a039088cb40(31),
        result: _0x7a039088cb40(201),
        orderId: _0x7a039088cb40(172),
        observedUnitPrice: _0x7a039088cb40(172),
        selectedQuantity: _0x7a039088cb40(172),
        precheckPassed: false,
        addedToCart: false,
        updatedAt: new Date().toISOString()
    };
}
function _0x488d2016cacd(_0x72381b7207ff) {
    return [
        _0x72381b7207ff.temuOrderId,
        _0x72381b7207ff.amzLink,
        _0x72381b7207ff.quantityToShip,
        _0x72381b7207ff.recipientName,
        _0x72381b7207ff.phoneNumber,
        _0x72381b7207ff.shipAddress,
        _0x72381b7207ff.address2,
        _0x72381b7207ff.shipCity,
        _0x72381b7207ff.shipPostalCode
    ].every((_0x7c076eb41522) => String(_0x7c076eb41522 ?? _0x7a039088cb40(172)).trim() === _0x7a039088cb40(172));
}
function _0x0f9db2374199(_0x16821e17a3df, _0x197c013c93f3, _0x35db65fc4cb7) {
    _0x16821e17a3df.status = _0x197c013c93f3;
    _0x16821e17a3df.result = _0x35db65fc4cb7;
    _0x16821e17a3df.updatedAt = new Date().toISOString();
}
function _0xd59cc556eefa(_0xb94af3fe3153, _0x9863ea830d60) {
    const _0x4c13179d1d39 = new Map();
    for (const _0x8d4561a6996b of _0x9863ea830d60) {
        const _0xe32743a16fed = _0xb94af3fe3153[_0x8d4561a6996b];
        if (!_0xe32743a16fed?.asin || !Number.isSafeInteger(_0xe32743a16fed.requestedQuantity) || _0xe32743a16fed.requestedQuantity <= 0) {
            continue;
        }
        _0x4c13179d1d39.set(_0xe32743a16fed.asin, (_0x4c13179d1d39.get(_0xe32743a16fed.asin) || 0) + _0xe32743a16fed.requestedQuantity);
    }
    return [..._0x4c13179d1d39.entries()]
        .sort(([_0x61ef4f1d3813], [_0x83ef2deba89c]) => _0x61ef4f1d3813.localeCompare(_0x83ef2deba89c))
        .map(([_0x19f638c6f7c9, _0x66cae0388cab]) => ({ asin: _0x19f638c6f7c9, quantity: _0x66cae0388cab }));
}
function _0x3e1a6607af47(_0xa1b6f08ea896) {
    return (Array.isArray(_0xa1b6f08ea896) ? _0xa1b6f08ea896 : [])
        .map((_0xc21c70289812) => `${_0xc21c70289812.asin}x${_0xc21c70289812.quantity}`)
        .join(_0x7a039088cb40(83));
}
function _0x8ee291ad35d0(_0x57ded5586e3e, _0x56bca3bb78ff, _0x5d7f504da808) {
    return _0x56bca3bb78ff.rowIndexes.filter((_0xa91cb845c385) => _0x57ded5586e3e[_0xa91cb845c385]?.normalizedTemuOrderId === _0x5d7f504da808);
}
function _0xc4b187d8262c(_0x27b8582483c8, _0xf8565287e4d1, _0x1a0b7940d5e2) {
    const _0x1f3e4d8304c7 = [..._0xf8565287e4d1].sort((_0x6e751443c74c, _0x499f4fbbe82c) => _0x27b8582483c8[_0x6e751443c74c].sourceIndex - _0x27b8582483c8[_0x499f4fbbe82c].sourceIndex);
    const _0x28cef562dbc4 = _0x1f3e4d8304c7[0];
    const _0x134186328eb5 = _0x27b8582483c8[_0x28cef562dbc4];
    const _0x28aa2e917713 = [...new Set(_0x1f3e4d8304c7.map((_0x482dd8e88590) => _0x1afacc1c0905(_0x27b8582483c8[_0x482dd8e88590].phoneNumber)).filter(Boolean))];
    const _0xea122f8c91bf = _0xd59cc556eefa(_0x27b8582483c8, _0x1f3e4d8304c7);
    const _0xcdcd8b79b6eb = _0xea122f8c91bf.reduce((_0x98e93b720b0e, _0x99e1b2560d81) => _0x98e93b720b0e + _0x99e1b2560d81.quantity, 0);
    const _0x9f756d5ea10b = [...new Set(_0x1f3e4d8304c7.map((_0xf5f466c26e6c) => _0x27b8582483c8[_0xf5f466c26e6c].normalizedTemuOrderId).filter(Boolean))];
    const _0x2e7e1f83d0e9 = {};
    const _0x69d46f2040ac = {};
    for (const _0xab1ef4f6a28d of _0x9f756d5ea10b) {
        const _0x789f04fe6d86 = _0x8ee291ad35d0(_0x27b8582483c8, { rowIndexes: _0x1f3e4d8304c7 }, _0xab1ef4f6a28d);
        const _0x9103f12761e4 = _0xd59cc556eefa(_0x27b8582483c8, _0x789f04fe6d86);
        const _0xe081e179a595 = _0x3e1a6607af47(_0x9103f12761e4);
        _0x69d46f2040ac[_0xab1ef4f6a28d] = _0xe081e179a595;
        _0x2e7e1f83d0e9[_0xab1ef4f6a28d] = `${_0x134186328eb5.addressSignature}||${_0xe081e179a595}`;
    }
    const _0xa0c664145bb6 = `group-${_0x1a0b7940d5e2}-${crypto.randomUUID()}`;
    _0x1f3e4d8304c7.forEach((_0x8bf428a7cc66, _0x086872347957) => {
        _0x27b8582483c8[_0x8bf428a7cc66].groupId = _0xa0c664145bb6;
        _0x27b8582483c8[_0x8bf428a7cc66].groupPosition = _0x086872347957;
        _0x27b8582483c8[_0x8bf428a7cc66].groupSize = _0x1f3e4d8304c7.length;
    });
    return {
        id: _0xa0c664145bb6,
        key: _0x134186328eb5.addressSignature,
        sortKey: [
            _0xc4a6acb37df9(_0x134186328eb5.shipAddress),
            _0xc4a6acb37df9(_0x134186328eb5.address2),
            _0xc4a6acb37df9(_0x134186328eb5.shipCity),
            _0xc4a6acb37df9(_0x134186328eb5.shipPostalCode),
            _0x134186328eb5.normalizedNameKey
        ].join(_0x7a039088cb40(83)),
        originalPosition: _0x134186328eb5.sourceIndex,
        rowIndexes: _0x1f3e4d8304c7,
        primaryRowIndex: _0x28cef562dbc4,
        isCombined: _0x1f3e4d8304c7.length > 1,
        normalizedName: _0x134186328eb5.normalizedName,
        normalizedNameKey: _0x134186328eb5.normalizedNameKey,
        shipAddress: _0x134186328eb5.shipAddress,
        address2: _0x134186328eb5.address2,
        shipCity: _0x134186328eb5.shipCity,
        shipPostalCode: _0x134186328eb5.shipPostalCode,
        phoneNumber: _0x134186328eb5.phoneNumber,
        phoneMismatch: _0x28aa2e917713.length > 1,
        phoneNumbers: _0x28aa2e917713,
        addressSignature: _0x134186328eb5.addressSignature,
        expectedItems: _0xea122f8c91bf,
        expectedItemSignature: _0x3e1a6607af47(_0xea122f8c91bf),
        expectedTotalQuantity: _0xcdcd8b79b6eb,
        uniqueTemuOrderIds: _0x9f756d5ea10b,
        temuSignatures: _0x2e7e1f83d0e9,
        temuItemSignatures: _0x69d46f2040ac,
        groupSignature: `${_0x134186328eb5.addressSignature}||${_0x3e1a6607af47(_0xea122f8c91bf)}`,
        result: _0x7a039088cb40(169),
        status: _0x7a039088cb40(31),
        triggerRowIndex: null,
        precheckCursor: 0,
        addCursor: 0,
        expectedCartCount: 0,
        actualDeliveryAddress: _0x7a039088cb40(172),
        orderId: _0x7a039088cb40(172),
        updatedAt: new Date().toISOString()
    };
}
function _0x1a9d3a7c154f(_0x76843207a5a3, _0xbd5a179ee630, _0x11f336da57d0, _0x5aeeee9c93f4, _0x25902e002769 = false) {
    _0xbd5a179ee630.result = _0x7a039088cb40(238);
    _0xbd5a179ee630.status = _0x5aeeee9c93f4;
    _0xbd5a179ee630.triggerRowIndex = _0x11f336da57d0;
    _0xbd5a179ee630.updatedAt = new Date().toISOString();
    for (const _0x3a188f27111c of _0xbd5a179ee630.rowIndexes) {
        const _0x003c2eea9a65 = _0x76843207a5a3[_0x3a188f27111c];
        const _0xc3e5234a8b8a = _0x25902e002769 ? _0x5aeeee9c93f4 : _0x3a188f27111c === _0x11f336da57d0 || _0xbd5a179ee630.rowIndexes.length === 1
            ? _0x5aeeee9c93f4 : _0x7a039088cb40(118);
        _0x0f9db2374199(_0x003c2eea9a65, _0xc3e5234a8b8a, _0x7a039088cb40(238));
    }
}
function _0xe81840907d4e(_0x1c647688a08d, _0x845a9e48c523, _0x90af940ed5db) {
    _0x845a9e48c523.result = _0x7a039088cb40(99);
    _0x845a9e48c523.status = `等待人工检查：${_0x90af940ed5db}`;
    _0x845a9e48c523.updatedAt = new Date().toISOString();
    for (const _0x83382386ece8 of _0x845a9e48c523.rowIndexes) {
        _0x0f9db2374199(_0x1c647688a08d[_0x83382386ece8], `等待人工检查：${_0x90af940ed5db}`, _0x7a039088cb40(99));
    }
}
function _0x2d20ea6f6b9e(_0xaf87f8b3b9c9, _0xd5a0ad99e260, _0xdc66f46f7f9f) {
    _0xd5a0ad99e260.result = _0x7a039088cb40(167);
    _0xd5a0ad99e260.status = _0xdc66f46f7f9f;
    _0xd5a0ad99e260.updatedAt = new Date().toISOString();
    for (const _0x3fa7cbc3eda7 of _0xd5a0ad99e260.rowIndexes) {
        const _0xf9d322c2b835 = _0xaf87f8b3b9c9[_0x3fa7cbc3eda7];
        if (_0xf9d322c2b835.result !== _0x7a039088cb40(198) && _0xf9d322c2b835.result !== _0x7a039088cb40(238)) {
            _0x0f9db2374199(_0xf9d322c2b835, _0xdc66f46f7f9f, _0x7a039088cb40(167));
        }
    }
}
function _0x5e2355e736c1(_0x91d1ef75dfa7, _0x45bed3a800d2, _0x574a60c50a20) {
    _0x45bed3a800d2.result = _0x7a039088cb40(198);
    _0x45bed3a800d2.status = _0x7a039088cb40(231);
    _0x45bed3a800d2.orderId = _0x574a60c50a20;
    _0x45bed3a800d2.updatedAt = new Date().toISOString();
    for (const _0x1cb93b8d83a7 of _0x45bed3a800d2.rowIndexes) {
        const _0x790684350764 = _0x91d1ef75dfa7[_0x1cb93b8d83a7];
        _0x790684350764.orderId = _0x574a60c50a20;
        _0x0f9db2374199(_0x790684350764, _0x7a039088cb40(231), _0x7a039088cb40(198));
    }
}
function _0xfa3a2c2887bc(_0x0e59d53d7711, _0x9cf82c065429, _0xcdb77531fc0e) {
    const _0x4aac6b6990ea = _0x5927bc040c8e(_0xcdb77531fc0e, _0x9cf82c065429);
    const _0xe48ff01e812c = _0xa5552c751906();
    const _0x2ae1d81994d1 = (Array.isArray(_0x0e59d53d7711) ? _0x0e59d53d7711 : [])
        .map((_0xcc8da96def1a, _0x4731747ff23b) => _0xedfa3a2d2989(_0xcc8da96def1a, _0x4731747ff23b))
        .filter((_0x3cca8c6e7246) => !_0x488d2016cacd(_0x3cca8c6e7246));
    const _0x921336510d10 = new Map();
    for (let _0x1bcb5c932750 = 0; _0x1bcb5c932750 < _0x2ae1d81994d1.length; _0x1bcb5c932750 += 1) {
        const _0x7503a903488b = _0x2ae1d81994d1[_0x1bcb5c932750];
        if (!_0x7503a903488b.addressSignature) {
            _0x0f9db2374199(_0x7503a903488b, _0x7503a903488b.initialFailureReason || _0x7a039088cb40(186), _0x7a039088cb40(238));
            continue;
        }
        if (!_0x921336510d10.has(_0x7503a903488b.addressSignature)) {
            _0x921336510d10.set(_0x7503a903488b.addressSignature, []);
        }
        _0x921336510d10.get(_0x7503a903488b.addressSignature).push(_0x1bcb5c932750);
    }
    const _0x7bc1de942f3f = [..._0x921336510d10.values()].map((_0x2b5dc57a91d1, _0x4aa4133d258c) => _0xc4b187d8262c(_0x2ae1d81994d1, _0x2b5dc57a91d1, _0x4aa4133d258c + 1));
    _0x7bc1de942f3f.sort((_0x3fec5421aaf8, _0xeaab4641e8b6) => _0x3fec5421aaf8.originalPosition - _0xeaab4641e8b6.originalPosition);
    for (const _0x4785bc7532ce of _0x7bc1de942f3f) {
        const _0xa18cbad336d2 = _0x4785bc7532ce.rowIndexes.find((_0x4bfedb92caf0) => _0x2ae1d81994d1[_0x4bfedb92caf0].initialFailureReason);
        if (_0xa18cbad336d2 !== undefined) {
            _0x1a9d3a7c154f(_0x2ae1d81994d1, _0x4785bc7532ce, _0xa18cbad336d2, _0x2ae1d81994d1[_0xa18cbad336d2].initialFailureReason);
        }
        else {
            _0x4785bc7532ce.result = _0x7a039088cb40(169);
            _0x4785bc7532ce.status = _0x7a039088cb40(31);
            for (const _0xe7037a019cf3 of _0x4785bc7532ce.rowIndexes) {
                _0x0f9db2374199(_0x2ae1d81994d1[_0xe7037a019cf3], _0x7a039088cb40(31), _0x7a039088cb40(169));
            }
        }
    }
    const _0x6f906e8ad48a = [];
    const _0xe07fe433a7c5 = new Map();
    for (const _0x2ada856a7d8e of _0x7bc1de942f3f) {
        for (const _0x7c6ed135e96a of _0x2ada856a7d8e.uniqueTemuOrderIds) {
            if (!_0xe07fe433a7c5.has(_0x7c6ed135e96a)) {
                _0xe07fe433a7c5.set(_0x7c6ed135e96a, new Set());
            }
            _0xe07fe433a7c5.get(_0x7c6ed135e96a).add(_0x2ada856a7d8e.id);
        }
    }
    for (const [_0xdef3e12759a9, _0x5d43b895461f] of _0xe07fe433a7c5.entries()) {
        if (_0x5d43b895461f.size <= 1) {
            continue;
        }
        const _0x5bb69a6e65f6 = `Temu Order ID ${_0xdef3e12759a9} 出现在不同收件地址组，已停止等待人工检查。`;
        _0x6f906e8ad48a.push(_0x5bb69a6e65f6);
        for (const _0x8ede14fa5cab of _0x5d43b895461f) {
            const _0xdf299f659267 = _0x7bc1de942f3f.find((_0x29ec6b0676b7) => _0x29ec6b0676b7.id === _0x8ede14fa5cab);
            if (_0xdf299f659267) {
                _0xe81840907d4e(_0x2ae1d81994d1, _0xdf299f659267, _0x5bb69a6e65f6);
            }
        }
    }
    for (const _0x5b8a234192da of _0x7bc1de942f3f) {
        if (_0x5b8a234192da.result !== _0x7a039088cb40(169)) {
            continue;
        }
        let _0xb726332dd863 = null;
        let _0xdf8eac5c9cb6 = null;
        for (const _0x8f1372840daf of _0x5b8a234192da.uniqueTemuOrderIds) {
            const _0x1f7353e4a3a0 = _0x4aac6b6990ea[_0x47588c686c5f(_0x8f1372840daf)];
            if (!_0x1f7353e4a3a0 ||
                _0x1f7353e4a3a0.status !== _0x7a039088cb40(144) ||
                _0x1f7353e4a3a0.dateKey !== _0xe48ff01e812c ||
                !_0x7d58e108a4a5(_0x1f7353e4a3a0.orderId)) {
                continue;
            }
            const _0x6b2c6d78df50 = _0x5b8a234192da.temuSignatures[_0x8f1372840daf] || _0x7a039088cb40(172);
            if (_0x1f7353e4a3a0.temuSignature && _0x6b2c6d78df50 && _0x1f7353e4a3a0.temuSignature !== _0x6b2c6d78df50) {
                _0xdf8eac5c9cb6 = `Temu Order ID ${_0x8f1372840daf} 今天已有订单，但本次地址、商品或数量签名不同，已停止等待人工检查。`;
                break;
            }
            const _0x7efcaaf28482 = _0x5b8a234192da.rowIndexes.find((_0x5070701a5302) => _0x2ae1d81994d1[_0x5070701a5302].normalizedTemuOrderId === _0x8f1372840daf);
            _0xb726332dd863 = {
                triggerRowIndex: _0x7efcaaf28482,
                reason: _0x7a039088cb40(96)
            };
            break;
        }
        if (_0xdf8eac5c9cb6) {
            _0x6f906e8ad48a.push(_0xdf8eac5c9cb6);
            _0xe81840907d4e(_0x2ae1d81994d1, _0x5b8a234192da, _0xdf8eac5c9cb6);
        }
        else if (_0xb726332dd863) {
            _0x1a9d3a7c154f(_0x2ae1d81994d1, _0x5b8a234192da, _0xb726332dd863.triggerRowIndex, _0xb726332dd863.reason);
        }
    }
    const _0x959a52aed490 = [...new Set(Object.values(_0x4aac6b6990ea)
            .filter((_0xe439520b638c) => _0xe439520b638c?.dateKey === _0xe48ff01e812c && _0x7d58e108a4a5(_0xe439520b638c?.orderId))
            .map((_0x123f8bfc1884) => _0x123f8bfc1884.orderId))];
    return { rows: _0x2ae1d81994d1, groups: _0x7bc1de942f3f, orderIndex: _0x4aac6b6990ea, fatalConflicts: _0x6f906e8ad48a, knownOrderIds: _0x959a52aed490 };
}
function _0x7e67cc333945(_0x70c9faf8c535, _0x86ad1ed7f55a, _0x483d65fb04d7, _0x5c5c27660479) {
    const _0xc582f0665fc6 = _0x5927bc040c8e(_0x5c5c27660479, _0x483d65fb04d7);
    const _0xa985781bb8ee = Array.isArray(_0x70c9faf8c535) ? _0x70c9faf8c535 : [];
    const _0x67563117b490 = Array.isArray(_0x86ad1ed7f55a) ? _0x86ad1ed7f55a : [];
    const _0xeac8c58c3857 = new Map();
    const _0xff01316c393a = new Map();
    for (const _0x1fd78d9ce399 of _0x67563117b490) {
        const _0x187a94c4a9c1 = _0xcc4c5febdd97(_0x1fd78d9ce399?.draftRowId);
        if (_0x187a94c4a9c1 && !_0xeac8c58c3857.has(_0x187a94c4a9c1)) {
            _0xeac8c58c3857.set(_0x187a94c4a9c1, _0x1fd78d9ce399);
        }
        if (Number.isInteger(_0x1fd78d9ce399?.sourceIndex) && !_0xff01316c393a.has(_0x1fd78d9ce399.sourceIndex)) {
            _0xff01316c393a.set(_0x1fd78d9ce399.sourceIndex, _0x1fd78d9ce399);
        }
    }
    const _0x60d3401c2ddc = new Set();
    const _0x0c9cd6fa91d1 = [];
    const _0x931f521a135f = [];
    const _0xf309051095b5 = [];
    for (let _0xb90052351b33 = 0; _0xb90052351b33 < _0xa985781bb8ee.length; _0xb90052351b33 += 1) {
        const _0xd2237cfa6468 = _0xa985781bb8ee[_0xb90052351b33] && typeof _0xa985781bb8ee[_0xb90052351b33] === _0x7a039088cb40(101)
            ? _0xa985781bb8ee[_0xb90052351b33]
            : {};
        if (_0x488d2016cacd(_0xd2237cfa6468)) {
            continue;
        }
        const _0xd7a8e9cce657 = _0xcc4c5febdd97(_0xd2237cfa6468._rowId || _0xd2237cfa6468.draftRowId);
        let _0xea2d88bc51e0 = _0xd7a8e9cce657 ? _0xeac8c58c3857.get(_0xd7a8e9cce657) : null;
        if (!_0xea2d88bc51e0) {
            const _0xce896741b88c = _0xff01316c393a.get(_0xb90052351b33) || null;
            if (!_0xd7a8e9cce657 || !_0xcc4c5febdd97(_0xce896741b88c?.draftRowId)) {
                _0xea2d88bc51e0 = _0xce896741b88c;
            }
        }
        if (!_0xea2d88bc51e0) {
            continue;
        }
        if (_0x60d3401c2ddc.has(_0xea2d88bc51e0)) {
            _0xf309051095b5.push(_0xea2d88bc51e0.rowNumber || _0xb90052351b33 + 1);
            continue;
        }
        _0x60d3401c2ddc.add(_0xea2d88bc51e0);
        const _0x333bda7cca3a = _0xea2d88bc51e0.result === _0x7a039088cb40(238) && !_0x7d58e108a4a5(_0xea2d88bc51e0.orderId);
        if (_0x333bda7cca3a) {
            const _0x0a0ef75c355d = _0xedfa3a2d2989(_0xd2237cfa6468, _0xb90052351b33);
            _0x0a0ef75c355d.id = _0xea2d88bc51e0.id || _0x0a0ef75c355d.id;
            _0x0a0ef75c355d.draftRowId = _0xd7a8e9cce657 || _0xcc4c5febdd97(_0xea2d88bc51e0.draftRowId) || _0x0a0ef75c355d.draftRowId;
            _0x0a0ef75c355d.status = _0x7a039088cb40(16);
            _0x0a0ef75c355d.result = _0x7a039088cb40(201);
            const _0x4a6dfd35dbbe = _0x0c9cd6fa91d1.length;
            _0x0c9cd6fa91d1.push(_0x0a0ef75c355d);
            _0x931f521a135f.push(_0x4a6dfd35dbbe);
            continue;
        }
        _0x0c9cd6fa91d1.push({
            ..._0xea2d88bc51e0,
            draftRowId: _0xd7a8e9cce657 || _0xcc4c5febdd97(_0xea2d88bc51e0.draftRowId) || crypto.randomUUID(),
            sourceIndex: _0xb90052351b33,
            rowNumber: _0xb90052351b33 + 1
        });
    }
    const _0x84929e426236 = [];
    for (const _0xe491d1235c5a of _0x67563117b490) {
        if (_0x60d3401c2ddc.has(_0xe491d1235c5a)) {
            continue;
        }
        const _0x3f60fde1222f = _0xe491d1235c5a.result === _0x7a039088cb40(238) && !_0x7d58e108a4a5(_0xe491d1235c5a.orderId);
        if (_0x3f60fde1222f) {
            _0x84929e426236.push(_0xe491d1235c5a.rowNumber || _0xe491d1235c5a.sourceIndex + 1);
            continue;
        }
        _0x0c9cd6fa91d1.push({ ..._0xe491d1235c5a });
    }
    if (_0xf309051095b5.length > 0) {
        return {
            error: `当前输入表格存在重复内部行标识，涉及原工作记录第 ${_0xf309051095b5.join(_0x7a039088cb40(86))} 行。请清空并重新粘贴后再重下。`
        };
    }
    if (_0x84929e426236.length > 0) {
        return {
            error: `有 ${_0x84929e426236.length} 条跳过记录已从当前输入表格删除或无法对应（原第 ${_0x84929e426236.join(_0x7a039088cb40(86))} 行），不能保证安全覆盖工作结果。`
        };
    }
    if (_0x931f521a135f.length === 0) {
        return { error: _0x7a039088cb40(124) };
    }
    const _0xc14bfd15589a = new Map();
    for (const _0x39e26745f832 of _0x931f521a135f) {
        const _0x7e94e88cdf84 = _0x0c9cd6fa91d1[_0x39e26745f832];
        if (!_0x7e94e88cdf84.addressSignature) {
            _0x0f9db2374199(_0x7e94e88cdf84, _0x7e94e88cdf84.initialFailureReason || _0x7a039088cb40(186), _0x7a039088cb40(238));
            continue;
        }
        if (!_0xc14bfd15589a.has(_0x7e94e88cdf84.addressSignature)) {
            _0xc14bfd15589a.set(_0x7e94e88cdf84.addressSignature, []);
        }
        _0xc14bfd15589a.get(_0x7e94e88cdf84.addressSignature).push(_0x39e26745f832);
    }
    const _0x481291da3c7c = [..._0xc14bfd15589a.values()].map((_0x0687f74db6cb, _0xc6df2a593edb) => _0xc4b187d8262c(_0x0c9cd6fa91d1, _0x0687f74db6cb, _0xc6df2a593edb + 1));
    _0x481291da3c7c.sort((_0x76f9185b4062, _0x1399bfa525cf) => _0x76f9185b4062.originalPosition - _0x1399bfa525cf.originalPosition);
    for (const _0x6c4bf46da990 of _0x481291da3c7c) {
        const _0x3724c0a0ec15 = _0x6c4bf46da990.rowIndexes.find((_0xe777a977836e) => _0x0c9cd6fa91d1[_0xe777a977836e].initialFailureReason);
        if (_0x3724c0a0ec15 !== undefined) {
            _0x1a9d3a7c154f(_0x0c9cd6fa91d1, _0x6c4bf46da990, _0x3724c0a0ec15, _0x0c9cd6fa91d1[_0x3724c0a0ec15].initialFailureReason);
        }
        else {
            _0x6c4bf46da990.result = _0x7a039088cb40(169);
            _0x6c4bf46da990.status = _0x7a039088cb40(16);
            for (const _0xd999e289de2f of _0x6c4bf46da990.rowIndexes) {
                _0x0f9db2374199(_0x0c9cd6fa91d1[_0xd999e289de2f], _0x7a039088cb40(16), _0x7a039088cb40(169));
            }
        }
    }
    const _0x78e5f7586df3 = [];
    const _0x276794901076 = new Map();
    for (const _0x26bccc82daa0 of _0x481291da3c7c) {
        for (const _0xce4dcecb38ae of _0x26bccc82daa0.uniqueTemuOrderIds) {
            if (!_0x276794901076.has(_0xce4dcecb38ae)) {
                _0x276794901076.set(_0xce4dcecb38ae, new Set());
            }
            _0x276794901076.get(_0xce4dcecb38ae).add(_0x26bccc82daa0.id);
        }
    }
    for (const [_0x6291baa98a80, _0x81d32795c334] of _0x276794901076.entries()) {
        if (_0x81d32795c334.size <= 1) {
            continue;
        }
        const _0xc4bbbbe0b383 = `重下数据中 Temu Order ID ${_0x6291baa98a80} 出现在不同收件地址组，已停止等待人工检查。`;
        _0x78e5f7586df3.push(_0xc4bbbbe0b383);
        for (const _0x38a4339033cf of _0x81d32795c334) {
            const _0x48499dad78f7 = _0x481291da3c7c.find((_0x6033ca043a0f) => _0x6033ca043a0f.id === _0x38a4339033cf);
            if (_0x48499dad78f7) {
                _0xe81840907d4e(_0x0c9cd6fa91d1, _0x48499dad78f7, _0xc4bbbbe0b383);
            }
        }
    }
    const _0x9aec3e22109e = [...new Set([
            ...Object.values(_0xc582f0665fc6)
                .map((_0x487ffe180b2d) => String(_0x487ffe180b2d?.orderId || _0x7a039088cb40(172)).trim())
                .filter(_0x7d58e108a4a5),
            ..._0x67563117b490.map((_0x865118c30677) => String(_0x865118c30677?.orderId || _0x7a039088cb40(172)).trim())
                .filter(_0x7d58e108a4a5)
        ])];
    return {
        rows: _0x0c9cd6fa91d1,
        groups: _0x481291da3c7c,
        orderIndex: _0xc582f0665fc6,
        fatalConflicts: _0x78e5f7586df3,
        knownOrderIds: _0x9aec3e22109e,
        retryCount: _0x931f521a135f.length
    };
}
function _0x395fc3223ef8(_0x68706b3589c2, _0xab03401917aa = -1) {
    for (let _0x87ab6a3015e4 = _0xab03401917aa + 1; _0x87ab6a3015e4 < _0x68706b3589c2.length; _0x87ab6a3015e4 += 1) {
        if (_0x68706b3589c2[_0x87ab6a3015e4]?.result === _0x7a039088cb40(169)) {
            return _0x87ab6a3015e4;
        }
    }
    return -1;
}
function _0xd422dd9d0b08(_0x767c9043cc82) {
    if (!_0x767c9043cc82 || !Array.isArray(_0x767c9043cc82.groups) || !Number.isInteger(_0x767c9043cc82.currentGroupIndex)) {
        return null;
    }
    return _0x767c9043cc82.groups[_0x767c9043cc82.currentGroupIndex] || null;
}
function _0x9ee79768b312(_0xa3f1dbc2f899) {
    if (!_0xa3f1dbc2f899 || !Array.isArray(_0xa3f1dbc2f899.rows) || !Number.isInteger(_0xa3f1dbc2f899.currentIndex)) {
        return null;
    }
    return _0xa3f1dbc2f899.rows[_0xa3f1dbc2f899.currentIndex] || null;
}
function _0x7e1b2a3dfb08(_0x7bed01d60cf4) {
    const _0xcc2e295c5db3 = _0xd422dd9d0b08(_0x7bed01d60cf4);
    if (!_0xcc2e295c5db3 || !Array.isArray(_0x7bed01d60cf4?.rows)) {
        return _0x9ee79768b312(_0x7bed01d60cf4);
    }
    return _0x7bed01d60cf4.rows[_0xcc2e295c5db3.primaryRowIndex] || _0x9ee79768b312(_0x7bed01d60cf4);
}
async function _0x6fe49eb4993c() {
    return chrome.storage.local.get([
        _0xcaf96649348b.RUN_STATE,
        _0xcaf96649348b.HISTORY,
        _0xcaf96649348b.ORDER_INDEX,
        _0xcaf96649348b.CART_LOCK,
        _0xcaf96649348b.LOGS,
        _0xcaf96649348b.DRAFT_ROWS,
        _0xcaf96649348b.SETTINGS
    ]);
}
async function _0x56fe6cac629b() {
    const _0xed2ab79b251d = chrome.runtime.getURL(_0x7a039088cb40(147));
    const _0x4ae092618e41 = await chrome.windows.getAll({ populate: true });
    for (const _0xb84e5ed64791 of _0x4ae092618e41) {
        const _0x19c0f0b2066d = _0xb84e5ed64791.tabs?.find((_0x8ca70dad8773) => _0x8ca70dad8773.url === _0xed2ab79b251d);
        if (_0x19c0f0b2066d) {
            await chrome.windows.update(_0xb84e5ed64791.id, { focused: true });
            await chrome.tabs.update(_0x19c0f0b2066d.id, { active: true });
            return;
        }
    }
    await chrome.windows.create({
        url: _0xed2ab79b251d,
        type: _0x7a039088cb40(71),
        width: 1440,
        height: 920,
        focused: true
    });
}
async function _0xccd82dbe5f3a(_0x914dd54939ed = null) {
    if (Number.isInteger(_0x914dd54939ed)) {
        try {
            const _0x6a04aab2a45b = await chrome.tabs.get(_0x914dd54939ed);
            await chrome.tabs.update(_0x6a04aab2a45b.id, { url: _0x7a039088cb40(157), active: true });
            await chrome.windows.update(_0x6a04aab2a45b.windowId, { focused: true });
            await _0xd54f82b58d09(120);
            return _0x6a04aab2a45b.id;
        }
        catch {
        }
    }
    const _0x4f0b5dc3e706 = await chrome.windows.getAll({ windowTypes: [_0x7a039088cb40(212)] });
    const _0xfeaa6feeab35 = _0x4f0b5dc3e706.find((_0xa8d37f199d28) => _0xa8d37f199d28.focused) || _0x4f0b5dc3e706[0];
    if (_0xfeaa6feeab35) {
        const _0x100999224a8b = await chrome.tabs.create({
            windowId: _0xfeaa6feeab35.id,
            url: _0x7a039088cb40(157),
            active: true
        });
        await chrome.windows.update(_0xfeaa6feeab35.id, { focused: true });
        return _0x100999224a8b.id;
    }
    const _0x591eb38470cd = await chrome.windows.create({
        type: _0x7a039088cb40(212),
        url: _0x7a039088cb40(157),
        focused: true
    });
    const _0xfe2a679c77b7 = _0x591eb38470cd.tabs?.[0]?.id;
    if (!Number.isInteger(_0xfe2a679c77b7)) {
        throw new Error(_0x7a039088cb40(232));
    }
    return _0xfe2a679c77b7;
}
async function _0xc91066d77463(_0x0b18fe92b9cf) {
    if (!Number.isInteger(_0x0b18fe92b9cf)) {
        throw new Error(_0x7a039088cb40(65));
    }
    const _0x065b0e3adcdf = await chrome.tabs.get(_0x0b18fe92b9cf);
    await chrome.tabs.update(_0x0b18fe92b9cf, { active: true });
    await chrome.windows.update(_0x065b0e3adcdf.windowId, { focused: true });
}
async function _0x5e364a929d0c(_0xa8f4820aca23) {
    if (!Number.isInteger(_0xa8f4820aca23)) {
        return;
    }
    try {
        await chrome.tabs.sendMessage(_0xa8f4820aca23, { type: _0x7a039088cb40(165) });
    }
    catch {
    }
}
async function _0xb6d8e0551352(_0x9b425797c130, _0x9ac00b69ebc2) {
    if (!Number.isInteger(_0x9b425797c130)) {
        throw new Error(_0x7a039088cb40(65));
    }
    await chrome.tabs.update(_0x9b425797c130, { url: _0x9ac00b69ebc2, active: true });
    await _0xc91066d77463(_0x9b425797c130);
}
async function _0x9dbbfec3a9e5(_0x113d92e940bd, _0x0759d0909995, _0x1cfa40d736dd, _0xbae7f8e936d6 = {}, _0xbfffc4f4cb31 = _0x7a039088cb40(204)) {
    const _0x4c061eea00fb = Number.isInteger(_0x113d92e940bd?.workTabId) ? _0x113d92e940bd.workTabId : null;
    let _0xe3e69339478a = null;
    let _0xa25acb73e39b = null;
    if (_0x4c061eea00fb !== null) {
        try {
            _0xe3e69339478a = await chrome.tabs.get(_0x4c061eea00fb);
        }
        catch {
            _0xe3e69339478a = null;
        }
    }
    try {
        if (_0xe3e69339478a) {
            const _0xe851f9a16704 = {
                windowId: _0xe3e69339478a.windowId,
                url: _0x7a039088cb40(157),
                active: true
            };
            if (Number.isInteger(_0xe3e69339478a.index)) {
                _0xe851f9a16704.index = _0xe3e69339478a.index + 1;
            }
            const _0x098ca7f51b16 = await chrome.tabs.create(_0xe851f9a16704);
            if (!Number.isInteger(_0x098ca7f51b16?.id)) {
                throw new Error(_0x7a039088cb40(152));
            }
            _0xa25acb73e39b = _0x098ca7f51b16.id;
            await chrome.windows.update(_0xe3e69339478a.windowId, { focused: true });
        }
        else {
            _0xa25acb73e39b = await _0xccd82dbe5f3a(null);
        }
        _0x113d92e940bd.workTabId = _0xa25acb73e39b;
        _0x113d92e940bd.updatedAt = new Date().toISOString();
        await _0x9fec061c38d6(_0x113d92e940bd, _0x0759d0909995, _0xbae7f8e936d6);
        await _0xb6d8e0551352(_0xa25acb73e39b, _0x1cfa40d736dd);
        if (_0x4c061eea00fb !== null && _0x4c061eea00fb !== _0xa25acb73e39b) {
            try {
                await chrome.tabs.remove(_0x4c061eea00fb);
            }
            catch {
            }
        }
        return { ok: true, oldTabId: _0x4c061eea00fb, newTabId: _0xa25acb73e39b };
    }
    catch (_0x8c27028520e0) {
        if (Number.isInteger(_0xa25acb73e39b) && _0xa25acb73e39b !== _0x4c061eea00fb) {
            try {
                await chrome.tabs.remove(_0xa25acb73e39b);
            }
            catch {
            }
        }
        let _0x98a04e586d58 = false;
        if (_0x4c061eea00fb !== null) {
            try {
                await chrome.tabs.get(_0x4c061eea00fb);
                _0x98a04e586d58 = true;
            }
            catch {
                _0x98a04e586d58 = false;
            }
        }
        _0x113d92e940bd.workTabId = _0x98a04e586d58 ? _0x4c061eea00fb : null;
        _0x113d92e940bd.mode = _0x7a039088cb40(136);
        _0x113d92e940bd.pauseReason = `${_0xbfffc4f4cb31}失败：${_0x8c27028520e0.message || String(_0x8c27028520e0)}`;
        _0x113d92e940bd.updatedAt = new Date().toISOString();
        const _0x6b1ed518ac7e = _0xd422dd9d0b08(_0x113d92e940bd);
        const _0xf4fed08ecb1f = _0x9ee79768b312(_0x113d92e940bd);
        if (_0x6b1ed518ac7e?.isCombined) {
            _0xe81840907d4e(_0x113d92e940bd.rows, _0x6b1ed518ac7e, _0x113d92e940bd.pauseReason);
        }
        else if (_0xf4fed08ecb1f) {
            _0x0f9db2374199(_0xf4fed08ecb1f, `等待人工检查：${_0x113d92e940bd.pauseReason}`, _0x7a039088cb40(99));
        }
        _0x8d616eca1a29(_0x0759d0909995, _0x7a039088cb40(20), _0x113d92e940bd.pauseReason, _0xf4fed08ecb1f?.rowNumber ?? null);
        await _0x9fec061c38d6(_0x113d92e940bd, _0x0759d0909995, _0xbae7f8e936d6);
        return { ok: false, error: _0x113d92e940bd.pauseReason };
    }
}
async function _0x9fec061c38d6(_0xe1da57a47895, _0x3c2383193599, _0x09c874c09885 = {}) {
    await chrome.storage.local.set({
        [_0xcaf96649348b.RUN_STATE]: _0xe1da57a47895,
        [_0xcaf96649348b.LOGS]: _0x3c2383193599,
        ..._0x09c874c09885
    });
}
function _0x9b5d4010766c(_0x965a858fe2f8, _0x41412b1358f4) {
    return {
        version: 1,
        runId: _0x965a858fe2f8.runId,
        groupId: _0x41412b1358f4.id,
        groupSignature: _0x41412b1358f4.groupSignature,
        rowNumbers: _0x41412b1358f4.rowIndexes.map((_0xa739c5de2a15) => _0x965a858fe2f8.rows[_0xa739c5de2a15].rowNumber),
        temuOrderIds: _0x41412b1358f4.uniqueTemuOrderIds,
        expectedTotalQuantity: _0x41412b1358f4.expectedTotalQuantity,
        expectedItems: _0x41412b1358f4.expectedItems,
        addedRowIndexes: [],
        expectedCartCount: 0,
        stage: _0x7a039088cb40(70),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
}
function _0x863787a6bab8(_0xe8a04476ee7d, _0x535acb508873, _0xa17eb5a1edf5) {
    return Boolean(_0xe8a04476ee7d &&
        _0xe8a04476ee7d.runId === _0x535acb508873?.runId &&
        _0xe8a04476ee7d.groupId === _0xa17eb5a1edf5?.id &&
        _0xe8a04476ee7d.groupSignature === _0xa17eb5a1edf5?.groupSignature);
}
async function _0x17f92a0c8392(_0x913130aba004, _0x88ec78b2fd2e) {
    const _0x14ecbd69fa33 = await _0x6fe49eb4993c();
    const _0x5adba094d345 = Array.isArray(_0x14ecbd69fa33[_0xcaf96649348b.LOGS]) ? _0x14ecbd69fa33[_0xcaf96649348b.LOGS] : [];
    if (_0x14ecbd69fa33[_0xcaf96649348b.CART_LOCK]) {
        _0x8d616eca1a29(_0x5adba094d345, _0x7a039088cb40(20), _0x7a039088cb40(93));
        await chrome.storage.local.set({ [_0xcaf96649348b.LOGS]: _0x5adba094d345 });
        return {
            ok: false,
            error: _0x7a039088cb40(72)
        };
    }
    const _0x839446312ae6 = _0x14ecbd69fa33[_0xcaf96649348b.RUN_STATE];
    if (_0x839446312ae6 && _0x2098732dc69d.has(_0x839446312ae6.mode)) {
        return {
            ok: false,
            error: _0x7a039088cb40(233)
        };
    }
    if (_0x839446312ae6?.runId) {
        await _0xc413dbf4d41b(_0x839446312ae6.runId);
    }
    const _0x2055c0851224 = _0x7a411f09453c(_0x14ecbd69fa33[_0xcaf96649348b.SETTINGS]);
    const _0xf474c0f5cfb5 = _0x88ec78b2fd2e ?? _0x2055c0851224.orderIntervalSeconds;
    const _0xc6d7d02bafb4 = Number(_0xf474c0f5cfb5);
    if (!Number.isInteger(_0xc6d7d02bafb4) || _0xc6d7d02bafb4 < 0 || _0xc6d7d02bafb4 > 3600) {
        return { ok: false, error: _0x7a039088cb40(236) };
    }
    const _0xb0d35bc317f3 = _0xc6d7d02bafb4;
    const _0xb67fc28d9a93 = { orderIntervalSeconds: _0xb0d35bc317f3 };
    const _0x961a093ad608 = _0xa2248a8b28d3(_0x14ecbd69fa33[_0xcaf96649348b.HISTORY]);
    const _0xdd4b75e181d5 = _0xfa3a2c2887bc(_0x913130aba004, _0x961a093ad608, _0x14ecbd69fa33[_0xcaf96649348b.ORDER_INDEX]);
    const { rows: _0xdad27fb34a99, groups: _0xb7eda411e0fd, orderIndex: _0xf36f61adbea3, fatalConflicts: _0x86f3d04eff24, knownOrderIds: _0x1299ce93b305 } = _0xdd4b75e181d5;
    if (_0xdad27fb34a99.length === 0) {
        return { ok: false, error: _0x7a039088cb40(94) };
    }
    _0x8d616eca1a29(_0x5adba094d345, _0x7a039088cb40(209), `任务预检查开始：共 ${_0xdad27fb34a99.length} 条非空数据，内部形成 ${_0xb7eda411e0fd.length} 个收件人地址组。`);
    _0x8d616eca1a29(_0x5adba094d345, _0x7a039088cb40(209), _0x7a039088cb40(4));
    for (const _0xe68caa8eb5db of _0xb7eda411e0fd) {
        if (_0xe68caa8eb5db.phoneMismatch) {
            const _0xcfa762bdfad3 = _0xdad27fb34a99[_0xe68caa8eb5db.primaryRowIndex];
            _0x8d616eca1a29(_0x5adba094d345, _0x7a039088cb40(15), `同地址组合单存在不同电话号码，将使用原始输入中最先出现一行的电话号码：${_0xcfa762bdfad3.phoneNumber}。`, _0xcfa762bdfad3.rowNumber);
        }
    }
    const _0xd31aa4361f6b = _0xb7eda411e0fd.filter((_0xd26f6fbcb0d8) => _0xd26f6fbcb0d8.result === _0x7a039088cb40(169)).length;
    const _0x2081f55c0ced = _0xb7eda411e0fd.filter((_0x2e43087d3d26) => _0x2e43087d3d26.result === _0x7a039088cb40(169) && _0x2e43087d3d26.isCombined).length;
    const _0x2cb9742e6f0d = _0xdad27fb34a99.filter((_0x147f95ee08ff) => _0x147f95ee08ff.result === _0x7a039088cb40(238)).length;
    _0x8d616eca1a29(_0x5adba094d345, _0x7a039088cb40(209), `预检查完成：待处理地址组 ${_0xd31aa4361f6b} 个（其中组合单 ${_0x2081f55c0ced} 个），预先跳过 ${_0x2cb9742e6f0d} 行。`);
    if (_0x86f3d04eff24.length > 0) {
        const _0x37a904149be1 = _0xb7eda411e0fd.findIndex((_0xf3e385b7a0d2) => _0xf3e385b7a0d2.result === _0x7a039088cb40(99));
        const _0x7c142e03b0a5 = _0xb7eda411e0fd[_0x37a904149be1] || null;
        const _0x67ccc2011611 = {
            version: _0x72caa2d2f815,
            runId: crypto.randomUUID(),
            mode: _0x7a039088cb40(136),
            phase: _0x7a039088cb40(140),
            pauseReason: _0x86f3d04eff24[0],
            currentGroupIndex: _0x37a904149be1 >= 0 ? _0x37a904149be1 : null,
            currentIndex: _0x7c142e03b0a5?.primaryRowIndex ?? null,
            rows: _0xdad27fb34a99,
            groups: _0xb7eda411e0fd,
            workTabId: null,
            orderIntervalSeconds: _0xb0d35bc317f3,
            intervalEndsAt: null,
            intervalRemainingSeconds: 0,
            knownOrderIds: _0x1299ce93b305,
            todayDateKey: _0xa5552c751906(),
            startedAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        _0x86f3d04eff24.forEach((_0xb1e179d60e21) => _0x8d616eca1a29(_0x5adba094d345, _0x7a039088cb40(20), _0xb1e179d60e21));
        await _0x9fec061c38d6(_0x67ccc2011611, _0x5adba094d345, {
            [_0xcaf96649348b.DRAFT_ROWS]: Array.isArray(_0x913130aba004) ? _0x913130aba004 : [],
            [_0xcaf96649348b.HISTORY]: _0x961a093ad608,
            [_0xcaf96649348b.ORDER_INDEX]: _0xf36f61adbea3
        });
        return { ok: true, state: _0x67ccc2011611, paused: true, started: false };
    }
    const _0xcd18e27919ec = _0x395fc3223ef8(_0xb7eda411e0fd);
    if (_0xcd18e27919ec === -1) {
        const _0xee4a290a8a30 = {
            version: _0x72caa2d2f815,
            runId: crypto.randomUUID(),
            mode: _0x7a039088cb40(120),
            phase: _0x7a039088cb40(163),
            pauseReason: _0x7a039088cb40(172),
            currentGroupIndex: null,
            currentIndex: null,
            rows: _0xdad27fb34a99,
            groups: _0xb7eda411e0fd,
            workTabId: null,
            orderIntervalSeconds: _0xb0d35bc317f3,
            intervalEndsAt: null,
            intervalRemainingSeconds: 0,
            knownOrderIds: _0x1299ce93b305,
            todayDateKey: _0xa5552c751906(),
            startedAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        _0x8d616eca1a29(_0x5adba094d345, _0x7a039088cb40(198), _0x7a039088cb40(64));
        await _0x9fec061c38d6(_0xee4a290a8a30, _0x5adba094d345, {
            [_0xcaf96649348b.DRAFT_ROWS]: Array.isArray(_0x913130aba004) ? _0x913130aba004 : [],
            [_0xcaf96649348b.HISTORY]: _0x961a093ad608,
            [_0xcaf96649348b.ORDER_INDEX]: _0xf36f61adbea3
        });
        return { ok: true, state: _0xee4a290a8a30, started: false };
    }
    const _0x038f37e3c057 = Number.isInteger(_0x839446312ae6?.workTabId) ? _0x839446312ae6.workTabId : null;
    let _0x7b3ae6aa05c1;
    try {
        _0x7b3ae6aa05c1 = await _0xccd82dbe5f3a(_0x038f37e3c057);
    }
    catch (_0xef85932e4607) {
        return { ok: false, error: _0xef85932e4607.message || String(_0xef85932e4607) };
    }
    const _0x22e312340899 = {
        version: _0x72caa2d2f815,
        runId: crypto.randomUUID(),
        mode: _0x7a039088cb40(148),
        phase: _0x7a039088cb40(76),
        pauseReason: _0x7a039088cb40(172),
        currentGroupIndex: _0xcd18e27919ec,
        currentIndex: _0xb7eda411e0fd[_0xcd18e27919ec].primaryRowIndex,
        rows: _0xdad27fb34a99,
        groups: _0xb7eda411e0fd,
        workTabId: _0x7b3ae6aa05c1,
        orderIntervalSeconds: _0xb0d35bc317f3,
        intervalEndsAt: null,
        intervalRemainingSeconds: 0,
        knownOrderIds: _0x1299ce93b305,
        todayDateKey: _0xa5552c751906(),
        startedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    _0x8d616eca1a29(_0x5adba094d345, _0x7a039088cb40(209), _0x7a039088cb40(89));
    _0x8d616eca1a29(_0x5adba094d345, _0x7a039088cb40(209), _0x7a039088cb40(126));
    _0x8d616eca1a29(_0x5adba094d345, _0x7a039088cb40(209), _0x7a039088cb40(114));
    _0x8d616eca1a29(_0x5adba094d345, _0x7a039088cb40(209), `成功取得一个 Amazon Order ID 后等待 ${_0xb0d35bc317f3} 秒，再处理下一个地址组。`);
    await _0x9fec061c38d6(_0x22e312340899, _0x5adba094d345, {
        [_0xcaf96649348b.DRAFT_ROWS]: Array.isArray(_0x913130aba004) ? _0x913130aba004 : [],
        [_0xcaf96649348b.HISTORY]: _0x961a093ad608,
        [_0xcaf96649348b.ORDER_INDEX]: _0xf36f61adbea3
    });
    const _0xe0d02c9853ba = await _0x86e2ed4b960a(_0x22e312340899, _0x5adba094d345, false);
    const _0xc9d733dda6c6 = !_0xe0d02c9853ba?.error && !_0xe0d02c9853ba?.authorizationFailed;
    if (_0xc9d733dda6c6) {
        await chrome.storage.local.set({ [_0xcaf96649348b.SETTINGS]: _0xb67fc28d9a93 });
    }
    return {
        ok: true,
        state: _0x22e312340899,
        started: _0xc9d733dda6c6,
        paused: Boolean(_0xe0d02c9853ba?.error || _0xe0d02c9853ba?.authorizationFailed),
        settings: _0xc9d733dda6c6 ? _0xb67fc28d9a93 : _0x2055c0851224
    };
}
async function _0xc77b36460513(_0xff5e978e2649, _0xd63b12c5abc1) {
    const _0x557074b9410a = await _0x6fe49eb4993c();
    const _0x0fb7f714ffb9 = Array.isArray(_0x557074b9410a[_0xcaf96649348b.LOGS]) ? _0x557074b9410a[_0xcaf96649348b.LOGS] : [];
    const _0x66272b364110 = _0x557074b9410a[_0xcaf96649348b.RUN_STATE];
    if (_0x557074b9410a[_0xcaf96649348b.CART_LOCK]) {
        _0x8d616eca1a29(_0x0fb7f714ffb9, _0x7a039088cb40(20), _0x7a039088cb40(9));
        await chrome.storage.local.set({ [_0xcaf96649348b.LOGS]: _0x0fb7f714ffb9 });
        return { ok: false, error: _0x7a039088cb40(44) };
    }
    if (!_0x66272b364110 || ![_0x7a039088cb40(120), _0x7a039088cb40(137)].includes(_0x66272b364110.mode)) {
        return { ok: false, error: _0x7a039088cb40(47) };
    }
    if (_0x66272b364110.runId) {
        await _0xc413dbf4d41b(_0x66272b364110.runId);
    }
    const _0x68dc6ffa0685 = _0x7a411f09453c(_0x557074b9410a[_0xcaf96649348b.SETTINGS]);
    const _0x0c5fff15f232 = _0xd63b12c5abc1 ?? _0x68dc6ffa0685.orderIntervalSeconds;
    const _0x787433fce232 = Number(_0x0c5fff15f232);
    if (!Number.isInteger(_0x787433fce232) || _0x787433fce232 < 0 || _0x787433fce232 > 3600) {
        return { ok: false, error: _0x7a039088cb40(236) };
    }
    const _0xf8ae65532e8f = _0x787433fce232;
    const _0xa1fe90ad6204 = { orderIntervalSeconds: _0xf8ae65532e8f };
    const _0xd968d8f48f0f = _0xa2248a8b28d3(_0x557074b9410a[_0xcaf96649348b.HISTORY]);
    const _0x7ddc0cae3f44 = _0x7e67cc333945(_0xff5e978e2649, _0x66272b364110.rows, _0xd968d8f48f0f, _0x557074b9410a[_0xcaf96649348b.ORDER_INDEX]);
    if (_0x7ddc0cae3f44.error) {
        _0x8d616eca1a29(_0x0fb7f714ffb9, _0x7a039088cb40(20), _0x7ddc0cae3f44.error);
        await chrome.storage.local.set({ [_0xcaf96649348b.LOGS]: _0x0fb7f714ffb9 });
        return { ok: false, error: _0x7ddc0cae3f44.error };
    }
    const { rows: _0x3f2cd4a95654, groups: _0xf6735cd9aa06, orderIndex: _0x4689e2adfc2b, fatalConflicts: _0xe6c8e6b67e47, knownOrderIds: _0xfbd122775be4, retryCount: _0x9114a8bdc540 } = _0x7ddc0cae3f44;
    _0x8d616eca1a29(_0x0fb7f714ffb9, _0x7a039088cb40(15), `开始“重下所有跳过单”：使用当前输入表格最新数据，共选择 ${_0x9114a8bdc540} 条 skipped 记录。`);
    _0x8d616eca1a29(_0x0fb7f714ffb9, _0x7a039088cb40(15), _0x7a039088cb40(129));
    _0x8d616eca1a29(_0x0fb7f714ffb9, _0x7a039088cb40(209), _0x7a039088cb40(203));
    for (const _0xe1fc45e36685 of _0xf6735cd9aa06) {
        if (_0xe1fc45e36685.phoneMismatch) {
            const _0xdca2e6b5a08b = _0x3f2cd4a95654[_0xe1fc45e36685.primaryRowIndex];
            _0x8d616eca1a29(_0x0fb7f714ffb9, _0x7a039088cb40(15), `重下组合单存在不同电话号码，将使用当前输入中最先出现一行的电话号码：${_0xdca2e6b5a08b.phoneNumber}。`, _0xdca2e6b5a08b.rowNumber);
        }
    }
    const _0x2abd88f810d6 = _0xf6735cd9aa06.filter((_0x0583f12049b5) => _0x0583f12049b5.result === _0x7a039088cb40(169)).length;
    const _0xe3cb47a281f0 = _0xf6735cd9aa06.filter((_0x6bec3711cd0d) => _0x6bec3711cd0d.result === _0x7a039088cb40(169) && _0x6bec3711cd0d.isCombined).length;
    const _0x7492b333507a = _0x3f2cd4a95654.filter((_0x9efd38eaf540) => _0x9efd38eaf540.result === _0x7a039088cb40(238)).length;
    _0x8d616eca1a29(_0x0fb7f714ffb9, _0x7a039088cb40(209), `重下预检查完成：待处理地址组 ${_0x2abd88f810d6} 个（其中组合单 ${_0xe3cb47a281f0} 个）；当前仍为 skipped 的工作记录 ${_0x7492b333507a} 行。`);
    const _0xf5304232e766 = {
        version: _0x72caa2d2f815,
        runId: crypto.randomUUID(),
        retryMode: _0x7a039088cb40(49),
        bypassTodayOrderCheck: true,
        rows: _0x3f2cd4a95654,
        groups: _0xf6735cd9aa06,
        orderIntervalSeconds: _0xf8ae65532e8f,
        intervalEndsAt: null,
        intervalRemainingSeconds: 0,
        knownOrderIds: _0xfbd122775be4,
        todayDateKey: _0xa5552c751906(),
        startedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    if (_0xe6c8e6b67e47.length > 0) {
        const _0x903a65c83f54 = _0xf6735cd9aa06.findIndex((_0x4f4871720d59) => _0x4f4871720d59.result === _0x7a039088cb40(99));
        const _0xc35a08abd390 = _0xf6735cd9aa06[_0x903a65c83f54] || null;
        const _0x59527ad75b0c = {
            ..._0xf5304232e766,
            mode: _0x7a039088cb40(136),
            phase: _0x7a039088cb40(140),
            pauseReason: _0xe6c8e6b67e47[0],
            currentGroupIndex: _0x903a65c83f54 >= 0 ? _0x903a65c83f54 : null,
            currentIndex: _0xc35a08abd390?.primaryRowIndex ?? null,
            workTabId: null
        };
        _0xe6c8e6b67e47.forEach((_0x4cf4ddd33433) => _0x8d616eca1a29(_0x0fb7f714ffb9, _0x7a039088cb40(20), _0x4cf4ddd33433));
        await _0x9fec061c38d6(_0x59527ad75b0c, _0x0fb7f714ffb9, {
            [_0xcaf96649348b.DRAFT_ROWS]: Array.isArray(_0xff5e978e2649) ? _0xff5e978e2649 : [],
            [_0xcaf96649348b.HISTORY]: _0xd968d8f48f0f,
            [_0xcaf96649348b.ORDER_INDEX]: _0x4689e2adfc2b
        });
        return { ok: true, state: _0x59527ad75b0c, paused: true, retryCount: _0x9114a8bdc540, started: false };
    }
    const _0x2340712cef5c = _0x395fc3223ef8(_0xf6735cd9aa06);
    if (_0x2340712cef5c === -1) {
        const _0xb33e8e39d2dc = {
            ..._0xf5304232e766,
            mode: _0x7a039088cb40(120),
            phase: _0x7a039088cb40(163),
            pauseReason: _0x7a039088cb40(172),
            currentGroupIndex: null,
            currentIndex: null,
            workTabId: null
        };
        _0x8d616eca1a29(_0x0fb7f714ffb9, _0x7a039088cb40(198), _0x7a039088cb40(28));
        await _0x9fec061c38d6(_0xb33e8e39d2dc, _0x0fb7f714ffb9, {
            [_0xcaf96649348b.DRAFT_ROWS]: Array.isArray(_0xff5e978e2649) ? _0xff5e978e2649 : [],
            [_0xcaf96649348b.HISTORY]: _0xd968d8f48f0f,
            [_0xcaf96649348b.ORDER_INDEX]: _0x4689e2adfc2b
        });
        return { ok: true, state: _0xb33e8e39d2dc, retryCount: _0x9114a8bdc540, started: false };
    }
    let _0x30a8fc8b8fc6;
    try {
        _0x30a8fc8b8fc6 = await _0xccd82dbe5f3a(Number.isInteger(_0x66272b364110.workTabId) ? _0x66272b364110.workTabId : null);
    }
    catch (_0xccfa7d362233) {
        return { ok: false, error: _0xccfa7d362233.message || String(_0xccfa7d362233) };
    }
    const _0x13143c0e4f12 = {
        ..._0xf5304232e766,
        mode: _0x7a039088cb40(148),
        phase: _0x7a039088cb40(76),
        pauseReason: _0x7a039088cb40(172),
        currentGroupIndex: _0x2340712cef5c,
        currentIndex: _0xf6735cd9aa06[_0x2340712cef5c].primaryRowIndex,
        workTabId: _0x30a8fc8b8fc6
    };
    _0x8d616eca1a29(_0x0fb7f714ffb9, _0x7a039088cb40(209), _0x7a039088cb40(117));
    _0x8d616eca1a29(_0x0fb7f714ffb9, _0x7a039088cb40(209), `成功取得一个新 Amazon Order ID 后等待 ${_0xf8ae65532e8f} 秒，再处理下一个重下地址组。`);
    await _0x9fec061c38d6(_0x13143c0e4f12, _0x0fb7f714ffb9, {
        [_0xcaf96649348b.DRAFT_ROWS]: Array.isArray(_0xff5e978e2649) ? _0xff5e978e2649 : [],
        [_0xcaf96649348b.HISTORY]: _0xd968d8f48f0f,
        [_0xcaf96649348b.ORDER_INDEX]: _0x4689e2adfc2b
    });
    const _0x2c3e64949a4b = await _0x86e2ed4b960a(_0x13143c0e4f12, _0x0fb7f714ffb9, false);
    const _0x1a256512ff8a = !_0x2c3e64949a4b?.error && !_0x2c3e64949a4b?.authorizationFailed;
    if (_0x1a256512ff8a) {
        await chrome.storage.local.set({ [_0xcaf96649348b.SETTINGS]: _0xa1fe90ad6204 });
    }
    return {
        ok: true,
        state: _0x13143c0e4f12,
        retryCount: _0x9114a8bdc540,
        started: _0x1a256512ff8a,
        paused: Boolean(_0x2c3e64949a4b?.error || _0x2c3e64949a4b?.authorizationFailed),
        settings: _0x1a256512ff8a ? _0xa1fe90ad6204 : _0x68dc6ffa0685
    };
}
async function _0xdf5eeaefef4c(_0x4fbee82b86b6, _0xbecf982290ba) {
    const _0x7e110eb05b35 = await _0x6fe49eb4993c();
    const _0x0ac02bcf4d93 = _0x7e110eb05b35[_0xcaf96649348b.RUN_STATE];
    const _0xe7ee7606dca3 = Array.isArray(_0x7e110eb05b35[_0xcaf96649348b.LOGS]) ? _0x7e110eb05b35[_0xcaf96649348b.LOGS] : [];
    if (!_0x0ac02bcf4d93 || _0xbecf982290ba.tab?.id !== _0x0ac02bcf4d93.workTabId) {
        return { ok: false, error: _0x7a039088cb40(153) };
    }
    if (_0x0ac02bcf4d93.runId !== _0x4fbee82b86b6.runId) {
        return { ok: false, error: _0x7a039088cb40(108) };
    }
    if (_0x4fbee82b86b6.expectedPhase && _0x0ac02bcf4d93.phase !== _0x4fbee82b86b6.expectedPhase) {
        return { ok: false, stale: true, error: `当前阶段已变为 ${_0x0ac02bcf4d93.phase}。` };
    }
    if (_0x0ac02bcf4d93.mode !== _0x7a039088cb40(111)) {
        return { ok: false, paused: true, error: _0x7a039088cb40(237) };
    }
    const _0x1ae20184dd60 = _0x9ee79768b312(_0x0ac02bcf4d93);
    const _0xb08adf1fb94a = _0xd422dd9d0b08(_0x0ac02bcf4d93);
    _0x0ac02bcf4d93.phase = _0x4fbee82b86b6.nextPhase;
    _0x0ac02bcf4d93.updatedAt = new Date().toISOString();
    if (_0x1ae20184dd60 && Number.isFinite(Number(_0x4fbee82b86b6.observedUnitPrice))) {
        _0x1ae20184dd60.observedUnitPrice = Number(_0x4fbee82b86b6.observedUnitPrice).toFixed(2);
    }
    if (_0x1ae20184dd60 && Number.isSafeInteger(Number(_0x4fbee82b86b6.selectedQuantity)) && Number(_0x4fbee82b86b6.selectedQuantity) > 0) {
        _0x1ae20184dd60.selectedQuantity = Number(_0x4fbee82b86b6.selectedQuantity);
    }
    if (_0xb08adf1fb94a && _0x4fbee82b86b6.observedDeliveryAddress) {
        _0xb08adf1fb94a.actualDeliveryAddress = _0x1afacc1c0905(_0x4fbee82b86b6.observedDeliveryAddress);
    }
    if (typeof _0x4fbee82b86b6.paymentMethodAttempted === _0x7a039088cb40(191)) {
        _0x0ac02bcf4d93.paymentMethodAttempted = _0x4fbee82b86b6.paymentMethodAttempted;
    }
    if (_0x4fbee82b86b6.status) {
        if (_0xb08adf1fb94a?.isCombined && _0x07566f65198c.has(_0x4fbee82b86b6.nextPhase)) {
            _0x2d20ea6f6b9e(_0x0ac02bcf4d93.rows, _0xb08adf1fb94a, _0x4fbee82b86b6.status);
        }
        else if (_0x1ae20184dd60) {
            _0x0f9db2374199(_0x1ae20184dd60, _0x4fbee82b86b6.status, _0x7a039088cb40(167));
        }
    }
    if (_0x4fbee82b86b6.logMessage) {
        _0x8d616eca1a29(_0xe7ee7606dca3, _0x4fbee82b86b6.level || _0x7a039088cb40(209), _0x4fbee82b86b6.logMessage, _0x1ae20184dd60?.rowNumber ?? null);
    }
    await _0x9fec061c38d6(_0x0ac02bcf4d93, _0xe7ee7606dca3);
    return { ok: true, state: _0x0ac02bcf4d93 };
}
async function _0xdb927225336e(_0xf3e1b2a16cb0, _0x82bdea3a0beb) {
    const _0x243111451461 = await chrome.storage.local.get(_0xcaf96649348b.RUN_STATE);
    const _0x5bf9bf930d52 = _0x243111451461[_0xcaf96649348b.RUN_STATE] || null;
    const _0xbcca18371623 = Boolean(_0x5bf9bf930d52 &&
        _0x82bdea3a0beb.tab?.id === _0x5bf9bf930d52.workTabId &&
        _0x5bf9bf930d52.runId === _0xf3e1b2a16cb0.runId &&
        _0x8c713513dd6a.has(_0x5bf9bf930d52.phase) &&
        _0x8c713513dd6a.has(_0xf3e1b2a16cb0.nextPhase));
    if (!_0xbcca18371623) {
        const _0xf059c1b35054 = await _0x911a8739ff3b(false);
        if (!_0xf059c1b35054.ok) {
            return _0xf059c1b35054;
        }
    }
    return _0xdf5eeaefef4c(_0xf3e1b2a16cb0, _0x82bdea3a0beb);
}
async function _0x2709737f6710(_0x0f98182df719, _0x25b427ed1c6c) {
    const _0xda80c2c05991 = await _0x6fe49eb4993c();
    const _0x6243905ef14f = _0xda80c2c05991[_0xcaf96649348b.RUN_STATE];
    const _0xff0779d61924 = Array.isArray(_0xda80c2c05991[_0xcaf96649348b.LOGS]) ? _0xda80c2c05991[_0xcaf96649348b.LOGS] : [];
    if (!_0x6243905ef14f || _0x25b427ed1c6c.tab?.id !== _0x6243905ef14f.workTabId || _0x6243905ef14f.runId !== _0x0f98182df719.runId) {
        return { ok: false, stale: true };
    }
    if (_0x0f98182df719.expectedPhase && _0x6243905ef14f.phase !== _0x0f98182df719.expectedPhase) {
        return { ok: false, stale: true };
    }
    const _0x9eacd7d217fe = _0x9ee79768b312(_0x6243905ef14f);
    const _0x224bff4821b1 = _0xd422dd9d0b08(_0x6243905ef14f);
    _0x6243905ef14f.mode = _0x7a039088cb40(136);
    _0x6243905ef14f.pauseReason = _0x0f98182df719.reason || _0x7a039088cb40(138);
    _0x6243905ef14f.updatedAt = new Date().toISOString();
    if (_0x224bff4821b1?.isCombined) {
        _0xe81840907d4e(_0x6243905ef14f.rows, _0x224bff4821b1, _0x6243905ef14f.pauseReason);
    }
    else if (_0x9eacd7d217fe) {
        _0x0f9db2374199(_0x9eacd7d217fe, `等待人工检查：${_0x6243905ef14f.pauseReason}`, _0x7a039088cb40(99));
    }
    _0x8d616eca1a29(_0xff0779d61924, _0x7a039088cb40(20), _0x6243905ef14f.pauseReason, _0x9eacd7d217fe?.rowNumber ?? null);
    await _0x9fec061c38d6(_0x6243905ef14f, _0xff0779d61924);
    return { ok: true, state: _0x6243905ef14f };
}
async function _0x2bc7eac90e58(_0x54a77e36ed87, _0xf85ea35c9d94) {
    const _0x060997fcd806 = await _0x6fe49eb4993c();
    const _0x4c1feabff969 = _0x060997fcd806[_0xcaf96649348b.RUN_STATE];
    const _0x00a73da87996 = Array.isArray(_0x060997fcd806[_0xcaf96649348b.LOGS]) ? _0x060997fcd806[_0xcaf96649348b.LOGS] : [];
    const _0x87985be3d572 = _0xa2248a8b28d3(_0x060997fcd806[_0xcaf96649348b.HISTORY]);
    const _0xc78a5b89f414 = _0x5927bc040c8e(_0x060997fcd806[_0xcaf96649348b.ORDER_INDEX], _0x87985be3d572);
    let _0x22e3d6982a95 = _0x060997fcd806[_0xcaf96649348b.CART_LOCK] || null;
    if (!_0x4c1feabff969 || _0xf85ea35c9d94.tab?.id !== _0x4c1feabff969.workTabId || _0x4c1feabff969.runId !== _0x54a77e36ed87.runId) {
        return { ok: false, stale: true, error: _0x7a039088cb40(196) };
    }
    if (_0x4c1feabff969.mode !== _0x7a039088cb40(111) || _0x4c1feabff969.phase !== _0x7a039088cb40(78)) {
        return { ok: false, stale: true, error: `当前阶段不是付款页姓名验证阶段：${_0x4c1feabff969.phase}` };
    }
    const _0x4549ea748dee = _0xd422dd9d0b08(_0x4c1feabff969);
    const _0xd5d3c128aa48 = _0x7e1b2a3dfb08(_0x4c1feabff969);
    if (!_0x4549ea748dee || !_0xd5d3c128aa48) {
        return { ok: false, error: _0x7a039088cb40(223) };
    }
    const _0xd1487c960ebe = _0x1afacc1c0905(_0x54a77e36ed87.observedRecipientName);
    if (!_0xd1487c960ebe || _0xc4a6acb37df9(_0xd1487c960ebe) !== _0xc4a6acb37df9(_0x4549ea748dee.normalizedName)) {
        return { ok: false, error: _0x7a039088cb40(173) };
    }
    if (_0x4549ea748dee.isCombined) {
        if (!_0x4549ea748dee.rowIndexes.every((_0xe4e5621ba05a) => _0x4c1feabff969.rows[_0xe4e5621ba05a].precheckPassed && _0x4c1feabff969.rows[_0xe4e5621ba05a].addedToCart)) {
            return { ok: false, error: _0x7a039088cb40(32) };
        }
        if (!_0x863787a6bab8(_0x22e3d6982a95, _0x4c1feabff969, _0x4549ea748dee)) {
            return { ok: false, error: _0x7a039088cb40(219) };
        }
    }
    else {
        const _0x622547befedf = Number(_0xd5d3c128aa48.observedUnitPrice);
        if (!Number.isFinite(_0x622547befedf) || Math.abs(_0x622547befedf - 2) > 0.0001) {
            return { ok: false, error: _0x7a039088cb40(73) };
        }
        const _0x7f241c5b9b7a = Number(_0xd5d3c128aa48.selectedQuantity);
        if (!Number.isSafeInteger(_0x7f241c5b9b7a) ||
            _0x7f241c5b9b7a <= 0 ||
            _0x7f241c5b9b7a !== _0xd5d3c128aa48.requestedQuantity) {
            return { ok: false, error: _0x7a039088cb40(62) };
        }
    }
    if (!_0x4c1feabff969.bypassTodayOrderCheck) {
        const _0xb453a136ffe0 = _0xa5552c751906();
        for (const _0x1609289af431 of _0x4549ea748dee.uniqueTemuOrderIds) {
            const _0x2531e9af7b56 = _0xc78a5b89f414[_0x47588c686c5f(_0x1609289af431)];
            if (_0x2531e9af7b56?.status === _0x7a039088cb40(144) &&
                _0x2531e9af7b56.dateKey === _0xb453a136ffe0 &&
                _0x7d58e108a4a5(_0x2531e9af7b56.orderId)) {
                _0x4c1feabff969.mode = _0x7a039088cb40(136);
                _0x4c1feabff969.pauseReason = `最终付款前发现 Temu Order ID ${_0x1609289af431} 今天已有成功订单，已停止以避免重复下单。`;
                if (_0x4549ea748dee.isCombined) {
                    _0xe81840907d4e(_0x4c1feabff969.rows, _0x4549ea748dee, _0x4c1feabff969.pauseReason);
                }
                else {
                    _0x0f9db2374199(_0xd5d3c128aa48, `等待人工检查：${_0x4c1feabff969.pauseReason}`, _0x7a039088cb40(99));
                }
                _0x8d616eca1a29(_0x00a73da87996, _0x7a039088cb40(20), _0x4c1feabff969.pauseReason, _0xd5d3c128aa48.rowNumber);
                await _0x9fec061c38d6(_0x4c1feabff969, _0x00a73da87996, {
                    [_0xcaf96649348b.HISTORY]: _0x87985be3d572,
                    [_0xcaf96649348b.ORDER_INDEX]: _0xc78a5b89f414
                });
                return { ok: false, error: _0x4c1feabff969.pauseReason };
            }
        }
    }
    _0x4549ea748dee.actualDeliveryAddress = _0x1afacc1c0905(_0x54a77e36ed87.observedDeliveryAddress || _0x4549ea748dee.actualDeliveryAddress);
    if (_0x4549ea748dee.isCombined) {
        _0x2d20ea6f6b9e(_0x4c1feabff969.rows, _0x4549ea748dee, _0x7a039088cb40(171));
        _0x22e3d6982a95 = {
            ..._0x22e3d6982a95,
            stage: _0x7a039088cb40(183),
            actualDeliveryAddress: _0x4549ea748dee.actualDeliveryAddress,
            updatedAt: new Date().toISOString()
        };
    }
    else {
        _0x0f9db2374199(_0xd5d3c128aa48, _0x7a039088cb40(82), _0x7a039088cb40(167));
    }
    _0x4c1feabff969.phase = _0x7a039088cb40(239);
    _0x4c1feabff969.updatedAt = new Date().toISOString();
    _0x8d616eca1a29(_0x00a73da87996, _0x7a039088cb40(15), _0x4549ea748dee.isCombined
        ? `组合单共 ${_0x4549ea748dee.rowIndexes.length} 行、总数量 ${_0x4549ea748dee.expectedTotalQuantity}，付款页收件人姓名已核对；购物篮安全锁将保留到取得 Order ID。`
        : `商品含税单价 €2.00、精准数量 ${_0xd5d3c128aa48.requestedQuantity} 和付款页收件人姓名均已核对；只有取得 Order ID 后才计入当天下单记录。`, _0xd5d3c128aa48.rowNumber);
    const _0x8b4b8392845a = {
        [_0xcaf96649348b.HISTORY]: _0x87985be3d572,
        [_0xcaf96649348b.ORDER_INDEX]: _0xc78a5b89f414
    };
    if (_0x4549ea748dee.isCombined) {
        _0x8b4b8392845a[_0xcaf96649348b.CART_LOCK] = _0x22e3d6982a95;
    }
    await _0x9fec061c38d6(_0x4c1feabff969, _0x00a73da87996, _0x8b4b8392845a);
    return { ok: true, state: _0x4c1feabff969 };
}
async function _0x86e2ed4b960a(_0x55d55a87ba44, _0x81fb9136e77f, _0xf4c6bfeb3de8 = true) {
    const _0xf44e71019b2c = await _0x8e689ed9b70e(false);
    if (!_0xf44e71019b2c.authorized) {
        _0x43e4f44b3f3c(_0x55d55a87ba44, _0x81fb9136e77f);
        await _0x9fec061c38d6(_0x55d55a87ba44, _0x81fb9136e77f);
        return { completed: false, authorizationFailed: true, error: _0x58ad35219aee.failureMessage };
    }
    const _0x8cd08b14efb6 = _0xd422dd9d0b08(_0x55d55a87ba44);
    if (!_0x8cd08b14efb6) {
        return { completed: false, error: _0x7a039088cb40(12) };
    }
    _0x8cd08b14efb6.precheckCursor = 0;
    _0x8cd08b14efb6.addCursor = 0;
    _0x8cd08b14efb6.expectedCartCount = 0;
    _0x8cd08b14efb6.actualDeliveryAddress = _0x7a039088cb40(172);
    _0x8cd08b14efb6.orderId = _0x7a039088cb40(172);
    _0x8cd08b14efb6.result = _0x7a039088cb40(167);
    _0x8cd08b14efb6.updatedAt = new Date().toISOString();
    for (const _0x24d0da14d4ff of _0x8cd08b14efb6.rowIndexes) {
        const _0x0fff64946142 = _0x55d55a87ba44.rows[_0x24d0da14d4ff];
        _0x0fff64946142.precheckPassed = false;
        _0x0fff64946142.addedToCart = false;
        _0x0fff64946142.observedUnitPrice = _0x7a039088cb40(172);
        _0x0fff64946142.selectedQuantity = _0x7a039088cb40(172);
        _0x0fff64946142.orderId = _0x7a039088cb40(172);
    }
    const _0x44e063086e43 = _0x8cd08b14efb6.rowIndexes[0];
    const _0xed4ee98d354f = _0x55d55a87ba44.rows[_0x44e063086e43];
    _0x55d55a87ba44.currentIndex = _0x44e063086e43;
    _0x55d55a87ba44.mode = _0x7a039088cb40(111);
    _0x55d55a87ba44.phase = _0x8cd08b14efb6.isCombined ? _0x7a039088cb40(19) : _0x7a039088cb40(23);
    _0x55d55a87ba44.pauseReason = _0x7a039088cb40(172);
    _0x55d55a87ba44.intervalEndsAt = null;
    _0x55d55a87ba44.intervalRemainingSeconds = 0;
    _0x55d55a87ba44.paymentMethodAttempted = false;
    _0x55d55a87ba44.updatedAt = new Date().toISOString();
    if (_0x8cd08b14efb6.isCombined) {
        _0x2d20ea6f6b9e(_0x55d55a87ba44.rows, _0x8cd08b14efb6, _0x7a039088cb40(10));
        _0x8d616eca1a29(_0x81fb9136e77f, _0x7a039088cb40(209), `开始组合单：${_0x8cd08b14efb6.rowIndexes.length} 行，${_0x8cd08b14efb6.uniqueTemuOrderIds.length} 个唯一 Temu Order ID，总数量 ${_0x8cd08b14efb6.expectedTotalQuantity}。`, _0xed4ee98d354f.rowNumber);
    }
    else {
        _0x0f9db2374199(_0xed4ee98d354f, _0x7a039088cb40(51), _0x7a039088cb40(167));
        _0x8d616eca1a29(_0x81fb9136e77f, _0x7a039088cb40(209), `第 ${_0xed4ee98d354f.rowNumber} 行：开始单行 Buy Now 流程，Temu Order ID ${_0xed4ee98d354f.temuOrderId}，ASIN ${_0xed4ee98d354f.asin}，目标数量 ${_0xed4ee98d354f.requestedQuantity}。`, _0xed4ee98d354f.rowNumber);
    }
    if (_0xf4c6bfeb3de8) {
        _0x8d616eca1a29(_0x81fb9136e77f, _0x7a039088cb40(209), _0x7a039088cb40(103), _0xed4ee98d354f.rowNumber);
        const _0x6d4ecc5536f5 = await _0x9dbbfec3a9e5(_0x55d55a87ba44, _0x81fb9136e77f, _0xed4ee98d354f.amzLink, {}, _0x7a039088cb40(67));
        return _0x6d4ecc5536f5.ok
            ? { completed: false }
            : { completed: false, error: _0x6d4ecc5536f5.error || _0x7a039088cb40(176) };
    }
    try {
        let _0x1ebb5e62ab58 = false;
        if (Number.isInteger(_0x55d55a87ba44.workTabId)) {
            try {
                await chrome.tabs.get(_0x55d55a87ba44.workTabId);
                _0x1ebb5e62ab58 = true;
            }
            catch {
                _0x1ebb5e62ab58 = false;
            }
        }
        if (!_0x1ebb5e62ab58) {
            _0x55d55a87ba44.workTabId = await _0xccd82dbe5f3a(null);
        }
        await _0x9fec061c38d6(_0x55d55a87ba44, _0x81fb9136e77f);
        await _0xb6d8e0551352(_0x55d55a87ba44.workTabId, _0xed4ee98d354f.amzLink);
        return { completed: false };
    }
    catch (_0x179e5a5e530b) {
        _0x55d55a87ba44.mode = _0x7a039088cb40(136);
        _0x55d55a87ba44.pauseReason = `无法打开商品页面：${_0x179e5a5e530b.message || String(_0x179e5a5e530b)}`;
        if (_0x8cd08b14efb6.isCombined) {
            _0xe81840907d4e(_0x55d55a87ba44.rows, _0x8cd08b14efb6, _0x55d55a87ba44.pauseReason);
        }
        else {
            _0x0f9db2374199(_0xed4ee98d354f, `等待人工检查：${_0x55d55a87ba44.pauseReason}`, _0x7a039088cb40(99));
        }
        _0x8d616eca1a29(_0x81fb9136e77f, _0x7a039088cb40(20), _0x55d55a87ba44.pauseReason, _0xed4ee98d354f.rowNumber);
        await _0x9fec061c38d6(_0x55d55a87ba44, _0x81fb9136e77f);
        return { completed: false, error: _0x55d55a87ba44.pauseReason };
    }
}
async function _0x33441fcb1dbf(_0xcaf5cfbfa259, _0xf5f26321837a, _0xa9536db6aa1a, _0x6be4db5137f7 = 0) {
    const _0xc8985847ed0f = await _0x8e689ed9b70e(false);
    if (!_0xc8985847ed0f.authorized) {
        _0xcaf5cfbfa259.authorizationBlocked = true;
        _0xcaf5cfbfa259.authorizationFailureDeferred = false;
        _0xcaf5cfbfa259.mode = _0x7a039088cb40(136);
        _0xcaf5cfbfa259.pauseReason = _0x58ad35219aee.failureMessage;
        _0xcaf5cfbfa259.updatedAt = new Date().toISOString();
        const _0xc69cf5ec59a0 = _0x9ee79768b312(_0xcaf5cfbfa259);
        const _0x7af74e7153c5 = _0xf5f26321837a?.[_0xf5f26321837a.length - 1];
        if (_0x7af74e7153c5?.message !== _0x58ad35219aee.failureMessage) {
            _0x8d616eca1a29(_0xf5f26321837a, _0x7a039088cb40(20), _0x58ad35219aee.failureMessage, _0xc69cf5ec59a0?.rowNumber ?? null);
        }
        await _0x9fec061c38d6(_0xcaf5cfbfa259, _0xf5f26321837a);
        return { completed: false, authorizationFailed: true, error: _0x58ad35219aee.failureMessage };
    }
    const _0x0d634153dc98 = _0xcaf5cfbfa259.currentGroupIndex;
    const _0xf90673096571 = _0x395fc3223ef8(_0xcaf5cfbfa259.groups, Number.isInteger(_0x0d634153dc98) ? _0x0d634153dc98 : -1);
    if (_0xf90673096571 === -1) {
        await _0xc413dbf4d41b(_0xcaf5cfbfa259.runId);
        _0xcaf5cfbfa259.mode = _0x7a039088cb40(120);
        _0xcaf5cfbfa259.phase = _0x7a039088cb40(163);
        _0xcaf5cfbfa259.pauseReason = _0x7a039088cb40(172);
        _0xcaf5cfbfa259.currentGroupIndex = null;
        _0xcaf5cfbfa259.currentIndex = null;
        _0xcaf5cfbfa259.intervalEndsAt = null;
        _0xcaf5cfbfa259.intervalRemainingSeconds = 0;
        _0xcaf5cfbfa259.updatedAt = new Date().toISOString();
        _0x8d616eca1a29(_0xf5f26321837a, _0x7a039088cb40(198), _0xa9536db6aa1a || _0x7a039088cb40(84));
        await _0x9fec061c38d6(_0xcaf5cfbfa259, _0xf5f26321837a);
        return { completed: true };
    }
    _0xcaf5cfbfa259.currentGroupIndex = _0xf90673096571;
    const _0x2ab0dbb60e1b = _0xcaf5cfbfa259.groups[_0xf90673096571];
    _0xcaf5cfbfa259.currentIndex = _0x2ab0dbb60e1b.primaryRowIndex;
    const _0x0ee0ad9889bf = _0x135106ccd004(_0x6be4db5137f7, 0);
    if (_0x0ee0ad9889bf > 0) {
        _0xcaf5cfbfa259.mode = _0x7a039088cb40(148);
        _0xcaf5cfbfa259.phase = _0x7a039088cb40(91);
        _0xcaf5cfbfa259.pauseReason = _0x7a039088cb40(172);
        _0xcaf5cfbfa259.intervalEndsAt = new Date(Date.now() + _0x0ee0ad9889bf * 1000).toISOString();
        _0xcaf5cfbfa259.intervalRemainingSeconds = _0x0ee0ad9889bf;
        _0x2d20ea6f6b9e(_0xcaf5cfbfa259.rows, _0x2ab0dbb60e1b, `等待下单间隔（${_0x0ee0ad9889bf}秒）`);
        _0xcaf5cfbfa259.updatedAt = new Date().toISOString();
        const _0x57864d109d3a = _0xcaf5cfbfa259.rows[_0x2ab0dbb60e1b.primaryRowIndex];
        _0x8d616eca1a29(_0xf5f26321837a, _0x7a039088cb40(209), `距离下一个地址组还有 ${_0x0ee0ad9889bf} 秒；等待结束后从第 ${_0x57864d109d3a.rowNumber} 行开始。`, _0x57864d109d3a.rowNumber);
        await _0x9fec061c38d6(_0xcaf5cfbfa259, _0xf5f26321837a);
        try {
            await _0x5f674b8d9edd(_0xcaf5cfbfa259, _0x0ee0ad9889bf * 1000);
            return { completed: false, waiting: true };
        }
        catch (_0x7a63fe9e1052) {
            _0xcaf5cfbfa259.mode = _0x7a039088cb40(136);
            _0xcaf5cfbfa259.pauseReason = `无法安排下一单间隔：${_0x7a63fe9e1052.message || String(_0x7a63fe9e1052)}`;
            _0xe81840907d4e(_0xcaf5cfbfa259.rows, _0x2ab0dbb60e1b, _0xcaf5cfbfa259.pauseReason);
            _0x8d616eca1a29(_0xf5f26321837a, _0x7a039088cb40(20), _0xcaf5cfbfa259.pauseReason, _0x57864d109d3a.rowNumber);
            await _0x9fec061c38d6(_0xcaf5cfbfa259, _0xf5f26321837a);
            return { completed: false, error: _0xcaf5cfbfa259.pauseReason };
        }
    }
    return _0x86e2ed4b960a(_0xcaf5cfbfa259, _0xf5f26321837a, true);
}
async function _0x77f68b192075(_0x5227339e15aa) {
    const _0xfcb1e080657a = await _0x6fe49eb4993c();
    const _0x2848b8539dc1 = _0xfcb1e080657a[_0xcaf96649348b.RUN_STATE];
    const _0x5d132aea00dc = Array.isArray(_0xfcb1e080657a[_0xcaf96649348b.LOGS]) ? _0xfcb1e080657a[_0xcaf96649348b.LOGS] : [];
    if (!_0x2848b8539dc1 ||
        _0x2848b8539dc1.runId !== _0x5227339e15aa ||
        _0x2848b8539dc1.mode !== _0x7a039088cb40(148) ||
        _0x2848b8539dc1.phase !== _0x7a039088cb40(91)) {
        await _0xc413dbf4d41b(_0x5227339e15aa);
        return { ok: false, stale: true };
    }
    const _0xc22b21477fe1 = _0x9999f9481c0c(_0x2848b8539dc1);
    if (_0xc22b21477fe1 > 500) {
        _0x2848b8539dc1.intervalRemainingSeconds = Math.ceil(_0xc22b21477fe1 / 1000);
        await _0x9fec061c38d6(_0x2848b8539dc1, _0x5d132aea00dc);
        await _0x5f674b8d9edd(_0x2848b8539dc1, _0xc22b21477fe1);
        return { ok: true, waiting: true };
    }
    await _0xc413dbf4d41b(_0x5227339e15aa);
    _0x2848b8539dc1.intervalEndsAt = null;
    _0x2848b8539dc1.intervalRemainingSeconds = 0;
    const _0x9066234eaf22 = _0xd422dd9d0b08(_0x2848b8539dc1);
    const _0x28e929a95250 = _0x9066234eaf22 ? _0x2848b8539dc1.rows[_0x9066234eaf22.primaryRowIndex] : null;
    _0x8d616eca1a29(_0x5d132aea00dc, _0x7a039088cb40(209), _0x7a039088cb40(27), _0x28e929a95250?.rowNumber ?? null);
    await _0x9fec061c38d6(_0x2848b8539dc1, _0x5d132aea00dc);
    await _0x86e2ed4b960a(_0x2848b8539dc1, _0x5d132aea00dc, true);
    return { ok: true };
}
async function _0xecd57fbcd97d(_0xf423f6448bb1, _0xc908fc4dd95d) {
    const _0x8d0fcbc47bff = await _0x6fe49eb4993c();
    const _0xca5505d6b220 = _0x8d0fcbc47bff[_0xcaf96649348b.RUN_STATE];
    const _0xded6e836d9ab = Array.isArray(_0x8d0fcbc47bff[_0xcaf96649348b.LOGS]) ? _0x8d0fcbc47bff[_0xcaf96649348b.LOGS] : [];
    if (!_0xca5505d6b220 || _0xc908fc4dd95d.tab?.id !== _0xca5505d6b220.workTabId || _0xca5505d6b220.runId !== _0xf423f6448bb1.runId) {
        return { ok: false, stale: true };
    }
    if (![_0x7a039088cb40(19), _0x7a039088cb40(235)].includes(_0xca5505d6b220.phase)) {
        return { ok: false, stale: true, error: `当前阶段不能确认空购物篮：${_0xca5505d6b220.phase}` };
    }
    const _0x1a7918b47e01 = _0xd422dd9d0b08(_0xca5505d6b220);
    if (!_0x1a7918b47e01?.isCombined) {
        return { ok: false, error: _0x7a039088cb40(38) };
    }
    if (Number(_0xf423f6448bb1.cartCount) !== 0) {
        return { ok: false, error: `购物篮数量不是0：${_0xf423f6448bb1.cartCount}` };
    }
    const _0xe3209b77fbe2 = _0x1a7918b47e01.rowIndexes[0];
    const _0xc235b23c5564 = _0xca5505d6b220.rows[_0xe3209b77fbe2];
    _0xca5505d6b220.currentIndex = _0xe3209b77fbe2;
    if (_0xca5505d6b220.phase === _0x7a039088cb40(19)) {
        _0x1a7918b47e01.precheckCursor = 0;
        _0xca5505d6b220.phase = _0x7a039088cb40(52);
        _0x0f9db2374199(_0xc235b23c5564, _0x7a039088cb40(95), _0x7a039088cb40(167));
        _0x8d616eca1a29(_0xded6e836d9ab, _0x7a039088cb40(198), _0x7a039088cb40(46), _0xc235b23c5564.rowNumber);
        await _0x9fec061c38d6(_0xca5505d6b220, _0xded6e836d9ab);
        await _0x5e364a929d0c(_0xca5505d6b220.workTabId);
        return { ok: true, state: _0xca5505d6b220 };
    }
    if (_0x8d0fcbc47bff[_0xcaf96649348b.CART_LOCK]) {
        return { ok: false, error: _0x7a039088cb40(1) };
    }
    _0x1a7918b47e01.addCursor = 0;
    _0x1a7918b47e01.expectedCartCount = 0;
    const _0xed72c65e43b7 = _0x9b5d4010766c(_0xca5505d6b220, _0x1a7918b47e01);
    _0xca5505d6b220.phase = _0x7a039088cb40(162);
    _0x2d20ea6f6b9e(_0xca5505d6b220.rows, _0x1a7918b47e01, _0x7a039088cb40(30));
    _0x0f9db2374199(_0xc235b23c5564, _0x7a039088cb40(200), _0x7a039088cb40(167));
    _0x8d616eca1a29(_0xded6e836d9ab, _0x7a039088cb40(198), _0x7a039088cb40(104), _0xc235b23c5564.rowNumber);
    await _0x9fec061c38d6(_0xca5505d6b220, _0xded6e836d9ab, { [_0xcaf96649348b.CART_LOCK]: _0xed72c65e43b7 });
    await _0x5e364a929d0c(_0xca5505d6b220.workTabId);
    return { ok: true, state: _0xca5505d6b220 };
}
async function _0x681515893eba(_0xc86ef60654e6, _0x9658a6ab8927) {
    const _0x2ba89406c3d3 = await _0x6fe49eb4993c();
    const _0xb792202dda2f = _0x2ba89406c3d3[_0xcaf96649348b.RUN_STATE];
    const _0x9049c7e36cc5 = Array.isArray(_0x2ba89406c3d3[_0xcaf96649348b.LOGS]) ? _0x2ba89406c3d3[_0xcaf96649348b.LOGS] : [];
    if (!_0xb792202dda2f || _0x9658a6ab8927.tab?.id !== _0xb792202dda2f.workTabId || _0xb792202dda2f.runId !== _0xc86ef60654e6.runId) {
        return { ok: false, stale: true };
    }
    if (_0xb792202dda2f.phase !== _0x7a039088cb40(52)) {
        return { ok: false, stale: true, error: `当前阶段不是组合单预检查：${_0xb792202dda2f.phase}` };
    }
    const _0x0db252135a87 = _0xd422dd9d0b08(_0xb792202dda2f);
    const _0x60bb54771202 = _0x9ee79768b312(_0xb792202dda2f);
    if (!_0x0db252135a87?.isCombined || !_0x60bb54771202) {
        return { ok: false, error: _0x7a039088cb40(207) };
    }
    const _0xc128ccc6c826 = _0x0db252135a87.rowIndexes[_0x0db252135a87.precheckCursor];
    if (_0xb792202dda2f.currentIndex !== _0xc128ccc6c826) {
        return { ok: false, stale: true, error: _0x7a039088cb40(139) };
    }
    const _0x4ca6549f6246 = Number(_0xc86ef60654e6.observedUnitPrice);
    const _0x7e486c1cef24 = Number(_0xc86ef60654e6.selectedQuantity);
    if (!Number.isFinite(_0x4ca6549f6246) || Math.abs(_0x4ca6549f6246 - 2) > 0.0001) {
        return { ok: false, error: _0x7a039088cb40(193) };
    }
    if (!Number.isSafeInteger(_0x7e486c1cef24) || _0x7e486c1cef24 !== _0x60bb54771202.requestedQuantity) {
        return { ok: false, error: _0x7a039088cb40(34) };
    }
    _0x60bb54771202.observedUnitPrice = _0x4ca6549f6246.toFixed(2);
    _0x60bb54771202.selectedQuantity = _0x7e486c1cef24;
    _0x60bb54771202.precheckPassed = true;
    _0x0f9db2374199(_0x60bb54771202, _0x7a039088cb40(85), _0x7a039088cb40(167));
    _0x8d616eca1a29(_0x9049c7e36cc5, _0x7a039088cb40(198), `组合单预检查通过：ASIN ${_0x60bb54771202.asin}，含税单价 €2.00，精准数量 ${_0x7e486c1cef24}。`, _0x60bb54771202.rowNumber);
    if (_0x0db252135a87.precheckCursor + 1 < _0x0db252135a87.rowIndexes.length) {
        _0x0db252135a87.precheckCursor += 1;
        const _0x3cd342c568ec = _0x0db252135a87.rowIndexes[_0x0db252135a87.precheckCursor];
        const _0xaab137f9a770 = _0xb792202dda2f.rows[_0x3cd342c568ec];
        _0xb792202dda2f.currentIndex = _0x3cd342c568ec;
        _0xb792202dda2f.phase = _0x7a039088cb40(52);
        _0x0f9db2374199(_0xaab137f9a770, _0x7a039088cb40(141), _0x7a039088cb40(167));
        _0x8d616eca1a29(_0x9049c7e36cc5, _0x7a039088cb40(209), `上一件商品预检查完成；关闭旧商品标签并为第 ${_0xaab137f9a770.rowNumber} 行打开独立标签页。`, _0xaab137f9a770.rowNumber);
        _0xb792202dda2f.updatedAt = new Date().toISOString();
        const _0x360e005a56ca = await _0x9dbbfec3a9e5(_0xb792202dda2f, _0x9049c7e36cc5, _0xaab137f9a770.amzLink, {}, _0x7a039088cb40(0));
        return _0x360e005a56ca.ok ? { ok: true, state: _0xb792202dda2f } : _0x360e005a56ca;
    }
    _0x0db252135a87.result = _0x7a039088cb40(167);
    _0x0db252135a87.status = _0x7a039088cb40(185);
    _0xb792202dda2f.currentIndex = _0x0db252135a87.rowIndexes[0];
    _0xb792202dda2f.phase = _0x7a039088cb40(235);
    _0x2d20ea6f6b9e(_0xb792202dda2f.rows, _0x0db252135a87, _0x7a039088cb40(240));
    _0x8d616eca1a29(_0x9049c7e36cc5, _0x7a039088cb40(209), _0x7a039088cb40(151), _0xb792202dda2f.rows[_0x0db252135a87.rowIndexes[0]].rowNumber);
    _0x8d616eca1a29(_0x9049c7e36cc5, _0x7a039088cb40(209), _0x7a039088cb40(161), _0xb792202dda2f.rows[_0x0db252135a87.rowIndexes[0]].rowNumber);
    _0xb792202dda2f.updatedAt = new Date().toISOString();
    const _0x0d16852dee26 = await _0x9dbbfec3a9e5(_0xb792202dda2f, _0x9049c7e36cc5, _0xb792202dda2f.rows[_0x0db252135a87.rowIndexes[0]].amzLink, {}, _0x7a039088cb40(250));
    return _0x0d16852dee26.ok ? { ok: true, state: _0xb792202dda2f } : _0x0d16852dee26;
}
async function _0xbdda60dee737(_0x4671da37e07c, _0xa77fa2aa88b2) {
    const _0x1e7c894df63f = await _0x6fe49eb4993c();
    const _0x8b5f67758d50 = _0x1e7c894df63f[_0xcaf96649348b.RUN_STATE];
    const _0xde0c10c32f71 = Array.isArray(_0x1e7c894df63f[_0xcaf96649348b.LOGS]) ? _0x1e7c894df63f[_0xcaf96649348b.LOGS] : [];
    if (!_0x8b5f67758d50 || _0xa77fa2aa88b2.tab?.id !== _0x8b5f67758d50.workTabId || _0x8b5f67758d50.runId !== _0x4671da37e07c.runId) {
        return { ok: false, stale: true };
    }
    if (_0x8b5f67758d50.phase !== _0x7a039088cb40(52)) {
        return { ok: false, stale: true };
    }
    const _0x1581a9ed6cac = _0xd422dd9d0b08(_0x8b5f67758d50);
    const _0x5e762bbfe5b1 = _0x9ee79768b312(_0x8b5f67758d50);
    if (!_0x1581a9ed6cac?.isCombined || !_0x5e762bbfe5b1) {
        return { ok: false, error: _0x7a039088cb40(207) };
    }
    if (Number.isFinite(Number(_0x4671da37e07c.observedUnitPrice))) {
        _0x5e762bbfe5b1.observedUnitPrice = Number(_0x4671da37e07c.observedUnitPrice).toFixed(2);
    }
    if (Number.isSafeInteger(Number(_0x4671da37e07c.selectedQuantity)) && Number(_0x4671da37e07c.selectedQuantity) > 0) {
        _0x5e762bbfe5b1.selectedQuantity = Number(_0x4671da37e07c.selectedQuantity);
    }
    const _0xf1748fbb49ec = _0x4671da37e07c.reason || _0x7a039088cb40(18);
    _0x1a9d3a7c154f(_0x8b5f67758d50.rows, _0x1581a9ed6cac, _0x8b5f67758d50.currentIndex, _0xf1748fbb49ec);
    _0x8d616eca1a29(_0xde0c10c32f71, _0x7a039088cb40(15), `${_0xf1748fbb49ec}；该收件人地址组全部不下单。`, _0x5e762bbfe5b1.rowNumber);
    _0x8b5f67758d50.updatedAt = new Date().toISOString();
    await _0x9fec061c38d6(_0x8b5f67758d50, _0xde0c10c32f71);
    await _0x33441fcb1dbf(_0x8b5f67758d50, _0xde0c10c32f71, _0x7a039088cb40(84), 0);
    return { ok: true };
}
async function _0x3773ed746f4b(_0xeb8d3c7db3ee, _0xb1edde16d283) {
    const _0x9d8e1768c294 = await _0x6fe49eb4993c();
    const _0xacffd535023d = _0x9d8e1768c294[_0xcaf96649348b.RUN_STATE];
    const _0x4314e42c232a = Array.isArray(_0x9d8e1768c294[_0xcaf96649348b.LOGS]) ? _0x9d8e1768c294[_0xcaf96649348b.LOGS] : [];
    let _0x2471ac747b46 = _0x9d8e1768c294[_0xcaf96649348b.CART_LOCK] || null;
    if (!_0xacffd535023d || _0xb1edde16d283.tab?.id !== _0xacffd535023d.workTabId || _0xacffd535023d.runId !== _0xeb8d3c7db3ee.runId) {
        return { ok: false, stale: true };
    }
    if (_0xacffd535023d.phase !== _0x7a039088cb40(162)) {
        return { ok: false, stale: true, error: `当前阶段不是组合单正式加购：${_0xacffd535023d.phase}` };
    }
    const _0x747607f7d849 = _0xd422dd9d0b08(_0xacffd535023d);
    const _0x0dafeec874d1 = _0x9ee79768b312(_0xacffd535023d);
    if (!_0x747607f7d849?.isCombined || !_0x0dafeec874d1 || !_0x863787a6bab8(_0x2471ac747b46, _0xacffd535023d, _0x747607f7d849)) {
        return { ok: false, error: _0x7a039088cb40(155) };
    }
    const _0x0d3070bb3c17 = _0x747607f7d849.rowIndexes[_0x747607f7d849.addCursor];
    if (_0xacffd535023d.currentIndex !== _0x0d3070bb3c17) {
        return { ok: false, stale: true, error: _0x7a039088cb40(66) };
    }
    const _0xcc16534691d2 = Number(_0xeb8d3c7db3ee.selectedQuantity);
    const _0x472d1bb7eacb = Number(_0xeb8d3c7db3ee.observedUnitPrice);
    if (!Number.isSafeInteger(_0xcc16534691d2) || _0xcc16534691d2 !== _0x0dafeec874d1.requestedQuantity) {
        return { ok: false, error: _0x7a039088cb40(225) };
    }
    if (!Number.isFinite(_0x472d1bb7eacb) || Math.abs(_0x472d1bb7eacb - 2) > 0.0001) {
        return { ok: false, error: _0x7a039088cb40(11) };
    }
    const _0xdafbe0928723 = _0x747607f7d849.rowIndexes
        .slice(0, _0x747607f7d849.addCursor + 1)
        .reduce((_0xde6abe1cfa5b, _0x29656f415fbe) => _0xde6abe1cfa5b + _0xacffd535023d.rows[_0x29656f415fbe].requestedQuantity, 0);
    _0x0dafeec874d1.observedUnitPrice = _0x472d1bb7eacb.toFixed(2);
    _0x0dafeec874d1.selectedQuantity = _0xcc16534691d2;
    _0x0f9db2374199(_0x0dafeec874d1, `正在加入购物篮（完成后应累计 ${_0xdafbe0928723} 件）`, _0x7a039088cb40(167));
    _0xacffd535023d.phase = _0x7a039088cb40(55);
    _0xacffd535023d.updatedAt = new Date().toISOString();
    _0x2471ac747b46 = {
        ..._0x2471ac747b46,
        stage: _0x7a039088cb40(243),
        pendingRowIndex: _0xacffd535023d.currentIndex,
        expectedCartCountAfter: _0xdafbe0928723,
        updatedAt: new Date().toISOString()
    };
    _0x8d616eca1a29(_0x4314e42c232a, _0x7a039088cb40(209), `正式加购前再次核对通过：ASIN ${_0x0dafeec874d1.asin} × ${_0xcc16534691d2}；点击后购物篮应累计 ${_0xdafbe0928723} 件。`, _0x0dafeec874d1.rowNumber);
    await _0x9fec061c38d6(_0xacffd535023d, _0x4314e42c232a, { [_0xcaf96649348b.CART_LOCK]: _0x2471ac747b46 });
    return { ok: true, state: _0xacffd535023d, expectedCartCountAfter: _0xdafbe0928723 };
}
async function _0xd128bc3e869e(_0x90d0c772183a, _0x8811e1b505cc) {
    const _0x5dc4af3b1f55 = await _0x6fe49eb4993c();
    const _0x3fc65800a5f5 = _0x5dc4af3b1f55[_0xcaf96649348b.RUN_STATE];
    const _0x0a2736adfb3f = Array.isArray(_0x5dc4af3b1f55[_0xcaf96649348b.LOGS]) ? _0x5dc4af3b1f55[_0xcaf96649348b.LOGS] : [];
    let _0x63b03b0c4c30 = _0x5dc4af3b1f55[_0xcaf96649348b.CART_LOCK] || null;
    if (!_0x3fc65800a5f5 || _0x8811e1b505cc.tab?.id !== _0x3fc65800a5f5.workTabId || _0x3fc65800a5f5.runId !== _0x90d0c772183a.runId) {
        return { ok: false, stale: true };
    }
    if (_0x3fc65800a5f5.phase !== _0x7a039088cb40(55)) {
        return { ok: false, stale: true, error: `当前阶段不是组合单加购结果确认：${_0x3fc65800a5f5.phase}` };
    }
    const _0x78a2ecd4a557 = _0xd422dd9d0b08(_0x3fc65800a5f5);
    const _0x12a2375ec138 = _0x9ee79768b312(_0x3fc65800a5f5);
    if (!_0x78a2ecd4a557?.isCombined || !_0x12a2375ec138 || !_0x863787a6bab8(_0x63b03b0c4c30, _0x3fc65800a5f5, _0x78a2ecd4a557)) {
        return { ok: false, error: _0x7a039088cb40(155) };
    }
    const _0xa880c78782ca = _0x78a2ecd4a557.rowIndexes[_0x78a2ecd4a557.addCursor];
    if (_0x3fc65800a5f5.currentIndex !== _0xa880c78782ca) {
        return { ok: false, stale: true, error: _0x7a039088cb40(66) };
    }
    const _0xbc86c6dc03a9 = Number(_0x90d0c772183a.selectedQuantity);
    const _0x9d164708cdfa = Number(_0x90d0c772183a.observedUnitPrice);
    if (!Number.isSafeInteger(_0xbc86c6dc03a9) || _0xbc86c6dc03a9 !== _0x12a2375ec138.requestedQuantity) {
        return { ok: false, error: _0x7a039088cb40(35) };
    }
    if (!Number.isFinite(_0x9d164708cdfa) || Math.abs(_0x9d164708cdfa - 2) > 0.0001) {
        return { ok: false, error: _0x7a039088cb40(79) };
    }
    const _0xf47d1224ecfd = _0x78a2ecd4a557.rowIndexes
        .slice(0, _0x78a2ecd4a557.addCursor + 1)
        .reduce((_0x91f5e9bba123, _0x00813bd7ee57) => _0x91f5e9bba123 + _0x3fc65800a5f5.rows[_0x00813bd7ee57].requestedQuantity, 0);
    const _0x9e2a8754994a = Number(_0x90d0c772183a.cartCount);
    if (!Number.isSafeInteger(_0x9e2a8754994a) || _0x9e2a8754994a !== _0xf47d1224ecfd) {
        return {
            ok: false,
            error: `购物篮累计数量异常：应为 ${_0xf47d1224ecfd}，页面为 ${_0x90d0c772183a.cartCount}。`
        };
    }
    _0x12a2375ec138.observedUnitPrice = _0x9d164708cdfa.toFixed(2);
    _0x12a2375ec138.selectedQuantity = _0xbc86c6dc03a9;
    _0x12a2375ec138.addedToCart = true;
    _0x78a2ecd4a557.expectedCartCount = _0xf47d1224ecfd;
    _0x0f9db2374199(_0x12a2375ec138, `已加入购物篮（累计 ${_0xf47d1224ecfd} 件）`, _0x7a039088cb40(167));
    _0x8d616eca1a29(_0x0a2736adfb3f, _0x7a039088cb40(198), `已加入购物篮：ASIN ${_0x12a2375ec138.asin} × ${_0xbc86c6dc03a9}；累计购物篮数量 ${_0xf47d1224ecfd}。`, _0x12a2375ec138.rowNumber);
    _0x63b03b0c4c30 = {
        ..._0x63b03b0c4c30,
        addedRowIndexes: [...new Set([...(_0x63b03b0c4c30.addedRowIndexes || []), _0x3fc65800a5f5.currentIndex])],
        expectedCartCount: _0xf47d1224ecfd,
        stage: _0x7a039088cb40(48),
        updatedAt: new Date().toISOString()
    };
    if (_0x78a2ecd4a557.addCursor + 1 < _0x78a2ecd4a557.rowIndexes.length) {
        _0x78a2ecd4a557.addCursor += 1;
        const _0x34e537454bd0 = _0x78a2ecd4a557.rowIndexes[_0x78a2ecd4a557.addCursor];
        const _0x668b2e63ba32 = _0x3fc65800a5f5.rows[_0x34e537454bd0];
        _0x3fc65800a5f5.currentIndex = _0x34e537454bd0;
        _0x3fc65800a5f5.phase = _0x7a039088cb40(162);
        _0x0f9db2374199(_0x668b2e63ba32, _0x7a039088cb40(6), _0x7a039088cb40(167));
        _0x8d616eca1a29(_0x0a2736adfb3f, _0x7a039088cb40(209), `上一件商品已成功加入购物篮；关闭成功添加页面并为第 ${_0x668b2e63ba32.rowNumber} 行打开独立标签页。`, _0x668b2e63ba32.rowNumber);
        _0x3fc65800a5f5.updatedAt = new Date().toISOString();
        const _0xc6715be56dd9 = await _0x9dbbfec3a9e5(_0x3fc65800a5f5, _0x0a2736adfb3f, _0x668b2e63ba32.amzLink, { [_0xcaf96649348b.CART_LOCK]: _0x63b03b0c4c30 }, _0x7a039088cb40(142));
        return _0xc6715be56dd9.ok ? { ok: true, state: _0x3fc65800a5f5 } : _0xc6715be56dd9;
    }
    _0x3fc65800a5f5.phase = _0x7a039088cb40(59);
    _0x2d20ea6f6b9e(_0x3fc65800a5f5.rows, _0x78a2ecd4a557, _0x7a039088cb40(214));
    _0x63b03b0c4c30.stage = _0x7a039088cb40(42);
    _0x63b03b0c4c30.updatedAt = new Date().toISOString();
    _0x3fc65800a5f5.updatedAt = new Date().toISOString();
    _0x8d616eca1a29(_0x0a2736adfb3f, _0x7a039088cb40(209), `组合单全部商品已加入购物篮，总数量 ${_0x78a2ecd4a557.expectedTotalQuantity}，准备交叉检查并结算。`, _0x12a2375ec138.rowNumber);
    await _0x9fec061c38d6(_0x3fc65800a5f5, _0x0a2736adfb3f, { [_0xcaf96649348b.CART_LOCK]: _0x63b03b0c4c30 });
    await _0x5e364a929d0c(_0x3fc65800a5f5.workTabId);
    return { ok: true, state: _0x3fc65800a5f5 };
}
async function _0x82ef913751ce(_0xb5545f089f16, _0x8949f47fee99) {
    const _0x6dddebcf1e37 = await _0x6fe49eb4993c();
    const _0xa54888dc7bcd = _0x6dddebcf1e37[_0xcaf96649348b.RUN_STATE];
    const _0xd48fe586237d = Array.isArray(_0x6dddebcf1e37[_0xcaf96649348b.LOGS]) ? _0x6dddebcf1e37[_0xcaf96649348b.LOGS] : [];
    let _0x4cc0693a8695 = _0x6dddebcf1e37[_0xcaf96649348b.CART_LOCK] || null;
    if (!_0xa54888dc7bcd || _0x8949f47fee99.tab?.id !== _0xa54888dc7bcd.workTabId || _0xa54888dc7bcd.runId !== _0xb5545f089f16.runId) {
        return { ok: false, stale: true };
    }
    if (_0xa54888dc7bcd.phase !== _0x7a039088cb40(59)) {
        return { ok: false, stale: true, error: `当前阶段不是 Proceed to Checkout：${_0xa54888dc7bcd.phase}` };
    }
    const _0x94407ac2c5a1 = _0xd422dd9d0b08(_0xa54888dc7bcd);
    if (!_0x94407ac2c5a1?.isCombined || !_0x863787a6bab8(_0x4cc0693a8695, _0xa54888dc7bcd, _0x94407ac2c5a1)) {
        return { ok: false, error: _0x7a039088cb40(155) };
    }
    const _0x6256ecfd2c35 = Number(_0xb5545f089f16.cartCount);
    if (!Number.isSafeInteger(_0x6256ecfd2c35) || _0x6256ecfd2c35 !== _0x94407ac2c5a1.expectedTotalQuantity) {
        return { ok: false, error: `Proceed 前购物篮数量应为 ${_0x94407ac2c5a1.expectedTotalQuantity}，页面为 ${_0xb5545f089f16.cartCount}。` };
    }
    if (_0xb5545f089f16.proceedItemCount !== null &&
        _0xb5545f089f16.proceedItemCount !== undefined &&
        Number(_0xb5545f089f16.proceedItemCount) !== _0x94407ac2c5a1.expectedTotalQuantity) {
        return { ok: false, error: `Proceed 按钮显示 ${_0xb5545f089f16.proceedItemCount} items，与预期 ${_0x94407ac2c5a1.expectedTotalQuantity} 不一致。` };
    }
    _0xa54888dc7bcd.currentIndex = _0x94407ac2c5a1.primaryRowIndex;
    _0xa54888dc7bcd.phase = _0x7a039088cb40(208);
    _0x2d20ea6f6b9e(_0xa54888dc7bcd.rows, _0x94407ac2c5a1, _0x7a039088cb40(3));
    _0x4cc0693a8695 = {
        ..._0x4cc0693a8695,
        stage: _0x7a039088cb40(39),
        expectedCartCount: _0x94407ac2c5a1.expectedTotalQuantity,
        proceedItemCount: _0xb5545f089f16.proceedItemCount ?? null,
        updatedAt: new Date().toISOString()
    };
    _0x8d616eca1a29(_0xd48fe586237d, _0x7a039088cb40(198), _0xb5545f089f16.proceedItemCount === null || _0xb5545f089f16.proceedItemCount === undefined
        ? `Proceed 前购物篮数量核对通过：${_0x6256ecfd2c35} 件。`
        : `Proceed 前购物篮数量与按钮 items 数均核对通过：${_0x6256ecfd2c35} 件。`, _0xa54888dc7bcd.rows[_0x94407ac2c5a1.primaryRowIndex].rowNumber);
    _0xa54888dc7bcd.updatedAt = new Date().toISOString();
    await _0x9fec061c38d6(_0xa54888dc7bcd, _0xd48fe586237d, { [_0xcaf96649348b.CART_LOCK]: _0x4cc0693a8695 });
    return { ok: true, state: _0xa54888dc7bcd };
}
async function _0xbb40f218db8b(_0x40261ccbacb7, _0x444a14991b15 = null, _0x584095f39902 = false) {
    const _0x00fcc41b380c = await _0x6fe49eb4993c();
    const _0x43ad3dd99e7e = _0x00fcc41b380c[_0xcaf96649348b.RUN_STATE];
    const _0x7880d15b6e8c = Array.isArray(_0x00fcc41b380c[_0xcaf96649348b.LOGS]) ? _0x00fcc41b380c[_0xcaf96649348b.LOGS] : [];
    const _0x8bd55a40e7d9 = _0x00fcc41b380c[_0xcaf96649348b.CART_LOCK] || null;
    if (!_0x43ad3dd99e7e) {
        return { ok: false, error: _0x7a039088cb40(202) };
    }
    if (_0x584095f39902 && _0x43ad3dd99e7e.mode !== _0x7a039088cb40(136)) {
        return { ok: false, error: _0x7a039088cb40(234) };
    }
    if (_0x444a14991b15?.tab && _0x444a14991b15.tab.id !== _0x43ad3dd99e7e.workTabId) {
        return { ok: false, stale: true };
    }
    if (_0x40261ccbacb7.runId && _0x43ad3dd99e7e.runId !== _0x40261ccbacb7.runId) {
        return { ok: false, stale: true };
    }
    if (_0x40261ccbacb7.expectedPhase && _0x43ad3dd99e7e.phase !== _0x40261ccbacb7.expectedPhase) {
        return { ok: false, stale: true };
    }
    const _0xf20a41f56f51 = _0x9ee79768b312(_0x43ad3dd99e7e);
    const _0x41d99bd8ee3b = _0xd422dd9d0b08(_0x43ad3dd99e7e);
    if (!_0xf20a41f56f51 || !_0x41d99bd8ee3b) {
        return { ok: false, error: _0x7a039088cb40(179) };
    }
    const _0x0a72f5c8fa75 = _0x863787a6bab8(_0x8bd55a40e7d9, _0x43ad3dd99e7e, _0x41d99bd8ee3b);
    if (_0x8bd55a40e7d9 && !_0x0a72f5c8fa75) {
        return {
            ok: false,
            error: _0x7a039088cb40(68)
        };
    }
    if (_0x0a72f5c8fa75 && !_0x584095f39902) {
        return {
            ok: false,
            error: _0x7a039088cb40(248)
        };
    }
    if (_0x43ad3dd99e7e.phase === _0x7a039088cb40(91)) {
        await _0xc413dbf4d41b(_0x43ad3dd99e7e.runId);
        _0x43ad3dd99e7e.intervalEndsAt = null;
        _0x43ad3dd99e7e.intervalRemainingSeconds = 0;
    }
    const _0xbd2ce68e04ea = _0x40261ccbacb7.reason || (_0x584095f39902 ? _0x7a039088cb40(75) : _0x7a039088cb40(143));
    if (Number.isFinite(Number(_0x40261ccbacb7.observedUnitPrice))) {
        _0xf20a41f56f51.observedUnitPrice = Number(_0x40261ccbacb7.observedUnitPrice).toFixed(2);
    }
    if (Number.isSafeInteger(Number(_0x40261ccbacb7.selectedQuantity)) && Number(_0x40261ccbacb7.selectedQuantity) > 0) {
        _0xf20a41f56f51.selectedQuantity = Number(_0x40261ccbacb7.selectedQuantity);
    }
    const _0x2c11400ab07e = _0x8c713513dd6a.has(_0x43ad3dd99e7e.phase) || _0x8bd55a40e7d9?.stage === _0x7a039088cb40(183);
    const _0x80db87c18b33 = _0x584095f39902 && _0x2c11400ab07e ? `${_0xbd2ce68e04ea}（订单结果未确认）` : _0xbd2ce68e04ea;
    if (_0x41d99bd8ee3b.isCombined) {
        _0x1a9d3a7c154f(_0x43ad3dd99e7e.rows, _0x41d99bd8ee3b, _0x43ad3dd99e7e.currentIndex, _0x80db87c18b33, _0x584095f39902);
        _0x8d616eca1a29(_0x7880d15b6e8c, _0x7a039088cb40(15), _0x584095f39902 ? `${_0x80db87c18b33}；该收件人地址组全部人工跳过。` : `${_0x80db87c18b33}；该收件人地址组全部跳过。`, _0xf20a41f56f51.rowNumber);
    }
    else {
        _0x41d99bd8ee3b.result = _0x7a039088cb40(238);
        _0x41d99bd8ee3b.status = _0x80db87c18b33;
        _0x0f9db2374199(_0xf20a41f56f51, _0x80db87c18b33, _0x7a039088cb40(238));
        _0x8d616eca1a29(_0x7880d15b6e8c, _0x7a039088cb40(15), _0x80db87c18b33, _0xf20a41f56f51.rowNumber);
    }
    if (_0x0a72f5c8fa75) {
        await chrome.storage.local.remove(_0xcaf96649348b.CART_LOCK);
        _0x8d616eca1a29(_0x7880d15b6e8c, _0x7a039088cb40(15), `用户在暂停状态下人工跳过组合单，已立即清除 CART_BUILDING 安全锁并继续下一地址组；Amazon 购物篮或订单不会被插件自动处理（原锁阶段：${_0x8bd55a40e7d9.stage || _0x7a039088cb40(54)}）。`, _0xf20a41f56f51.rowNumber);
    }
    _0x43ad3dd99e7e.pauseReason = _0x7a039088cb40(172);
    _0x43ad3dd99e7e.updatedAt = new Date().toISOString();
    await _0x9fec061c38d6(_0x43ad3dd99e7e, _0x7880d15b6e8c);
    await _0x33441fcb1dbf(_0x43ad3dd99e7e, _0x7880d15b6e8c, _0x7a039088cb40(84), 0);
    return { ok: true, skippedGroup: Boolean(_0x41d99bd8ee3b.isCombined), clearedCartLock: Boolean(_0x0a72f5c8fa75) };
}
async function _0xbed32fceee88(_0x8b9cf27acd04, _0x2c11134371a3) {
    const _0x3f3987387aca = await _0x6fe49eb4993c();
    const _0x335ad4a34b83 = _0x3f3987387aca[_0xcaf96649348b.RUN_STATE];
    const _0xa61bf213f4e8 = Array.isArray(_0x3f3987387aca[_0xcaf96649348b.LOGS]) ? _0x3f3987387aca[_0xcaf96649348b.LOGS] : [];
    const _0x1d392995d2b2 = _0xa2248a8b28d3(_0x3f3987387aca[_0xcaf96649348b.HISTORY]);
    const _0xdc70b83b4012 = _0x5927bc040c8e(_0x3f3987387aca[_0xcaf96649348b.ORDER_INDEX], _0x1d392995d2b2);
    const _0x3bbd6fddd956 = _0x3f3987387aca[_0xcaf96649348b.CART_LOCK] || null;
    if (!_0x335ad4a34b83 || _0x2c11134371a3.tab?.id !== _0x335ad4a34b83.workTabId || _0x335ad4a34b83.runId !== _0x8b9cf27acd04.runId) {
        return { ok: false, stale: true };
    }
    if (_0x335ad4a34b83.phase !== _0x7a039088cb40(241)) {
        return { ok: false, stale: true, error: `当前阶段不是订单核对阶段：${_0x335ad4a34b83.phase}` };
    }
    const _0x3e97ffd7274a = _0xd422dd9d0b08(_0x335ad4a34b83);
    const _0x55793690a53f = _0x7e1b2a3dfb08(_0x335ad4a34b83);
    if (!_0x3e97ffd7274a || !_0x55793690a53f) {
        return { ok: false, error: _0x7a039088cb40(56) };
    }
    const _0x9083120e3ed0 = String(_0x8b9cf27acd04.orderId ?? _0x7a039088cb40(172)).trim();
    if (!_0x7d58e108a4a5(_0x9083120e3ed0)) {
        return { ok: false, error: _0x7a039088cb40(107) };
    }
    if (_0x3e97ffd7274a.isCombined && !_0x863787a6bab8(_0x3bbd6fddd956, _0x335ad4a34b83, _0x3e97ffd7274a)) {
        return { ok: false, error: _0x7a039088cb40(249) };
    }
    const _0xbfa74a92414e = new Date().toISOString();
    const _0xe39bef7627ff = _0xa5552c751906();
    for (const _0xdc43683227fa of _0x3e97ffd7274a.uniqueTemuOrderIds) {
        const _0x8ef52626427c = _0x8ee291ad35d0(_0x335ad4a34b83.rows, _0x3e97ffd7274a, _0xdc43683227fa);
        const _0xd5bd5958402a = _0x335ad4a34b83.rows[_0x8ef52626427c[0]];
        const _0xfa936fea6976 = _0x3e97ffd7274a.temuItemSignatures[_0xdc43683227fa] || _0x7a039088cb40(172);
        const _0xec09b8d6632e = _0x3e97ffd7274a.temuSignatures[_0xdc43683227fa] || _0x7a039088cb40(172);
        _0x1d392995d2b2.push({
            id: crypto.randomUUID(),
            runId: _0x335ad4a34b83.runId,
            rowNumbers: _0x8ef52626427c.map((_0xc9914b2e4f4e) => _0x335ad4a34b83.rows[_0xc9914b2e4f4e].rowNumber),
            dateKey: _0xe39bef7627ff,
            temuOrderId: _0xd5bd5958402a?.temuOrderId || _0xdc43683227fa,
            temuOrderIdKey: _0xdc43683227fa,
            asin: _0xd5bd5958402a?.asin || _0x7a039088cb40(172),
            normalizedName: _0x3e97ffd7274a.normalizedName,
            shipAddress: _0x3e97ffd7274a.shipAddress,
            address2: _0x3e97ffd7274a.address2,
            shipCity: _0x3e97ffd7274a.shipCity,
            shipPostalCode: _0x3e97ffd7274a.shipPostalCode,
            phoneNumber: _0x3e97ffd7274a.phoneNumber,
            status: _0x7a039088cb40(144),
            orderId: _0x9083120e3ed0,
            addressSignature: _0x3e97ffd7274a.addressSignature,
            itemSignature: _0xfa936fea6976,
            temuSignature: _0xec09b8d6632e,
            groupSignature: _0x3e97ffd7274a.groupSignature,
            expectedItems: _0xd59cc556eefa(_0x335ad4a34b83.rows, _0x8ef52626427c),
            actualDeliveryAddress: _0x3e97ffd7274a.actualDeliveryAddress,
            createdAt: _0xbfa74a92414e,
            updatedAt: _0xbfa74a92414e
        });
        _0xdc70b83b4012[_0x47588c686c5f(_0xdc43683227fa)] = {
            temuOrderId: _0xdc43683227fa,
            status: _0x7a039088cb40(144),
            orderId: _0x9083120e3ed0,
            dateKey: _0xe39bef7627ff,
            addressSignature: _0x3e97ffd7274a.addressSignature,
            itemSignature: _0xfa936fea6976,
            temuSignature: _0xec09b8d6632e,
            groupSignature: _0x3e97ffd7274a.groupSignature,
            updatedAt: _0xbfa74a92414e
        };
    }
    if (_0x1d392995d2b2.length > _0xa44b032669e9) {
        _0x1d392995d2b2.splice(0, _0x1d392995d2b2.length - _0xa44b032669e9);
    }
    _0x5e2355e736c1(_0x335ad4a34b83.rows, _0x3e97ffd7274a, _0x9083120e3ed0);
    _0x335ad4a34b83.knownOrderIds = [...new Set([...(_0x335ad4a34b83.knownOrderIds || []), _0x9083120e3ed0])];
    _0x335ad4a34b83.updatedAt = _0xbfa74a92414e;
    _0x8d616eca1a29(_0xa61bf213f4e8, _0x7a039088cb40(198), _0x3e97ffd7274a.isCombined
        ? `组合单下单成功，${_0x3e97ffd7274a.rowIndexes.length} 行共用 Order ID：${_0x9083120e3ed0}`
        : `下单成功，Order ID：${_0x9083120e3ed0}`, _0x55793690a53f.rowNumber);
    const _0x443d55eeed1a = {
        [_0xcaf96649348b.RUN_STATE]: _0x335ad4a34b83,
        [_0xcaf96649348b.HISTORY]: _0x1d392995d2b2,
        [_0xcaf96649348b.ORDER_INDEX]: _0xdc70b83b4012,
        [_0xcaf96649348b.LOGS]: _0xa61bf213f4e8
    };
    await chrome.storage.local.set(_0x443d55eeed1a);
    if (_0x3e97ffd7274a.isCombined) {
        await chrome.storage.local.remove(_0xcaf96649348b.CART_LOCK);
        _0x8d616eca1a29(_0xa61bf213f4e8, _0x7a039088cb40(198), _0x7a039088cb40(123), _0x55793690a53f.rowNumber);
        await chrome.storage.local.set({ [_0xcaf96649348b.LOGS]: _0xa61bf213f4e8 });
    }
    await _0x33441fcb1dbf(_0x335ad4a34b83, _0xa61bf213f4e8, _0x7a039088cb40(84), _0x135106ccd004(_0x335ad4a34b83.orderIntervalSeconds, _0xf0715585cf3d.orderIntervalSeconds));
    return { ok: true, orderId: _0x9083120e3ed0 };
}
async function _0xf278d8d8b5ec() {
    const _0x1a0a5f819576 = await _0x6fe49eb4993c();
    const _0x0f61a19a3325 = _0x1a0a5f819576[_0xcaf96649348b.RUN_STATE];
    const _0x3ddda6ce0afa = Array.isArray(_0x1a0a5f819576[_0xcaf96649348b.LOGS]) ? _0x1a0a5f819576[_0xcaf96649348b.LOGS] : [];
    if (!_0x0f61a19a3325 || !_0x2098732dc69d.has(_0x0f61a19a3325.mode) || _0x0f61a19a3325.mode === _0x7a039088cb40(136)) {
        return { ok: false, error: _0x7a039088cb40(125) };
    }
    const _0x8100dc3aeb8e = _0xd422dd9d0b08(_0x0f61a19a3325);
    const _0xb119578c51b6 = _0x9ee79768b312(_0x0f61a19a3325);
    if (_0x0f61a19a3325.phase === _0x7a039088cb40(91)) {
        const _0xebd38afa65c2 = _0x9999f9481c0c(_0x0f61a19a3325);
        await _0xc413dbf4d41b(_0x0f61a19a3325.runId);
        _0x0f61a19a3325.intervalEndsAt = null;
        _0x0f61a19a3325.intervalRemainingSeconds = Math.ceil(_0xebd38afa65c2 / 1000);
    }
    _0x0f61a19a3325.mode = _0x7a039088cb40(136);
    _0x0f61a19a3325.pauseReason = _0x7a039088cb40(36);
    _0x0f61a19a3325.updatedAt = new Date().toISOString();
    const _0xd280eebe17e4 = _0x0f61a19a3325.phase === _0x7a039088cb40(91)
        ? `（间隔剩余约 ${_0x0f61a19a3325.intervalRemainingSeconds} 秒）`
        : _0x7a039088cb40(172);
    if (_0x8100dc3aeb8e?.isCombined) {
        _0xe81840907d4e(_0x0f61a19a3325.rows, _0x8100dc3aeb8e, `人工暂停${_0xd280eebe17e4}`);
    }
    else if (_0xb119578c51b6) {
        _0x0f9db2374199(_0xb119578c51b6, `已暂停：人工暂停${_0xd280eebe17e4}`, _0x7a039088cb40(99));
    }
    _0x8d616eca1a29(_0x3ddda6ce0afa, _0x7a039088cb40(15), _0x7a039088cb40(178), _0xb119578c51b6?.rowNumber ?? null);
    await _0x9fec061c38d6(_0x0f61a19a3325, _0x3ddda6ce0afa);
    return { ok: true };
}
async function _0xdb52219f072d() {
    const _0xc8bcdf2c254b = await _0x6fe49eb4993c();
    const _0xbb346ec238a3 = _0xc8bcdf2c254b[_0xcaf96649348b.RUN_STATE];
    const _0x12cfdd0b35a7 = Array.isArray(_0xc8bcdf2c254b[_0xcaf96649348b.LOGS]) ? _0xc8bcdf2c254b[_0xcaf96649348b.LOGS] : [];
    const _0xc54acd7bc88c = _0xc8bcdf2c254b[_0xcaf96649348b.CART_LOCK] || null;
    if (!_0xbb346ec238a3 || _0xbb346ec238a3.mode !== _0x7a039088cb40(136)) {
        return { ok: false, error: _0x7a039088cb40(5) };
    }
    if (_0xbb346ec238a3.phase === _0x7a039088cb40(140)) {
        return { ok: false, error: _0x7a039088cb40(90) };
    }
    const _0x6deaef08cebd = _0xd422dd9d0b08(_0xbb346ec238a3);
    const _0x12322e74e282 = _0x9ee79768b312(_0xbb346ec238a3);
    if (_0x6deaef08cebd?.isCombined && _0xf1737035e986.has(_0xbb346ec238a3.phase) && !_0x863787a6bab8(_0xc54acd7bc88c, _0xbb346ec238a3, _0x6deaef08cebd)) {
        return { ok: false, error: _0x7a039088cb40(156) };
    }
    if (_0xbb346ec238a3.phase === _0x7a039088cb40(91)) {
        const _0x8e1f278bd30a = Math.max(0, Number(_0xbb346ec238a3.intervalRemainingSeconds || 0) * 1000);
        _0xbb346ec238a3.mode = _0x7a039088cb40(148);
        _0xbb346ec238a3.pauseReason = _0x7a039088cb40(172);
        _0xbb346ec238a3.intervalEndsAt = new Date(Date.now() + _0x8e1f278bd30a).toISOString();
        _0xbb346ec238a3.intervalRemainingSeconds = Math.ceil(_0x8e1f278bd30a / 1000);
        _0xbb346ec238a3.updatedAt = new Date().toISOString();
        if (_0x6deaef08cebd) {
            _0x2d20ea6f6b9e(_0xbb346ec238a3.rows, _0x6deaef08cebd, `等待下单间隔（${_0xbb346ec238a3.intervalRemainingSeconds}秒）`);
        }
        _0x8d616eca1a29(_0x12cfdd0b35a7, _0x7a039088cb40(209), _0x7a039088cb40(160), _0x12322e74e282?.rowNumber ?? null);
        await _0x9fec061c38d6(_0xbb346ec238a3, _0x12cfdd0b35a7);
        if (_0x8e1f278bd30a <= 0) {
            await _0x77f68b192075(_0xbb346ec238a3.runId);
        }
        else {
            await _0x5f674b8d9edd(_0xbb346ec238a3, _0x8e1f278bd30a);
        }
        return { ok: true };
    }
    let _0xc830a4ff8759 = false;
    if (Number.isInteger(_0xbb346ec238a3.workTabId)) {
        try {
            await chrome.tabs.get(_0xbb346ec238a3.workTabId);
            _0xc830a4ff8759 = true;
        }
        catch {
            _0xc830a4ff8759 = false;
        }
    }
    if (!_0xc830a4ff8759) {
        const _0x5c4a0a113c41 = [_0x7a039088cb40(23), _0x7a039088cb40(19), _0x7a039088cb40(52), _0x7a039088cb40(235)].includes(_0xbb346ec238a3.phase);
        if (!_0x5c4a0a113c41 || !_0x12322e74e282?.amzLink || _0xc8bcdf2c254b[_0xcaf96649348b.CART_LOCK]) {
            return {
                ok: false,
                error: _0x7a039088cb40(164)
            };
        }
        _0xbb346ec238a3.workTabId = await _0xccd82dbe5f3a(null);
    }
    _0xbb346ec238a3.mode = _0x7a039088cb40(111);
    _0xbb346ec238a3.pauseReason = _0x7a039088cb40(172);
    _0xbb346ec238a3.updatedAt = new Date().toISOString();
    if (_0x6deaef08cebd?.isCombined) {
        _0x2d20ea6f6b9e(_0xbb346ec238a3.rows, _0x6deaef08cebd, _0x7a039088cb40(154));
    }
    else if (_0x12322e74e282) {
        _0x0f9db2374199(_0x12322e74e282, _0x7a039088cb40(168), _0x7a039088cb40(167));
    }
    _0x8d616eca1a29(_0x12cfdd0b35a7, _0x7a039088cb40(209), _0x7a039088cb40(105), _0x12322e74e282?.rowNumber ?? null);
    await _0x9fec061c38d6(_0xbb346ec238a3, _0x12cfdd0b35a7);
    if (!_0xc830a4ff8759 && _0x12322e74e282?.amzLink) {
        await _0xb6d8e0551352(_0xbb346ec238a3.workTabId, _0x12322e74e282.amzLink);
    }
    else {
        await _0x5e364a929d0c(_0xbb346ec238a3.workTabId);
    }
    return { ok: true };
}
async function _0x2ad95a5ea035() {
    const _0x21693e3ba273 = await _0x6fe49eb4993c();
    const _0x7b4a2e3e84c3 = _0x21693e3ba273[_0xcaf96649348b.RUN_STATE];
    const _0x653a01b1e36d = Array.isArray(_0x21693e3ba273[_0xcaf96649348b.LOGS]) ? _0x21693e3ba273[_0xcaf96649348b.LOGS] : [];
    const _0xfae179d50d15 = _0x21693e3ba273[_0xcaf96649348b.CART_LOCK] || null;
    if (!_0x7b4a2e3e84c3 || !_0x2098732dc69d.has(_0x7b4a2e3e84c3.mode)) {
        return { ok: false, error: _0x7a039088cb40(53) };
    }
    const _0x6e242285351f = _0xd422dd9d0b08(_0x7b4a2e3e84c3);
    const _0x4cd4bf2bdd22 = _0x9ee79768b312(_0x7b4a2e3e84c3);
    const _0x517cfde478c6 = _0x7b4a2e3e84c3.phase;
    if (_0x517cfde478c6 === _0x7a039088cb40(91)) {
        await _0xc413dbf4d41b(_0x7b4a2e3e84c3.runId);
    }
    _0x7b4a2e3e84c3.mode = _0x7a039088cb40(137);
    _0x7b4a2e3e84c3.phase = _0x7a039088cb40(230);
    _0x7b4a2e3e84c3.pauseReason = _0x7a039088cb40(172);
    _0x7b4a2e3e84c3.intervalEndsAt = null;
    _0x7b4a2e3e84c3.intervalRemainingSeconds = 0;
    _0x7b4a2e3e84c3.updatedAt = new Date().toISOString();
    const _0x4b791976e38d = _0x863787a6bab8(_0xfae179d50d15, _0x7b4a2e3e84c3, _0x6e242285351f);
    const _0x16cb5e6ae1d4 = _0x4b791976e38d ? _0x7a039088cb40(41) : _0x8c713513dd6a.has(_0x517cfde478c6)
        ? _0x7a039088cb40(113) : _0x7a039088cb40(150);
    if (_0x6e242285351f?.isCombined) {
        _0xe81840907d4e(_0x7b4a2e3e84c3.rows, _0x6e242285351f, _0x16cb5e6ae1d4);
    }
    else if (_0x4cd4bf2bdd22 && (_0x4cd4bf2bdd22.result === _0x7a039088cb40(167) || _0x4cd4bf2bdd22.result === _0x7a039088cb40(99))) {
        _0x0f9db2374199(_0x4cd4bf2bdd22, _0x16cb5e6ae1d4, _0x7a039088cb40(99));
    }
    _0x8d616eca1a29(_0x653a01b1e36d, _0x7a039088cb40(15), _0x4b791976e38d ? _0x7a039088cb40(2) : _0x8c713513dd6a.has(_0x517cfde478c6)
        ? _0x7a039088cb40(97) : _0x7a039088cb40(224), _0x4cd4bf2bdd22?.rowNumber ?? null);
    await _0x9fec061c38d6(_0x7b4a2e3e84c3, _0x653a01b1e36d);
    return { ok: true };
}
async function _0x62fc543ff536() {
    const _0x603fbb4cba1f = await _0x6fe49eb4993c();
    const _0x13b8431ad26a = _0x603fbb4cba1f[_0xcaf96649348b.RUN_STATE] || null;
    const _0x4018b52de138 = Array.isArray(_0x603fbb4cba1f[_0xcaf96649348b.LOGS]) ? _0x603fbb4cba1f[_0xcaf96649348b.LOGS] : [];
    const _0xa2b320420045 = _0x603fbb4cba1f[_0xcaf96649348b.CART_LOCK] || null;
    if (!_0xa2b320420045) {
        return { ok: true, cleared: false, message: _0x7a039088cb40(189) };
    }
    if (_0x13b8431ad26a && [_0x7a039088cb40(111), _0x7a039088cb40(148), _0x7a039088cb40(136)].includes(_0x13b8431ad26a.mode)) {
        return {
            ok: false,
            error: _0x13b8431ad26a.mode === _0x7a039088cb40(136)
                ? _0x7a039088cb40(177) : _0x7a039088cb40(247)
        };
    }
    const _0x840691a969cd = _0xa2b320420045.stage === _0x7a039088cb40(183) ? _0x7a039088cb40(131) : _0x7a039088cb40(145);
    if (_0x13b8431ad26a && _0x13b8431ad26a.runId === _0xa2b320420045.runId) {
        const _0xbb1f6dffa931 = _0xd422dd9d0b08(_0x13b8431ad26a);
        if (_0xbb1f6dffa931?.id === _0xa2b320420045.groupId && _0xbb1f6dffa931.result !== _0x7a039088cb40(198) && _0xbb1f6dffa931.result !== _0x7a039088cb40(238)) {
            _0xe81840907d4e(_0x13b8431ad26a.rows, _0xbb1f6dffa931, _0x840691a969cd === _0x7a039088cb40(131)
                ? _0x7a039088cb40(63) : _0x7a039088cb40(121));
        }
        _0x13b8431ad26a.mode = _0x7a039088cb40(137);
        _0x13b8431ad26a.phase = _0x7a039088cb40(230);
        _0x13b8431ad26a.pauseReason = _0x7a039088cb40(172);
        _0x13b8431ad26a.updatedAt = new Date().toISOString();
    }
    _0x8d616eca1a29(_0x4018b52de138, _0x7a039088cb40(15), _0x840691a969cd === _0x7a039088cb40(131)
        ? `用户确认已人工检查最近订单，已通过“继续当前步骤”清除组合单锁（组 ${_0xa2b320420045.groupId || _0x7a039088cb40(54)}，原阶段 final-submit）。`
        : `用户确认已人工检查 Amazon 购物篮，已通过“继续当前步骤”清除组合单锁（组 ${_0xa2b320420045.groupId || _0x7a039088cb40(54)}，原阶段 ${_0xa2b320420045.stage || _0x7a039088cb40(54)}）。`);
    await chrome.storage.local.remove(_0xcaf96649348b.CART_LOCK);
    await chrome.storage.local.set({
        [_0xcaf96649348b.RUN_STATE]: _0x13b8431ad26a,
        [_0xcaf96649348b.LOGS]: _0x4018b52de138
    });
    return { ok: true, cleared: true, recoveryType: _0x840691a969cd };
}
async function _0xb1c29856f132(_0xf388c458666b, _0x266d4a0087b2) {
    const _0x06f82a440a37 = await _0x6fe49eb4993c();
    const _0x7c331be4217f = _0x06f82a440a37[_0xcaf96649348b.RUN_STATE];
    const _0xa835aff07243 = Array.isArray(_0x06f82a440a37[_0xcaf96649348b.LOGS]) ? _0x06f82a440a37[_0xcaf96649348b.LOGS] : [];
    if (!_0x7c331be4217f || _0x266d4a0087b2.tab?.id !== _0x7c331be4217f.workTabId || _0x7c331be4217f.runId !== _0xf388c458666b.runId) {
        return { ok: false, stale: true };
    }
    const _0xd65354303f9a = _0x9ee79768b312(_0x7c331be4217f);
    _0x8d616eca1a29(_0xa835aff07243, _0xf388c458666b.level || _0x7a039088cb40(209), String(_0xf388c458666b.message || _0x7a039088cb40(172)), _0xd65354303f9a?.rowNumber ?? null);
    await chrome.storage.local.set({ [_0xcaf96649348b.LOGS]: _0xa835aff07243 });
    return { ok: true };
}
async function _0x2fdbd67400a0(_0x5009069d85bf) {
    const _0xe67c607703ab = await chrome.storage.local.get(_0xcaf96649348b.RUN_STATE);
    const _0x201e9a1d06d6 = _0xe67c607703ab[_0xcaf96649348b.RUN_STATE];
    if (_0x201e9a1d06d6 && _0x2098732dc69d.has(_0x201e9a1d06d6.mode)) {
        return { ok: false, error: _0x7a039088cb40(80) };
    }
    await chrome.storage.local.set({
        [_0xcaf96649348b.DRAFT_ROWS]: Array.isArray(_0x5009069d85bf) ? _0x5009069d85bf : []
    });
    return { ok: true };
}
async function _0x5f1e47aa0d6b() {
    const _0xcf79361e5fc4 = await chrome.storage.local.get([_0xcaf96649348b.RUN_STATE, _0xcaf96649348b.CART_LOCK]);
    const _0x9562150502dc = _0xcf79361e5fc4[_0xcaf96649348b.RUN_STATE];
    if (_0x9562150502dc && _0x2098732dc69d.has(_0x9562150502dc.mode)) {
        return { ok: false, error: _0x7a039088cb40(92) };
    }
    if (_0xcf79361e5fc4[_0xcaf96649348b.CART_LOCK]) {
        return { ok: false, error: _0x7a039088cb40(116) };
    }
    await chrome.storage.local.set({
        [_0xcaf96649348b.DRAFT_ROWS]: [],
        [_0xcaf96649348b.RUN_STATE]: null
    });
    return { ok: true };
}
async function _0x61304e0877f5() {
    await chrome.storage.local.set({ [_0xcaf96649348b.LOGS]: [] });
    return { ok: true };
}
async function _0xbe70e61e2c39(_0x49514a10031b) {
    const _0x222f251615bd = _0x49514a10031b?.orderIntervalSeconds;
    const _0xeb6d5b8e14ac = Number(_0x222f251615bd);
    if (!Number.isInteger(_0xeb6d5b8e14ac) || _0xeb6d5b8e14ac < 0 || _0xeb6d5b8e14ac > 3600) {
        return { ok: false, error: _0x7a039088cb40(236) };
    }
    const _0xfdace3df0f08 = await chrome.storage.local.get(_0xcaf96649348b.SETTINGS);
    return {
        ok: true,
        settings: _0x7a411f09453c(_0xfdace3df0f08[_0xcaf96649348b.SETTINGS]),
        pendingOrderIntervalSeconds: _0xeb6d5b8e14ac
    };
}
async function _0x3a8796ccc600() {
    const _0xe9bc82afacf8 = await _0x6fe49eb4993c();
    const _0x313b905f8831 = _0xe9bc82afacf8[_0xcaf96649348b.RUN_STATE];
    if (_0x313b905f8831 && _0x2098732dc69d.has(_0x313b905f8831.mode)) {
        return { ok: false, error: _0x7a039088cb40(102) };
    }
    const _0x2cabb2cb05d5 = _0xa5552c751906();
    const _0xaeb2134b146c = Array.isArray(_0xe9bc82afacf8[_0xcaf96649348b.LOGS]) ? _0xe9bc82afacf8[_0xcaf96649348b.LOGS] : [];
    const _0x38d8449df74a = _0xa2248a8b28d3(_0xe9bc82afacf8[_0xcaf96649348b.HISTORY]);
    const _0x963dab39df38 = _0x5927bc040c8e(_0xe9bc82afacf8[_0xcaf96649348b.ORDER_INDEX], _0x38d8449df74a);
    const _0x6804c7f052e6 = new Set();
    for (const [_0xfb168048788b, _0x740edc76fa04] of Object.entries(_0x963dab39df38)) {
        if (_0x740edc76fa04?.status === _0x7a039088cb40(144) && _0x740edc76fa04.dateKey === _0x2cabb2cb05d5 && _0x7d58e108a4a5(_0x740edc76fa04.orderId)) {
            _0x6804c7f052e6.add(_0x19c8aef802df(_0x740edc76fa04.temuOrderId));
            delete _0x963dab39df38[_0xfb168048788b];
        }
    }
    const _0xdb21b9301d16 = _0x38d8449df74a.filter((_0xea39341e75ea) => {
        const _0xef956d73c7ae = _0xea39341e75ea.status === _0x7a039088cb40(144) &&
            _0xea39341e75ea.dateKey === _0x2cabb2cb05d5 &&
            _0x7d58e108a4a5(_0xea39341e75ea.orderId);
        if (_0xef956d73c7ae) {
            _0x6804c7f052e6.add(_0x19c8aef802df(_0xea39341e75ea.temuOrderIdKey || _0xea39341e75ea.temuOrderId));
        }
        return !_0xef956d73c7ae;
    });
    _0x8d616eca1a29(_0xaeb2134b146c, _0x7a039088cb40(15), `已清空 ${_0x6804c7f052e6.size} 条 ${_0x2cabb2cb05d5} 的成功下单防重复记录。`);
    await chrome.storage.local.set({
        [_0xcaf96649348b.HISTORY]: _0xdb21b9301d16,
        [_0xcaf96649348b.ORDER_INDEX]: _0x963dab39df38,
        [_0xcaf96649348b.LOGS]: _0xaeb2134b146c
    });
    return { ok: true, clearedCount: _0x6804c7f052e6.size, dateKey: _0x2cabb2cb05d5 };
}
async function _0xef899cf01f58() {
    const _0xfb34093e3ae5 = await _0x6fe49eb4993c();
    const _0xc216bc1b47ab = _0xfb34093e3ae5[_0xcaf96649348b.RUN_STATE];
    if (!_0xc216bc1b47ab || _0xc216bc1b47ab.mode !== _0x7a039088cb40(148) || _0xc216bc1b47ab.phase !== _0x7a039088cb40(91) || !_0xc216bc1b47ab.runId) {
        return { ok: false, stale: true };
    }
    const _0x8bd4fadd3f14 = _0x9999f9481c0c(_0xc216bc1b47ab);
    if (_0x8bd4fadd3f14 <= 0) {
        return _0x77f68b192075(_0xc216bc1b47ab.runId);
    }
    await _0x5f674b8d9edd(_0xc216bc1b47ab, _0x8bd4fadd3f14);
    return { ok: true, waiting: true };
}
async function _0x7829643f5bfc(_0x415910b2936e) {
    const _0x7594d39ff67d = await chrome.storage.local.get([_0xcaf96649348b.RUN_STATE, _0xcaf96649348b.CART_LOCK]);
    const _0xd7f2297247c8 = _0x7594d39ff67d[_0xcaf96649348b.RUN_STATE] || null;
    const _0x9bb001f4b434 = Boolean(_0xd7f2297247c8 && _0x415910b2936e.tab?.id === _0xd7f2297247c8.workTabId);
    const _0x84ec43c9602b = _0x9bb001f4b434 ? _0xd422dd9d0b08(_0xd7f2297247c8) : null;
    return {
        ok: true,
        isWorkTab: _0x9bb001f4b434,
        state: _0xd7f2297247c8,
        row: _0x9bb001f4b434 ? _0x9ee79768b312(_0xd7f2297247c8) : null,
        group: _0x84ec43c9602b,
        orderRow: _0x9bb001f4b434 ? _0x7e1b2a3dfb08(_0xd7f2297247c8) : null,
        cartLock: _0x9bb001f4b434 ? _0x7594d39ff67d[_0xcaf96649348b.CART_LOCK] || null : null
    };
}
chrome.action.onClicked.addListener(() => {
    _0x56fe6cac629b().catch((_0x49fc67ec19f9) => console.error(_0x7a039088cb40(14), _0x49fc67ec19f9));
});
chrome.runtime.onInstalled.addListener(() => {
    _0x349a83340562(async () => {
        const _0x10ac76485358 = await _0x6fe49eb4993c();
        const _0x75ee378eff51 = _0xa2248a8b28d3(_0x10ac76485358[_0xcaf96649348b.HISTORY]);
        const _0x91c6c3399c48 = _0x5927bc040c8e(_0x10ac76485358[_0xcaf96649348b.ORDER_INDEX], _0x75ee378eff51);
        const _0x002665186981 = Array.isArray(_0x10ac76485358[_0xcaf96649348b.LOGS]) ? _0x10ac76485358[_0xcaf96649348b.LOGS] : [];
        const _0x82b84150c250 = _0x7a411f09453c(_0x10ac76485358[_0xcaf96649348b.SETTINGS]);
        const _0x7c4e23feb6cb = Array.isArray(_0x10ac76485358[_0xcaf96649348b.DRAFT_ROWS]) ? _0x10ac76485358[_0xcaf96649348b.DRAFT_ROWS] : [];
        const _0x005da5a14f90 = _0x10ac76485358[_0xcaf96649348b.CART_LOCK] || null;
        let _0x9fecd21e271f = _0x10ac76485358[_0xcaf96649348b.RUN_STATE] || null;
        if (_0x9fecd21e271f && _0x2098732dc69d.has(_0x9fecd21e271f.mode) && Number(_0x9fecd21e271f.version || 0) < _0x72caa2d2f815) {
            const _0xbf9d0cf965e2 = _0x9ee79768b312(_0x9fecd21e271f);
            if (_0xbf9d0cf965e2) {
                _0x0f9db2374199(_0xbf9d0cf965e2, _0x7a039088cb40(222), _0x7a039088cb40(99));
            }
            _0x9fecd21e271f = {
                ..._0x9fecd21e271f,
                version: _0x72caa2d2f815,
                mode: _0x7a039088cb40(137),
                phase: _0x7a039088cb40(230),
                pauseReason: _0x7a039088cb40(172),
                intervalEndsAt: null,
                intervalRemainingSeconds: 0,
                updatedAt: new Date().toISOString()
            };
            _0x8d616eca1a29(_0x002665186981, _0x7a039088cb40(15), _0x7a039088cb40(134));
        }
        if (_0x005da5a14f90) {
            _0x8d616eca1a29(_0x002665186981, _0x7a039088cb40(15), _0x7a039088cb40(244));
        }
        await chrome.storage.local.set({
            [_0xcaf96649348b.RUN_STATE]: _0x9fecd21e271f,
            [_0xcaf96649348b.HISTORY]: _0x75ee378eff51,
            [_0xcaf96649348b.ORDER_INDEX]: _0x91c6c3399c48,
            [_0xcaf96649348b.LOGS]: _0x002665186981,
            [_0xcaf96649348b.DRAFT_ROWS]: _0x7c4e23feb6cb,
            [_0xcaf96649348b.SETTINGS]: _0x82b84150c250
        });
        if (_0x9fecd21e271f?.mode === _0x7a039088cb40(148) && _0x9fecd21e271f.phase === _0x7a039088cb40(91)) {
            await _0xef899cf01f58();
        }
    }).catch((_0xbafea55d94b6) => console.error(_0xbafea55d94b6));
});
chrome.runtime.onStartup.addListener(() => {
    _0x349a83340562(_0xef899cf01f58).catch((_0x925f3b44b840) => console.error(_0x925f3b44b840));
});
chrome.alarms.onAlarm.addListener((_0x71afdb470c6a) => {
    if (!_0x71afdb470c6a?.name?.startsWith(_0xef695cb59b4e)) {
        return;
    }
    const _0xebf28cc47e75 = _0x71afdb470c6a.name.slice(_0xef695cb59b4e.length);
    _0x349a83340562(() => _0x77f68b192075(_0xebf28cc47e75)).catch((_0xcd51a4243b0a) => console.error(_0xcd51a4243b0a));
});
chrome.runtime.onMessage.addListener((_0xb3e68c42bdd0, _0xccfdd208961a, _0x9fd1e059629c) => {
    const _0xcc0b7081c68c = (_0x044385f5c9fb) => {
        _0x044385f5c9fb.then((_0xd93301267c2f) => _0x9fd1e059629c(_0xd93301267c2f))
            .catch((_0xce89f90ca58f) => {
            console.error(_0xce89f90ca58f);
            _0x9fd1e059629c({ ok: false, error: _0xce89f90ca58f.message || String(_0xce89f90ca58f) });
        });
    };
    switch (_0xb3e68c42bdd0?.type) {
        case _0x7a039088cb40(13):
            _0xcc0b7081c68c(_0x349a83340562(_0xf861bc103e1e));
            return true;
        case _0x7a039088cb40(158):
            _0xcc0b7081c68c(_0x911a8739ff3b(false));
            return true;
        case _0x7a039088cb40(58):
            _0x9fd1e059629c({ ok: true });
            return false;
        case _0x7a039088cb40(106):
            _0xcc0b7081c68c(_0x33ffaa921fa0(_0xccfdd208961a));
            return true;
        case _0x7a039088cb40(135):
            _0xcc0b7081c68c(_0x436078b5b72f());
            return true;
        case _0x7a039088cb40(43):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xaad0ccf27d63(() => _0x17f92a0c8392(_0xb3e68c42bdd0.rows, _0xb3e68c42bdd0.orderIntervalSeconds))));
            return true;
        case _0x7a039088cb40(25):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xaad0ccf27d63(() => _0xc77b36460513(_0xb3e68c42bdd0.rows, _0xb3e68c42bdd0.orderIntervalSeconds))));
            return true;
        case _0x7a039088cb40(45):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xaad0ccf27d63(() => _0x2fdbd67400a0(_0xb3e68c42bdd0.rows))));
            return true;
        case _0x7a039088cb40(216):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xaad0ccf27d63(_0x5f1e47aa0d6b)));
            return true;
        case _0x7a039088cb40(74):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xaad0ccf27d63(_0x61304e0877f5)));
            return true;
        case _0x7a039088cb40(22):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xaad0ccf27d63(() => _0xbe70e61e2c39(_0xb3e68c42bdd0.settings))));
            return true;
        case _0x7a039088cb40(187):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xaad0ccf27d63(_0x3a8796ccc600)));
            return true;
        case _0x7a039088cb40(40):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xaad0ccf27d63(_0x62fc543ff536)));
            return true;
        case _0x7a039088cb40(195):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xdb927225336e(_0xb3e68c42bdd0, _0xccfdd208961a)));
            return true;
        case _0x7a039088cb40(122):
            _0xcc0b7081c68c(_0x349a83340562(() => _0x2709737f6710(_0xb3e68c42bdd0, _0xccfdd208961a)));
            return true;
        case _0x7a039088cb40(24):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xaad0ccf27d63(() => _0x2bc7eac90e58(_0xb3e68c42bdd0, _0xccfdd208961a))));
            return true;
        case _0x7a039088cb40(112):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xb1c29856f132(_0xb3e68c42bdd0, _0xccfdd208961a)));
            return true;
        case _0x7a039088cb40(174):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xaad0ccf27d63(() => _0xbb40f218db8b(_0xb3e68c42bdd0, _0xccfdd208961a, false))));
            return true;
        case _0x7a039088cb40(182):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xaad0ccf27d63(() => _0xecd57fbcd97d(_0xb3e68c42bdd0, _0xccfdd208961a))));
            return true;
        case _0x7a039088cb40(251):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xaad0ccf27d63(() => _0x681515893eba(_0xb3e68c42bdd0, _0xccfdd208961a))));
            return true;
        case _0x7a039088cb40(100):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xaad0ccf27d63(() => _0xbdda60dee737(_0xb3e68c42bdd0, _0xccfdd208961a))));
            return true;
        case _0x7a039088cb40(211):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xaad0ccf27d63(() => _0x3773ed746f4b(_0xb3e68c42bdd0, _0xccfdd208961a))));
            return true;
        case _0x7a039088cb40(115):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xaad0ccf27d63(() => _0xd128bc3e869e(_0xb3e68c42bdd0, _0xccfdd208961a))));
            return true;
        case _0x7a039088cb40(242):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xaad0ccf27d63(() => _0x82ef913751ce(_0xb3e68c42bdd0, _0xccfdd208961a))));
            return true;
        case _0x7a039088cb40(229):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xbed32fceee88(_0xb3e68c42bdd0, _0xccfdd208961a)));
            return true;
        case _0x7a039088cb40(128):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xaad0ccf27d63(_0xf278d8d8b5ec)));
            return true;
        case _0x7a039088cb40(188):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xaad0ccf27d63(_0xdb52219f072d)));
            return true;
        case _0x7a039088cb40(17):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xaad0ccf27d63(_0x2ad95a5ea035)));
            return true;
        case _0x7a039088cb40(37):
            _0xcc0b7081c68c(_0x349a83340562(() => _0xaad0ccf27d63(() => _0xbb40f218db8b({ reason: _0x7a039088cb40(75) }, null, true))));
            return true;
        default:
            return false;
    }
});
chrome.tabs.onRemoved.addListener((_0xa568de182dcc) => {
    _0x349a83340562(async () => {
        const _0x9b28700e03b8 = await _0x6fe49eb4993c();
        const _0xda76ab98ae7b = _0x9b28700e03b8[_0xcaf96649348b.RUN_STATE];
        if (!_0xda76ab98ae7b || _0xa568de182dcc !== _0xda76ab98ae7b.workTabId || !_0x2098732dc69d.has(_0xda76ab98ae7b.mode)) {
            return;
        }
        const _0x8aa37ab0839a = Array.isArray(_0x9b28700e03b8[_0xcaf96649348b.LOGS]) ? _0x9b28700e03b8[_0xcaf96649348b.LOGS] : [];
        const _0xb61a8716cb70 = _0xd422dd9d0b08(_0xda76ab98ae7b);
        const _0xa9bc207d243f = _0x9ee79768b312(_0xda76ab98ae7b);
        const _0xec80f3095ec7 = _0x9b28700e03b8[_0xcaf96649348b.CART_LOCK] || null;
        _0xda76ab98ae7b.workTabId = null;
        _0xda76ab98ae7b.updatedAt = new Date().toISOString();
        if (_0xda76ab98ae7b.phase === _0x7a039088cb40(91) && _0xda76ab98ae7b.mode === _0x7a039088cb40(148)) {
            _0x8d616eca1a29(_0x8aa37ab0839a, _0x7a039088cb40(15), _0x7a039088cb40(220), _0xa9bc207d243f?.rowNumber ?? null);
            await _0x9fec061c38d6(_0xda76ab98ae7b, _0x8aa37ab0839a);
            return;
        }
        _0xda76ab98ae7b.mode = _0x7a039088cb40(136);
        _0xda76ab98ae7b.pauseReason = _0x863787a6bab8(_0xec80f3095ec7, _0xda76ab98ae7b, _0xb61a8716cb70)
            ? _0x7a039088cb40(119) : _0x7a039088cb40(199);
        if (_0xb61a8716cb70?.isCombined) {
            _0xe81840907d4e(_0xda76ab98ae7b.rows, _0xb61a8716cb70, _0xda76ab98ae7b.pauseReason);
        }
        else if (_0xa9bc207d243f) {
            _0x0f9db2374199(_0xa9bc207d243f, `等待人工检查：${_0xda76ab98ae7b.pauseReason}`, _0x7a039088cb40(99));
        }
        _0x8d616eca1a29(_0x8aa37ab0839a, _0x7a039088cb40(20), _0xda76ab98ae7b.pauseReason, _0xa9bc207d243f?.rowNumber ?? null);
        await _0x9fec061c38d6(_0xda76ab98ae7b, _0x8aa37ab0839a);
    }).catch((_0xacdb14ddeb3d) => console.error(_0xacdb14ddeb3d));
});

})();
