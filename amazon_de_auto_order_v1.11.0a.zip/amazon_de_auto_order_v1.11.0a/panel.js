(()=>{'use strict';const _0x6685decc62df=Object.freeze(["K3dIKVxEKUFZJW5IKm9MKlNpKUVBK21iJGJoJHhhK0VlK2NiKHR2K2V2","KXFfKUVBK3dIKVxEKUFZKUNjJE9xKXt+K3dDKkNcKHZoKHFKKXxWKlBmKUNaKXJb7IO+qKm+7IWIL0xOJHt/JHNLKVxCI3BAKll4KHRmKVB8KVFMK3dIKHBWJGJ8KXFZKHR2LkxQKHZ2KXtpJHt/JHNLI3BEJGJuKUFZK3dfKlJQKlBmK21iJGJoI3BFLkxRI3BAKkNeKHd6KHBWK2dHKUF/KnRJJVVoK3dIKVxEKUFZJVhNKXV6KXBMKWtHKHRHKHRMKVB8KVFMK3dII3BXKHRBKHBWKm9MKlNpKkRaKUNaKnpE7I2hrbajouwkYm4pQVkvTE4rbWIpYlYke38kc0spXFsjcFM=","JUxcJG1AKmFvKXBDKUZsKUlpJHhhK0VlK2Ni","7u4=","r6Stoqup","KXFfKUVBKVB8KVFMK3dIKXt+KUlkJU9kKHZ2KXtpJHt/JHNLL0xO","vK2/uKk=","76O+qKm+haK4qb66raCfqa+joqi/","KXFfKUVBJGJuKUFZKUNjJE9xKXt+K3dDKkNcKHZoKHFKKXxWKlBmKUNaKXJb7IO+qKm+7IWIL0xOKU1QKmFuKVxCKHRBKHBWKUpVKUlpKXFfKWhlKHRHKUFZJGJ8KXFZI3BAJUtBKlp8JHNcJG1AKUNjJE9xJUxsKkRcJUtBKWhBKHRHKUFZL0xOK21iKWJWKU1QKmFuKUlkJU9kKHd3KUZtKVxbI3BT","v6SlvI2oqL6pv78=","76+jvLWeqa+jvqi/jrii","KlBmKXBMKWtH","vKSjoqnsormhrqm+","JGN7K21iJGJoKk5kKXt+K3dDKHZ2KXtpKm9MKlNpKXV6KkBFJVBMJGpNKWhIK1xK7I2hrbajouwkeGErRWUrY2IvTE4rd2srd2EpXEIpQ2YocFYqdEklVWgqQ14od3orVkjsj42emJOOmYWAiIWCi+wlWE0jcFcodEEocFYpRGwlVWgkeGErRWUrY2IpWUopX00jcEAod3cpRm0oc1EqQE0pTVAqYW4vTE4rbWIpYlYrd2srd2EpXFsjcFM=","raG2gKWipw==","KHd3KUZtKWJAKkRc","mKmhueyDvqipvuyFiA==","uKg=","KXFfKUVBKWFUKVBk7I+NnpiTjpmFgIiFgovsK3dIKVxEKUFZKWJFKUlkJVhNL0xOKU1QKmFuKHd3KUZtKVxCJVhNKHdBKHBWKHNRK1lVI3BXKHZ2KXtpKm9MKlNpJHhhK0VlK2NiKkRaKlBMJHNdJGJuKUFZKVxCI3BAKUNjKHFzK1hkLkxQK3drK3dhKXFfKUVBKmFpJWZoLkxRKnRJJVVoJU1bK1lVJVhNL0xOK21iKWJWKU1QKmFuKUlkJU9kKHd3KUZtKVxbI3BT","v7ijvLypqA==","KXtpKHFQKltpKXNbKXt+KWhBKUR6L0xO","KlZOKltsKltpKXNb","KlBmK1Np","vqmvo76o4b+5r6+pv78=","oKOr4b6juw==","vKSjoqmCuaGuqb4=","uKm0uOO8oK2log==","K21iJGJoKHdUKmByKlp1KXBDKXV6JHNXKUlpKlBMK3dE7I65teyio7s=","m42FmJODnoiJnpOEhZ+Yg56V","uKmhuYO+qKm+hag=","K21iJGJo7I2oqKmo7Lij7K6tv6epuOwodEIreGMkYm0qWXwlS0M=","o6qq","j4CJjZ6TiJ6NipiTnoObnw==","wcY=","paKqow==","KXFfKUVBKn5tKlBFK3dIKVxEKUFZKWJFKUlkJVhNL0xO","ibm+o7yp446pvqClog==","KURLKkFuKHRh","K2FFKXJJKVB8KVFMJUxFKkdlJW15JVFuKUZsJHFx","K2FFKXJJKHRHKUFZKkRaKHdUKmByJUxFKkdlJW15JVFu","KXtpKHFQK3dfKlJQ","raiovqm/v/4=","vK25v6mo","KHdGKWhl","rb6lreGgra6poA==","ormhqb6lrw==","oKOvraA=","KXtpKHFQKltpKXNbKXt+KnRJK2V2L0xO","pKWoqKmi","paK8ubg=","raG2g76oqb6Ao6u/","n5iDnJOemYI=","KXtpKHFQJGJ8KXFZKXt+KWhBKUR6L0xO","JUxFKkdl7I2hqb6lr62i7Im0vL6pv7/sqaKopaKr7KWi7P38/PU=","776puL61n6elvLypqI64og==","n4eFnJOPmZ6eiYKYk4GNgpmNgA==","K2FFKXJJKVB8KVFMJWZAJGNNK3dfKlJQ","qKW6","oKOr4b6ju+GiuaGuqb4=","77ytub+pjrii","j4CJjZ6TmIOIjZWTg56IiZ6TnomPg56Inw==","raG2g76oqb6Ivq2quJ6ju78=","v6SlvJyjv7itoI+jqKk=","JW5IKm9MKlNpKUNdK0J8KUp+K2ZNI3BAKHd3KUZtKXt+KlZOKU1QK2FFKXJJKHZ2KXtpKWhIK1xKL0xO","77+4rb64jrii","Kn5tKlBFKUNjKWNwKUt2K1ZIKXtpKHFQJGJ8KXFZL0xO","K2FFKXJJKHRHKHRMKUFZKHRHKUFZJVt4JVZY","76+jorilormpjrii","KmxtJWZAKWh9JHhpI3BAJGN7JE1YK393n6Stoqutog==","LkxY","vbmtoriluLXsuKPsv6SlvA==","76m0vKO+uJ6pr6O+qL+Pv7qOuKI=","nI2Zn4mTnpmC","KHd3KUZtK3drK3dhKkVrJG1AL0xO","/uGopauluA==","JHJfKUlpKll8KkFiKXt+KnRJK2V2I3BXKXFfKWhlKkRcKUZTKHRHKUFZJVR+JUtBKWhBJGJ8KXFZKHdBKHNRK1lVL0xO","KXt+KUNaKXJb7IO+qKm+7IWI7CtWSCpEXClGUyRtQCh0QShwViVLQSh0Ry9MTiphaCpfQShxUClDYyRPcSVMbCpEXCVLQSloQSRibilBWSNwQCRjeyttYiRiaCl7fih2dil7aSpvTCpTaS9MTg==","KXt+KlZOKU1Q","qaG8uLXhr6mgoA==","jZmYhJOKjYWAiYg=","Kmx0KWN1Kkx3Kll8JUtDKXV67Jy+o6+pqajsuKPsj6Spr6ejubg=","n42aiZOIno2KmJOeg5uf","raG2j62+uI65paCopaKrgKOvpw==","KXt+KWJAKkRc","m42FmJOFgpiJnpqNgA==","raiovqm/vw==","KkVMKlBF7L6pv7mguPG/p6W8vKmo7CtWSCRtQCVPcShwViVLQSpafCh0RylBWSNwQClASSpHYC5MUJipobnsg76oqb7shYgpcV8paGUpe34odEckc0spQVkuTFEpXkAuTFAodnYpe2kke38kc0sjcEQkYm4pQVkrd18qUlAqUGYrbWIkYmgjcEUuTFEvTE4=","paK8ubjhvqO74aK5oa6pvg==","JHNcJG1AKHRh","qqWiraDhv7muoaW4","jZmYhIOehZaNmIWDgpOPhI2Ci4mI","77+npbyOuKI=","K21iKWJWKnRJK2V2KHdGKWhlKXt+KkRcKUZTJEJ7KUNa7IO+qKm+7IWI7CtWSOyYqaG57IO+qKm+7IWI7CVUfiVLQSloQSRifClxWSlcWyNwU8bGKnRJK2V2KVxCI3BAJHNVKHZX7Jipobnsg76oqb7shYjsKHdGKWhlKUNjKHdpKUpBKmBtKHRHKUFZL0xOKXtpKHFQJGJ8KXFZL0xNJHJfKUlpKll8KkFiKV5AKXtpKHFQKltpKXNbKHRBKHBWJG5nKnRJJVVoL0xO","77+4o7yOuKI=","776puq2gpaituKmNubiko76ltq24paOijrii","qaLhi44=","JHJfKUlpJW5IKm9MKlNpKUp+K2ZNI3BAK2FFKXJJKHZ2KXtpKWhIK1xK","vbmtoriluLWYo5+kpbw=","v6SlvOyvpbi1","76WivLm4mK2uoKmOo6i1","KXFfKUVBJG1AKXt+JHt/JHNLL0xO","uKm0uA==","76+jvLWAo6uOuKI=","qq2loKmo","m42FmJODnoiJnpOfmY+PiZ+f","KHd3KUZtKXt+KU1QKmFu","76+gqa2+haK8ubiOuKI=","r6OhvKCpuKmo","JUxcJG1AJW5IKm9MKlNpK3dIKVxEKUFZKVlKKV9N","7625uKSjvqW2rbilo6KKraWgub6pjq2+","","rbm4pKO+pbapqA==","vKO/uK2g7K+jqKk=","K2FFKXJJKHRHKUFZKkRcKUZTJW15JVFu","raG2g76oqb6fqbi4paKrvw==","oKOr4amhvLi1","r6W4tQ==","KVdSJGN3KXV6Kmx0KWN1JHhhKHV8Kll8JUtD","KURLKkFuKUR8KHRHKHRMKlFtKll8KkFi","uL4=","K2FFKXJJKlBMK3dEKHdUKmByJW15JVFu","76+go7+pm6WiqKO7jrii","vqmvo76o4butvqKloqs=","i4mYk42AgJOIjZiN","uKm0uOOvv7r3r6Stvr+puPG5uKrh9A==","7A==","j4OCmIWCmYmTnpmC","K21iKWJWKnRJK2V2KXtpKHFQKltpKXNbKVxbI3BTKXtpKHFQJGJ8KXFZKV5AKXFfKWhlKkRcKUZTKHRHKUFZJVR+JUtBKWhBJGJ8KXFZKHRBKHBWJG5nKURsJVVoL0xO","KHd3KUZtKXt+KlZOKU1QL0xO","KmNDKUFZKHRHKUFZKlt6JVt4JVt4JVZYKXNJJW13KlRj7PwuTF//+vz87CtWSCpZeCpZfCtrXi9MTg==","pP7/","o66mqa+4","uL6tor+luKWjoqWiqw==","v7mvr6m/vw==","76Cjq4+joritpaKpvg==","76+gqa2+mKOorbWDvqipvr+OuKI=","v6SlvI+luLU=","vKmiqKWiqw==","JGN7K21iJGJoKk5kKXt+K3dDKHZ2KXtpKm9MKlNp7I2hrbajouwqUEwkc10kYm4pQVkjcEApRGgqWmEkY2krd0gpXEQpQVkqVGMpXGope34rd0MpYlIlVUkqQ1wodmgvTE4rd2srd2EpXEIpQ2YocFYqdEklVWgqQ14od3orVkjsj42emJOOmYWAiIWCi+wlWE0jcFcodEEocFYpSlUpSWnsg76oqb7shYgvTE0odEEocFYpQ1oqekQkYm4pQVkjcEAod3cpRm0oc1EqQE0pTVAqYW4vTE4rbWIpYlYrd2srd2EpXFsjcFM=","Km9MKlNpKVlKKV9NKVxnK2RCKUFZKHd77C5OYP7i/Pw=","oKOr4aCpuqmg","xQ==","raG2g76oqb6euaKfuK24qQ==","v6SlvOy8o7+4raDsr6OoqQ==","qb6+o74=","raG2g76oqb6Epb+4o761","wQ==","K3dIKVxEKUFZKWJFKUlkJVhNKXt+KnRJJVVoI3BXKHd3KUZtKHNRKkBNKU1QKmFuL0xO","KXtpKHFQJGJ8KXFZKHRhKn5tKlBFKUNjKWhBKUR6K1ZI7IO+qKm+7IWIL0xO","76+5vr6porieo7s=","vqmvo76o4am+vqO+","Kn5tKlBFKUNjKWhIK1xKK1ZIKll8KkFiJG1AL0xO","v7ytog==","KkVfKXBMKVlKKV9NJW15KXV6JGNKKURnKHRHKUFZKmRtKVFb","9w==","KXFfKUVBJGJuKUFZKUNjJE9xKXt+K3dDKkNcKHZoKHFKKXxWKlBmKUNaKXJb7IO+qKm+7IWIL0xOJHt/JHNLKVxCKHRBKHBWKUpVKUlpKXFfKWhlKHRHKUFZJGJ8KXFZI3BAJUtBKlp8JHNcJG1AK1d0KVxA7Jipobnsg76oqb7shYjsKUNjJE9xJUxsKkRcJUtBKWhBKHRHKUFZL0xOK21iKWJWJHt/JHNLKXFfKUVBJG1AKVxbI3BT","K2FFKXJJKHZ2KXtpJUxFKkdlKkJkJEFcKVB8KVFM","KHd3KUZtKXt+KXBMKWtHL0xO","K2FFKXJJKlp8KXd2KVB8KVFMK2ZbKUNv","xg==","JUxFKkdlK35yKUtKJHhhKHV8Kll8JUtD","KXFfKUVBK3dIKVxEKUFZKXt+K3dDKXBMKWtHKlJIKXd2JHhhK0VlK2NiL0xOJHt/JHNLKVxCI3BAKll4KHRmKVB8KVFMK3dIKHBWJGJ8KXFZKHR2LkxQKHZ2KXtpJHt/JHNLLkxRI3BAKkNeKHd6KHBWK2dHKUF/KnRJJVVoK3dIKVxEKUFZJVhNKXV6KXBMKWtHKHRHKHRMKVB8KVFMK3dII3BXKHRBKHBWJEtmKUZkKnRJK1xKJHhhK0VlK2NiKVlKKV9NL0xOK21iKWJWJHt/JHNLKVxbI3BT","KXFfKUVBKXtpKHFQJGJ8KXFZKHRhKn5tKlBFKUNjJUtBKHRHK1ZIJHt/JHNLJG1AL0xO","7765ooGjqKk=","oKOr4aGpv7+tq6k=","KlZOKltsKXtpKHFQJGJ8KXFZ","jYGW7KCloqc=","jZ+Fgg==","K21iKWJWKnRJK2V2JHJfKUlpJG1kKmxwKV5AKXFfKUVBKXt+K3dfKlFTKHd3KUZtK1ZIKXtpKHFQJGJ8KXFZKVxbI3BTKXFfKWhlKkRcKUZTKHRHKUFZJVR+JUtBKWhBJGJ8KXFZKHRBKHBWJG5nKURsJVVoL0xO","paK8ubiXqK24reGqpamgqJE=","vqmvpbylqaK47KKtoak=","JUtBKHRHKHd3KUZtJW5IKm9MKlNpKUNdK0J8KUp+K2ZNI3BAKXt+KlZOKU1QK2FFKXJJKHZ2KXtpKWhIK1xKL0xO","77ijrb+4","76+5vr6poricpK2/qQ==","KXt+KU1QKmFu","77ytub+pnqmtv6Oi","nomajYCFiI2YiZONmZiEg56Flo2YhYOC","K051KUt3KVB8KVFMKmRtKVFb7I+kraKrqQ==","nomYnpWTn4eFnJyJiJOemYI=","rqCjr6epqA==","r6Clr6c=","rQ==","rrm4uKOi4Oylory5uA==","vrmioqWiqw==","vqmvpbylqaK4gq2hqQ==","Kmx0KWN1KHdUKmByJW15Klh6KHd6KHZ2KWtfKVxB","776pr6O+qL+Yra6gqY6jqLU=","KmFvKXBDKUZsJHhhKUVBKUpBKmBtK21iJGJoJHhhK0VlK2NiKHR2K2V2","7g==","oKOr4biloak=","v6SlvOytqKi+qb+/","KHd3KUZtKXt+KU1QKmFuL0xO","76+jvLWDvqipvoWov464og==","v6elvLypqA==","76+gqa2+gKOrjrii","n5iNnpiTnpmC","j4CJjZ6TgIOLnw==","Kmx0KWN1K2BgKHRMKXBsJGJuKUFZKUFtK0VLKWtfKVxBKV5AKlp87IO+qKm+7IWI","nomPg5qJnpOPjZ6Yk46ZhYCIhYKLk4CDj4c="]);const _0xfbca01a5325b=[];const _0x66bfc99a0068=204;let _0x362050258487=_0x66bfc99a0068>>>0;for(const _0xv of _0x6685decc62df)_0x362050258487=(((_0x362050258487*131)>>>0)+_0xv.length)>>>0;const _0x9aaed143665d=2857889236>>>0;if(_0x362050258487!==_0x9aaed143665d)throw 0;function _0xc2c682dc38cc(_0xi){if(_0xfbca01a5325b[_0xi]!==undefined)return _0xfbca01a5325b[_0xi];const _0xb=atob(_0x6685decc62df[_0xi]);const _0xu=new Uint8Array(_0xb.length);for(let _0xj=0;_0xj<_0xb.length;_0xj++)_0xu[_0xj]=_0xb.charCodeAt(_0xj)^_0x66bfc99a0068;return _0xfbca01a5325b[_0xi]=new TextDecoder().decode(_0xu);}
'use strict';
const _0x7b374ad145f3 = Object.freeze({
    RUN_STATE: _0xc2c682dc38cc(142),
    HISTORY: _0xc2c682dc38cc(145),
    LOGS: _0xc2c682dc38cc(50),
    DRAFT_ROWS: _0xc2c682dc38cc(61),
    SETTINGS: _0xc2c682dc38cc(114),
    CART_LOCK: _0xc2c682dc38cc(82)
});
const _0x1005db810398 = Object.freeze([
    { key: _0xc2c682dc38cc(29), label: _0xc2c682dc38cc(16) },
    { key: _0xc2c682dc38cc(14), label: _0xc2c682dc38cc(166) },
    { key: _0xc2c682dc38cc(97), label: _0xc2c682dc38cc(70) },
    { key: _0xc2c682dc38cc(184), label: _0xc2c682dc38cc(170) },
    { key: _0xc2c682dc38cc(25), label: _0xc2c682dc38cc(12) },
    { key: _0xc2c682dc38cc(9), label: _0xc2c682dc38cc(190) },
    { key: _0xc2c682dc38cc(41), label: _0xc2c682dc38cc(41) },
    { key: _0xc2c682dc38cc(136), label: _0xc2c682dc38cc(98) },
    { key: _0xc2c682dc38cc(62), label: _0xc2c682dc38cc(143) }
]);
const _0xc39640af9a9e = new Set([_0xc2c682dc38cc(183), _0xc2c682dc38cc(42), _0xc2c682dc38cc(132)]);
const _0x79a4bcd6f97a = _0xc2c682dc38cc(68);
const _0xdfe5ab4714a4 = Object.freeze({
    PRECHECK_CONFLICT: _0xc2c682dc38cc(96),
    CHECK_CART_BEFORE_PRECHECK: _0xc2c682dc38cc(0),
    GROUP_PRECHECK_PRODUCT: _0xc2c682dc38cc(108),
    CHECK_CART_BEFORE_BUILD: _0xc2c682dc38cc(187),
    GROUP_ADD_PRODUCT: _0xc2c682dc38cc(2),
    WAIT_GROUP_ADD_RESULT: _0xc2c682dc38cc(30),
    GROUP_PROCEED_CHECKOUT: _0xc2c682dc38cc(80),
    WAIT_PRODUCT: _0xc2c682dc38cc(153),
    VERIFY_PRODUCT_PRICE: _0xc2c682dc38cc(139),
    SELECT_QUANTITY: _0xc2c682dc38cc(160),
    VERIFY_QUANTITY: _0xc2c682dc38cc(117),
    WAIT_CHECKOUT: _0xc2c682dc38cc(39),
    SELECT_PAYMENT_CARD: _0xc2c682dc38cc(53),
    WAIT_CHANGE_ADDRESS: _0xc2c682dc38cc(177),
    WAIT_ADD_ADDRESS_AFTER_CHANGE: _0xc2c682dc38cc(38),
    WAIT_ADDRESS_FORM: _0xc2c682dc38cc(158),
    WAIT_ADDRESS_RESULT: _0xc2c682dc38cc(56),
    WAIT_MANUAL_ADDRESS: _0xc2c682dc38cc(156),
    WAIT_PAYMENT: _0xc2c682dc38cc(120),
    CONFIRM_PAYMENT_METHOD: _0xc2c682dc38cc(27),
    VERIFY_PAYMENT_NAME: _0xc2c682dc38cc(185),
    WAIT_ORDER_SUCCESS: _0xc2c682dc38cc(113),
    WAIT_ORDER_HISTORY: _0xc2c682dc38cc(197),
    TRANSITIONING: _0xc2c682dc38cc(118),
    WAIT_INTERVAL: _0xc2c682dc38cc(66),
    COMPLETED: _0xc2c682dc38cc(15),
    STOPPED: _0xc2c682dc38cc(105)
});
const _0xc02f3fb42d17 = Object.freeze({
    running: _0xc2c682dc38cc(88),
    paused: _0xc2c682dc38cc(77),
    transitioning: _0xc2c682dc38cc(37),
    completed: _0xc2c682dc38cc(83),
    stopped: _0xc2c682dc38cc(174)
});
let _0xbe370349ac8a = [];
let _0x432dccb8a5b6 = null;
let _0x4b1b709153d6 = [];
let _0xe99074e3f1b2 = { orderIntervalSeconds: 30 };
let _0x8676f61eb95f = null;
let _0xdf9dcab67ce7 = null;
let _0x9efa0b34f19c = null;
let _0x782bed6b5dea = _0xc2c682dc38cc(137);
let _0x91a3be6c6708 = false;
const _0x23af7358c4c7 = {
    runMode: document.querySelector(_0xc2c682dc38cc(163)),
    currentRow: document.querySelector(_0xc2c682dc38cc(149)),
    currentPhase: document.querySelector(_0xc2c682dc38cc(173)),
    pauseReason: document.querySelector(_0xc2c682dc38cc(175)),
    authorizationFailureBar: document.querySelector(_0xc2c682dc38cc(109)),
    revalidateAuthorizationBtn: document.querySelector(_0xc2c682dc38cc(94)),
    closeWindowBtn: document.querySelector(_0xc2c682dc38cc(121)),
    startBtn: document.querySelector(_0xc2c682dc38cc(64)),
    retrySkippedBtn: document.querySelector(_0xc2c682dc38cc(54)),
    pauseBtn: document.querySelector(_0xc2c682dc38cc(59)),
    continueBtn: document.querySelector(_0xc2c682dc38cc(67)),
    skipBtn: document.querySelector(_0xc2c682dc38cc(91)),
    stopBtn: document.querySelector(_0xc2c682dc38cc(93)),
    orderIntervalSeconds: document.querySelector(_0xc2c682dc38cc(7)),
    clearTodayOrdersBtn: document.querySelector(_0xc2c682dc38cc(135)),
    clearInputBtn: document.querySelector(_0xc2c682dc38cc(106)),
    copyOrderIdsBtn: document.querySelector(_0xc2c682dc38cc(192)),
    exportRecordsCsvBtn: document.querySelector(_0xc2c682dc38cc(71)),
    copyRecordsBtn: document.querySelector(_0xc2c682dc38cc(10)),
    copyLogBtn: document.querySelector(_0xc2c682dc38cc(102)),
    clearLogBtn: document.querySelector(_0xc2c682dc38cc(194)),
    inputTableBody: document.querySelector(_0xc2c682dc38cc(99)),
    recordsTableBody: document.querySelector(_0xc2c682dc38cc(186)),
    logContainer: document.querySelector(_0xc2c682dc38cc(134)),
    toast: document.querySelector(_0xc2c682dc38cc(172))
};
function _0xa0d4c64cb210() {
    return crypto.randomUUID();
}
function _0xe5d1bf66e2be() {
    return {
        _rowId: _0xa0d4c64cb210(),
        ...Object.fromEntries(_0x1005db810398.map(({ key: _0xf5a847cf8cae }) => [_0xf5a847cf8cae, _0xc2c682dc38cc(110)]))
    };
}
function _0x0085646e9e9c(_0x3354a95cb332) {
    const _0xacafe154dfbb = _0x3354a95cb332 && typeof _0x3354a95cb332 === _0xc2c682dc38cc(131) ? _0x3354a95cb332 : {};
    const _0xf4150a25eb55 = String(_0xacafe154dfbb._rowId || _0xacafe154dfbb.draftRowId || _0xc2c682dc38cc(110)).trim() || _0xa0d4c64cb210();
    return {
        _rowId: _0xf4150a25eb55,
        ...Object.fromEntries(_0x1005db810398.map(({ key: _0x1a33570c268c }) => [_0x1a33570c268c, String(_0xacafe154dfbb[_0x1a33570c268c] ?? _0xc2c682dc38cc(110))]))
    };
}
function _0x8ef588e7e8c0(_0xda81b0f55d66, _0xdfdd3e6a4d5c = 12) {
    const _0x48f096661ae4 = _0xda81b0f55d66.map(_0x0085646e9e9c);
    while (_0x48f096661ae4.length < _0xdfdd3e6a4d5c) {
        _0x48f096661ae4.push(_0xe5d1bf66e2be());
    }
    return _0x48f096661ae4;
}
function _0xc863170e94ee(_0xea86cd6a7cd9) {
    return _0x1005db810398.every(({ key: _0x5e75015cd385 }) => String(_0xea86cd6a7cd9?.[_0x5e75015cd385] ?? _0xc2c682dc38cc(110)).trim() === _0xc2c682dc38cc(110));
}
function _0x04c69ec7bbd9(_0x82c07d27f7c8, _0xfa18e73943b7 = false) {
    clearTimeout(_0x9efa0b34f19c);
    _0x23af7358c4c7.toast.textContent = _0x82c07d27f7c8;
    _0x23af7358c4c7.toast.classList.toggle(_0xc2c682dc38cc(144), _0xfa18e73943b7);
    _0x23af7358c4c7.toast.classList.remove(_0xc2c682dc38cc(48));
    _0x9efa0b34f19c = setTimeout(() => _0x23af7358c4c7.toast.classList.add(_0xc2c682dc38cc(48)), 4000);
}
function _0xfdbe9f0fa984(_0x4d12dab060ac, _0x62d30b6f2447 = true) {
    if (_0x4d12dab060ac?.authorized) {
        _0x782bed6b5dea = _0xc2c682dc38cc(111);
        _0x91a3be6c6708 = false;
        _0x23af7358c4c7.authorizationFailureBar.classList.add(_0xc2c682dc38cc(48));
        _0xe24ac985a4ff();
        return;
    }
    _0x782bed6b5dea = _0xc2c682dc38cc(103);
    _0x23af7358c4c7.authorizationFailureBar.classList.remove(_0xc2c682dc38cc(48));
    _0xe24ac985a4ff();
    if (_0x62d30b6f2447 && !_0x91a3be6c6708) {
        _0x91a3be6c6708 = true;
        window.alert(_0x79a4bcd6f97a);
    }
}
function _0x866b38bfb35d(_0x3818018b93f8) {
    return Boolean(_0x3818018b93f8?.code === _0xc2c682dc38cc(79) ||
        _0x3818018b93f8?.authorization?.authorized === false);
}
async function _0x3fd0054b4ac0(_0x8e4e779ef629, _0xb2ab9efbbb46 = {}) {
    try {
        const _0x2407cc456b22 = await chrome.runtime.sendMessage({ type: _0x8e4e779ef629, ..._0xb2ab9efbbb46 });
        if (_0x2407cc456b22?.authorization) {
            _0xfdbe9f0fa984(_0x2407cc456b22.authorization, true);
        }
        if (_0x866b38bfb35d(_0x2407cc456b22)) {
            _0xfdbe9f0fa984(_0x2407cc456b22.authorization || { authorized: false }, true);
            return _0x2407cc456b22;
        }
        if (!_0x2407cc456b22?.ok && _0x2407cc456b22?.error) {
            _0x04c69ec7bbd9(_0x2407cc456b22.error, true);
        }
        return _0x2407cc456b22;
    }
    catch (_0x31d93e9946a1) {
        _0x04c69ec7bbd9(_0x31d93e9946a1.message || String(_0x31d93e9946a1), true);
        return { ok: false, error: _0x31d93e9946a1.message || String(_0x31d93e9946a1) };
    }
}
function _0x1e7de8b50417() {
    _0x23af7358c4c7.inputTableBody.replaceChildren();
    const _0x28e410ad93d8 = document.createDocumentFragment();
    _0xbe370349ac8a.forEach((_0x1f1a610e1771, _0x3230597ee232) => {
        const _0x173da802264a = document.createElement(_0xc2c682dc38cc(119));
        const _0x66710116e954 = document.createElement(_0xc2c682dc38cc(17));
        _0x66710116e954.className = _0xc2c682dc38cc(87);
        _0x66710116e954.textContent = String(_0x3230597ee232 + 1);
        _0x173da802264a.appendChild(_0x66710116e954);
        _0x1005db810398.forEach(({ key: _0xce36c4e76c41, label: _0x2dd4c4d9ad2a }, _0xc12256239182) => {
            const _0x151fba19798f = document.createElement(_0xc2c682dc38cc(17));
            const _0x6bdd7bd8f4bf = document.createElement(_0xc2c682dc38cc(49));
            _0x6bdd7bd8f4bf.type = _0xc2c682dc38cc(101);
            _0x6bdd7bd8f4bf.value = String(_0x1f1a610e1771[_0xce36c4e76c41] ?? _0xc2c682dc38cc(110));
            _0x6bdd7bd8f4bf.autocomplete = _0xc2c682dc38cc(31);
            _0x6bdd7bd8f4bf.spellcheck = false;
            _0x6bdd7bd8f4bf.setAttribute(_0xc2c682dc38cc(44), `${_0x2dd4c4d9ad2a}，第 ${_0x3230597ee232 + 1} 行`);
            _0x6bdd7bd8f4bf.dataset.rowIndex = String(_0x3230597ee232);
            _0x6bdd7bd8f4bf.dataset.columnIndex = String(_0xc12256239182);
            _0x6bdd7bd8f4bf.dataset.field = _0xce36c4e76c41;
            _0x6bdd7bd8f4bf.addEventListener(_0xc2c682dc38cc(49), () => {
                _0xbe370349ac8a[_0x3230597ee232][_0xce36c4e76c41] = _0x6bdd7bd8f4bf.value;
                _0x8a65971edf9e();
            });
            _0x6bdd7bd8f4bf.addEventListener(_0xc2c682dc38cc(6), (_0x2ef881ef3648) => {
                const _0xf33497dd15e2 = _0x2ef881ef3648.clipboardData?.getData(_0xc2c682dc38cc(26)) || _0xc2c682dc38cc(110);
                if (!_0xf33497dd15e2.includes(_0xc2c682dc38cc(141)) && !/[\r\n]/.test(_0xf33497dd15e2)) {
                    return;
                }
                _0x2ef881ef3648.preventDefault();
                _0xbcc3c84f4a04(_0x3230597ee232, _0xc12256239182, _0xf33497dd15e2);
            });
            _0x151fba19798f.appendChild(_0x6bdd7bd8f4bf);
            _0x173da802264a.appendChild(_0x151fba19798f);
        });
        _0x28e410ad93d8.appendChild(_0x173da802264a);
    });
    _0x23af7358c4c7.inputTableBody.appendChild(_0x28e410ad93d8);
    _0xe24ac985a4ff();
}
function _0x2639efc8ce2d(_0x6996298b2edd) {
    const _0x3d4754a90e77 = [];
    let _0x188dff0e87e1 = [];
    let _0x788a0da1bf8e = _0xc2c682dc38cc(110);
    let _0x893ac1efd520 = false;
    for (let _0xb3bf3065a432 = 0; _0xb3bf3065a432 < _0x6996298b2edd.length; _0xb3bf3065a432 += 1) {
        const _0x120b088daf54 = _0x6996298b2edd[_0xb3bf3065a432];
        const _0x628458d33c63 = _0x6996298b2edd[_0xb3bf3065a432 + 1];
        if (_0x120b088daf54 === _0xc2c682dc38cc(188)) {
            if (_0x893ac1efd520 && _0x628458d33c63 === _0xc2c682dc38cc(188)) {
                _0x788a0da1bf8e += _0xc2c682dc38cc(188);
                _0xb3bf3065a432 += 1;
            }
            else {
                _0x893ac1efd520 = !_0x893ac1efd520;
            }
            continue;
        }
        if (!_0x893ac1efd520 && _0x120b088daf54 === _0xc2c682dc38cc(141)) {
            _0x188dff0e87e1.push(_0x788a0da1bf8e);
            _0x788a0da1bf8e = _0xc2c682dc38cc(110);
            continue;
        }
        if (!_0x893ac1efd520 && (_0x120b088daf54 === _0xc2c682dc38cc(159) || _0x120b088daf54 === _0xc2c682dc38cc(146))) {
            if (_0x120b088daf54 === _0xc2c682dc38cc(146) && _0x628458d33c63 === _0xc2c682dc38cc(159)) {
                _0xb3bf3065a432 += 1;
            }
            _0x188dff0e87e1.push(_0x788a0da1bf8e);
            _0x3d4754a90e77.push(_0x188dff0e87e1);
            _0x188dff0e87e1 = [];
            _0x788a0da1bf8e = _0xc2c682dc38cc(110);
            continue;
        }
        _0x788a0da1bf8e += _0x120b088daf54;
    }
    _0x188dff0e87e1.push(_0x788a0da1bf8e);
    _0x3d4754a90e77.push(_0x188dff0e87e1);
    while (_0x3d4754a90e77.length > 1 && _0x3d4754a90e77[_0x3d4754a90e77.length - 1].every((_0x107fbf91a225) => _0x107fbf91a225 === _0xc2c682dc38cc(110))) {
        _0x3d4754a90e77.pop();
    }
    return _0x3d4754a90e77;
}
function _0xbcc3c84f4a04(_0x53d1732331d9, _0xc0589a2241d3, _0x727db879ecf0) {
    const _0x2ec49f560b61 = _0x2639efc8ce2d(_0x727db879ecf0);
    const _0xaa08354c4977 = _0x2ec49f560b61.some((_0x5b99aad84b3d) => _0x5b99aad84b3d.length > 1);
    if (_0xaa08354c4977) {
        const _0x4a8f33c3d3e4 = _0x2ec49f560b61.findIndex((_0x5c2da6ff8bac) => _0x5c2da6ff8bac.length !== _0x1005db810398.length);
        if (_0x4a8f33c3d3e4 >= 0) {
            _0x04c69ec7bbd9(`粘贴失败：第 ${_0x4a8f33c3d3e4 + 1} 行有 ${_0x2ec49f560b61[_0x4a8f33c3d3e4].length} 列，批量数据必须严格为 ${_0x1005db810398.length} 列；address2 为空时也要保留空列。`, true);
            return;
        }
        _0xc0589a2241d3 = 0;
    }
    const _0xad069c6e8573 = _0x1005db810398.length - _0xc0589a2241d3;
    const _0xd08028b92924 = _0x2ec49f560b61.findIndex((_0x1b09f44decaa) => _0x1b09f44decaa.length > _0xad069c6e8573);
    if (_0xd08028b92924 >= 0) {
        _0x04c69ec7bbd9(`粘贴失败：从当前单元格开始最多还能粘贴 ${_0xad069c6e8573} 列，第 ${_0xd08028b92924 + 1} 行超出输入表格范围。`, true);
        return;
    }
    const _0x9b250347cef9 = _0x53d1732331d9 + _0x2ec49f560b61.length;
    while (_0xbe370349ac8a.length < _0x9b250347cef9) {
        _0xbe370349ac8a.push(_0xe5d1bf66e2be());
    }
    _0x2ec49f560b61.forEach((_0xa4080b59d510, _0xa8b6c2345f3f) => {
        _0xa4080b59d510.forEach((_0x7743f7183069, _0x859310a6cfa2) => {
            const _0xce3515561e93 = _0xc0589a2241d3 + _0x859310a6cfa2;
            if (_0xce3515561e93 >= _0x1005db810398.length) {
                return;
            }
            const _0x9b0f59404291 = _0x1005db810398[_0xce3515561e93].key;
            _0xbe370349ac8a[_0x53d1732331d9 + _0xa8b6c2345f3f][_0x9b0f59404291] = _0x7743f7183069;
        });
    });
    _0xbe370349ac8a = _0x8ef588e7e8c0(_0xbe370349ac8a);
    _0x1e7de8b50417();
    _0x8a65971edf9e(0);
    _0x04c69ec7bbd9(_0xaa08354c4977 ? `已按九列新格式粘贴 ${_0x2ec49f560b61.length} 行数据。`
        : `已粘贴 ${_0x2ec49f560b61.length} 行单列数据。`);
}
function _0x7dbcec4ee6bd() {
    const _0x86ff37ee490b = [..._0x23af7358c4c7.inputTableBody.querySelectorAll(_0xc2c682dc38cc(169))];
    _0x86ff37ee490b.forEach((_0xfa1c1fb9dfba) => {
        const _0xaf925cc1c8a1 = Number(_0xfa1c1fb9dfba.dataset.rowIndex);
        const _0x62aee32e55b5 = _0xfa1c1fb9dfba.dataset.field;
        if (_0xbe370349ac8a[_0xaf925cc1c8a1] && _0x62aee32e55b5) {
            _0xbe370349ac8a[_0xaf925cc1c8a1][_0x62aee32e55b5] = _0xfa1c1fb9dfba.value;
        }
    });
    return _0xbe370349ac8a.map(_0x0085646e9e9c);
}
function _0x8a65971edf9e(_0x4d80b1a15504 = 450) {
    clearTimeout(_0xdf9dcab67ce7);
    _0xdf9dcab67ce7 = setTimeout(async () => {
        _0xdf9dcab67ce7 = null;
        if (_0x432dccb8a5b6 && _0xc39640af9a9e.has(_0x432dccb8a5b6.mode)) {
            return;
        }
        _0x7dbcec4ee6bd();
        await _0x3fd0054b4ac0(_0xc2c682dc38cc(81), { rows: _0xbe370349ac8a });
    }, _0x4d80b1a15504);
}
function _0x3696ab2b8e6a(_0xa2231b63d4d9) {
    return String(_0xa2231b63d4d9 ?? _0xc2c682dc38cc(110)).replace(/[\t\r\n]+/g, _0xc2c682dc38cc(125)).trim();
}
function _0x3bcf469955f0(_0x6834243d3f25, _0x52ca46568fd4, _0xb63842a31740 = _0xc2c682dc38cc(110)) {
    const _0x02ed256ed042 = document.createElement(_0xc2c682dc38cc(17));
    _0x02ed256ed042.textContent = String(_0x52ca46568fd4 ?? _0xc2c682dc38cc(110));
    _0x02ed256ed042.title = String(_0x52ca46568fd4 ?? _0xc2c682dc38cc(110));
    if (_0xb63842a31740) {
        _0x02ed256ed042.className = _0xb63842a31740;
    }
    _0x6834243d3f25.appendChild(_0x02ed256ed042);
}
function _0xb9d8a59e38db(_0x25c082163a5a) {
    if (_0x25c082163a5a.result === _0xc2c682dc38cc(133)) {
        return _0xc2c682dc38cc(23);
    }
    if (_0x25c082163a5a.result === _0xc2c682dc38cc(179)) {
        return _0xc2c682dc38cc(150);
    }
    if (_0x25c082163a5a.result === _0xc2c682dc38cc(193)) {
        return _0xc2c682dc38cc(122);
    }
    return _0xc2c682dc38cc(110);
}
function _0x2bde208a68f8(_0x6c55b76a244e) {
    if (_0x6c55b76a244e?.result === _0xc2c682dc38cc(133) && /^\d{3}-\d{7}-\d{7}$/.test(String(_0x6c55b76a244e?.orderId || _0xc2c682dc38cc(110)).trim())) {
        return String(_0x6c55b76a244e.orderId).trim();
    }
    return String(_0x6c55b76a244e?.status || _0xc2c682dc38cc(110));
}
function _0xb7ef405e3f95() {
    _0x23af7358c4c7.recordsTableBody.replaceChildren();
    const _0x6ea61971807a = Array.isArray(_0x432dccb8a5b6?.rows) ? _0x432dccb8a5b6.rows : [];
    if (_0x6ea61971807a.length === 0) {
        const _0xeabb9c205b6c = document.createElement(_0xc2c682dc38cc(119));
        const _0xccb1848f382f = document.createElement(_0xc2c682dc38cc(17));
        _0xccb1848f382f.colSpan = 7;
        _0xccb1848f382f.className = _0xc2c682dc38cc(78);
        _0xccb1848f382f.textContent = _0xc2c682dc38cc(165);
        _0xeabb9c205b6c.appendChild(_0xccb1848f382f);
        _0x23af7358c4c7.recordsTableBody.appendChild(_0xeabb9c205b6c);
        return;
    }
    const _0xbba72f92e935 = document.createDocumentFragment();
    _0x6ea61971807a.forEach((_0xeb6f1b5f79e3) => {
        const _0xdf2d37332f75 = document.createElement(_0xc2c682dc38cc(119));
        _0x3bcf469955f0(_0xdf2d37332f75, _0xeb6f1b5f79e3.temuOrderId || _0xc2c682dc38cc(110));
        _0x3bcf469955f0(_0xdf2d37332f75, _0xeb6f1b5f79e3.asin || _0xc2c682dc38cc(110));
        _0x3bcf469955f0(_0xdf2d37332f75, _0xeb6f1b5f79e3.recipientName || _0xc2c682dc38cc(110));
        _0x3bcf469955f0(_0xdf2d37332f75, _0xeb6f1b5f79e3.shipAddress || _0xc2c682dc38cc(110));
        _0x3bcf469955f0(_0xdf2d37332f75, _0xeb6f1b5f79e3.shipCity || _0xc2c682dc38cc(110));
        _0x3bcf469955f0(_0xdf2d37332f75, _0xeb6f1b5f79e3.shipPostalCode || _0xc2c682dc38cc(110));
        _0x3bcf469955f0(_0xdf2d37332f75, _0x2bde208a68f8(_0xeb6f1b5f79e3), _0xb9d8a59e38db(_0xeb6f1b5f79e3));
        _0xbba72f92e935.appendChild(_0xdf2d37332f75);
    });
    _0x23af7358c4c7.recordsTableBody.appendChild(_0xbba72f92e935);
}
function _0xf40db31b9d36() {
    _0x23af7358c4c7.logContainer.replaceChildren();
    if (!Array.isArray(_0x4b1b709153d6) || _0x4b1b709153d6.length === 0) {
        const _0x533c21acf61d = document.createElement(_0xc2c682dc38cc(57));
        _0x533c21acf61d.className = _0xc2c682dc38cc(115);
        _0x533c21acf61d.textContent = _0xc2c682dc38cc(21);
        _0x23af7358c4c7.logContainer.appendChild(_0x533c21acf61d);
        return;
    }
    const _0x465d4110318d = document.createDocumentFragment();
    _0x4b1b709153d6.forEach((_0x39febb61da8e) => {
        const _0xb7c29e11e6ff = document.createElement(_0xc2c682dc38cc(57));
        _0xb7c29e11e6ff.className = _0xc2c682dc38cc(24);
        _0xb7c29e11e6ff.dataset.level = _0x39febb61da8e.level || _0xc2c682dc38cc(34);
        const _0x0b995c50d240 = document.createElement(_0xc2c682dc38cc(152));
        _0x0b995c50d240.className = _0xc2c682dc38cc(189);
        _0x0b995c50d240.textContent = _0x39febb61da8e.time || _0xc2c682dc38cc(110);
        const _0x621dffe1fb51 = document.createElement(_0xc2c682dc38cc(152));
        _0x621dffe1fb51.className = _0xc2c682dc38cc(140);
        _0x621dffe1fb51.textContent = _0x39febb61da8e.level || _0xc2c682dc38cc(34);
        const _0x89a206fb7529 = document.createElement(_0xc2c682dc38cc(152));
        _0x89a206fb7529.className = _0xc2c682dc38cc(58);
        _0x89a206fb7529.textContent = _0x39febb61da8e.rowNumber ? `第${_0x39febb61da8e.rowNumber}行` : _0xc2c682dc38cc(69);
        const _0x2ee7568d4f2c = document.createElement(_0xc2c682dc38cc(152));
        _0x2ee7568d4f2c.className = _0xc2c682dc38cc(164);
        _0x2ee7568d4f2c.textContent = _0x39febb61da8e.message || _0xc2c682dc38cc(110);
        _0xb7c29e11e6ff.append(_0x0b995c50d240, _0x621dffe1fb51, _0x89a206fb7529, _0x2ee7568d4f2c);
        _0x465d4110318d.appendChild(_0xb7c29e11e6ff);
    });
    _0x23af7358c4c7.logContainer.appendChild(_0x465d4110318d);
    _0x23af7358c4c7.logContainer.scrollTop = _0x23af7358c4c7.logContainer.scrollHeight;
}
function _0xa8266aeeed88() {
    if (!_0x432dccb8a5b6) {
        _0x23af7358c4c7.runMode.textContent = _0xc2c682dc38cc(11);
        _0x23af7358c4c7.currentRow.textContent = _0xc2c682dc38cc(69);
        _0x23af7358c4c7.currentPhase.textContent = _0xc2c682dc38cc(69);
        _0x23af7358c4c7.pauseReason.classList.add(_0xc2c682dc38cc(48));
        _0x23af7358c4c7.pauseReason.textContent = _0xc2c682dc38cc(110);
        return;
    }
    _0x23af7358c4c7.runMode.textContent = _0xc02f3fb42d17[_0x432dccb8a5b6.mode] || _0x432dccb8a5b6.mode || _0xc2c682dc38cc(22);
    const _0xe1520eba2524 = Number.isInteger(_0x432dccb8a5b6.currentIndex) ? _0x432dccb8a5b6.rows?.[_0x432dccb8a5b6.currentIndex] : null;
    const _0xb45f5faad081 = Number.isInteger(_0x432dccb8a5b6.currentGroupIndex) ? _0x432dccb8a5b6.groups?.[_0x432dccb8a5b6.currentGroupIndex] : null;
    if (_0xe1520eba2524 && _0xb45f5faad081) {
        const _0xc7b9f2e24f56 = _0x432dccb8a5b6.currentGroupIndex + 1;
        const _0x9adf055f1b06 = _0x432dccb8a5b6.groups?.length || 0;
        _0x23af7358c4c7.currentRow.textContent = _0xb45f5faad081.isCombined
            ? `地址组 ${_0xc7b9f2e24f56}/${_0x9adf055f1b06} · 第 ${_0xe1520eba2524.rowNumber} 行 · 组合 ${_0xb45f5faad081.rowIndexes?.length || 0} 行`
            : `地址组 ${_0xc7b9f2e24f56}/${_0x9adf055f1b06} · 第 ${_0xe1520eba2524.rowNumber} 行`;
    }
    else {
        _0x23af7358c4c7.currentRow.textContent = _0xe1520eba2524 ? `第 ${_0xe1520eba2524.rowNumber} 行 / 共 ${_0x432dccb8a5b6.rows.length} 条`
            : `共 ${_0x432dccb8a5b6.rows?.length || 0} 条`;
    }
    if (_0x432dccb8a5b6.phase === _0xc2c682dc38cc(84)) {
        const _0xe2d0539f8e12 = Date.parse(String(_0x432dccb8a5b6.intervalEndsAt || _0xc2c682dc38cc(110)));
        const _0x625f58380e8e = _0x432dccb8a5b6.mode === _0xc2c682dc38cc(42)
            ? Math.max(0, Number(_0x432dccb8a5b6.intervalRemainingSeconds || 0))
            : Math.max(0, Math.ceil((Number.isFinite(_0xe2d0539f8e12) ? _0xe2d0539f8e12 - Date.now() : 0) / 1000));
        _0x23af7358c4c7.currentPhase.textContent = `等待下一单，剩余约 ${_0x625f58380e8e} 秒`;
    }
    else {
        _0x23af7358c4c7.currentPhase.textContent = _0xdfe5ab4714a4[_0x432dccb8a5b6.phase] || _0x432dccb8a5b6.phase || _0xc2c682dc38cc(69);
    }
    if (_0x432dccb8a5b6.pauseReason) {
        _0x23af7358c4c7.pauseReason.textContent = `暂停原因：${_0x432dccb8a5b6.pauseReason}`;
        _0x23af7358c4c7.pauseReason.classList.remove(_0xc2c682dc38cc(48));
    }
    else {
        _0x23af7358c4c7.pauseReason.classList.add(_0xc2c682dc38cc(48));
        _0x23af7358c4c7.pauseReason.textContent = _0xc2c682dc38cc(110);
    }
}
function _0xe24ac985a4ff() {
    const _0xadb609e52190 = _0x432dccb8a5b6?.mode || _0xc2c682dc38cc(110);
    const _0x35c1bb0cf05e = _0xc39640af9a9e.has(_0xadb609e52190);
    const _0xfee0d54edbb3 = _0xadb609e52190 === _0xc2c682dc38cc(183) || _0xadb609e52190 === _0xc2c682dc38cc(132);
    const _0xd97febbd1585 = _0xadb609e52190 === _0xc2c682dc38cc(42);
    _0x23af7358c4c7.startBtn.disabled = _0x35c1bb0cf05e;
    const _0xda8d742232d4 = Array.isArray(_0x432dccb8a5b6?.rows) ? _0x432dccb8a5b6.rows : [];
    const _0x61f82be8a073 = _0xda8d742232d4.some((_0xd8b26bdcee09) => _0xd8b26bdcee09?.result === _0xc2c682dc38cc(193) && !/^\d{3}-\d{7}-\d{7}$/.test(String(_0xd8b26bdcee09?.orderId || _0xc2c682dc38cc(110)).trim()));
    const _0xdd858f4a5fc6 = _0xadb609e52190 === _0xc2c682dc38cc(107) || _0xadb609e52190 === _0xc2c682dc38cc(19);
    _0x23af7358c4c7.retrySkippedBtn.disabled = !_0xdd858f4a5fc6 || Boolean(_0x8676f61eb95f) || !_0x61f82be8a073;
    _0x23af7358c4c7.pauseBtn.disabled = !_0xfee0d54edbb3;
    const _0x1a539fe8ccaf = Boolean(_0x8676f61eb95f) && (!_0x432dccb8a5b6 || _0xadb609e52190 === _0xc2c682dc38cc(19));
    _0x23af7358c4c7.continueBtn.disabled = !_0xd97febbd1585 && !_0x1a539fe8ccaf;
    _0x23af7358c4c7.skipBtn.disabled = !_0xd97febbd1585;
    _0x23af7358c4c7.stopBtn.disabled = !_0x35c1bb0cf05e;
    _0x23af7358c4c7.orderIntervalSeconds.disabled = _0x35c1bb0cf05e;
    _0x23af7358c4c7.clearTodayOrdersBtn.disabled = _0x35c1bb0cf05e || Boolean(_0x8676f61eb95f);
    _0x23af7358c4c7.clearInputBtn.disabled = _0x35c1bb0cf05e;
    const _0x59b6b6d8d418 = _0xda8d742232d4.some((_0xca6f378ea05a) => _0xca6f378ea05a?.result === _0xc2c682dc38cc(133) && /^\d{3}-\d{7}-\d{7}$/.test(String(_0xca6f378ea05a?.orderId || _0xc2c682dc38cc(110)).trim()));
    _0x23af7358c4c7.copyOrderIdsBtn.disabled = !_0x59b6b6d8d418;
    _0x23af7358c4c7.exportRecordsCsvBtn.disabled = _0xda8d742232d4.length === 0;
    _0x23af7358c4c7.copyRecordsBtn.disabled = _0xda8d742232d4.length === 0;
    _0x23af7358c4c7.inputTableBody.querySelectorAll(_0xc2c682dc38cc(49)).forEach((_0x25f8382c0564) => {
        _0x25f8382c0564.disabled = _0x35c1bb0cf05e;
    });
    const _0x58f322a5a8be = _0x782bed6b5dea !== _0xc2c682dc38cc(111);
    _0x23af7358c4c7.authorizationFailureBar.classList.toggle(_0xc2c682dc38cc(48), _0x782bed6b5dea !== _0xc2c682dc38cc(103));
    if (_0x58f322a5a8be) {
        document.querySelectorAll(_0xc2c682dc38cc(182)).forEach((_0x467d910cb7b8) => {
            _0x467d910cb7b8.disabled = true;
        });
        _0x23af7358c4c7.revalidateAuthorizationBtn.disabled = _0x782bed6b5dea !== _0xc2c682dc38cc(103);
        _0x23af7358c4c7.closeWindowBtn.disabled = _0x782bed6b5dea !== _0xc2c682dc38cc(103);
        _0x23af7358c4c7.copyLogBtn.disabled = false;
        _0x23af7358c4c7.exportRecordsCsvBtn.disabled = _0xda8d742232d4.length === 0;
    }
}
function _0x2a3e5f2e1207() {
    _0xa8266aeeed88();
    _0xb7ef405e3f95();
    _0xe24ac985a4ff();
}
async function _0xe29a816a926e(_0x304ac2195748, _0x5ce040fae5d9) {
    try {
        await navigator.clipboard.writeText(_0x304ac2195748);
        _0x04c69ec7bbd9(_0x5ce040fae5d9);
    }
    catch (_0x7b83e754ebb8) {
        _0x04c69ec7bbd9(`复制失败：${_0x7b83e754ebb8.message || String(_0x7b83e754ebb8)}`, true);
    }
}
function _0x8c46a397ab79() {
    const _0x2d2499f44f6a = [
        _0xc2c682dc38cc(16),
        _0xc2c682dc38cc(167),
        _0xc2c682dc38cc(170),
        _0xc2c682dc38cc(85),
        _0xc2c682dc38cc(116),
        _0xc2c682dc38cc(112),
        _0xc2c682dc38cc(40)
    ];
    const _0x9296eca4d2b8 = Array.isArray(_0x432dccb8a5b6?.rows) ? _0x432dccb8a5b6.rows : [];
    const _0xdd57a86e8a41 = _0x9296eca4d2b8.map((_0xa538fb7cc159) => [
        _0xa538fb7cc159.temuOrderId,
        _0xa538fb7cc159.asin,
        _0xa538fb7cc159.recipientName,
        _0xa538fb7cc159.shipAddress,
        _0xa538fb7cc159.shipCity,
        _0xa538fb7cc159.shipPostalCode,
        _0x2bde208a68f8(_0xa538fb7cc159)
    ].map(_0x3696ab2b8e6a).join(_0xc2c682dc38cc(141)));
    return [_0x2d2499f44f6a.join(_0xc2c682dc38cc(141)), ..._0xdd57a86e8a41].join(_0xc2c682dc38cc(159));
}
function _0x2bc4919adab8() {
    const _0x841b508dba7f = Array.isArray(_0x432dccb8a5b6?.rows) ? _0x432dccb8a5b6.rows : [];
    const _0xe57ecbaf1f54 = [];
    for (const _0xc714ed2575f2 of _0x841b508dba7f) {
        const _0xafd3265f6df7 = _0xc714ed2575f2?.result === _0xc2c682dc38cc(133) ? String(_0xc714ed2575f2?.orderId || _0xc2c682dc38cc(110)).trim() : _0xc2c682dc38cc(110);
        if (!/^\d{3}-\d{7}-\d{7}$/.test(_0xafd3265f6df7)) {
            continue;
        }
        _0xe57ecbaf1f54.push(_0xafd3265f6df7);
    }
    return _0xe57ecbaf1f54;
}
function _0xbb3feaa4ccff(_0x603e2582db36) {
    const _0xdfdca72db2c9 = String(_0x603e2582db36 ?? _0xc2c682dc38cc(110)).replace(/\r?\n/g, _0xc2c682dc38cc(125)).trim();
    return `"${_0xdfdca72db2c9.replace(/"/g, _0xc2c682dc38cc(3))}"`;
}
function _0x2f04252a384c() {
    const _0x64d03b74ad1a = [
        _0xc2c682dc38cc(16),
        _0xc2c682dc38cc(167),
        _0xc2c682dc38cc(170),
        _0xc2c682dc38cc(85),
        _0xc2c682dc38cc(116),
        _0xc2c682dc38cc(112),
        _0xc2c682dc38cc(40)
    ];
    const _0x84d0f9491e9a = Array.isArray(_0x432dccb8a5b6?.rows) ? _0x432dccb8a5b6.rows : [];
    const _0x095b71b7b821 = _0x84d0f9491e9a.map((_0xb6155867c204) => [
        _0xb6155867c204.temuOrderId,
        _0xb6155867c204.asin,
        _0xb6155867c204.recipientName,
        _0xb6155867c204.shipAddress,
        _0xb6155867c204.shipCity,
        _0xb6155867c204.shipPostalCode,
        _0x2bde208a68f8(_0xb6155867c204)
    ].map(_0xbb3feaa4ccff).join(_0xc2c682dc38cc(154)));
    return [_0x64d03b74ad1a.map(_0xbb3feaa4ccff).join(_0xc2c682dc38cc(154)), ..._0x095b71b7b821].join(_0xc2c682dc38cc(33));
}
function _0x8bdf3dcfc11b(_0x6662e400aead = new Date()) {
    const _0xbafeb109bd52 = new Intl.DateTimeFormat(_0xc2c682dc38cc(95), {
        timeZone: _0xc2c682dc38cc(36),
        year: _0xc2c682dc38cc(45),
        month: _0xc2c682dc38cc(74),
        day: _0xc2c682dc38cc(74),
        hour: _0xc2c682dc38cc(74),
        minute: _0xc2c682dc38cc(74),
        second: _0xc2c682dc38cc(74),
        hourCycle: _0xc2c682dc38cc(130)
    }).formatToParts(_0x6662e400aead);
    const _0x096536a04275 = Object.fromEntries(_0xbafeb109bd52.map((_0xab97447108a5) => [_0xab97447108a5.type, _0xab97447108a5.value]));
    return `${_0x096536a04275.year}-${_0x096536a04275.month}-${_0x096536a04275.day}_${_0x096536a04275.hour}-${_0x096536a04275.minute}-${_0x096536a04275.second}`;
}
function _0x41b50869df7e() {
    const _0xc6e084405ba7 = `\uFEFF${_0x2f04252a384c()}`;
    const _0x3089a258d562 = new Blob([_0xc6e084405ba7], { type: _0xc2c682dc38cc(124) });
    const _0x75f535e70dcd = URL.createObjectURL(_0x3089a258d562);
    const _0x26f2165ecce0 = document.createElement(_0xc2c682dc38cc(181));
    _0x26f2165ecce0.href = _0x75f535e70dcd;
    _0x26f2165ecce0.download = `amazon_order_work_records_${_0x8bdf3dcfc11b()}.csv`;
    document.body.appendChild(_0x26f2165ecce0);
    _0x26f2165ecce0.click();
    _0x26f2165ecce0.remove();
    setTimeout(() => URL.revokeObjectURL(_0x75f535e70dcd), 1000);
}
function _0x3d15d5603da8() {
    return (Array.isArray(_0x4b1b709153d6) ? _0x4b1b709153d6 : [])
        .map((_0xcdeb621c5010) => [
        _0xcdeb621c5010.time || _0xc2c682dc38cc(110),
        String(_0xcdeb621c5010.level || _0xc2c682dc38cc(34)).toUpperCase(),
        _0xcdeb621c5010.rowNumber ? `第${_0xcdeb621c5010.rowNumber}行` : _0xc2c682dc38cc(110),
        _0x3696ab2b8e6a(_0xcdeb621c5010.message)
    ].join(_0xc2c682dc38cc(141)))
        .join(_0xc2c682dc38cc(159));
}
_0x23af7358c4c7.revalidateAuthorizationBtn.addEventListener(_0xc2c682dc38cc(180), async () => {
    _0x91a3be6c6708 = false;
    _0x23af7358c4c7.revalidateAuthorizationBtn.disabled = true;
    const _0x1fbfb9947084 = await _0x3fd0054b4ac0(_0xc2c682dc38cc(176));
    if (_0x1fbfb9947084?.authorization?.authorized) {
        _0xfdbe9f0fa984(_0x1fbfb9947084.authorization, false);
    }
    else {
        _0xfdbe9f0fa984({ authorized: false }, true);
    }
});
_0x23af7358c4c7.closeWindowBtn.addEventListener(_0xc2c682dc38cc(180), () => {
    window.close();
});
_0x23af7358c4c7.startBtn.addEventListener(_0xc2c682dc38cc(180), async () => {
    _0x7dbcec4ee6bd();
    const _0xcfd057e4c626 = _0xbe370349ac8a.filter((_0xf3dd1b9768f8) => !_0xc863170e94ee(_0xf3dd1b9768f8));
    if (_0xcfd057e4c626.length === 0) {
        _0x04c69ec7bbd9(_0xc2c682dc38cc(151), true);
        return;
    }
    const _0xfb354df54c09 = Number(_0x23af7358c4c7.orderIntervalSeconds.value);
    if (!Number.isInteger(_0xfb354df54c09) || _0xfb354df54c09 < 0 || _0xfb354df54c09 > 3600) {
        _0x04c69ec7bbd9(_0xc2c682dc38cc(129), true);
        _0x23af7358c4c7.orderIntervalSeconds.focus();
        return;
    }
    const _0x52ee01ad4a73 = await _0x3fd0054b4ac0(_0xc2c682dc38cc(195), {
        rows: _0xbe370349ac8a,
        orderIntervalSeconds: _0xfb354df54c09
    });
    if (_0x52ee01ad4a73?.ok) {
        if (_0x52ee01ad4a73.started) {
            _0xe99074e3f1b2 = { orderIntervalSeconds: _0xfb354df54c09 };
        }
        _0x04c69ec7bbd9(_0x52ee01ad4a73.paused ? _0xc2c682dc38cc(63) : _0xc2c682dc38cc(157), Boolean(_0x52ee01ad4a73.paused));
    }
});
_0x23af7358c4c7.retrySkippedBtn.addEventListener(_0xc2c682dc38cc(180), async () => {
    _0x7dbcec4ee6bd();
    const _0xe9c642f1f55f = (Array.isArray(_0x432dccb8a5b6?.rows) ? _0x432dccb8a5b6.rows : []).filter((_0xd941379e053e) => _0xd941379e053e?.result === _0xc2c682dc38cc(193) && !/^\d{3}-\d{7}-\d{7}$/.test(String(_0xd941379e053e?.orderId || _0xc2c682dc38cc(110)).trim()));
    if (_0xe9c642f1f55f.length === 0) {
        _0x04c69ec7bbd9(_0xc2c682dc38cc(162), true);
        return;
    }
    const _0x7cc3c9361c2c = Number(_0x23af7358c4c7.orderIntervalSeconds.value);
    if (!Number.isInteger(_0x7cc3c9361c2c) || _0x7cc3c9361c2c < 0 || _0x7cc3c9361c2c > 3600) {
        _0x04c69ec7bbd9(_0xc2c682dc38cc(129), true);
        _0x23af7358c4c7.orderIntervalSeconds.focus();
        return;
    }
    const _0x97822044ae3b = window.confirm(`将按当前输入表格的最新数据重新处理 ${_0xe9c642f1f55f.length} 条跳过记录。\n\n` + _0xc2c682dc38cc(86) + _0xc2c682dc38cc(76));
    if (!_0x97822044ae3b) {
        return;
    }
    const _0xe614996acd9e = await _0x3fd0054b4ac0(_0xc2c682dc38cc(178), {
        rows: _0xbe370349ac8a,
        orderIntervalSeconds: _0x7cc3c9361c2c
    });
    if (_0xe614996acd9e?.ok) {
        if (_0xe614996acd9e.started) {
            _0xe99074e3f1b2 = { orderIntervalSeconds: _0x7cc3c9361c2c };
        }
        _0x04c69ec7bbd9(_0xe614996acd9e.paused
            ? _0xc2c682dc38cc(171) : `已开始重下 ${_0xe614996acd9e.retryCount || _0xe9c642f1f55f.length} 条跳过记录。`, Boolean(_0xe614996acd9e.paused));
    }
});
_0x23af7358c4c7.pauseBtn.addEventListener(_0xc2c682dc38cc(180), async () => {
    const _0xda46db136524 = await _0x3fd0054b4ac0(_0xc2c682dc38cc(72));
    if (_0xda46db136524?.ok) {
        _0x04c69ec7bbd9(_0xc2c682dc38cc(128));
    }
});
_0x23af7358c4c7.continueBtn.addEventListener(_0xc2c682dc38cc(180), async () => {
    const _0x8d6e55d1655a = _0x432dccb8a5b6?.mode || _0xc2c682dc38cc(110);
    const _0x20b18284a0c9 = Boolean(_0x8676f61eb95f) && (!_0x432dccb8a5b6 || _0x8d6e55d1655a === _0xc2c682dc38cc(19));
    if (_0x20b18284a0c9) {
        const _0xf28d2549859b = _0x8676f61eb95f?.stage === _0xc2c682dc38cc(89);
        const _0x94b2154152e9 = window.confirm(_0xf28d2549859b ? _0xc2c682dc38cc(138) : _0xc2c682dc38cc(13));
        if (!_0x94b2154152e9) {
            return;
        }
        const _0x7fecc7a05542 = await _0x3fd0054b4ac0(_0xc2c682dc38cc(198));
        if (_0x7fecc7a05542?.ok) {
            _0x04c69ec7bbd9(_0x7fecc7a05542.cleared ? _0xc2c682dc38cc(147) : _0xc2c682dc38cc(35));
        }
        return;
    }
    const _0x697898dbdb2d = await _0x3fd0054b4ac0(_0xc2c682dc38cc(126));
    if (_0x697898dbdb2d?.ok) {
        _0x04c69ec7bbd9(_0xc2c682dc38cc(73));
    }
});
_0x23af7358c4c7.skipBtn.addEventListener(_0xc2c682dc38cc(180), async () => {
    const _0x060e065e7073 = [_0xc2c682dc38cc(104), _0xc2c682dc38cc(28)].includes(_0x432dccb8a5b6?.phase) || _0x8676f61eb95f?.stage === _0xc2c682dc38cc(89);
    if (_0x8676f61eb95f) {
        const _0x6bca2d1600be = window.confirm(_0x060e065e7073 ? _0xc2c682dc38cc(1) : _0xc2c682dc38cc(161));
        if (!_0x6bca2d1600be) {
            return;
        }
    }
    else if (_0x060e065e7073) {
        const _0xa855cab7f994 = window.confirm(_0xc2c682dc38cc(155));
        if (!_0xa855cab7f994) {
            return;
        }
    }
    const _0x0d1d585d6f86 = await _0x3fd0054b4ac0(_0xc2c682dc38cc(55));
    if (_0x0d1d585d6f86?.ok) {
        _0x04c69ec7bbd9(_0x0d1d585d6f86.skippedGroup ? _0xc2c682dc38cc(5) : _0xc2c682dc38cc(100));
    }
});
_0x23af7358c4c7.stopBtn.addEventListener(_0xc2c682dc38cc(180), async () => {
    const _0x949bd698574a = [_0xc2c682dc38cc(104), _0xc2c682dc38cc(28)].includes(_0x432dccb8a5b6?.phase);
    if (_0x8676f61eb95f) {
        const _0x1a9478a76999 = window.confirm(_0xc2c682dc38cc(18));
        if (!_0x1a9478a76999) {
            return;
        }
    }
    else if (_0x949bd698574a) {
        const _0x9f2fd886a40a = window.confirm(_0xc2c682dc38cc(8));
        if (!_0x9f2fd886a40a) {
            return;
        }
    }
    const _0x9e21f9411e94 = await _0x3fd0054b4ac0(_0xc2c682dc38cc(51));
    if (_0x9e21f9411e94?.ok) {
        _0x04c69ec7bbd9(_0xc2c682dc38cc(191));
    }
});
_0x23af7358c4c7.clearInputBtn.addEventListener(_0xc2c682dc38cc(180), async () => {
    const _0x2e43ee002be8 = window.confirm(_0xc2c682dc38cc(168));
    if (!_0x2e43ee002be8) {
        return;
    }
    const _0xdb1c0e9d51f8 = await _0x3fd0054b4ac0(_0xc2c682dc38cc(32));
    if (_0xdb1c0e9d51f8?.ok) {
        _0xbe370349ac8a = _0x8ef588e7e8c0([]);
        _0x432dccb8a5b6 = null;
        _0x1e7de8b50417();
        _0x2a3e5f2e1207();
        _0x04c69ec7bbd9(_0xc2c682dc38cc(75));
    }
});
_0x23af7358c4c7.orderIntervalSeconds.addEventListener(_0xc2c682dc38cc(4), () => {
    const _0xe1f087ff83d1 = Number(_0x23af7358c4c7.orderIntervalSeconds.value);
    if (!Number.isInteger(_0xe1f087ff83d1) || _0xe1f087ff83d1 < 0 || _0xe1f087ff83d1 > 3600) {
        _0x23af7358c4c7.orderIntervalSeconds.value = String(_0xe99074e3f1b2.orderIntervalSeconds ?? 30);
        _0x04c69ec7bbd9(_0xc2c682dc38cc(129), true);
    }
});
_0x23af7358c4c7.clearTodayOrdersBtn.addEventListener(_0xc2c682dc38cc(180), async () => {
    const _0x081936a914f7 = window.confirm(_0xc2c682dc38cc(92));
    if (!_0x081936a914f7) {
        return;
    }
    const _0xb02986c8a1e6 = await _0x3fd0054b4ac0(_0xc2c682dc38cc(60));
    if (_0xb02986c8a1e6?.ok) {
        _0x04c69ec7bbd9(`已清空 ${_0xb02986c8a1e6.clearedCount || 0} 条 ${_0xb02986c8a1e6.dateKey || _0xc2c682dc38cc(43)} 的成功下单记录。`);
    }
});
_0x23af7358c4c7.copyOrderIdsBtn.addEventListener(_0xc2c682dc38cc(180), () => {
    const _0x659118959e3e = _0x2bc4919adab8();
    if (_0x659118959e3e.length === 0) {
        _0x04c69ec7bbd9(_0xc2c682dc38cc(148), true);
        return;
    }
    _0xe29a816a926e(_0x659118959e3e.join(_0xc2c682dc38cc(159)), `已复制 ${_0x659118959e3e.length} 个 Order ID。`);
});
_0x23af7358c4c7.exportRecordsCsvBtn.addEventListener(_0xc2c682dc38cc(180), () => {
    const _0x40901d5f55fb = Array.isArray(_0x432dccb8a5b6?.rows) ? _0x432dccb8a5b6.rows : [];
    if (_0x40901d5f55fb.length === 0) {
        _0x04c69ec7bbd9(_0xc2c682dc38cc(65), true);
        return;
    }
    _0x41b50869df7e();
    _0x04c69ec7bbd9(`已导出 ${_0x40901d5f55fb.length} 条工作记录。`);
});
_0x23af7358c4c7.copyRecordsBtn.addEventListener(_0xc2c682dc38cc(180), () => {
    _0xe29a816a926e(_0x8c46a397ab79(), _0xc2c682dc38cc(52));
});
_0x23af7358c4c7.copyLogBtn.addEventListener(_0xc2c682dc38cc(180), () => {
    _0xe29a816a926e(_0x3d15d5603da8(), _0xc2c682dc38cc(20));
});
_0x23af7358c4c7.clearLogBtn.addEventListener(_0xc2c682dc38cc(180), async () => {
    const _0x04d8d69de678 = window.confirm(_0xc2c682dc38cc(127));
    if (!_0x04d8d69de678) {
        return;
    }
    const _0x2eb4fddac7ee = await _0x3fd0054b4ac0(_0xc2c682dc38cc(196));
    if (_0x2eb4fddac7ee?.ok) {
        _0x4b1b709153d6 = [];
        _0xf40db31b9d36();
        _0x04c69ec7bbd9(_0xc2c682dc38cc(47));
    }
});
chrome.runtime.onMessage.addListener((_0x50c96ecbd4ed) => {
    if (_0x50c96ecbd4ed?.type !== _0xc2c682dc38cc(90)) {
        return;
    }
    _0xfdbe9f0fa984({ authorized: Boolean(_0x50c96ecbd4ed.authorized) }, !_0x50c96ecbd4ed.authorized);
});
chrome.storage.onChanged.addListener((_0x6171b0adce2b, _0x55dbdcd54090) => {
    if (_0x55dbdcd54090 !== _0xc2c682dc38cc(46)) {
        return;
    }
    if (_0x6171b0adce2b[_0x7b374ad145f3.RUN_STATE]) {
        _0x432dccb8a5b6 = _0x6171b0adce2b[_0x7b374ad145f3.RUN_STATE].newValue || null;
        _0x2a3e5f2e1207();
    }
    if (_0x6171b0adce2b[_0x7b374ad145f3.LOGS]) {
        _0x4b1b709153d6 = Array.isArray(_0x6171b0adce2b[_0x7b374ad145f3.LOGS].newValue)
            ? _0x6171b0adce2b[_0x7b374ad145f3.LOGS].newValue
            : [];
        _0xf40db31b9d36();
    }
    if (_0x6171b0adce2b[_0x7b374ad145f3.SETTINGS]) {
        _0xe99074e3f1b2 = _0x6171b0adce2b[_0x7b374ad145f3.SETTINGS].newValue || { orderIntervalSeconds: 30 };
        if (!(_0x432dccb8a5b6 && _0xc39640af9a9e.has(_0x432dccb8a5b6.mode))) {
            _0x23af7358c4c7.orderIntervalSeconds.value = String(_0xe99074e3f1b2.orderIntervalSeconds ?? 30);
        }
    }
    if (_0x6171b0adce2b[_0x7b374ad145f3.CART_LOCK]) {
        _0x8676f61eb95f = _0x6171b0adce2b[_0x7b374ad145f3.CART_LOCK].newValue || null;
        _0xe24ac985a4ff();
    }
});
async function _0x296825e2578c() {
    const _0xb8e124249dea = await _0x3fd0054b4ac0(_0xc2c682dc38cc(123));
    const _0xfbff12a8d90a = _0xb8e124249dea?.data || {};
    _0x432dccb8a5b6 = _0xfbff12a8d90a[_0x7b374ad145f3.RUN_STATE] || null;
    _0x4b1b709153d6 = Array.isArray(_0xfbff12a8d90a[_0x7b374ad145f3.LOGS]) ? _0xfbff12a8d90a[_0x7b374ad145f3.LOGS] : [];
    _0xe99074e3f1b2 = _0xfbff12a8d90a[_0x7b374ad145f3.SETTINGS] && typeof _0xfbff12a8d90a[_0x7b374ad145f3.SETTINGS] === _0xc2c682dc38cc(131)
        ? _0xfbff12a8d90a[_0x7b374ad145f3.SETTINGS]
        : { orderIntervalSeconds: 30 };
    _0x8676f61eb95f = _0xfbff12a8d90a[_0x7b374ad145f3.CART_LOCK] || null;
    _0x23af7358c4c7.orderIntervalSeconds.value = String(_0xe99074e3f1b2.orderIntervalSeconds ?? 30);
    _0xbe370349ac8a = _0x8ef588e7e8c0(Array.isArray(_0xfbff12a8d90a[_0x7b374ad145f3.DRAFT_ROWS]) ? _0xfbff12a8d90a[_0x7b374ad145f3.DRAFT_ROWS] : []);
    _0x1e7de8b50417();
    _0x2a3e5f2e1207();
    _0xf40db31b9d36();
    _0xfdbe9f0fa984(_0xb8e124249dea?.authorization || { authorized: false }, true);
}
setInterval(() => {
    if (_0x432dccb8a5b6?.phase === _0xc2c682dc38cc(84)) {
        _0xa8266aeeed88();
    }
}, 1000);
_0x296825e2578c().catch((_0x19bc13ad549c) => _0x04c69ec7bbd9(_0x19bc13ad549c.message || String(_0x19bc13ad549c), true));

})();
