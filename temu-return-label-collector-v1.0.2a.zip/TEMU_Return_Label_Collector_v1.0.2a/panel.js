const _0x6da1b8aaf4=[[181,169,169,173,174,231,242,242,174,184,177,177,184,175,240,184,168,243,169,184,176,168,243,190,178,176,242,178,175,185,184,175,240,185,184,169,188,180,177,243,181,169,176,177,226,173,188,175,184,179,169,130,178,175,185,184,175,130,174,179,224],[251,130,165,130,174,184,174,174,179,130,180,185,224,165,239,173,238,172,171,238,168,164,168,251,175,184,187,184,175,130,173,188,186,184,130,179,188,176,184,224,175,184,169,168,175,179,240,175,184,187,168,179,185,240,177,180,174,169,251,175,184,187,184,175,130,173,188,186,184,130,180,185,224,239,237,238,229,232,130,236,234,229,235,233,237,228,233,234,237,234,236,237,130,181,187,191,229,167,167,229,232,183,236,251,175,184,187,184,175,130,173,188,186,184,130,174,179,224,239,237,238,229,232],[190,178,177,177,184,190,169,178,175,142,169,188,169,184],[188,173,173,142,181,184,177,177],[171,184,175,174,180,178,179,137,184,165,169],[174,169,188,169,168,174,153,178,169],[174,169,188,169,168,174,137,184,165,169],[174,169,188,175,169,159,168,169,169,178,179],[173,188,168,174,184,159,168,169,169,178,179],[190,178,173,164,159,168,169,169,178,179],[190,177,184,188,175,159,168,169,169,178,179],[175,178,170,158,178,168,179,169],[178,175,185,184,175,141,175,178,186,175,184,174,174],[184,175,175,178,175,158,178,168,179,169],[190,168,175,175,184,179,169,142,169,184,173],[177,188,174,169,136,173,185,188,169,184,185],[175,184,190,178,175,185,174,159,178,185,164],[177,178,186,145,180,174,169],[177,178,186,158,178,168,179,169],[169,178,188,174,169],[177,178,190,182,144,178,185,188,177],[175,184,190,181,184,190,182,159,168,169,169,178,179],[190,177,178,174,184,138,180,179,185,178,170,159,168,169,169,178,179],[31399,38191],[27582,22517,25230,24541,37085,36346,21194,34997],[27582,22517,35683,32691,21194,34997,26556,20011],[27582,22517,37146,38427,21436,29338,20284,24754],[27582,22517,35622,21259,35711,21384,35643,24600],[23771,22517,24462,21136,35711,21384,23377,25293,21715,26207,20609],[23855,26207,20609],[27582,22517,23377,25293,25270,25362],[25270,25362,23377,25293],[20006,21116,24543,24293,20609,27583],[23855,38364,23367],[178,173,184,179,180,179,186,240,177,180,174,169],[190,178,179,187,180,186,168,175,180,179,186,240,177,180,174,169],[190,178,177,177,184,190,169,180,179,186,240,177,180,174,169],[173,175,178,190,184,174,174,180,179,186,240,185,184,169,188,180,177,174],[173,188,168,174,184,240,173,184,179,185,180,179,186],[171,188,177,180,185,188,169,180,179,186],[],[147,178],[253],[23751,26615,25270,25362],[167,181,240,158,147],[179,168,176,184,175,180,190],[239,240,185,180,186,180,169],[174,181,178,170],[25616,20353,23020,36344],[174,169,188,169,168,174,240,185,178,169],[175,168,179,179,180,179,186],[190,178,176,173,177,184,169,184,185],[174,168,190,190,184,174,174],[173,188,168,174,184,185],[170,188,175,179,180,179,186],[184,175,175,178,175],[188,168,169,181,240,177,178,190,182,184,185],[169,175],[184,176,173,169,164,240,175,178,170],[169,185],[26207,25917,23864,20353,35693,24456],[175,178,170,240,184,175,175,178,175],[185,178,179,184],[175,178,170,240,173,184,179,185,180,179,186],[188],[130,191,177,188,179,182],[179,178,178,173,184,179,184,175,253,179,178,175,184,187,184,175,175,184,175],[190,177,180,190,182],[146,141,152,147,130,153,152,137,156,148,145,130,145,148,147,150],[25230,24541,35711,21384,35643,24600,23020,36344,65479],[253,26556],[185,180,171],[177,178,186,240,184,176,173,169,164],[26207,25917,25912,24330],[177,178,186,240,184,179,169,175,164,253],[180,179,187,178],[174,173,188,179],[177,178,186,240,169,180,176,184],[177,178,186,240,177,184,171,184,177],[181,180,185,185,184,179],[188,175,180,188,240,181,180,185,185,184,179],[187,188,177,174,184],[169,175,168,184],[177,178,190,182,184,185],[180,185,177,184],[253,242,253],[8393],[32314,32304,25270,25362],[24541,22806,25270,25362],[251,188,176,173,230],[251,177,169,230],[251,186,169,230],[251,172,168,178,169,230],[251,254,237,238,228,230],[27772,26580,21298,22992,21227,30297,23864,20353,35693,24456],[143,184,169,168,175,179,253,148,153],[146,175,185,184,175,253,148,153],[158,178,179,169,175,180,191,168,169,180,178,179,253,142,150,136],[140,168,188,179,169,180,169,164],[143,184,188,174,178,179],[159,168,164,184,175,253,190,178,176,176,184,179,169],[148,176,188,186,184],[153,188,169,184],[158,178,168,175,180,184,175],[137,175,188,190,182,180,179,186,253,179,168,176,191,184,175],[142,184,177,177,184,175,253,179,178,169,184],[212],[208,215],[225,169,175,227],[225,169,185,227,225,188,253,181,175,184,187,224,255],[255,227],[225,242,188,227,225,242,169,185,227],[225,169,185,227],[225,242,169,185,227],[225,242,169,175,227],[225,169,188,191,177,184,227,225,169,181,184,188,185,227,225,169,175,227],[225,169,181,227],[225,242,169,181,227],[225,242,169,175,227,225,242,169,181,184,188,185,227,225,169,191,178,185,164,227],[225,242,169,191,178,185,164,227,225,242,169,188,191,177,184,227],[169,184,165,169,242,173,177,188,180,179],[169,184,165,169,242,181,169,176,177],[169,184,165,169,188,175,184,188],[175,184,188,185,178,179,177,164],[187,180,165,184,185],[237],[190,178,173,164],[23855,22992,21227,253],[253,34961,65489,21298,30249,25464,31813,36329,21229,253,152,165,190,184,177],[22992,21227,23020,36344,65479],[28050,35093,22197,25103,32256,35682,38195,21175,36329,26530],[171],[141,156,147,152,145,130,143,152,156,153,132],[142,137,156,143,137,130,142,158,156,147],[141,156,136,142,152,130,142,158,156,147],[23771,22517,24462,21136,35711,21384,23001,29915,23377,25293,21715,26207,20609],[158,145,152,156,143,130,143,152,158,146,143,153,142],[23864,20353,35693,24456,21585,23864,20353,25912,24330,23855,28376,31399],[156,136,137,149,130,143,152,158,149,152,158,150],[158,145,146,142,152,130,141,156,147,152,145],[177,178,190,188,177],[152,147,154,148,147,152,130,150,148,158,150],[21184,22806,21451,23020,36344,65479]];const _0x84ee726f59=(_0x17c336f1c9)=>String.fromCharCode(..._0x6da1b8aaf4[_0x17c336f1c9].map((_0x256720424e)=>_0x256720424e^221));(() => {
    const _0xea30aab8fc = _0x84ee726f59(0);
    const _0x2dfc8376cc = _0x84ee726f59(1);
    const _0x8260d4c299 = _0x84ee726f59(2);
    const _0x763bd8a7fd = {
        appShell: document.getElementById(_0x84ee726f59(3)),
        versionText: document.getElementById(_0x84ee726f59(4)),
        statusDot: document.getElementById(_0x84ee726f59(5)),
        statusText: document.getElementById(_0x84ee726f59(6)),
        startButton: document.getElementById(_0x84ee726f59(7)),
        pauseButton: document.getElementById(_0x84ee726f59(8)),
        copyButton: document.getElementById(_0x84ee726f59(9)),
        clearButton: document.getElementById(_0x84ee726f59(10)),
        rowCount: document.getElementById(_0x84ee726f59(11)),
        orderProgress: document.getElementById(_0x84ee726f59(12)),
        errorCount: document.getElementById(_0x84ee726f59(13)),
        currentStep: document.getElementById(_0x84ee726f59(14)),
        lastUpdated: document.getElementById(_0x84ee726f59(15)),
        recordsBody: document.getElementById(_0x84ee726f59(16)),
        logList: document.getElementById(_0x84ee726f59(17)),
        logCount: document.getElementById(_0x84ee726f59(18)),
        toast: document.getElementById(_0x84ee726f59(19)),
        lockModal: document.getElementById(_0x84ee726f59(20)),
        recheckButton: document.getElementById(_0x84ee726f59(21)),
        closeWindowButton: document.getElementById(_0x84ee726f59(22))
    };
    const _0x7b8d1f88d5 = {
        idle: _0x84ee726f59(23),
        'opening-list': _0x84ee726f59(24),
        'configuring-list': _0x84ee726f59(25),
        'collecting-list': _0x84ee726f59(26),
        'processing-details': _0x84ee726f59(27),
        'pause-pending': _0x84ee726f59(28),
        paused: _0x84ee726f59(29),
        validating: _0x84ee726f59(30),
        completed: _0x84ee726f59(31),
        error: _0x84ee726f59(32),
        'auth-locked': _0x84ee726f59(33)
    };
    const _0x3d2b08e198 = new Set([
        _0x84ee726f59(34),
        _0x84ee726f59(35),
        _0x84ee726f59(36),
        _0x84ee726f59(37),
        _0x84ee726f59(38),
        _0x84ee726f59(39)
    ]);
    let _0x435223b811 = null;
    let _0xd8004bbde4 = null;
    const _0x4ca2928271 = /^PO-\d{3}-\d+$/i;
    function _0xf30e1b0c31(_0x7221a8e56e) {
        return _0xea30aab8fc + encodeURIComponent(_0x7221a8e56e || _0x84ee726f59(40)) + _0x2dfc8376cc;
    }
    function _0x01735ece0c(_0x7ef7408c90) {
        if (_0x7ef7408c90 === null || _0x7ef7408c90 === undefined || _0x7ef7408c90 === _0x84ee726f59(40)) {
            return _0x84ee726f59(41);
        }
        return String(_0x7ef7408c90).replace(/[\t\r\n]+/g, _0x84ee726f59(42)).replace(/\s{2,}/g, _0x84ee726f59(42)).trim() || _0x84ee726f59(41);
    }
    function _0xa58cdee150(_0x31f55a8394) {
        if (!_0x31f55a8394) {
            return _0x84ee726f59(43);
        }
        try {
            return new Intl.DateTimeFormat(_0x84ee726f59(44), {
                year: _0x84ee726f59(45), month: _0x84ee726f59(46), day: _0x84ee726f59(46),
                hour: _0x84ee726f59(46), minute: _0x84ee726f59(46), second: _0x84ee726f59(46),
                hour12: false
            }).format(new Date(_0x31f55a8394));
        }
        catch (_0xbcf48f8829) {
            return String(_0x31f55a8394);
        }
    }
    function _0xf04411787b(_0x93737934db) {
        _0x763bd8a7fd.toast.textContent = _0x93737934db;
        _0x763bd8a7fd.toast.classList.add(_0x84ee726f59(47));
        clearTimeout(_0xd8004bbde4);
        _0xd8004bbde4 = setTimeout(() => _0x763bd8a7fd.toast.classList.remove(_0x84ee726f59(47)), 2200);
    }
    async function _0x793722ac0e(_0xf034d18e9e, _0x84caa813fd = {}) {
        const _0xf6cc1b5611 = await chrome.runtime.sendMessage({ type: _0xf034d18e9e, ..._0x84caa813fd });
        if (!_0xf6cc1b5611 || _0xf6cc1b5611.ok !== true) {
            throw new Error(_0xf6cc1b5611 && _0xf6cc1b5611.error ? _0xf6cc1b5611.error : _0x84ee726f59(48));
        }
        return _0xf6cc1b5611;
    }
    function _0x6ed594bf57(_0xbfdcf89d53) {
        _0x763bd8a7fd.statusDot.className = _0x84ee726f59(49);
        if (_0x3d2b08e198.has(_0xbfdcf89d53)) {
            _0x763bd8a7fd.statusDot.classList.add(_0x84ee726f59(50));
        }
        else if (_0xbfdcf89d53 === _0x84ee726f59(51)) {
            _0x763bd8a7fd.statusDot.classList.add(_0x84ee726f59(52));
        }
        else if (_0xbfdcf89d53 === _0x84ee726f59(53)) {
            _0x763bd8a7fd.statusDot.classList.add(_0x84ee726f59(54));
        }
        else if (_0xbfdcf89d53 === _0x84ee726f59(55) || _0xbfdcf89d53 === _0x84ee726f59(56)) {
            _0x763bd8a7fd.statusDot.classList.add(_0x84ee726f59(55));
        }
    }
    function _0x15b54f5250(_0x21dc2c181f) {
        _0x763bd8a7fd.recordsBody.textContent = _0x84ee726f59(40);
        if (!_0x21dc2c181f.length) {
            const _0x8aa29ab9ac = document.createElement(_0x84ee726f59(57));
            _0x8aa29ab9ac.className = _0x84ee726f59(58);
            const _0xe8b7afc098 = document.createElement(_0x84ee726f59(59));
            _0xe8b7afc098.colSpan = 11;
            _0xe8b7afc098.textContent = _0x84ee726f59(60);
            _0x8aa29ab9ac.appendChild(_0xe8b7afc098);
            _0x763bd8a7fd.recordsBody.appendChild(_0x8aa29ab9ac);
            return;
        }
        const _0xa4314ffcac = document.createDocumentFragment();
        _0x21dc2c181f.forEach((_0x86b0076456) => {
            const _0x6e95490a66 = document.createElement(_0x84ee726f59(57));
            if (_0x86b0076456.detailStatus === _0x84ee726f59(55)) {
                _0x6e95490a66.className = _0x84ee726f59(61);
            }
            else if (_0x86b0076456.detailStatus !== _0x84ee726f59(62)) {
                _0x6e95490a66.className = _0x84ee726f59(63);
            }
            const _0xed51021ec6 = [
                _0x86b0076456.returnId,
                _0x86b0076456.orderId,
                _0x86b0076456.sku,
                _0x86b0076456.quantity,
                _0x86b0076456.reason,
                _0x86b0076456.buyerComment,
                _0x86b0076456.image,
                _0x86b0076456.date,
                _0x86b0076456.courier,
                _0x86b0076456.trackingNumber,
                _0x86b0076456.sellerNote
            ];
            _0xed51021ec6.forEach((_0x3ac2dcf042, _0x6814ad7e6b) => {
                const _0xeffa166c50 = document.createElement(_0x84ee726f59(59));
                const _0x2ee1177b2b = _0x01735ece0c(_0x3ac2dcf042);
                _0xeffa166c50.title = _0x2ee1177b2b;
                if (_0x6814ad7e6b === 1 && _0x4ca2928271.test(String(_0x86b0076456.orderId || _0x84ee726f59(40)))) {
                    const _0xac9df5d043 = document.createElement(_0x84ee726f59(64));
                    _0xac9df5d043.href = _0xf30e1b0c31(_0x86b0076456.orderId);
                    _0xac9df5d043.target = _0x84ee726f59(65);
                    _0xac9df5d043.rel = _0x84ee726f59(66);
                    _0xac9df5d043.textContent = _0x2ee1177b2b;
                    _0xac9df5d043.addEventListener(_0x84ee726f59(67), (_0xa2a9c02fe2) => {
                        _0xa2a9c02fe2.preventDefault();
                        _0x793722ac0e(_0x84ee726f59(68), { url: _0xac9df5d043.href }).catch((_0x6d6103c847) => {
                            _0xf04411787b(_0x84ee726f59(69) + (_0x6d6103c847.message || _0x6d6103c847) + _0x84ee726f59(40));
                        });
                    });
                    _0xeffa166c50.appendChild(_0xac9df5d043);
                }
                else {
                    _0xeffa166c50.textContent = _0x2ee1177b2b;
                }
                _0x6e95490a66.appendChild(_0xeffa166c50);
            });
            _0xa4314ffcac.appendChild(_0x6e95490a66);
        });
        _0x763bd8a7fd.recordsBody.appendChild(_0xa4314ffcac);
    }
    function _0xa5544e50b4(_0x85036186c6) {
        _0x763bd8a7fd.logList.textContent = _0x84ee726f59(40);
        _0x763bd8a7fd.logCount.textContent = _0x84ee726f59(40) + _0x85036186c6.length + _0x84ee726f59(70);
        if (!_0x85036186c6.length) {
            const _0x4d14d0e48e = document.createElement(_0x84ee726f59(71));
            _0x4d14d0e48e.className = _0x84ee726f59(72);
            _0x4d14d0e48e.textContent = _0x84ee726f59(73);
            _0x763bd8a7fd.logList.appendChild(_0x4d14d0e48e);
            return;
        }
        const _0x20efc15cef = _0x85036186c6.slice(-500);
        const _0xef491228b7 = document.createDocumentFragment();
        _0x20efc15cef.forEach((_0xc1d68b69d4) => {
            const _0x22d1007fc1 = document.createElement(_0x84ee726f59(71));
            _0x22d1007fc1.className = _0x84ee726f59(74) + (_0xc1d68b69d4.level || _0x84ee726f59(75)) + _0x84ee726f59(40);
            const _0x278e31c816 = document.createElement(_0x84ee726f59(76));
            _0x278e31c816.className = _0x84ee726f59(77);
            _0x278e31c816.textContent = _0xa58cdee150(_0xc1d68b69d4.time);
            const _0x5928216f5d = document.createElement(_0x84ee726f59(76));
            _0x5928216f5d.className = _0x84ee726f59(78);
            _0x5928216f5d.textContent = _0xc1d68b69d4.level || _0x84ee726f59(75);
            const _0xf83b8c6225 = document.createElement(_0x84ee726f59(76));
            _0xf83b8c6225.textContent = _0xc1d68b69d4.message || _0x84ee726f59(40);
            _0x22d1007fc1.append(_0x278e31c816, _0x5928216f5d, _0xf83b8c6225);
            _0xef491228b7.appendChild(_0x22d1007fc1);
        });
        _0x763bd8a7fd.logList.appendChild(_0xef491228b7);
        _0x763bd8a7fd.logList.scrollTop = _0x763bd8a7fd.logList.scrollHeight;
    }
    function _0x73d8f2b2a8(_0xd33a8fd618) {
        _0x763bd8a7fd.lockModal.classList.toggle(_0x84ee726f59(79), !_0xd33a8fd618);
        _0x763bd8a7fd.lockModal.setAttribute(_0x84ee726f59(80), _0xd33a8fd618 ? _0x84ee726f59(81) : _0x84ee726f59(82));
        _0x763bd8a7fd.appShell.classList.toggle(_0x84ee726f59(83), _0xd33a8fd618);
    }
    function _0xcf421973fe(_0x274ea6ef53) {
        _0x435223b811 = _0x274ea6ef53 || {};
        const _0x6069803531 = Array.isArray(_0x435223b811.rows) ? _0x435223b811.rows : [];
        const _0x8e986f180b = Array.isArray(_0x435223b811.logs) ? _0x435223b811.logs : [];
        const _0x6e749eba89 = Array.isArray(_0x435223b811.detailQueue) ? _0x435223b811.detailQueue : [];
        const _0xc9a9fabaff = _0x435223b811.status || _0x84ee726f59(84);
        const _0x633cc2e519 = _0x3d2b08e198.has(_0xc9a9fabaff);
        const _0x8d900e17b0 = Boolean(_0x435223b811.authLocked || _0xc9a9fabaff === _0x84ee726f59(56));
        const _0xf473733bc7 = _0x6069803531.filter((_0x20de36399b) => _0x20de36399b.detailStatus === _0x84ee726f59(55)).length;
        const _0xc1697f4360 = Math.min(Number(_0x435223b811.detailIndex) || 0, _0x6e749eba89.length);
        _0x763bd8a7fd.statusText.textContent = _0x7b8d1f88d5[_0xc9a9fabaff] || _0xc9a9fabaff;
        _0x6ed594bf57(_0xc9a9fabaff);
        _0x763bd8a7fd.rowCount.textContent = String(_0x6069803531.length);
        _0x763bd8a7fd.orderProgress.textContent = _0x84ee726f59(40) + _0xc1697f4360 + _0x84ee726f59(85) + _0x6e749eba89.length + _0x84ee726f59(40);
        _0x763bd8a7fd.errorCount.textContent = String(_0xf473733bc7);
        _0x763bd8a7fd.currentStep.textContent = _0x435223b811.currentOrderId || _0x435223b811.currentStep || _0x84ee726f59(86);
        _0x763bd8a7fd.lastUpdated.textContent = _0xa58cdee150(_0x435223b811.updatedAt);
        _0x763bd8a7fd.startButton.textContent = _0xc9a9fabaff === _0x84ee726f59(53) ? _0x84ee726f59(87) : _0x84ee726f59(88);
        _0x763bd8a7fd.startButton.disabled = _0x8d900e17b0 || _0x633cc2e519;
        _0x763bd8a7fd.pauseButton.disabled = _0x8d900e17b0 || !_0x633cc2e519 || _0xc9a9fabaff === _0x84ee726f59(39) || _0xc9a9fabaff === _0x84ee726f59(38);
        _0x763bd8a7fd.copyButton.disabled = _0x8d900e17b0 || _0x6069803531.length === 0;
        _0x763bd8a7fd.clearButton.disabled = _0x8d900e17b0 || _0x633cc2e519 || (_0x6069803531.length === 0 && _0x8e986f180b.length === 0);
        _0x15b54f5250(_0x6069803531);
        _0xa5544e50b4(_0x8e986f180b);
        _0x73d8f2b2a8(_0x8d900e17b0);
    }
    function _0xfd886cc0a3(_0x8e484ce44f) {
        return _0x01735ece0c(_0x8e484ce44f)
            .replace(/&/g, _0x84ee726f59(89))
            .replace(/</g, _0x84ee726f59(90))
            .replace(/>/g, _0x84ee726f59(91))
            .replace(/"/g, _0x84ee726f59(92))
            .replace(/'/g, _0x84ee726f59(93));
    }
    async function _0xdb23e8a7d8() {
        const _0x1764dc6864 = _0x435223b811 && Array.isArray(_0x435223b811.rows) ? _0x435223b811.rows : [];
        if (!_0x1764dc6864.length) {
            _0xf04411787b(_0x84ee726f59(94));
            return;
        }
        const _0xf5f1596ed8 = [
            _0x84ee726f59(95),
            _0x84ee726f59(96),
            _0x84ee726f59(97),
            _0x84ee726f59(98),
            _0x84ee726f59(99),
            _0x84ee726f59(100),
            _0x84ee726f59(101),
            _0x84ee726f59(102),
            _0x84ee726f59(103),
            _0x84ee726f59(104),
            _0x84ee726f59(105)
        ];
        const _0xde8c33ce80 = _0x1764dc6864.map((_0x1d61bc3346) => [
            _0x1d61bc3346.returnId, _0x1d61bc3346.orderId, _0x1d61bc3346.sku, _0x1d61bc3346.quantity, _0x1d61bc3346.reason,
            _0x1d61bc3346.buyerComment, _0x1d61bc3346.image, _0x1d61bc3346.date, _0x1d61bc3346.courier, _0x1d61bc3346.trackingNumber, _0x1d61bc3346.sellerNote
        ].map(_0x01735ece0c));
        const _0xf0977b9c63 = [_0xf5f1596ed8, ..._0xde8c33ce80]
            .map((_0xab49f06939) => _0xab49f06939.map(_0x01735ece0c).join(_0x84ee726f59(106)))
            .join(_0x84ee726f59(107));
        const _0x9fe9ac96ae = _0xde8c33ce80.map((_0x9871611aa8) => {
            const _0x125a2b478f = _0x9871611aa8[1];
            return _0x84ee726f59(108) + _0x9871611aa8.map((_0xfc7d083da0, _0x97e370de12) => {
                if (_0x97e370de12 === 1 && _0x4ca2928271.test(String(_0x125a2b478f || _0x84ee726f59(40)))) {
                    return _0x84ee726f59(109) + _0xfd886cc0a3(_0xf30e1b0c31(_0x125a2b478f)) + _0x84ee726f59(110) + _0xfd886cc0a3(_0xfc7d083da0) + _0x84ee726f59(111);
                }
                return _0x84ee726f59(112) + _0xfd886cc0a3(_0xfc7d083da0) + _0x84ee726f59(113);
            }).join(_0x84ee726f59(40)) + _0x84ee726f59(114);
        }).join(_0x84ee726f59(40));
        const _0x9f4e1b005a = _0x84ee726f59(115) + _0xf5f1596ed8.map((_0xb134ef995f) => _0x84ee726f59(116) + _0xfd886cc0a3(_0xb134ef995f) + _0x84ee726f59(117)).join(_0x84ee726f59(40)) + _0x84ee726f59(118) + _0x9fe9ac96ae + _0x84ee726f59(119);
        let _0x21661f1532 = false;
        let _0x3c20a749b3 = null;
        if (window.ClipboardItem && navigator.clipboard && navigator.clipboard.write) {
            try {
                const _0x92536545f5 = new ClipboardItem({
                    'text/plain': new Blob([_0xf0977b9c63], { type: _0x84ee726f59(120) }),
                    'text/html': new Blob([_0x9f4e1b005a], { type: _0x84ee726f59(121) })
                });
                await navigator.clipboard.write([_0x92536545f5]);
                _0x21661f1532 = true;
            }
            catch (_0x3fa7b06519) {
                _0x3c20a749b3 = _0x3fa7b06519;
            }
        }
        if (!_0x21661f1532 && navigator.clipboard && navigator.clipboard.writeText) {
            try {
                await navigator.clipboard.writeText(_0xf0977b9c63);
                _0x21661f1532 = true;
            }
            catch (_0x68135c25cd) {
                _0x3c20a749b3 = _0x68135c25cd;
            }
        }
        if (!_0x21661f1532) {
            try {
                const _0xe05a65991b = document.createElement(_0x84ee726f59(122));
                _0xe05a65991b.value = _0xf0977b9c63;
                _0xe05a65991b.setAttribute(_0x84ee726f59(123), _0x84ee726f59(40));
                _0xe05a65991b.style.position = _0x84ee726f59(124);
                _0xe05a65991b.style.opacity = _0x84ee726f59(125);
                document.body.appendChild(_0xe05a65991b);
                _0xe05a65991b.select();
                _0x21661f1532 = document.execCommand(_0x84ee726f59(126));
                _0xe05a65991b.remove();
            }
            catch (_0x8a7bcebe61) {
                _0x3c20a749b3 = _0x8a7bcebe61;
            }
        }
        if (_0x21661f1532) {
            _0xf04411787b(_0x84ee726f59(127) + _0x1764dc6864.length + _0x84ee726f59(128));
        }
        else {
            _0xf04411787b(_0x84ee726f59(129) + (_0x3c20a749b3 && (_0x3c20a749b3.message || _0x3c20a749b3) || _0x84ee726f59(130)) + _0x84ee726f59(40));
        }
    }
    async function _0x8a30e9db29() {
        const _0x12ec9dd69c = chrome.runtime.getManifest();
        _0x763bd8a7fd.versionText.textContent = _0x84ee726f59(131) + (_0x12ec9dd69c.version_name || _0x12ec9dd69c.version) + _0x84ee726f59(40);
        const _0x3e29f41ff4 = await chrome.storage.local.get(_0x8260d4c299);
        _0xcf421973fe(_0x3e29f41ff4[_0x8260d4c299] || {});
        await _0x793722ac0e(_0x84ee726f59(132));
    }
    _0x763bd8a7fd.startButton.addEventListener(_0x84ee726f59(67), async () => {
        try {
            _0x763bd8a7fd.startButton.disabled = true;
            await _0x793722ac0e(_0x84ee726f59(133));
        }
        catch (_0x6c2c94545b) {
            _0xf04411787b(_0x6c2c94545b.message || String(_0x6c2c94545b));
            _0x763bd8a7fd.startButton.disabled = false;
        }
    });
    _0x763bd8a7fd.pauseButton.addEventListener(_0x84ee726f59(67), async () => {
        try {
            _0x763bd8a7fd.pauseButton.disabled = true;
            await _0x793722ac0e(_0x84ee726f59(134));
            _0xf04411787b(_0x84ee726f59(135));
        }
        catch (_0x2adee7d519) {
            _0xf04411787b(_0x2adee7d519.message || String(_0x2adee7d519));
            _0x763bd8a7fd.pauseButton.disabled = false;
        }
    });
    _0x763bd8a7fd.copyButton.addEventListener(_0x84ee726f59(67), _0xdb23e8a7d8);
    _0x763bd8a7fd.clearButton.addEventListener(_0x84ee726f59(67), async () => {
        try {
            await _0x793722ac0e(_0x84ee726f59(136));
            _0xf04411787b(_0x84ee726f59(137));
        }
        catch (_0x7411acafcc) {
            _0xf04411787b(_0x7411acafcc.message || String(_0x7411acafcc));
        }
    });
    _0x763bd8a7fd.recheckButton.addEventListener(_0x84ee726f59(67), async () => {
        try {
            _0x763bd8a7fd.recheckButton.disabled = true;
            await _0x793722ac0e(_0x84ee726f59(138));
        }
        catch (_0x06ce3f142a) {
            _0x763bd8a7fd.recheckButton.disabled = false;
        }
    });
    _0x763bd8a7fd.closeWindowButton.addEventListener(_0x84ee726f59(67), async () => {
        try {
            await _0x793722ac0e(_0x84ee726f59(139));
        }
        catch (_0x8a1ef60104) {
            window.close();
        }
    });
    chrome.storage.onChanged.addListener((_0x3e66a6dc10, _0x0befe3e5b7) => {
        if (_0x0befe3e5b7 === _0x84ee726f59(140) && _0x3e66a6dc10[_0x8260d4c299] && _0x3e66a6dc10[_0x8260d4c299].newValue) {
            _0xcf421973fe(_0x3e66a6dc10[_0x8260d4c299].newValue);
            _0x763bd8a7fd.recheckButton.disabled = false;
        }
    });
    window.setInterval(() => {
        if (_0x435223b811 && _0x3d2b08e198.has(_0x435223b811.status)) {
            chrome.runtime.sendMessage({ type: _0x84ee726f59(141) }).catch(() => { });
        }
    }, 2500);
    _0x8a30e9db29().catch((_0x4ff6777eb6) => {
        _0xf04411787b(_0x84ee726f59(142) + (_0x4ff6777eb6.message || _0x4ff6777eb6) + _0x84ee726f59(40));
    });
})();
