# DHL 地址自动填充 Chrome 扩展

本扩展在本机读取 Seller Central 当前订单页的订单号和收件地址，再填写 DHL 表单；不请求网络权限，也不上传信息。

## 安装

1. 在 Chrome 打开 `chrome://extensions`，开启“开发者模式”。
2. 选择“加载已解压的扩展程序”。
3. 选择本文件夹 `dhl-address-autofill`。

## 使用

1. 在 Seller Central 订单详情页点击扩展，选择“从当前亚马逊页面复制订单与地址”。内容已合并复制。
2. 打开 DHL 创建运单的页面，粘贴内容；首次填写固定收件邮箱（只保存在此浏览器）。
3. 点击“解析信息”，确认字段后选择“填入当前 DHL 页面”。

支持 `303-0450381-4649911` 格式的亚马逊订单号。它会同时精确填入 `shipmentReference` 和 `customerReference`。当前版本固定 Germany。
