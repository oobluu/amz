const _0xa2c84e63cd=[[247,251,248,248,241,247,224,251,230,199,224,245,224,241],[252,224,224,228,231,174,187,187,231,241,248,248,241,230,185,241,225,186,224,241,249,225,186,247,251,249,187,230,241,224,225,230,250,185,230,241,242,225,250,240,185,248,253,231,224,186,252,224,249,248,171,203,236,203,231,241,231,231,250,203,253,240,169,236,166,228,167,229,226,167,225,237,225,178,230,241,242,241,230,203,228,245,243,241,203,250,245,249,241,169,198,241,224,225,230,250,177,166,164,230,241,228,251,230,224,231,178,230,241,242,241,230,203,228,245,243,241,203,253,240,169,166,166,166,165,161,203,165,163,172,167,162,162,160,163,173,167,165,165,160,203,255,226,245,229,229,164,248,238,248,228,178,230,241,242,241,230,203,228,245,243,241,203,231,250,169,166,166,166,165,161,178,228,245,243,241,218,225,249,246,241,230,169,165,178,228,245,243,241,199,253,238,241,169,165,164,178,230,241,245,231,251,250,215,251,240,241,216,253,231,224,169,164,178,243,230,251,225,228,199,241,245,230,247,252,192,237,228,241,169,165,164,164,164,164,165,178,224,253,249,241,199,241,245,230,247,252,192,237,228,241,169,165,164,164,165,164,164,178,231,241,245,230,247,252,192,241,236,224,192,237,228,241,169,165,178,231,241,245,230,247,252,192,241,236,224,169,178,247,251,249,228,248,241,224,241,240,199,241,245,230,247,252,192,237,228,241,169,165,164,164,160,164,166,178,228,230,251,224,241,247,224,241,240,214,237,196,248,245,224,242,251,230,249,199,241,245,230,247,252,192,237,228,241,169,165,164,164,163,164,165],[252,224,224,228,231,174,187,187,231,241,248,248,241,230,185,241,225,186,224,241,249,225,186,247,251,249,187,251,230,240,241,230,185,240,241,224,245,253,248,186,252,224,249,248,171,228,245,230,241,250,224,203,251,230,240,241,230,203,231,250,169],[178,203,236,203,231,241,231,231,250,203,253,240,169,236,166,228,167,229,226,167,225,237,225,178,230,241,242,241,230,203,228,245,243,241,203,250,245,249,241,169,230,241,224,225,230,250,185,230,241,242,225,250,240,185,248,253,231,224,178,230,241,242,241,230,203,228,245,243,241,203,253,240,169,166,164,167,172,161,203,165,163,172,162,160,164,173,160,163,164,163,165,164,203,252,242,246,172,238,238,172,161,254,165,178,230,241,242,241,230,203,228,245,243,241,203,231,250,169,166,164,167,172,161],[252,224,224,228,231,174,187,187,245,250,245,250,185,165,166,161,173,164,173,161,172,172,167,186,247,251,231,186,241,225,185,242,230,245,250,255,242,225,230,224,186,249,237,229,247,248,251,225,240,186,247,251,249,187,165,187,248,245,246,241,248,186,252,224,249,248],[251,228,241,250,253,250,243,185,248,253,231,224],[247,251,250,242,253,243,225,230,253,250,243,185,248,253,231,224],[247,251,248,248,241,247,224,253,250,243,185,248,253,231,224],[228,230,251,247,241,231,231,253,250,243,185,240,241,224,245,253,248,231],[228,245,225,231,241,185,228,241,250,240,253,250,243],[226,245,248,253,240,245,224,253,250,243],[253,240,248,241],[8320],[251,246,254,241,247,224],[253,250,242,251],[],[250,251,230,249,245,248],[228,251,228,225,228],[23910,22460,30330,26771,28123,35164,22268,31235,21367,28500,28079,180,192,209,217,193,180,37012,36275,21123,35068,26771,31722,39137,12438],[227,245,230,250,253,250,243],[252,224,224,228,231,174,187,187,231,241,248,248,241,230,185,241,225,186,224,241,249,225,186,247,251,249,187,251,230,240,241,230,185,240,241,224,245,253,248,186,252,224,249,248,171],[25972,26076,30224,35638,21441,35698,24657,37994,25393],[30330,26771,26771,31722,39137,20121,23500,22460],[247,251,249,228,248,241,224,241],[30330,26771,26771,31722,39137,22460,21044,36841,36691,31391,20153,34879,20967,38265],[39137,38902,21044,36841,36113,25954],[228,245,250,241,248,186,252,224,249,248],[193,218,223,218,219,195,218,203,213,218,219,217,213,216,205],[203],[231,245,226,241,240],[228,241,250,240,253,250,243],[185],[220,192,217,216,180,199,213,217,196,216,209,174],[188,218,251,180,220,192,217,216,180,227,245,231,180,245,226,245,253,248,245,246,248,241,186,189],[153,158],[225,250,253,229,225,253,242,237],[241,230,230,251,230],[24519,21209,30168,38902,23910,38293,23310],[25343,25435,20079,21045,27639,22460,36676,35032],[228,245,225,231,241,240],[35695,21314,35638,21441,35698,24657],[32371,32377,25343,25435,26558,23320,25220,30224,35638,21441,35698,24657,12438],[27639,22460,23320,25220,25343,25435],[35638,21441,35698,24657,23910,20988,36988,22928,29842,65432,32371,32377,23320,25220,25343,25435,12438],[25287,24468,37012,36275,21123,35068],[24468,22879,25892,30224,25343,25435,20079,21045,12438],[23910,25287,24468,24290,21139,25590,21156,180,192,209,217,193,180,37012,36275,21123,35068,39137,38902,12438],[24519,21209,27701,26525,21371,26134,20680,30224,25343,25435,20079,21045],[23320,25220,21123,35068,37203,38482,21658,26134,20680],[23320,25220,24519,21209,27633,39472,21658,26134,20680],[23910,26018,21156,26134,20680,35683,27862,65432,23698,22460,24519,21209,21123,35068,37203,38482,23320,25220,21658,26134,20680,12438],[23910,26018,21156,26134,20680,35683,27862,65432,23698,22460,24519,21209,35638,21441,22928,29842,23320,25220,21658,26134,20680,12438],[25343,25435,36676,35032,26507,38240,20121,32873,28305,31470,35620,24513],[245,225,224,252,185,248,251,247,255,241,240],[20079,21045,24470,24236,20680,27638],[37209,25892,25287,24468,37012,36275,21123,35068],[37012,36275,21123,35068,26771,31722,39137,20121,23500,22460,65432,23910,37209,25892,25287,24468,12438],[252,224,224,228,231,174,187,187,231,241,248,248,241,230,185,241,225,186,224,241,249,225,186,247,251,249,187,230,241,224,225,230,250,185,230,241,242,225,250,240,185,248,253,231,224,186,252,224,249,248],[35626,32762,31695,37021,12437,25350,24091,21528,27483,39137,26084,37211],[216,221,199,192,203,199,215,198,221,196,192,203,221,218,222,209,215,192,221,219,218,203,210,213,221,216,209,208],[26558,30577,38285,35707],[21123,35068,37203,38482,22949,36273],[209,198,198,219,198],[213,248,248,180,228,241,250,240,253,250,243,180,245,247,224,253,251,250,180,23910,30970,35632,65422,195,245,253,224,253,250,243,180,224,251,180,225,228,248,251,245,240,180,230,241,224,225,230,250,180,248,245,246,241,248,12438],[25350,24091,25901,24475,23910,30970,35632,65422,199,251,230,224,180,246,237,180,231,252,251,230,224,241,231,224,180,230,241,249,245,253,250,253,250,243,180,228,230,251,247,241,231,231,253,250,243,180,224,253,249,241,180,188,230,241,229,225,241,231,224,231,180,227,253,224,252,180,230,241,249,245,253,250,253,250,243,180,228,230,251,247,241,231,231,253,250,243,180,224,253,249,241,180,251,250,248,237,189,12438],[27483,39137,26282,31150,26084,37211,23910,30970,35632,65422,165,164,164,12438],[231,225,247,247,241,231,231],[23910,26134,20680],[23910,22460,35638,21441,35698,24657,38562,27425,24468,22879,21209,26134,20680,12438],[21123,35068,21493,29395,37203,38482,23320,25220,65432,23910,20967,38265,21123,35068,39137,24290,36672,22090,25414,20066,31235,21367,12438],[21123,35068,21493,29395,37203,38482,23320,25220,65432,23910,20967,38265,21123,35068,39137,12438],[25343,25435,23910,26134,20680,12438],[25300,26525,35638,21441,35698,24657,23910,35695,21314,23320,25220,12438],[208,209,192,213,221,216,203,199,215,198,221,196,192,203,219,198,203,216,219,213,208,203,210,213,221,216,209,208],[218,251],[240,251,250,241],[24519,21209,35638,21441,23910,22928,29842,23320,25220,65432,25343,25435,29476,23910,26134,20680,12438],[211,209,192],[250,251,185,231,224,251,230,241],[242,251,248,248,251,227],[251,249,253,224],[247,251,249,228,248,241,224,241,240],[25343,25435,23320,25220],[25343,25435,20079,21045,23910,23320,25220,12438],[23910,38293,23310],[196,213,218,209,216,203,198,209,213,208,205],[199,192,213,198,192,203,199,215,213,218],[196,213,193,199,209,203,199,215,213,218],[215,216,209,213,198,203,198,209,215,219,198,208,199],[209,218,211,221,218,209,203,223,221,215,223],[213,193,192,220,203,198,209,215,220,209,215,223],[215,216,219,199,209,203,196,213,218,209,216],[219,196,209,218,203,208,209,192,213,221,216,203,216,221,218,223],[26558,30577,25689,20424],[37012,36275,21123,35068,26771,31722,39137,34879,20967,38265,65432,23698,33150,21052,37209,25892,25287,24468,12438],[35638,21441,35698,24657,26771,31722,39137,34879,20967,38265,65432,23698,33150,21052,37209,25892,25287,24468,24519,21209,35638,21441,12438],[23921,20963,31235,21367,23910,20967,38265,65432,23698,22460,21123,35068,37203,38482,23320,25220,21658,26134,20680,12438],[23921,20963,31235,21367,23910,20967,38265,65432,23698,22460,24519,21209,35638,21441,22928,29842,23320,25220,21658,26134,20680,12438]];const _0xe0f6272a85=(_0xi)=>String.fromCharCode(..._0xa2c84e63cd[_0xi].map((_0xc)=>_0xc^148));const _0x2650e28b = _0xe0f6272a85(0);
const _0x84096858 = _0xe0f6272a85(1);
const _0x62c1f629 = _0xe0f6272a85(2);
const _0xc0ba7dfe = _0xe0f6272a85(3);
const _0xaf72fb4f = _0xe0f6272a85(4);
const _0xd2b411c = 8 * 60 * 60 * 1000;
const _0xebe3c8ed = 10 * 1000;
const _0x49dc56b2 = 1200;
const _0x3794dc03 = 160000;
const _0x964d5bd0 = new Set([
    _0xe0f6272a85(5),
    _0xe0f6272a85(6),
    _0xe0f6272a85(7),
    _0xe0f6272a85(8),
    _0xe0f6272a85(9),
    _0xe0f6272a85(10)
]);
let _0x7405a1a1 = Promise.resolve();
let _0xd2fe2f76 = false;
let _0xb0b6b6c7 = false;
let _0x1f6f3c94 = false;
function _0xfd27ba65() {
    return {
        schemaVersion: 2,
        panelWindowId: null,
        sourceWindowId: null,
        listWindowId: null,
        status: _0xe0f6272a85(11),
        currentStep: _0xe0f6272a85(12),
        scanId: null,
        rows: [],
        detailQueue: [],
        detailIndex: 0,
        currentOrderId: null,
        detailAttempts: 0,
        listAttempts: 0,
        listTabId: null,
        detailTabId: null,
        pauseRequested: false,
        closePanelRequested: false,
        logs: [],
        authLocked: false,
        authCacheUntil: 0,
        anomalyTypes: {},
        lastError: null,
        startedAt: null,
        completedAt: null,
        updatedAt: Date.now()
    };
}
function _0x5b10002a(_0x39c88ffb) {
    const _0xa7811548 = { ..._0xfd27ba65(), ...(_0x39c88ffb || {}) };
    _0xa7811548.rows = Array.isArray(_0xa7811548.rows) ? _0xa7811548.rows : [];
    _0xa7811548.detailQueue = Array.isArray(_0xa7811548.detailQueue) ? _0xa7811548.detailQueue : [];
    _0xa7811548.logs = Array.isArray(_0xa7811548.logs) ? _0xa7811548.logs : [];
    _0xa7811548.anomalyTypes = _0xa7811548.anomalyTypes && typeof _0xa7811548.anomalyTypes === _0xe0f6272a85(13) ? _0xa7811548.anomalyTypes : {};
    _0xa7811548.schemaVersion = 2;
    return _0xa7811548;
}
async function _0x6799319() {
    const _0xe4321aee = await chrome.storage.local.get(_0x2650e28b);
    return _0x5b10002a(_0xe4321aee[_0x2650e28b]);
}
function _0x42eb60bf(_0x20a3ee0c) {
    const _0x8e9c75dd = _0x7405a1a1.then(async () => {
        const _0x6d54f3a2 = await chrome.storage.local.get(_0x2650e28b);
        const _0xcb0d7973 = _0x5b10002a(_0x6d54f3a2[_0x2650e28b]);
        const _0xa9c5c0c0 = await _0x20a3ee0c(_0xcb0d7973);
        _0xcb0d7973.updatedAt = Date.now();
        await chrome.storage.local.set({ [_0x2650e28b]: _0xcb0d7973 });
        return _0xa9c5c0c0 === undefined ? _0xcb0d7973 : _0xa9c5c0c0;
    });
    _0x7405a1a1 = _0x8e9c75dd.catch(() => { });
    return _0x8e9c75dd;
}
async function _0x17be4e91(_0xf676d466) {
    return _0x42eb60bf((_0x542f5237) => {
        Object.assign(_0x542f5237, _0xf676d466);
    });
}
async function _0x32e7d984(_0x90d02755, _0x7e88ad1a) {
    return _0x42eb60bf((_0xdd4134eb) => {
        _0xdd4134eb.logs.push({
            time: Date.now(),
            level: _0x90d02755 || _0xe0f6272a85(14),
            message: String(_0x7e88ad1a || _0xe0f6272a85(15))
        });
        if (_0xdd4134eb.logs.length > _0x49dc56b2) {
            _0xdd4134eb.logs.splice(0, _0xdd4134eb.logs.length - _0x49dc56b2);
        }
    });
}
function _0xbb39b2b8(_0x19f23809) {
    return _0x62c1f629 + encodeURIComponent(_0x19f23809) + _0xc0ba7dfe;
}
function _0x87aa87de(_0x66630daf) {
    return new Promise((_0xc45b8b7c) => setTimeout(_0xc45b8b7c, _0x66630daf));
}
async function _0xa21412cd(_0xcc9892) {
    if (!Number.isInteger(_0xcc9892)) {
        return null;
    }
    try {
        return await chrome.tabs.get(_0xcc9892);
    }
    catch (_0xee85e663) {
        return null;
    }
}
async function _0x4d7e6c30(_0x2b36eb81) {
    if (!Number.isInteger(_0x2b36eb81)) {
        return;
    }
    try {
        await chrome.tabs.remove(_0x2b36eb81);
    }
    catch (_0x89ef7156) {
    }
}
async function _0x77a7ff27(_0xd59046f4) {
    if (!Number.isInteger(_0xd59046f4)) {
        return null;
    }
    try {
        return await chrome.windows.get(_0xd59046f4);
    }
    catch (_0xb448cc45) {
        return null;
    }
}
async function _0x12014a0a(_0xf0f9d1db) {
    const _0x5eb25fa8 = await _0x77a7ff27(_0xf0f9d1db);
    if (_0x5eb25fa8 && _0x5eb25fa8.type === _0xe0f6272a85(16)) {
        return _0x5eb25fa8.id;
    }
    const _0x3d6aa579 = await _0x6799319();
    const _0x9b232cce = await _0x77a7ff27(_0x3d6aa579.sourceWindowId);
    if (_0x9b232cce && _0x9b232cce.type === _0xe0f6272a85(16)) {
        return _0x9b232cce.id;
    }
    const _0x791baa9f = await chrome.windows.getAll({ windowTypes: [_0xe0f6272a85(16)] });
    const _0xe7d4306c = _0x791baa9f.find((_0x458cbe3d) => _0x458cbe3d.focused && Number.isInteger(_0x458cbe3d.id));
    if (_0xe7d4306c) {
        return _0xe7d4306c.id;
    }
    const _0x24450582 = _0x791baa9f.find((_0x823d8353) => Number.isInteger(_0x823d8353.id));
    if (_0x24450582) {
        return _0x24450582.id;
    }
    const _0x60f60920 = await chrome.windows.create({ type: _0xe0f6272a85(16), focused: false });
    return _0x60f60920 && Number.isInteger(_0x60f60920.id) ? _0x60f60920.id : undefined;
}
async function _0xceae90f1(_0xad671e46, _0xb506417 = {}) {
    const _0xe908e3e4 = await _0x12014a0a(_0xb506417.windowId);
    return chrome.tabs.create({
        windowId: _0xe908e3e4,
        url: _0xad671e46,
        active: Boolean(_0xb506417.active)
    });
}
async function _0x57c169b5() {
    const _0x35b9f77a = await _0x6799319();
    if (!Number.isInteger(_0x35b9f77a.panelWindowId)) {
        return false;
    }
    try {
        const _0x94727ecb = await chrome.windows.get(_0x35b9f77a.panelWindowId);
        if (!_0x94727ecb || _0x94727ecb.type !== _0xe0f6272a85(17)) {
            return false;
        }
        await chrome.windows.update(_0x35b9f77a.panelWindowId, { focused: true });
        return true;
    }
    catch (_0x722ac498) {
        await _0x17be4e91({ panelWindowId: null });
        return false;
    }
}
async function _0xd0e34269(_0xbedbc83e, _0x1c94578f = false) {
    if (_0x1f6f3c94) {
        return false;
    }
    _0x1f6f3c94 = true;
    try {
        const _0xfb4cdd5c = await _0x6799319();
        if (![_0xe0f6272a85(5), _0xe0f6272a85(6), _0xe0f6272a85(7)].includes(_0xfb4cdd5c.status)) {
            return false;
        }
        const _0x59055b2d = await _0xa21412cd(_0xfb4cdd5c.listTabId);
        if (!_0x59055b2d || !Number.isInteger(_0x59055b2d.id) || !Number.isInteger(_0x59055b2d.windowId)) {
            return false;
        }
        await chrome.tabs.update(_0x59055b2d.id, { active: true });
        await chrome.windows.update(_0x59055b2d.windowId, { focused: true });
        await _0x17be4e91({
            sourceWindowId: _0x59055b2d.windowId,
            listWindowId: _0x59055b2d.windowId
        });
        if (_0x1c94578f) {
            await _0x32e7d984(_0xe0f6272a85(14), _0xbedbc83e || _0xe0f6272a85(18));
        }
        return true;
    }
    catch (_0xc7fda2f2) {
        if (_0x1c94578f) {
            await _0x32e7d984(_0xe0f6272a85(19), `无法将退货列表切换到前台 — ${_0xc7fda2f2.message || _0xc7fda2f2}`);
        }
        return false;
    }
    finally {
        _0x1f6f3c94 = false;
    }
}
async function _0xa5b62843(_0x46eb610) {
    const _0xe2273de1 = String(_0x46eb610 || _0xe0f6272a85(15));
    if (!_0xe2273de1.startsWith(_0xe0f6272a85(20))) {
        throw new Error(_0xe0f6272a85(21));
    }
    const _0x401fbbb6 = await _0x12014a0a();
    const _0x2ec80107 = await chrome.tabs.create({
        windowId: _0x401fbbb6,
        url: _0xe2273de1,
        active: true
    });
    if (Number.isInteger(_0x401fbbb6)) {
        await chrome.windows.update(_0x401fbbb6, { focused: true }).catch(() => { });
    }
    return _0x2ec80107;
}
async function _0x8c8088d4(_0x6b7916a5, _0xc9319c6a = 30000) {
    const _0xb7ea1a3b = await _0xa21412cd(_0x6b7916a5);
    if (!_0xb7ea1a3b) {
        throw new Error(_0xe0f6272a85(22));
    }
    if (_0xb7ea1a3b.status === _0xe0f6272a85(23)) {
        return _0xb7ea1a3b;
    }
    return new Promise((_0x15a36188, _0xf39bef59) => {
        let _0x5254752e = false;
        const _0x300cfcff = (_0x9ec57a4c, _0x7cbdc01d) => {
            if (_0x5254752e) {
                return;
            }
            _0x5254752e = true;
            clearTimeout(_0xa03935c4);
            chrome.tabs.onUpdated.removeListener(_0xdb764fe2);
            chrome.tabs.onRemoved.removeListener(_0x638820a6);
            if (_0x9ec57a4c) {
                _0xf39bef59(_0x9ec57a4c);
            }
            else {
                _0x15a36188(_0x7cbdc01d);
            }
        };
        const _0xdb764fe2 = (_0xb92ed5b3, _0x27e75300, _0x85dfdad1) => {
            if (_0xb92ed5b3 === _0x6b7916a5 && _0x27e75300.status === _0xe0f6272a85(23)) {
                _0x300cfcff(null, _0x85dfdad1);
            }
        };
        const _0x638820a6 = (_0xc240ae77) => {
            if (_0xc240ae77 === _0x6b7916a5) {
                _0x300cfcff(new Error(_0xe0f6272a85(24)));
            }
        };
        const _0xa03935c4 = setTimeout(() => _0x300cfcff(new Error(_0xe0f6272a85(25))), _0xc9319c6a);
        chrome.tabs.onUpdated.addListener(_0xdb764fe2);
        chrome.tabs.onRemoved.addListener(_0x638820a6);
        _0xa21412cd(_0x6b7916a5).then((_0xef1b395) => {
            if (!_0xef1b395) {
                _0x300cfcff(new Error(_0xe0f6272a85(24)));
            }
            else if (_0xef1b395.status === _0xe0f6272a85(23)) {
                _0x300cfcff(null, _0xef1b395);
            }
        }).catch(() => { });
    });
}
async function _0xecaa395a(_0x4b62872b) {
    const _0x295b0ef8 = await _0x12014a0a(_0x4b62872b && _0x4b62872b.windowId);
    if (Number.isInteger(_0x295b0ef8)) {
        await _0x17be4e91({ sourceWindowId: _0x295b0ef8 });
    }
    const _0x97139449 = await _0x6799319();
    if (Number.isInteger(_0x97139449.panelWindowId)) {
        try {
            await chrome.windows.get(_0x97139449.panelWindowId);
            await chrome.windows.update(_0x97139449.panelWindowId, { focused: true });
            return;
        }
        catch (_0x75cc121e) {
            await _0x17be4e91({ panelWindowId: null });
        }
    }
    const _0xd38499ef = await chrome.windows.create({
        url: chrome.runtime.getURL(_0xe0f6272a85(26)),
        type: _0xe0f6272a85(17),
        width: 1500,
        height: 900,
        focused: true
    });
    if (_0xd38499ef && Number.isInteger(_0xd38499ef.id)) {
        await _0x17be4e91({ panelWindowId: _0xd38499ef.id });
    }
}
async function _0xb27de7bc() {
    const _0x10366d0d = await _0x6799319();
    if (!Number.isInteger(_0x10366d0d.panelWindowId)) {
        return;
    }
    try {
        await chrome.windows.remove(_0x10366d0d.panelWindowId);
    }
    catch (_0xfeeef4d2) {
        await _0x17be4e91({ panelWindowId: null });
    }
}
async function _0x5ca772a3(_0x3a9ff870, _0x994847c1) {
    const _0x700cd96 = String(_0x3a9ff870 || _0xe0f6272a85(27)).toUpperCase().replace(/[^A-Z0-9_-]+/g, _0xe0f6272a85(28)).slice(0, 80);
    const _0xe5f94b67 = Date.now();
    const _0x43b1d134 = await _0x42eb60bf((_0x226a5885) => {
        const _0x8022a64a = _0x226a5885.anomalyTypes[_0x700cd96];
        if (_0x8022a64a && _0x8022a64a.status === _0xe0f6272a85(29)) {
            return false;
        }
        if (_0x8022a64a && _0x8022a64a.status === _0xe0f6272a85(30) && _0xe5f94b67 - Number(_0x8022a64a.time || 0) < 5 * 60 * 1000) {
            return false;
        }
        _0x226a5885.anomalyTypes[_0x700cd96] = { status: _0xe0f6272a85(30), time: _0xe5f94b67 };
        return true;
    });
    if (!_0x43b1d134) {
        return;
    }
    const _0x6e1b2c1b = new Date(_0xe5f94b67).toISOString().replace(/[:.]/g, _0xe0f6272a85(31));
    const _0xccd3abe8 = String((_0x994847c1 && _0x994847c1.html) || _0xe0f6272a85(15)).slice(0, _0x3794dc03);
    const _0xaa8c31b9 = [
        `ANOMALY TYPE: ${_0x700cd96}`,
        `RECORDED AT: ${new Date(_0xe5f94b67).toISOString()}`,
        `PAGE URL: ${(_0x994847c1 && _0x994847c1.url) || _0xe0f6272a85(15)}`,
        `ORDER ID: ${(_0x994847c1 && _0x994847c1.orderId) || _0xe0f6272a85(15)}`,
        `MESSAGE: ${(_0x994847c1 && _0x994847c1.message) || _0xe0f6272a85(15)}`,
        _0xe0f6272a85(15),
        _0xe0f6272a85(32),
        _0xccd3abe8 || _0xe0f6272a85(33)
    ].join(_0xe0f6272a85(34));
    const _0x944bf0e = `TEMU_Return_Label_Collector/Anomaly_Samples/${_0x700cd96}_${_0x6e1b2c1b}.txt`;
    try {
        const _0xf73d06df = await chrome.downloads.download({
            url: `data:text/plain;charset=utf-8,${encodeURIComponent(_0xaa8c31b9)}`,
            filename: _0x944bf0e,
            conflictAction: _0xe0f6272a85(35),
            saveAs: false
        });
        await _0x42eb60bf((_0x55f58cac) => {
            _0x55f58cac.anomalyTypes[_0x700cd96] = {
                status: _0xe0f6272a85(29),
                time: _0xe5f94b67,
                filename: _0x944bf0e,
                downloadId: _0xf73d06df
            };
            _0x55f58cac.logs.push({
                time: Date.now(),
                level: _0xe0f6272a85(19),
                message: `已记录异常样本：${_0x700cd96}`
            });
            if (_0x55f58cac.logs.length > _0x49dc56b2) {
                _0x55f58cac.logs.splice(0, _0x55f58cac.logs.length - _0x49dc56b2);
            }
        });
    }
    catch (_0x33ae0a7d) {
        await _0x42eb60bf((_0x926691c2) => {
            delete _0x926691c2.anomalyTypes[_0x700cd96];
            _0x926691c2.logs.push({
                time: Date.now(),
                level: _0xe0f6272a85(36),
                message: `异常样本保存失败：${_0x700cd96} — ${_0x33ae0a7d.message || _0x33ae0a7d}`
            });
            if (_0x926691c2.logs.length > _0x49dc56b2) {
                _0x926691c2.logs.splice(0, _0x926691c2.logs.length - _0x49dc56b2);
            }
        });
    }
}
async function _0x705f1f93() {
    const _0xde086560 = await _0x6799319();
    await _0x17be4e91({ listTabId: null, listWindowId: null, detailTabId: null, currentOrderId: null });
    await Promise.all([
        _0x4d7e6c30(_0xde086560.listTabId),
        _0x4d7e6c30(_0xde086560.detailTabId)
    ]);
}
async function _0xbcc0e331() {
    const _0x1ab96a86 = await _0x6799319();
    if (_0x1ab96a86.authLocked) {
        throw new Error(_0xe0f6272a85(37));
    }
    if (_0x964d5bd0.has(_0x1ab96a86.status)) {
        throw new Error(_0xe0f6272a85(38));
    }
    if (_0x1ab96a86.status === _0xe0f6272a85(39)) {
        if (_0x1ab96a86.detailQueue.length > _0x1ab96a86.detailIndex) {
            await _0x42eb60bf((_0xf971f057) => {
                _0xf971f057.status = _0xe0f6272a85(8);
                _0xf971f057.pauseRequested = false;
                _0xf971f057.closePanelRequested = false;
                _0xf971f057.currentStep = _0xf971f057.detailQueue[_0xf971f057.detailIndex] || _0xe0f6272a85(40);
                _0xf971f057.logs.push({ time: Date.now(), level: _0xe0f6272a85(14), message: _0xe0f6272a85(41) });
                if (_0xf971f057.logs.length > _0x49dc56b2) {
                    _0xf971f057.logs.splice(0, _0xf971f057.logs.length - _0x49dc56b2);
                }
            });
            _0xf1800250();
            return;
        }
        if (_0x1ab96a86.scanId && _0x1ab96a86.startedAt) {
            await _0x42eb60bf((_0x672a7e24) => {
                _0x672a7e24.status = _0xe0f6272a85(10);
                _0x672a7e24.pauseRequested = false;
                _0x672a7e24.closePanelRequested = false;
                _0x672a7e24.currentStep = _0xe0f6272a85(42);
                _0x672a7e24.logs.push({ time: Date.now(), level: _0xe0f6272a85(14), message: _0xe0f6272a85(43) });
                if (_0x672a7e24.logs.length > _0x49dc56b2) {
                    _0x672a7e24.logs.splice(0, _0x672a7e24.logs.length - _0x49dc56b2);
                }
            });
            _0xf1800250();
            return;
        }
    }
    await _0x705f1f93();
    const _0xc5e2c5f5 = `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
    await _0x42eb60bf((_0xa3db43ba) => {
        _0xa3db43ba.status = _0xe0f6272a85(5);
        _0xa3db43ba.currentStep = _0xe0f6272a85(44);
        _0xa3db43ba.scanId = _0xc5e2c5f5;
        _0xa3db43ba.rows = [];
        _0xa3db43ba.detailQueue = [];
        _0xa3db43ba.detailIndex = 0;
        _0xa3db43ba.currentOrderId = null;
        _0xa3db43ba.detailAttempts = 0;
        _0xa3db43ba.listAttempts = 0;
        _0xa3db43ba.pauseRequested = false;
        _0xa3db43ba.closePanelRequested = false;
        _0xa3db43ba.lastError = null;
        _0xa3db43ba.startedAt = Date.now();
        _0xa3db43ba.completedAt = null;
        _0xa3db43ba.logs.push({ time: Date.now(), level: _0xe0f6272a85(14), message: _0xe0f6272a85(45) });
        if (_0xa3db43ba.logs.length > _0x49dc56b2) {
            _0xa3db43ba.logs.splice(0, _0xa3db43ba.logs.length - _0x49dc56b2);
        }
    });
    const _0x193c90b = await _0x12014a0a(_0x1ab96a86.sourceWindowId);
    const _0xe04c50d8 = await _0xceae90f1(_0x84096858, { windowId: _0x193c90b, active: true });
    await _0x17be4e91({
        listTabId: _0xe04c50d8.id,
        listWindowId: _0xe04c50d8.windowId,
        sourceWindowId: _0xe04c50d8.windowId
    });
    await _0xd0e34269(_0xe0f6272a85(18), false);
    await _0x32e7d984(_0xe0f6272a85(14), _0xe0f6272a85(46));
    _0xf1800250();
}
async function _0x4e04dea9() {
    const _0x2cfd247e = await _0x6799319();
    if (!_0x964d5bd0.has(_0x2cfd247e.status) || _0x2cfd247e.status === _0xe0f6272a85(10)) {
        throw new Error(_0xe0f6272a85(47));
    }
    await _0x42eb60bf((_0x8ab5a3cf) => {
        _0x8ab5a3cf.pauseRequested = true;
        const _0x696e299c = [_0xe0f6272a85(5), _0xe0f6272a85(6), _0xe0f6272a85(7)].includes(_0x8ab5a3cf.status);
        if (!_0x696e299c) {
            _0x8ab5a3cf.status = _0xe0f6272a85(9);
        }
        _0x8ab5a3cf.currentStep = _0x8ab5a3cf.currentOrderId || (_0x696e299c ? _0xe0f6272a85(48) : _0xe0f6272a85(49));
        _0x8ab5a3cf.logs.push({
            time: Date.now(),
            level: _0xe0f6272a85(14),
            message: _0x696e299c ? _0xe0f6272a85(50) : _0xe0f6272a85(51)
        });
        if (_0x8ab5a3cf.logs.length > _0x49dc56b2) {
            _0x8ab5a3cf.logs.splice(0, _0x8ab5a3cf.logs.length - _0x49dc56b2);
        }
    });
    _0xf1800250();
}
async function _0xd726b76d() {
    const _0xb51f3d32 = await _0x6799319();
    if (_0x964d5bd0.has(_0xb51f3d32.status)) {
        throw new Error(_0xe0f6272a85(52));
    }
    await _0x705f1f93();
    await _0x42eb60bf((_0x13d78483) => {
        _0x13d78483.status = _0x13d78483.authLocked ? _0xe0f6272a85(53) : _0xe0f6272a85(11);
        _0x13d78483.currentStep = _0xe0f6272a85(12);
        _0x13d78483.rows = [];
        _0x13d78483.detailQueue = [];
        _0x13d78483.detailIndex = 0;
        _0x13d78483.currentOrderId = null;
        _0x13d78483.detailAttempts = 0;
        _0x13d78483.listAttempts = 0;
        _0x13d78483.pauseRequested = false;
        _0x13d78483.closePanelRequested = false;
        _0x13d78483.lastError = null;
        _0x13d78483.startedAt = null;
        _0x13d78483.completedAt = null;
        _0x13d78483.logs = [];
    });
}
function _0xf1800250() {
    if (_0xd2fe2f76) {
        _0xb0b6b6c7 = true;
        return;
    }
    queueMicrotask(() => {
        _0x50788821().catch(() => { });
    });
}
async function _0x50788821() {
    if (_0xd2fe2f76) {
        _0xb0b6b6c7 = true;
        return;
    }
    _0xd2fe2f76 = true;
    try {
        const _0x3e3117f6 = await _0x6799319();
        if (_0x3e3117f6.authLocked && _0x3e3117f6.status !== _0xe0f6272a85(53)) {
            await _0x17be4e91({ status: _0xe0f6272a85(53) });
            return;
        }
        if ([_0xe0f6272a85(5), _0xe0f6272a85(6), _0xe0f6272a85(7)].includes(_0x3e3117f6.status)) {
            await _0xd89b62e5(_0x3e3117f6);
        }
        else if ([_0xe0f6272a85(8), _0xe0f6272a85(9)].includes(_0x3e3117f6.status)) {
            await _0x8e57f94d(_0x3e3117f6);
        }
        else if (_0x3e3117f6.status === _0xe0f6272a85(10)) {
            await _0xac536236(false);
        }
    }
    catch (_0x9ce99d47) {
        await _0x42eb60bf((_0x7aa21b14) => {
            _0x7aa21b14.status = _0x7aa21b14.authLocked ? _0xe0f6272a85(53) : _0xe0f6272a85(36);
            _0x7aa21b14.lastError = _0x9ce99d47.message || String(_0x9ce99d47);
            _0x7aa21b14.currentStep = _0xe0f6272a85(54);
            _0x7aa21b14.logs.push({
                time: Date.now(),
                level: _0xe0f6272a85(36),
                message: `任务异常停止 — ${_0x9ce99d47.message || _0x9ce99d47}`
            });
            if (_0x7aa21b14.logs.length > _0x49dc56b2) {
                _0x7aa21b14.logs.splice(0, _0x7aa21b14.logs.length - _0x49dc56b2);
            }
        });
    }
    finally {
        _0xd2fe2f76 = false;
        if (_0xb0b6b6c7) {
            _0xb0b6b6c7 = false;
            _0xf1800250();
        }
    }
}
async function _0xd89b62e5(_0x4753e8aa) {
    let _0x250c767b = await _0xa21412cd(_0x4753e8aa.listTabId);
    if (!_0x250c767b) {
        const _0x83c4fdc8 = await _0x12014a0a(_0x4753e8aa.sourceWindowId);
        _0x250c767b = await _0xceae90f1(_0x84096858, { windowId: _0x83c4fdc8, active: true });
        await _0x17be4e91({
            listTabId: _0x250c767b.id,
            listWindowId: _0x250c767b.windowId,
            sourceWindowId: _0x250c767b.windowId,
            status: _0xe0f6272a85(5),
            currentStep: _0xe0f6272a85(55)
        });
        await _0x32e7d984(_0xe0f6272a85(19), _0xe0f6272a85(56));
    }
    else if (!String(_0x250c767b.url || _0x250c767b.pendingUrl || _0xe0f6272a85(15)).startsWith(_0xe0f6272a85(57))) {
        await chrome.tabs.update(_0x250c767b.id, { url: _0x84096858, active: true });
        await _0x17be4e91({ status: _0xe0f6272a85(5), currentStep: _0xe0f6272a85(55) });
    }
    await _0xd0e34269(Number(_0x4753e8aa.listAttempts || 0) > 0
        ? `列表采集重试前已重新激活列表标签页（${Number(_0x4753e8aa.listAttempts || 0) + 1}/3）。`
        : _0xe0f6272a85(18), true);
    await _0x8c8088d4(_0x250c767b.id, 35000);
    await _0xd0e34269(_0xe0f6272a85(15), false);
    await _0x17be4e91({ status: _0xe0f6272a85(6), currentStep: _0xe0f6272a85(58) });
    let _0x61bd7b99;
    try {
        const _0xc075c16e = await chrome.scripting.executeScript({
            target: { tabId: _0x250c767b.id },
            func: prepareAndCollectListPage
        });
        _0x61bd7b99 = _0xc075c16e && _0xc075c16e[0] ? _0xc075c16e[0].result : null;
    }
    catch (_0xae2e4f3f) {
        _0x61bd7b99 = {
            ok: false,
            error: `无法执行列表页采集脚本：${_0xae2e4f3f.message || _0xae2e4f3f}`,
            anomaly: {
                type: _0xe0f6272a85(59),
                message: _0xae2e4f3f.message || String(_0xae2e4f3f),
                url: _0x250c767b.url || _0x84096858,
                html: _0xe0f6272a85(15)
            }
        };
    }
    if (!_0x61bd7b99 || _0x61bd7b99.ok !== true) {
        const _0xce6d68c = _0x61bd7b99 && _0x61bd7b99.anomaly;
        if (_0xce6d68c) {
            await _0x5ca772a3(_0xce6d68c.type, _0xce6d68c);
        }
        const _0xeadf5c5d = Number(_0x4753e8aa.listAttempts || 0) + 1;
        if (_0xeadf5c5d < 3) {
            await _0x42eb60bf((_0x4897da22) => {
                _0x4897da22.listAttempts = _0xeadf5c5d;
                _0x4897da22.status = _0xe0f6272a85(5);
                _0x4897da22.currentStep = `重试列表采集（${_0xeadf5c5d + 1}/3）`;
                _0x4897da22.logs.push({
                    time: Date.now(),
                    level: _0xe0f6272a85(19),
                    message: `列表采集失败，准备重试（${_0xeadf5c5d}/3）— ${(_0x61bd7b99 && _0x61bd7b99.error) || _0xe0f6272a85(60)}`
                });
                if (_0x4897da22.logs.length > _0x49dc56b2) {
                    _0x4897da22.logs.splice(0, _0x4897da22.logs.length - _0x49dc56b2);
                }
            });
            try {
                await _0xd0e34269(_0xe0f6272a85(15), false);
                await chrome.tabs.reload(_0x250c767b.id);
            }
            catch (_0x374021f3) {
                await _0x17be4e91({ listTabId: null, listWindowId: null });
            }
            _0xf1800250();
            return;
        }
        await _0x42eb60bf((_0x9538af40) => {
            _0x9538af40.status = _0xe0f6272a85(36);
            _0x9538af40.currentStep = _0xe0f6272a85(61);
            _0x9538af40.lastError = (_0x61bd7b99 && _0x61bd7b99.error) || _0xe0f6272a85(61);
            _0x9538af40.logs.push({
                time: Date.now(),
                level: _0xe0f6272a85(36),
                message: `列表采集连续失败，任务停止 — ${_0x9538af40.lastError}`
            });
            if (_0x9538af40.logs.length > _0x49dc56b2) {
                _0x9538af40.logs.splice(0, _0x9538af40.logs.length - _0x49dc56b2);
            }
        });
        return;
    }
    const _0x73f13511 = Array.isArray(_0x61bd7b99.anomalies) ? _0x61bd7b99.anomalies : [];
    for (const _0xd1a9bce6 of _0x73f13511) {
        await _0x5ca772a3(_0xd1a9bce6.type, _0xd1a9bce6);
    }
    const _0xb0623ab7 = Array.isArray(_0x61bd7b99.rows) ? _0x61bd7b99.rows : [];
    const _0x1e5a8004 = /^PO-\d{3}-\d+$/i;
    const _0xfc130fd5 = _0xb0623ab7.map((_0x5acb959a) => _0x1e5a8004.test(String(_0x5acb959a.orderId || _0xe0f6272a85(15))) ? _0x5acb959a : {
        ..._0x5acb959a,
        courier: _0xe0f6272a85(62),
        trackingNumber: _0xe0f6272a85(62),
        sellerNote: _0xe0f6272a85(62),
        detailStatus: _0xe0f6272a85(36)
    });
    const _0x3884136b = [];
    const _0xa77c9938 = new Set();
    for (const _0x535e089 of _0xfc130fd5) {
        if (_0x1e5a8004.test(String(_0x535e089.orderId || _0xe0f6272a85(15))) && !_0xa77c9938.has(_0x535e089.orderId)) {
            _0xa77c9938.add(_0x535e089.orderId);
            _0x3884136b.push(_0x535e089.orderId);
        }
    }
    await _0x42eb60bf((_0xe3ee6e5e) => {
        _0xe3ee6e5e.rows = _0xfc130fd5;
        _0xe3ee6e5e.detailQueue = _0x3884136b;
        _0xe3ee6e5e.detailIndex = 0;
        _0xe3ee6e5e.currentOrderId = null;
        _0xe3ee6e5e.detailAttempts = 0;
        _0xe3ee6e5e.listAttempts = 0;
        _0xe3ee6e5e.listTabId = null;
        _0xe3ee6e5e.listWindowId = null;
        _0xe3ee6e5e.logs.push({
            time: Date.now(),
            level: _0xe0f6272a85(14),
            message: _0xe0f6272a85(63)
        });
        _0xe3ee6e5e.logs.push({
            time: Date.now(),
            level: _0xe0f6272a85(14),
            message: _0xe0f6272a85(64)
        });
        _0xe3ee6e5e.logs.push({
            time: Date.now(),
            level: _0xe0f6272a85(14),
            message: _0xe0f6272a85(65)
        });
        if (Number.isFinite(Number(_0x61bd7b99.totalCount))) {
            const _0x41a6f42f = Math.min(Number(_0x61bd7b99.totalCount), 100);
            _0xe3ee6e5e.logs.push({
                time: Date.now(),
                level: _0xe0f6272a85(66),
                message: `页面显示 ${Number(_0x61bd7b99.totalCount)} 个请求，当前页应采集 ${_0x41a6f42f} 个，已稳定采集 ${_0x61bd7b99.cardCount} 个 Return ID。`
            });
        }
        else {
            _0xe3ee6e5e.logs.push({
                time: Date.now(),
                level: _0xe0f6272a85(66),
                message: `已稳定采集 ${_0x61bd7b99.cardCount} 个 Return ID。`
            });
        }
        _0xe3ee6e5e.logs.push({
            time: Date.now(),
            level: _0xe0f6272a85(66),
            message: `卡片采集完成：${_0x61bd7b99.cardCount} 个退货请求，生成 ${_0xfc130fd5.length} 行，需读取 ${_0x3884136b.length} 个唯一订单详情。`
        });
        if (_0xe3ee6e5e.pauseRequested || _0xe3ee6e5e.closePanelRequested) {
            _0xe3ee6e5e.status = _0xe0f6272a85(39);
            _0xe3ee6e5e.currentStep = _0xe0f6272a85(67);
            _0xe3ee6e5e.logs.push({ time: Date.now(), level: _0xe0f6272a85(19), message: _0xe0f6272a85(68) });
        }
        else if (_0x3884136b.length === 0) {
            _0xe3ee6e5e.status = _0xe0f6272a85(10);
            _0xe3ee6e5e.currentStep = _0xe0f6272a85(42);
        }
        else {
            _0xe3ee6e5e.status = _0xe0f6272a85(8);
            _0xe3ee6e5e.currentStep = _0x3884136b[0];
        }
        if (_0xe3ee6e5e.logs.length > _0x49dc56b2) {
            _0xe3ee6e5e.logs.splice(0, _0xe3ee6e5e.logs.length - _0x49dc56b2);
        }
    });
    await _0x4d7e6c30(_0x250c767b.id);
    const _0x2f9f73fc = await _0x57c169b5();
    await _0x32e7d984(_0xe0f6272a85(14), _0x2f9f73fc ? _0xe0f6272a85(69) : _0xe0f6272a85(70));
    _0xf1800250();
}
async function _0x8e57f94d(_0x6c004712) {
    if (_0x6c004712.pauseRequested && !_0x6c004712.currentOrderId) {
        const _0xcaf8cee3 = _0x6c004712.detailTabId;
        await _0x42eb60bf((_0xa8b154b0) => {
            _0xa8b154b0.status = _0xe0f6272a85(39);
            _0xa8b154b0.currentStep = _0xe0f6272a85(67);
            _0xa8b154b0.detailTabId = null;
            _0xa8b154b0.logs.push({ time: Date.now(), level: _0xe0f6272a85(19), message: _0xe0f6272a85(71) });
            if (_0xa8b154b0.logs.length > _0x49dc56b2) {
                _0xa8b154b0.logs.splice(0, _0xa8b154b0.logs.length - _0x49dc56b2);
            }
        });
        await _0x4d7e6c30(_0xcaf8cee3);
        return;
    }
    if (_0x6c004712.detailIndex >= _0x6c004712.detailQueue.length) {
        const _0x1769d201 = _0x6c004712.detailTabId;
        await _0x42eb60bf((_0xf52259d6) => {
            _0xf52259d6.status = _0xe0f6272a85(10);
            _0xf52259d6.currentStep = _0xe0f6272a85(42);
            _0xf52259d6.currentOrderId = null;
            _0xf52259d6.detailTabId = null;
            _0xf52259d6.logs.push({ time: Date.now(), level: _0xe0f6272a85(66), message: _0xe0f6272a85(72) });
            if (_0xf52259d6.logs.length > _0x49dc56b2) {
                _0xf52259d6.logs.splice(0, _0xf52259d6.logs.length - _0x49dc56b2);
            }
        });
        await _0x4d7e6c30(_0x1769d201);
        _0xf1800250();
        return;
    }
    const _0x531aa7a7 = _0x6c004712.currentOrderId || _0x6c004712.detailQueue[_0x6c004712.detailIndex];
    await _0x17be4e91({
        status: _0x6c004712.pauseRequested ? _0xe0f6272a85(9) : _0xe0f6272a85(8),
        currentOrderId: _0x531aa7a7,
        currentStep: _0x531aa7a7
    });
    if (!_0x6c004712.currentOrderId) {
        await _0x32e7d984(_0xe0f6272a85(14), `读取订单详情 ${_0x6c004712.detailIndex + 1}/${_0x6c004712.detailQueue.length}：${_0x531aa7a7}`);
    }
    let _0x31d32d74 = await _0xa21412cd(_0x6c004712.detailTabId);
    const _0x9f8bb4c5 = _0xbb39b2b8(_0x531aa7a7);
    if (!_0x31d32d74) {
        _0x31d32d74 = await _0xceae90f1(_0x9f8bb4c5, { windowId: _0x6c004712.sourceWindowId, active: false });
        await _0x17be4e91({ detailTabId: _0x31d32d74.id });
    }
    else {
        const _0x7e44328a = String(_0x31d32d74.url || _0x31d32d74.pendingUrl || _0xe0f6272a85(15));
        if (!_0x7e44328a.includes(encodeURIComponent(_0x531aa7a7)) && !_0x7e44328a.includes(_0x531aa7a7)) {
            _0x31d32d74 = await chrome.tabs.update(_0x31d32d74.id, { url: _0x9f8bb4c5 });
        }
    }
    let _0xdc3cb85b;
    try {
        await _0x8c8088d4(_0x31d32d74.id, 30000);
        const _0xbaf50628 = await chrome.scripting.executeScript({
            target: { tabId: _0x31d32d74.id },
            func: extractOrderDetailPage,
            args: [_0x531aa7a7]
        });
        _0xdc3cb85b = _0xbaf50628 && _0xbaf50628[0] ? _0xbaf50628[0].result : null;
    }
    catch (_0x18ad8df9) {
        _0xdc3cb85b = {
            ok: false,
            error: _0x18ad8df9.message || String(_0x18ad8df9),
            anomalies: [{
                    type: _0xe0f6272a85(73),
                    orderId: _0x531aa7a7,
                    message: _0x18ad8df9.message || String(_0x18ad8df9),
                    url: _0x9f8bb4c5,
                    html: _0xe0f6272a85(15)
                }]
        };
    }
    const _0x87660b4e = _0xdc3cb85b && Array.isArray(_0xdc3cb85b.anomalies) ? _0xdc3cb85b.anomalies : [];
    for (const _0x655e911f of _0x87660b4e) {
        await _0x5ca772a3(_0x655e911f.type, _0x655e911f);
    }
    if (!_0xdc3cb85b || _0xdc3cb85b.ok !== true) {
        const _0xc31718ec = Number(_0x6c004712.detailAttempts || 0) + 1;
        if (_0xc31718ec < 2) {
            await _0x42eb60bf((_0xa1c066bd) => {
                _0xa1c066bd.detailAttempts = _0xc31718ec;
                _0xa1c066bd.logs.push({
                    time: Date.now(),
                    level: _0xe0f6272a85(19),
                    message: `订单 ${_0x531aa7a7} 详情读取失败，准备重试 — ${(_0xdc3cb85b && _0xdc3cb85b.error) || _0xe0f6272a85(60)}`
                });
                if (_0xa1c066bd.logs.length > _0x49dc56b2) {
                    _0xa1c066bd.logs.splice(0, _0xa1c066bd.logs.length - _0x49dc56b2);
                }
            });
            try {
                await chrome.tabs.reload(_0x31d32d74.id);
            }
            catch (_0xfb8ec02) {
                await _0x17be4e91({ detailTabId: null });
            }
            _0xf1800250();
            return;
        }
        await _0x42eb60bf((_0xee716bd3) => {
            _0xee716bd3.rows = _0xee716bd3.rows.map((_0x4c29f1a0) => _0x4c29f1a0.orderId === _0x531aa7a7 ? {
                ..._0x4c29f1a0,
                courier: _0xe0f6272a85(62),
                trackingNumber: _0xe0f6272a85(62),
                sellerNote: _0xe0f6272a85(62),
                detailStatus: _0xe0f6272a85(36)
            } : _0x4c29f1a0);
            _0xee716bd3.detailIndex += 1;
            _0xee716bd3.currentOrderId = null;
            _0xee716bd3.detailAttempts = 0;
            _0xee716bd3.logs.push({
                time: Date.now(),
                level: _0xe0f6272a85(36),
                message: `订单 ${_0x531aa7a7} 详情读取失败，已记录 ERROR 并继续下一条。`
            });
            if (_0xee716bd3.logs.length > _0x49dc56b2) {
                _0xee716bd3.logs.splice(0, _0xee716bd3.logs.length - _0x49dc56b2);
            }
        });
    }
    else {
        const _0x2ae27f71 = _0xdc3cb85b.courier || _0xe0f6272a85(74);
        const _0x88dac6c6 = _0xdc3cb85b.trackingNumber || _0xe0f6272a85(74);
        const _0x76934c97 = _0xdc3cb85b.sellerNote || _0xe0f6272a85(74);
        const _0xd54bca64 = [_0x2ae27f71, _0x88dac6c6, _0x76934c97].includes(_0xe0f6272a85(62));
        await _0x42eb60bf((_0xb3045035) => {
            _0xb3045035.rows = _0xb3045035.rows.map((_0x11fcdffa) => _0x11fcdffa.orderId === _0x531aa7a7 ? {
                ..._0x11fcdffa,
                courier: _0x2ae27f71,
                trackingNumber: _0x88dac6c6,
                sellerNote: _0x76934c97,
                detailStatus: _0xd54bca64 ? _0xe0f6272a85(36) : _0xe0f6272a85(75)
            } : _0x11fcdffa);
            _0xb3045035.detailIndex += 1;
            _0xb3045035.currentOrderId = null;
            _0xb3045035.detailAttempts = 0;
            _0xb3045035.logs.push({
                time: Date.now(),
                level: _0xd54bca64 ? _0xe0f6272a85(19) : _0xe0f6272a85(66),
                message: _0xd54bca64 ? `订单 ${_0x531aa7a7} 详情读取完成，但存在无法识别的字段，已记录 ERROR。`
                    : `订单 ${_0x531aa7a7} 详情读取完成。`
            });
            if (_0xb3045035.logs.length > _0x49dc56b2) {
                _0xb3045035.logs.splice(0, _0xb3045035.logs.length - _0x49dc56b2);
            }
        });
    }
    const _0xffb5254b = await _0x6799319();
    if (_0xffb5254b.pauseRequested || _0xffb5254b.closePanelRequested) {
        const _0x5e6da318 = _0xffb5254b.detailTabId;
        await _0x42eb60bf((_0x3c262ae9) => {
            _0x3c262ae9.status = _0xe0f6272a85(39);
            _0x3c262ae9.currentStep = _0xe0f6272a85(67);
            _0x3c262ae9.detailTabId = null;
            _0x3c262ae9.logs.push({ time: Date.now(), level: _0xe0f6272a85(19), message: _0xe0f6272a85(76) });
            if (_0x3c262ae9.logs.length > _0x49dc56b2) {
                _0x3c262ae9.logs.splice(0, _0x3c262ae9.logs.length - _0x49dc56b2);
            }
        });
        await _0x4d7e6c30(_0x5e6da318);
        return;
    }
    await _0x17be4e91({
        status: _0xe0f6272a85(8),
        currentStep: _0xffb5254b.detailQueue[_0xffb5254b.detailIndex] || _0xe0f6272a85(42)
    });
    _0xf1800250();
}
async function _0x9a1eb0be(_0x78d73e0f) {
    const _0xe68f85dc = await _0x6799319();
    const _0x457803ad = Date.now();
    if (!_0x78d73e0f && !_0xe68f85dc.authLocked && Number(_0xe68f85dc.authCacheUntil || 0) > _0x457803ad) {
        return true;
    }
    const _0x23308972 = new AbortController();
    const _0x81e910c3 = setTimeout(() => _0x23308972.abort(), _0xebe3c8ed);
    try {
        const _0x6fa19e90 = await fetch(_0xaf72fb4f, {
            method: _0xe0f6272a85(77),
            cache: _0xe0f6272a85(78),
            redirect: _0xe0f6272a85(79),
            credentials: _0xe0f6272a85(80),
            signal: _0x23308972.signal
        });
        if (_0x6fa19e90.status !== 200) {
            return false;
        }
        await _0x17be4e91({
            authLocked: false,
            authCacheUntil: _0x457803ad + _0xd2b411c
        });
        return true;
    }
    catch (_0xcd9ae461) {
        return false;
    }
    finally {
        clearTimeout(_0x81e910c3);
    }
}
async function _0xac536236(_0xa0be987) {
    const _0xe8c47754 = await _0x9a1eb0be(_0xa0be987);
    if (_0xe8c47754) {
        await _0x42eb60bf((_0x56bcfd25) => {
            _0x56bcfd25.authLocked = false;
            _0x56bcfd25.status = _0xe0f6272a85(81);
            _0x56bcfd25.currentStep = _0xe0f6272a85(82);
            _0x56bcfd25.completedAt = Date.now();
            if (!_0x56bcfd25.logs.length || _0x56bcfd25.logs[_0x56bcfd25.logs.length - 1].message !== _0xe0f6272a85(83)) {
                _0x56bcfd25.logs.push({ time: Date.now(), level: _0xe0f6272a85(66), message: _0xe0f6272a85(83) });
            }
            if (_0x56bcfd25.logs.length > _0x49dc56b2) {
                _0x56bcfd25.logs.splice(0, _0x56bcfd25.logs.length - _0x49dc56b2);
            }
        });
    }
    else {
        await _0x42eb60bf((_0x357544ea) => {
            _0x357544ea.authLocked = true;
            _0x357544ea.status = _0xe0f6272a85(53);
            _0x357544ea.currentStep = _0xe0f6272a85(84);
        });
    }
}
async function prepareAndCollectListPage() {
    const _0x932dc2bb = [
        'Waiting to upload return label',
        'Waiting to upload the return label'
    ];
    const _0x71e64808 = 'Sort by shortest remaining processing time (requests with remaining processing time only)';
    const _0xdfded7d9 = (_0xbd975dae) => new Promise((_0x1c4fdb7f) => setTimeout(_0x1c4fdb7f, _0xbd975dae));
    const _0xfa3822cc = (_0x58f0a89d) => String(_0x58f0a89d || '').replace(/\s+/g, ' ').trim();
    const _0xc6a93662 = (_0xa561bc33) => _0xfa3822cc(_0xa561bc33).toLowerCase().replace(/\bthe\b/g, '').replace(/\s+/g, ' ').trim();
    const _0x35a3b80 = (_0xe1128151) => {
        if (!_0xe1128151 || !_0xe1128151.isConnected) {
            return false;
        }
        const _0x4fcb0f26 = getComputedStyle(_0xe1128151);
        const _0x2d8396f7 = _0xe1128151.getBoundingClientRect();
        return _0x4fcb0f26.display !== 'none' && _0x4fcb0f26.visibility !== 'hidden' && _0x2d8396f7.width > 0 && _0x2d8396f7.height > 0;
    };
    const _0x8c7c1c44 = async (_0x6a349a15, _0xc8ede1da = 12000, _0xb6a66fab = 150) => {
        const _0x149ef578 = Date.now();
        let _0xf3577cc9 = null;
        while (Date.now() - _0x149ef578 < _0xc8ede1da) {
            try {
                const _0x510ffa9e = _0x6a349a15();
                if (_0x510ffa9e) {
                    return _0x510ffa9e;
                }
            }
            catch (_0x3ff8406f) {
                _0xf3577cc9 = _0x3ff8406f;
            }
            await _0xdfded7d9(_0xb6a66fab);
        }
        if (_0xf3577cc9) {
            throw _0xf3577cc9;
        }
        throw new Error('等待页面元素超时');
    };
    const _0x9db0ce3c = (_0x7c69558d) => {
        _0x7c69558d.scrollIntoView({ block: 'center', inline: 'center' });
        try {
            _0x7c69558d.focus({ preventScroll: true });
        }
        catch (_0xda21d352) {
            _0x7c69558d.focus();
        }
        const _0xb81a5923 = { bubbles: true, cancelable: true, view: window };
        _0x7c69558d.dispatchEvent(new PointerEvent('pointerdown', _0xb81a5923));
        _0x7c69558d.dispatchEvent(new MouseEvent('mousedown', _0xb81a5923));
        _0x7c69558d.dispatchEvent(new PointerEvent('pointerup', _0xb81a5923));
        _0x7c69558d.dispatchEvent(new MouseEvent('mouseup', _0xb81a5923));
        _0x7c69558d.click();
    };
    const _0x26d2a0f0 = () => Array.from(document.querySelectorAll('[data-testid="beast-core-select-header"]')).filter(_0x35a3b80);
    const _0x848b2e41 = (_0x6343b416) => {
        const _0xc13c33e7 = _0x6343b416.map(_0xc6a93662);
        const _0xaff4b9b4 = _0x26d2a0f0().map((_0xdad0705) => ({
            element: _0xdad0705,
            text: _0xc6a93662(_0xdad0705.innerText || _0xdad0705.textContent)
        }));
        const _0xec658eca = _0xaff4b9b4.find((_0x4a5e149b) => _0xc13c33e7.includes(_0x4a5e149b.text));
        if (_0xec658eca) {
            return _0xec658eca.element;
        }
        const _0x28169268 = _0xaff4b9b4.find((_0x96cf1839) => _0xc13c33e7.some((_0x74b8678e) => _0x96cf1839.text.includes(_0x74b8678e) || _0x74b8678e.includes(_0x96cf1839.text)));
        return _0x28169268 ? _0x28169268.element : null;
    };
    const _0xd370ed5f = (_0xb1296b2c) => {
        const _0x1fe1f2fd = _0xb1296b2c.map(_0xc6a93662);
        return Array.from(document.querySelectorAll('[role="option"]'))
            .filter(_0x35a3b80)
            .find((_0xfdda7842) => _0x1fe1f2fd.includes(_0xc6a93662(_0xfdda7842.innerText || _0xfdda7842.textContent))) || null;
    };
    const _0x5b92c613 = async (_0x3a4b4de0, _0x9803cbb1, _0x6fc5106) => {
        let _0xe4b4d8d7 = _0x848b2e41([..._0x3a4b4de0, ..._0x9803cbb1]);
        if (!_0xe4b4d8d7) {
            throw new Error(`未找到${_0x6fc5106}选择栏`);
        }
        if (_0x9803cbb1.map(_0xc6a93662).includes(_0xc6a93662(_0xe4b4d8d7.innerText || _0xe4b4d8d7.textContent))) {
            return;
        }
        for (let _0x436d26a4 = 0; _0x436d26a4 < 3; _0x436d26a4 += 1) {
            _0x9db0ce3c(_0xe4b4d8d7);
            const _0x2125ac75 = await _0x8c7c1c44(() => _0xd370ed5f(_0x9803cbb1), 2500, 100).catch(() => null);
            if (_0x2125ac75) {
                _0x9db0ce3c(_0x2125ac75);
                const _0x8f1e2a3a = await _0x8c7c1c44(() => {
                    _0xe4b4d8d7 = _0x848b2e41(_0x9803cbb1);
                    return _0xe4b4d8d7 && _0x9803cbb1.map(_0xc6a93662).includes(_0xc6a93662(_0xe4b4d8d7.innerText || _0xe4b4d8d7.textContent));
                }, 5000, 150).catch(() => null);
                if (_0x8f1e2a3a) {
                    await _0xdfded7d9(350);
                    return;
                }
            }
            try {
                _0xe4b4d8d7.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', bubbles: true }));
            }
            catch (_0x6dd6b18b) {
            }
            await _0xdfded7d9(350);
            _0xe4b4d8d7 = _0x848b2e41([..._0x3a4b4de0, ..._0x9803cbb1]) || _0xe4b4d8d7;
        }
        throw new Error(`${_0x6fc5106}未能切换到目标值`);
    };
    const _0xcb8f3f58 = async () => {
        const _0xaa478529 = await _0x8c7c1c44(() => document.querySelector('[data-testid="beast-core-pagination"]'), 12000, 150);
        const _0x8300cfe = () => _0xaa478529.querySelector('[data-testid="beast-core-select-header"]');
        let _0xf6e88a4f = _0x8300cfe();
        if (!_0xf6e88a4f) {
            throw new Error('未找到每页显示数量栏');
        }
        const _0x54a1101c = _0xf6e88a4f.querySelector('input[data-testid="beast-core-select-htmlInput"]');
        if ((_0x54a1101c && _0x54a1101c.value === '100') || _0xc6a93662(_0xf6e88a4f.innerText || _0xf6e88a4f.textContent) === '100') {
            return;
        }
        for (let _0x32999fed = 0; _0x32999fed < 3; _0x32999fed += 1) {
            _0x9db0ce3c(_0xf6e88a4f);
            const _0x9152e5b2 = await _0x8c7c1c44(() => _0xd370ed5f(['100']), 2500, 100).catch(() => null);
            if (_0x9152e5b2) {
                _0x9db0ce3c(_0x9152e5b2);
                const _0x7f0b6303 = await _0x8c7c1c44(() => {
                    _0xf6e88a4f = _0x8300cfe();
                    const _0xddc3ead0 = _0xf6e88a4f && _0xf6e88a4f.querySelector('input[data-testid="beast-core-select-htmlInput"]');
                    return Boolean(_0xddc3ead0 && _0xddc3ead0.value === '100');
                }, 7000, 150).catch(() => null);
                if (_0x7f0b6303) {
                    await _0xdfded7d9(600);
                    return;
                }
            }
            await _0xdfded7d9(350);
        }
        throw new Error('每页显示数量未能切换为100');
    };
    const _0xbbbc70a1 = (_0x1a74fe76, _0xf82d45c7) => {
        const _0x66e5c394 = _0xc6a93662(_0xf82d45c7);
        return Array.from(_0x1a74fe76.querySelectorAll('span,div')).filter((_0xc4de4965) => {
            if (_0xc6a93662(_0xc4de4965.textContent) !== _0x66e5c394) {
                return false;
            }
            return !Array.from(_0xc4de4965.children).some((_0xa296d72a) => _0xc6a93662(_0xa296d72a.textContent) === _0x66e5c394);
        });
    };
    const _0x14f5efb = (_0xef07a448) => {
        _0xef07a448.querySelectorAll('svg,style,script,button,[role="button"]').forEach((_0x4df02219) => _0x4df02219.remove());
    };
    const _0x2ba8a9ee = (_0x8a6137bf, _0x6859bd0c) => {
        const _0xd61204dd = _0xbbbc70a1(_0x8a6137bf, _0x6859bd0c)[0];
        if (!_0xd61204dd) {
            return '';
        }
        let _0xb4ca82a2 = _0xd61204dd.parentElement;
        for (let _0x12830873 = 0; _0xb4ca82a2 && _0xb4ca82a2 !== _0x8a6137bf.parentElement && _0x12830873 < 5; _0x12830873 += 1, _0xb4ca82a2 = _0xb4ca82a2.parentElement) {
            const _0xf17b97c0 = _0xb4ca82a2.cloneNode(true);
            _0x14f5efb(_0xf17b97c0);
            _0xbbbc70a1(_0xf17b97c0, _0x6859bd0c).forEach((_0x5f341d91) => _0x5f341d91.remove());
            let _0x3dec9b66 = _0xfa3822cc(_0xf17b97c0.textContent).replace(new RegExp(_0x6859bd0c.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'ig'), '').trim();
            _0x3dec9b66 = _0x3dec9b66.replace(/^See more\s*/i, '').replace(/\s*See more$/i, '').trim();
            if (_0x3dec9b66 && _0x3dec9b66.length <= 2500) {
                return _0x3dec9b66;
            }
        }
        return '';
    };
    const _0x9ba5e137 = (_0x799e6884, _0xd856f655) => {
        const _0x460f7c1a = [];
        for (const _0x24c7fbeb of _0xbbbc70a1(_0x799e6884, _0xd856f655)) {
            let _0x82b041b8 = _0x24c7fbeb.parentElement;
            let _0x6168cf09 = '';
            for (let _0xcf2156de = 0; _0x82b041b8 && _0x82b041b8 !== _0x799e6884.parentElement && _0xcf2156de < 5; _0xcf2156de += 1, _0x82b041b8 = _0x82b041b8.parentElement) {
                const _0xad19dcaf = _0x82b041b8.cloneNode(true);
                _0x14f5efb(_0xad19dcaf);
                _0xbbbc70a1(_0xad19dcaf, _0xd856f655).forEach((_0xbd25a7c) => _0xbd25a7c.remove());
                let _0xe98aa1cd = _0xfa3822cc(_0xad19dcaf.textContent).replace(new RegExp(_0xd856f655.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'ig'), '').trim();
                _0xe98aa1cd = _0xe98aa1cd.replace(/^See more\s*/i, '').replace(/\s*See more$/i, '').trim();
                if (_0xe98aa1cd && _0xe98aa1cd.length <= 2500) {
                    _0x6168cf09 = _0xe98aa1cd;
                    break;
                }
            }
            if (_0x6168cf09) {
                _0x460f7c1a.push(_0x6168cf09);
            }
        }
        return _0x460f7c1a;
    };
    let _0x48432f92 = document;
    let _0x363bb563 = '';
    const _0x94f43330 = (_0x72acba81) => {
        if (!_0x72acba81 || !_0x72acba81.isConnected) {
            return false;
        }
        const _0xd1650056 = _0xfa3822cc(_0x72acba81.textContent);
        const _0xbf5d8e27 = _0xd1650056.includes('Return ID:') && _0xd1650056.includes('Order ID:') && _0xd1650056.includes('Contribution SKU:')
            && _0xd1650056.includes('Return quantity:') && (_0xd1650056.includes('View return details') || _0xd1650056.includes('Upload return label'));
        if (!_0xbf5d8e27) {
            return false;
        }
        const _0x1d1615f4 = _0xbbbc70a1(_0x72acba81, 'Return ID:').length;
        if (_0x1d1615f4 !== 1) {
            return false;
        }
        const _0xfbce9345 = /^(?:Awaiting (?:the )?upload of (?:the )?return label\.?|Waiting to upload (?:the )?return label\.?)$/i;
        return Array.from(_0x72acba81.querySelectorAll('span,div')).some((_0x5987190a) => {
            const _0x387060db = _0xfa3822cc(_0x5987190a.textContent);
            if (!_0xfbce9345.test(_0x387060db)) {
                return false;
            }
            return !_0x5987190a.closest('[data-testid="beast-core-select-header"]');
        });
    };
    const _0xa628eea8 = (_0x4e17479) => {
        if (!_0x4e17479.length) {
            return null;
        }
        let _0xe2d9f3ce = _0x4e17479[0].parentElement;
        while (_0xe2d9f3ce && _0xe2d9f3ce !== document.body && !_0x4e17479.every((_0x4092799f) => _0xe2d9f3ce.contains(_0x4092799f))) {
            _0xe2d9f3ce = _0xe2d9f3ce.parentElement;
        }
        return _0xe2d9f3ce && _0xe2d9f3ce !== document.body ? _0xe2d9f3ce : null;
    };
    const _0x2f4ac76c = () => {
        if (_0x48432f92 !== document && !_0x48432f92.isConnected) {
            _0x48432f92 = document;
            _0x363bb563 = '';
        }
        if (_0x363bb563) {
            const _0x8d034d3d = Array.from(_0x48432f92.querySelectorAll(_0x363bb563)).filter(_0x94f43330);
            if (_0x8d034d3d.length) {
                return _0x8d034d3d;
            }
        }
        const _0x6bfbd482 = [];
        const _0xc9b45253 = new Set();
        for (const _0xa86cd820 of _0xbbbc70a1(_0x48432f92, 'Return ID:')) {
            let _0x162527f1 = _0xa86cd820.parentElement;
            for (let _0xf41dad46 = 0; _0x162527f1 && _0xf41dad46 < 12; _0xf41dad46 += 1, _0x162527f1 = _0x162527f1.parentElement) {
                if (_0x94f43330(_0x162527f1)) {
                    if (!_0xc9b45253.has(_0x162527f1)) {
                        _0xc9b45253.add(_0x162527f1);
                        _0x6bfbd482.push(_0x162527f1);
                    }
                    break;
                }
            }
        }
        if (_0x6bfbd482.length) {
            const _0x52d62b17 = _0xa628eea8(_0x6bfbd482);
            if (_0x52d62b17) {
                _0x48432f92 = _0x52d62b17;
            }
            const _0x308eb2e4 = _0x6bfbd482[0].classList && _0x6bfbd482[0].classList[0];
            if (_0x308eb2e4 && _0x6bfbd482.every((_0x9f4738b5) => _0x9f4738b5.classList.contains(_0x308eb2e4))) {
                _0x363bb563 = `.${CSS.escape(_0x308eb2e4)}`;
            }
            return _0x6bfbd482;
        }
        if (_0x48432f92 !== document) {
            _0x48432f92 = document;
            _0x363bb563 = '';
            return _0x2f4ac76c();
        }
        return _0x6bfbd482;
    };
    const _0x7d3f867a = (_0xdbe80dcb) => {
        const _0xb9a08b98 = _0xfa3822cc(_0xdbe80dcb.textContent);
        const _0x27991169 = (_0x2ba8a9ee(_0xdbe80dcb, 'Return ID:').match(/PO-\d{3}-\d+-D\d+/i) || _0xb9a08b98.match(/PO-\d{3}-\d+-D\d+/i) || [])[0] || '';
        const _0x86519f3e = (_0x2ba8a9ee(_0xdbe80dcb, 'Order ID:').match(/PO-\d{3}-\d+/i) || _0xb9a08b98.match(/PO-\d{3}-\d+/i) || [])[0] || '';
        const _0x640ae68f = _0x9ba5e137(_0xdbe80dcb, 'Contribution SKU:');
        const _0xc2c36c5c = _0x640ae68f.map((_0xa0bbea2d) => {
            const _0xf7471f2 = _0xa0bbea2d.match(/^([^\s]+)/);
            return _0xf7471f2 ? _0xf7471f2[1] : _0xa0bbea2d;
        }).filter(Boolean);
        const _0xed2cff43 = _0x9ba5e137(_0xdbe80dcb, 'Return quantity:').map((_0x4be54510) => (_0x4be54510.match(/\d+/) || [_0x4be54510])[0]);
        const _0x29ddcce1 = _0x9ba5e137(_0xdbe80dcb, 'Reason for request:');
        const _0x97964ab6 = _0x9ba5e137(_0xdbe80dcb, 'Buyer comment:').map((_0x764ed007) => _0x764ed007.replace(/^See more\s*/i, '').trim());
        const _0xd4075fd4 = /^(\d+)\s+(?:image\(s\)(?:\s+and\s+video\(s\))?|video\(s\))$/i;
        const _0xb2ffa5a5 = Array.from(_0xdbe80dcb.querySelectorAll('span,div')).find((_0x10a8236a) => {
            const _0xff60a93b = _0xfa3822cc(_0x10a8236a.textContent);
            if (!_0xd4075fd4.test(_0xff60a93b)) {
                return false;
            }
            return !Array.from(_0x10a8236a.children).some((_0x5d593088) => _0xd4075fd4.test(_0xfa3822cc(_0x5d593088.textContent)));
        });
        const _0x3b11be59 = _0xfa3822cc(_0xb2ffa5a5 && _0xb2ffa5a5.textContent).match(_0xd4075fd4);
        const _0x99ca042e = _0x3b11be59 && Number(_0x3b11be59[1]) > 0 ? 'Yes' : 'No';
        const _0x78283ff = [];
        const _0xe67b094c = _0xc2c36c5c.length ? _0xc2c36c5c : ['No'];
        _0xe67b094c.forEach((_0x4433971d, _0x22ec1ee2) => {
            _0x78283ff.push({
                key: `${_0x27991169 || _0x86519f3e || 'unknown'}::${_0x4433971d}::${_0x22ec1ee2}`,
                returnId: _0x27991169 || 'ERROR',
                orderId: _0x86519f3e || 'ERROR',
                sku: _0x4433971d || 'No',
                quantity: _0xed2cff43[_0x22ec1ee2] || _0xed2cff43[0] || 'No',
                reason: _0x29ddcce1[_0x22ec1ee2] || _0x29ddcce1[0] || 'No',
                buyerComment: _0x97964ab6[_0x22ec1ee2] || _0x97964ab6[0] || 'No',
                image: _0x99ca042e,
                courier: 'Pending',
                trackingNumber: 'Pending',
                sellerNote: 'Pending',
                detailStatus: 'pending'
            });
        });
        return { returnId: _0x27991169, orderId: _0x86519f3e, rows: _0x78283ff, skuCount: _0xc2c36c5c.length, html: _0xdbe80dcb.outerHTML.slice(0, 160000) };
    };
    const _0x80a564b3 = (_0x6e9de200) => {
        let _0xcd5669d1 = _0x6e9de200 && _0x6e9de200.parentElement;
        while (_0xcd5669d1 && _0xcd5669d1 !== document.body) {
            const _0xab0ef7a6 = getComputedStyle(_0xcd5669d1);
            if (/(auto|scroll)/.test(_0xab0ef7a6.overflowY) && _0xcd5669d1.scrollHeight > _0xcd5669d1.clientHeight + 20) {
                return _0xcd5669d1;
            }
            _0xcd5669d1 = _0xcd5669d1.parentElement;
        }
        return document.scrollingElement || document.documentElement;
    };
    const _0x9c77d77 = () => {
        const _0xf7bfc4c4 = document.querySelector('[data-testid="beast-core-pagination"]');
        const _0x56684295 = _0xfa3822cc(_0xf7bfc4c4 && _0xf7bfc4c4.textContent);
        const _0x3420c85a = _0x56684295.match(/Total\s+(\d+)\s+items/i);
        if (_0x3420c85a) {
            return Number(_0x3420c85a[1]);
        }
        const _0x9219562b = _0xfa3822cc(document.body.textContent);
        const _0x70d1ddf8 = _0x9219562b.match(/(\d+)\s+requests/i);
        if (_0x70d1ddf8) {
            return Number(_0x70d1ddf8[1]);
        }
        if (/(?:there (?:aren\x27t|are not) any return or refund requests|there are no return or refund requests|no (?:return |refund )?requests(?: found)?)/i.test(_0x9219562b)) {
            return 0;
        }
        return null;
    };
    try {
        await _0x8c7c1c44(() => _0x848b2e41(['All pending actions', ..._0x932dc2bb]), 18000, 200);
        await _0x5b92c613(['All pending actions', ..._0x932dc2bb], _0x932dc2bb, 'All pending action');
        await _0x8c7c1c44(() => _0x848b2e41(['Sort by oldest first', 'Sort by newest first', _0x71e64808]), 18000, 200);
        await _0x5b92c613(['Sort by oldest first', 'Sort by newest first', _0x71e64808], [_0x71e64808], '排序');
        await _0xcb8f3f58();
        await _0x8c7c1c44(() => _0x2f4ac76c().length > 0 || _0x9c77d77() === 0, 18000, 200);
        let _0xde8a5b49 = '';
        let _0xbd42a11e = 0;
        const _0x1b3b28ef = Date.now();
        while (Date.now() - _0x1b3b28ef < 5000) {
            const _0xf9f3b6bc = _0x2f4ac76c().map((_0x67ac3c0d) => {
                const _0xc664bbd2 = _0xfa3822cc(_0x67ac3c0d.textContent);
                return (_0xc664bbd2.match(/PO-\d{3}-\d+-D\d+/i) || [''])[0];
            }).filter(Boolean);
            const _0xa45d01a3 = `${_0x9c77d77()}:${_0xf9f3b6bc.join('|')}`;
            if (_0xa45d01a3 === _0xde8a5b49) {
                _0xbd42a11e += 1;
            }
            else {
                _0xde8a5b49 = _0xa45d01a3;
                _0xbd42a11e = 0;
            }
            if (_0xbd42a11e >= 4 && Date.now() - _0x1b3b28ef >= 1400) {
                break;
            }
            await _0xdfded7d9(250);
        }
        const _0x2158f70 = new Map();
        const _0xe0ce16c1 = new Set();
        const _0x4e869c96 = [];
        const _0x2d7f1a67 = new Set();
        const _0x8b286034 = (_0x69e0ef85, _0xd7d9754a) => {
            if (_0x2d7f1a67.has(_0x69e0ef85)) {
                return;
            }
            _0x2d7f1a67.add(_0x69e0ef85);
            _0x4e869c96.push(_0xd7d9754a);
        };
        let _0xb591f31b = _0x2f4ac76c();
        const _0x144a7ae8 = _0x80a564b3(_0xb591f31b[0]);
        let _0xf202c0b9 = 0;
        let _0x50fb4e0e = -1;
        const _0x3eb3d5df = _0x9c77d77();
        const _0x9d6c53ac = _0x3eb3d5df === null ? null : Math.min(_0x3eb3d5df, 100);
        const _0x7b24d97d = _0x9d6c53ac === null
            ? 100
            : Math.min(160, Math.max(60, Math.ceil(_0x9d6c53ac * 1.4)));
        for (let _0xd91d20c2 = 0; _0xd91d20c2 < _0x7b24d97d; _0xd91d20c2 += 1) {
            _0xb591f31b = _0x2f4ac76c();
            for (const _0x47d5ae93 of _0xb591f31b) {
                const _0x258e3460 = _0xfa3822cc(_0x47d5ae93.textContent);
                const _0x8446b231 = (_0x258e3460.match(/PO-\d{3}-\d+-D\d+/i) || [])[0] || '';
                if (_0x8446b231 && _0xe0ce16c1.has(_0x8446b231)) {
                    continue;
                }
                const _0x623f3986 = _0x7d3f867a(_0x47d5ae93);
                if (_0x623f3986.returnId) {
                    _0xe0ce16c1.add(_0x623f3986.returnId);
                }
                for (const _0xc0f78757 of _0x623f3986.rows) {
                    _0x2158f70.set(_0xc0f78757.key, _0xc0f78757);
                }
                if (_0x623f3986.skuCount > 1) {
                    _0x8b286034(`MULTI_SKU_CARD::${_0x623f3986.returnId || _0x623f3986.orderId || _0x623f3986.html.slice(0, 120)}`, {
                        type: 'MULTI_SKU_CARD',
                        message: `同一退货卡片包含 ${_0x623f3986.skuCount} 个 Contribution SKU。`,
                        url: location.href,
                        orderId: _0x623f3986.orderId,
                        html: _0x623f3986.html
                    });
                }
                if (!_0x623f3986.returnId || !_0x623f3986.orderId) {
                    _0x8b286034(`CARD_CORE_FIELD_UNRECOGNIZED::${_0x623f3986.returnId || _0x623f3986.orderId || _0x623f3986.html.slice(0, 120)}`, {
                        type: 'CARD_CORE_FIELD_UNRECOGNIZED',
                        message: '退货卡片未能稳定识别 Return ID 或 Order ID。',
                        url: location.href,
                        orderId: _0x623f3986.orderId,
                        html: _0x623f3986.html
                    });
                }
            }
            if (_0xe0ce16c1.size === _0x50fb4e0e) {
                _0xf202c0b9 += 1;
            }
            else {
                _0xf202c0b9 = 0;
                _0x50fb4e0e = _0xe0ce16c1.size;
            }
            if (_0x9d6c53ac !== null && _0xe0ce16c1.size >= _0x9d6c53ac) {
                break;
            }
            const _0xaea00d24 = Math.max(0, _0x144a7ae8.scrollHeight - _0x144a7ae8.clientHeight);
            const _0xc9894f5 = _0x144a7ae8 === document.scrollingElement || _0x144a7ae8 === document.documentElement
                ? window.scrollY
                : _0x144a7ae8.scrollTop;
            if (_0xc9894f5 >= _0xaea00d24 - 5) {
                if (_0xf202c0b9 >= 12) {
                    break;
                }
            }
            else {
                const _0xeb5112ba = Math.min(_0xaea00d24, _0xc9894f5 + Math.max(400, _0x144a7ae8.clientHeight * 0.8));
                if (_0x144a7ae8 === document.scrollingElement || _0x144a7ae8 === document.documentElement) {
                    window.scrollTo(0, _0xeb5112ba);
                }
                else {
                    _0x144a7ae8.scrollTop = _0xeb5112ba;
                }
            }
            await _0xdfded7d9(180);
        }
        if (_0x144a7ae8 === document.scrollingElement || _0x144a7ae8 === document.documentElement) {
            window.scrollTo(0, 0);
        }
        else {
            _0x144a7ae8.scrollTop = 0;
        }
        if (_0x9d6c53ac !== null && _0xe0ce16c1.size < _0x9d6c53ac) {
            const _0x4909980b = {
                type: 'LIST_CARD_COUNT_MISMATCH',
                message: `页面显示 ${_0x9d6c53ac} 个请求，但只稳定采集到 ${_0xe0ce16c1.size} 个 Return ID。为避免产生不完整表格，本轮采集不写入结果。`,
                url: location.href,
                orderId: '',
                html: document.documentElement.outerHTML.slice(0, 160000)
            };
            return {
                ok: false,
                error: _0x4909980b.message,
                anomaly: _0x4909980b
            };
        }
        const _0x37c2e7d8 = Array.from(_0x2158f70.values());
        if (_0x9d6c53ac !== 0 && _0x37c2e7d8.length === 0) {
            throw new Error('页面存在退货请求，但未采集到任何卡片数据');
        }
        return {
            ok: true,
            rows: _0x37c2e7d8,
            cardCount: _0xe0ce16c1.size,
            totalCount: _0x3eb3d5df,
            anomalies: _0x4e869c96
        };
    }
    catch (_0x95bb6da9) {
        return {
            ok: false,
            error: _0x95bb6da9.message || String(_0x95bb6da9),
            anomaly: {
                type: 'LIST_PAGE_SETUP_OR_COLLECTION_FAILED',
                message: _0x95bb6da9.message || String(_0x95bb6da9),
                url: location.href,
                orderId: '',
                html: document.documentElement.outerHTML.slice(0, 160000)
            }
        };
    }
}
async function extractOrderDetailPage(_0x7473eb7e) {
    const _0xd22c72cf = (_0xb0e4f89c) => new Promise((_0x1edd466d) => setTimeout(_0x1edd466d, _0xb0e4f89c));
    const _0xfc95cc32 = (_0x5b4e4b83) => String(_0x5b4e4b83 || '').replace(/\s+/g, ' ').trim();
    const _0x3906d150 = (_0xa7ff5f21) => _0xfc95cc32(_0xa7ff5f21).toLowerCase();
    const _0x5b7a6f6 = (_0xe4602c47, _0x4258aa14) => {
        const _0x201131e5 = _0x3906d150(_0x4258aa14);
        return Array.from(_0xe4602c47.querySelectorAll('span,div')).filter((_0x8ec9bfaa) => {
            if (_0x3906d150(_0x8ec9bfaa.textContent) !== _0x201131e5) {
                return false;
            }
            return !Array.from(_0x8ec9bfaa.children).some((_0x6c82057b) => _0x3906d150(_0x6c82057b.textContent) === _0x201131e5);
        });
    };
    const _0xcb7a8cc8 = (_0xa9330a99) => {
        _0xa9330a99.querySelectorAll('svg,style,script,button,[role="button"]').forEach((_0x17eb906e) => _0x17eb906e.remove());
    };
    const _0xf5a41e3f = (_0x539d658c, _0x3255e35d) => {
        const _0x900e6922 = _0x5b7a6f6(_0x539d658c, _0x3255e35d)[0];
        if (!_0x900e6922) {
            return '';
        }
        const _0x7ec6f0f3 = new Set([
            'courier', 'tracking number', 'shipment confirmed at', 'shipping from',
            'shipping address', 'see more', 'add a note', 'package lost or damage', 'file a claim'
        ]);
        let _0xdcbf7e40 = _0x900e6922.parentElement;
        for (let _0xbb77c411 = 0; _0xdcbf7e40 && _0xdcbf7e40 !== _0x539d658c.parentElement && _0xbb77c411 < 7; _0xbb77c411 += 1, _0xdcbf7e40 = _0xdcbf7e40.parentElement) {
            const _0x192043e6 = [];
            if (_0xdcbf7e40.matches && _0xdcbf7e40.matches('span,div')) {
                _0x192043e6.push(_0xdcbf7e40);
            }
            _0x192043e6.push(..._0xdcbf7e40.querySelectorAll('span,div'));
            const _0x8718c9b7 = _0x192043e6.filter((_0x65d15704, _0xc389ded5) => {
                if (_0x192043e6.indexOf(_0x65d15704) !== _0xc389ded5) {
                    return false;
                }
                const _0xa242249a = _0xfc95cc32(_0x65d15704.textContent);
                if (!_0xa242249a) {
                    return false;
                }
                return !Array.from(_0x65d15704.children).some((_0x3aa26b) => _0xfc95cc32(_0x3aa26b.textContent));
            });
            let _0xeef32838;
            const _0x4cabb789 = _0x8718c9b7.indexOf(_0x900e6922);
            if (_0x4cabb789 >= 0) {
                _0xeef32838 = _0x8718c9b7.slice(_0x4cabb789 + 1);
            }
            else {
                _0xeef32838 = _0x8718c9b7.filter((_0x2b643d5e) => Boolean(_0x900e6922.compareDocumentPosition(_0x2b643d5e) & Node.DOCUMENT_POSITION_FOLLOWING));
            }
            const _0x895cbb2f = _0xeef32838.map((_0x771502fc) => _0xfc95cc32(_0x771502fc.textContent)).filter((_0xd5cd884d) => {
                const _0xb3861612 = _0x3906d150(_0xd5cd884d);
                return _0xd5cd884d && _0xd5cd884d.length <= 300 && !_0x7ec6f0f3.has(_0xb3861612);
            });
            if (_0x3906d150(_0x3255e35d) === 'tracking number') {
                const _0x127e9de3 = _0x895cbb2f.find((_0xf0371bb0) => /\d{7,}/.test(_0xf0371bb0) || (/^[A-Z0-9-]{6,}$/i.test(_0xf0371bb0) && /\d/.test(_0xf0371bb0)));
                if (_0x127e9de3) {
                    return _0x127e9de3;
                }
            }
            else if (_0x3906d150(_0x3255e35d) === 'courier') {
                const _0x5ee06101 = _0x895cbb2f.find((_0x3cd8e8d6) => /[A-Z]/i.test(_0x3cd8e8d6) && !/^\d+$/.test(_0x3cd8e8d6) && !/^(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\b/i.test(_0x3cd8e8d6));
                if (_0x5ee06101) {
                    return _0x5ee06101;
                }
            }
            else if (_0x895cbb2f.length) {
                return _0x895cbb2f[0];
            }
        }
        return '';
    };
    const _0x9a9176a7 = (_0x7949fc74, _0xe7027bc5, _0x45fac18a = 10) => {
        let _0x23b34f5b = _0x7949fc74 && _0x7949fc74.parentElement;
        for (let _0x826bd528 = 0; _0x23b34f5b && _0x826bd528 < _0x45fac18a; _0x826bd528 += 1, _0x23b34f5b = _0x23b34f5b.parentElement) {
            if (_0xe7027bc5(_0x23b34f5b)) {
                return _0x23b34f5b;
            }
        }
        return null;
    };
    const _0x60245cf9 = async () => {
        const _0xce1cda4e = Date.now();
        let _0xacd5201f = '';
        let _0xa8dafec = 0;
        while (Date.now() - _0xce1cda4e < 12000) {
            const _0xe94635bd = _0xfc95cc32(document.body && document.body.textContent);
            if (/sign in|log in|verification required|access denied/i.test(_0xe94635bd) && !_0xe94635bd.includes('Seller notes')) {
                return { accessProblem: true };
            }
            const _0x573eb302 = _0x5b7a6f6(document, 'Seller notes').length;
            const _0x35f73ad3 = _0x5b7a6f6(document, 'Courier').length;
            const _0x93af80a0 = _0x5b7a6f6(document, 'Tracking number').length;
            const _0x71980e71 = [_0x573eb302, _0x35f73ad3, _0x93af80a0, _0xe94635bd.length].join(':');
            if (_0x71980e71 === _0xacd5201f) {
                _0xa8dafec += 1;
            }
            else {
                _0xa8dafec = 0;
            }
            _0xacd5201f = _0x71980e71;
            const _0xd05095c6 = Date.now() - _0xce1cda4e;
            const _0xbe091397 = _0x573eb302 > 0;
            const _0x1cc19964 = _0x35f73ad3 > 0 || _0x93af80a0 > 0;
            if (_0xbe091397 && _0x1cc19964 && _0xa8dafec >= 3 && _0xd05095c6 >= 900) {
                return { accessProblem: false };
            }
            if ((_0xbe091397 || _0x1cc19964) && _0xa8dafec >= 4 && _0xd05095c6 >= 4500) {
                return { accessProblem: false, partialSignals: true };
            }
            await _0xd22c72cf(300);
        }
        return { accessProblem: false, timedOut: true };
    };
    try {
        const _0xfabae735 = await _0x60245cf9();
        const _0x59736efa = _0xfc95cc32(document.body && document.body.textContent);
        const _0xc72bf44b = [];
        if (_0xfabae735.accessProblem) {
            return {
                ok: false,
                error: '订单详情页处于登录、验证或无权限状态',
                anomalies: [{
                        type: 'LOGIN_OR_ACCESS_PAGE',
                        message: '订单详情页未进入正常订单内容。',
                        url: location.href,
                        orderId: _0x7473eb7e,
                        html: document.documentElement.outerHTML.slice(0, 160000)
                    }]
            };
        }
        const _0xa5e47218 = _0x5b7a6f6(document, 'Seller notes')[0];
        let _0x3dcf9e9 = null;
        if (_0xa5e47218) {
            _0x3dcf9e9 = _0x9a9176a7(_0xa5e47218, (_0xe19547be) => {
                const _0x404dcd0f = _0xfc95cc32(_0xe19547be.textContent);
                return _0x404dcd0f.includes('Seller notes') && _0x404dcd0f.includes('Add a note') && _0x404dcd0f.length < 20000;
            }, 8);
        }
        let _0x2e0654dc = _0x3dcf9e9 ? 'No' : 'ERROR';
        if (_0x3dcf9e9) {
            const _0x8cfed2ad = /\b(?:GLS|DHL|DPD)(?=\b|\d)/i;
            const _0x6ab75872 = Array.from(_0x3dcf9e9.querySelectorAll('span,div')).filter((_0xc96fa7c3) => {
                const _0xb7582d90 = _0xfc95cc32(_0xc96fa7c3.textContent);
                if (!_0x8cfed2ad.test(_0xb7582d90)) {
                    return false;
                }
                return !Array.from(_0xc96fa7c3.children).some((_0x1510ab61) => _0x8cfed2ad.test(_0xfc95cc32(_0x1510ab61.textContent)));
            });
            const _0xf3c93136 = [];
            for (const _0x5181b887 of _0x6ab75872) {
                const _0x307a0654 = _0xfc95cc32(_0x5181b887.textContent);
                if (_0x307a0654 && !_0xf3c93136.includes(_0x307a0654)) {
                    _0xf3c93136.push(_0x307a0654);
                }
            }
            if (_0xf3c93136.length) {
                _0x2e0654dc = _0xf3c93136.join(' | ');
            }
        }
        else {
            _0xc72bf44b.push({
                type: 'SELLER_NOTES_MODULE_MISSING',
                message: '订单详情页未找到 Seller notes 模块，无法确认是无内容还是页面结构变化，字段按 ERROR 记录。',
                url: location.href,
                orderId: _0x7473eb7e,
                html: document.documentElement.outerHTML.slice(0, 160000)
            });
        }
        const _0x9e328c25 = _0x5b7a6f6(document, 'Courier');
        const _0x7ceb0bea = _0x5b7a6f6(document, 'Tracking number');
        const _0xdaa391bb = [];
        const _0xb89c1f08 = new Set();
        for (const _0x275566d9 of [..._0x9e328c25, ..._0x7ceb0bea]) {
            const _0x850decae = _0x9a9176a7(_0x275566d9, (_0x63c66a7f) => {
                const _0xc1bef1cc = _0xfc95cc32(_0x63c66a7f.textContent);
                return _0xc1bef1cc.includes('Courier') && _0xc1bef1cc.includes('Tracking number') && _0xc1bef1cc.length < 80000;
            }, 9);
            if (_0x850decae && !_0xb89c1f08.has(_0x850decae)) {
                _0xb89c1f08.add(_0x850decae);
                _0xdaa391bb.push(_0x850decae);
            }
        }
        const _0xa0777f9d = [];
        const _0xe2fc562 = [];
        let _0xec184333 = false;
        let _0x4ad0ca80 = false;
        for (const _0x28895051 of _0xdaa391bb) {
            let _0x9741de26 = _0xf5a41e3f(_0x28895051, 'Courier');
            let _0x753a25f7 = _0xf5a41e3f(_0x28895051, 'Tracking number');
            if (_0x9741de26) {
                _0x9741de26 = _0x9741de26.replace(/^Courier\s*/i, '').trim();
            }
            if (_0x753a25f7) {
                const _0xd3f2a344 = _0x753a25f7.match(/\d{7,}/);
                const _0xb1ab2915 = _0x753a25f7.match(/[A-Z0-9][A-Z0-9-]{5,}/i);
                _0x753a25f7 = _0xd3f2a344 ? _0xd3f2a344[0] : (_0xb1ab2915 ? _0xb1ab2915[0] : _0x753a25f7);
            }
            if (_0x9741de26 && !_0xa0777f9d.includes(_0x9741de26)) {
                _0xa0777f9d.push(_0x9741de26);
            }
            if (_0x753a25f7 && !_0xe2fc562.includes(_0x753a25f7)) {
                _0xe2fc562.push(_0x753a25f7);
            }
            if (!_0x9741de26) {
                _0xec184333 = true;
                _0xc72bf44b.push({
                    type: 'COURIER_VALUE_UNRECOGNIZED',
                    message: '找到 Courier 标签，但未稳定识别物流商。',
                    url: location.href,
                    orderId: _0x7473eb7e,
                    html: _0x28895051.outerHTML.slice(0, 160000)
                });
            }
            if (!_0x753a25f7) {
                _0x4ad0ca80 = true;
                _0xc72bf44b.push({
                    type: 'TRACKING_VALUE_UNRECOGNIZED',
                    message: '找到 Tracking number 标签，但未稳定识别运单号。',
                    url: location.href,
                    orderId: _0x7473eb7e,
                    html: _0x28895051.outerHTML.slice(0, 160000)
                });
            }
        }
        if ((_0x9e328c25.length || _0x7ceb0bea.length) && _0xdaa391bb.length === 0) {
            if (_0x9e328c25.length) {
                _0xec184333 = true;
            }
            if (_0x7ceb0bea.length) {
                _0x4ad0ca80 = true;
            }
            _0xc72bf44b.push({
                type: 'SHIPMENT_MODULE_STRUCTURE_UNRECOGNIZED',
                message: '页面存在 Courier 或 Tracking number 标签，但未识别到完整物流模块。',
                url: location.href,
                orderId: _0x7473eb7e,
                html: document.documentElement.outerHTML.slice(0, 160000)
            });
        }
        if (_0xdaa391bb.length > 1) {
            _0xc72bf44b.push({
                type: 'MULTI_SHIPMENT_DETAIL',
                message: `订单详情存在 ${_0xdaa391bb.length} 个物流模块，已按页面顺序合并。`,
                url: location.href,
                orderId: _0x7473eb7e,
                html: _0xdaa391bb.map((_0x1063b0da) => _0x1063b0da.outerHTML).join('\n\n').slice(0, 160000)
            });
        }
        if (_0xfabae735.timedOut && !_0xa5e47218 && !_0x9e328c25.length && !_0x7ceb0bea.length) {
            return {
                ok: false,
                error: '订单详情页面结构在等待时间内未就绪',
                anomalies: [{
                        type: 'DETAIL_PAGE_UNRECOGNIZED',
                        message: '等待后仍未找到 Seller notes、Courier 或 Tracking number。',
                        url: location.href,
                        orderId: _0x7473eb7e,
                        html: document.documentElement.outerHTML.slice(0, 160000)
                    }]
            };
        }
        const _0xfe5c3eab = _0x59736efa.includes(_0x7473eb7e) || location.href.includes(encodeURIComponent(_0x7473eb7e)) || location.href.includes(_0x7473eb7e);
        if (!_0xfe5c3eab) {
            _0xc72bf44b.push({
                type: 'DETAIL_ORDER_ID_NOT_CONFIRMED',
                message: '详情页中未确认到目标 Order ID，但仍按当前页面提取结果。',
                url: location.href,
                orderId: _0x7473eb7e,
                html: document.documentElement.outerHTML.slice(0, 160000)
            });
        }
        return {
            ok: true,
            courier: _0xa0777f9d.length ? _0xa0777f9d.join(' | ') : (_0xec184333 ? 'ERROR' : 'No'),
            trackingNumber: _0xe2fc562.length ? _0xe2fc562.join(' | ') : (_0x4ad0ca80 ? 'ERROR' : 'No'),
            sellerNote: _0x2e0654dc,
            anomalies: _0xc72bf44b
        };
    }
    catch (_0x5c148478) {
        return {
            ok: false,
            error: _0x5c148478.message || String(_0x5c148478),
            anomalies: [{
                    type: 'DETAIL_EXTRACTION_EXCEPTION',
                    message: _0x5c148478.message || String(_0x5c148478),
                    url: location.href,
                    orderId: _0x7473eb7e,
                    html: document.documentElement.outerHTML.slice(0, 160000)
                }]
        };
    }
}
chrome.action.onClicked.addListener((_0x3acd03c9) => {
    _0xecaa395a(_0x3acd03c9).catch(() => { });
});
chrome.runtime.onInstalled.addListener(() => {
    _0x6799319().then((_0x9885899e) => chrome.storage.local.set({ [_0x2650e28b]: _0x9885899e })).catch(() => { });
});
chrome.runtime.onStartup.addListener(() => {
    _0xf1800250();
});
chrome.runtime.onMessage.addListener((_0x77e176f, _0xe5369d3c, _0x43efe48d) => {
    (async () => {
        switch (_0x77e176f && _0x77e176f.type) {
            case _0xe0f6272a85(85): {
                const _0x21d86252 = _0xe5369d3c && _0xe5369d3c.tab && _0xe5369d3c.tab.windowId;
                if (Number.isInteger(_0x21d86252)) {
                    await _0x17be4e91({ panelWindowId: _0x21d86252 });
                }
                _0xf1800250();
                return { ok: true };
            }
            case _0xe0f6272a85(86):
                await _0xbcc0e331();
                return { ok: true };
            case _0xe0f6272a85(87):
                await _0x4e04dea9();
                return { ok: true };
            case _0xe0f6272a85(88):
                await _0xd726b76d();
                return { ok: true };
            case _0xe0f6272a85(89):
                _0xf1800250();
                return { ok: true };
            case _0xe0f6272a85(90):
                await _0xac536236(true);
                return { ok: true };
            case _0xe0f6272a85(91):
                await _0xb27de7bc();
                return { ok: true };
            case _0xe0f6272a85(92):
                await _0xa5b62843(_0x77e176f.url);
                return { ok: true };
            default:
                return { ok: false, error: _0xe0f6272a85(93) };
        }
    })().then(_0x43efe48d).catch((_0x8f90e823) => {
        _0x43efe48d({ ok: false, error: _0x8f90e823.message || String(_0x8f90e823) });
    });
    return true;
});
chrome.tabs.onActivated.addListener((_0x6e4977f0) => {
    _0x6799319().then((_0xcc01fd41) => {
        if (![_0xe0f6272a85(5), _0xe0f6272a85(6), _0xe0f6272a85(7)].includes(_0xcc01fd41.status)) {
            return;
        }
        if (!Number.isInteger(_0xcc01fd41.listTabId) || !Number.isInteger(_0xcc01fd41.listWindowId)) {
            return;
        }
        if (_0x6e4977f0.windowId === _0xcc01fd41.listWindowId && _0x6e4977f0.tabId !== _0xcc01fd41.listTabId) {
            _0xd0e34269(_0xe0f6272a85(15), false).catch(() => { });
        }
    }).catch(() => { });
});
chrome.tabs.onUpdated.addListener((_0xaafa7b16, _0x8b2c2e7) => {
    if (_0x8b2c2e7.status !== _0xe0f6272a85(23)) {
        return;
    }
    _0x6799319().then((_0xf76b48b4) => {
        if (_0xaafa7b16 === _0xf76b48b4.listTabId || _0xaafa7b16 === _0xf76b48b4.detailTabId) {
            _0xf1800250();
        }
    }).catch(() => { });
});
chrome.tabs.onRemoved.addListener((_0x5523d605) => {
    _0x6799319().then(async (_0x331c5dca) => {
        if (_0x5523d605 === _0x331c5dca.listTabId) {
            await _0x17be4e91({ listTabId: null, listWindowId: null });
            if ([_0xe0f6272a85(5), _0xe0f6272a85(6), _0xe0f6272a85(7)].includes(_0x331c5dca.status)) {
                await _0x32e7d984(_0xe0f6272a85(19), _0xe0f6272a85(94));
                _0xf1800250();
            }
        }
        if (_0x5523d605 === _0x331c5dca.detailTabId) {
            await _0x17be4e91({ detailTabId: null });
            if ([_0xe0f6272a85(8), _0xe0f6272a85(9)].includes(_0x331c5dca.status) && !_0x331c5dca.pauseRequested) {
                await _0x32e7d984(_0xe0f6272a85(19), _0xe0f6272a85(95));
                _0xf1800250();
            }
        }
    }).catch(() => { });
});
chrome.windows.onFocusChanged.addListener((_0x91d4db9b) => {
    if (!Number.isInteger(_0x91d4db9b) || _0x91d4db9b < 0) {
        return;
    }
    _0x6799319().then(async (_0x7f8d2168) => {
        if ([_0xe0f6272a85(5), _0xe0f6272a85(6), _0xe0f6272a85(7)].includes(_0x7f8d2168.status)) {
            return;
        }
        const _0xde45af39 = await _0x77a7ff27(_0x91d4db9b);
        if (_0xde45af39 && _0xde45af39.type === _0xe0f6272a85(16) && _0x91d4db9b !== _0x7f8d2168.sourceWindowId) {
            await _0x17be4e91({ sourceWindowId: _0x91d4db9b });
        }
    }).catch(() => { });
});
chrome.windows.onRemoved.addListener((_0xbc3e368e) => {
    _0x6799319().then(async (_0x1af6bc5f) => {
        if (_0xbc3e368e === _0x1af6bc5f.sourceWindowId || _0xbc3e368e === _0x1af6bc5f.listWindowId) {
            await _0x17be4e91({
                sourceWindowId: _0xbc3e368e === _0x1af6bc5f.sourceWindowId ? null : _0x1af6bc5f.sourceWindowId,
                listWindowId: _0xbc3e368e === _0x1af6bc5f.listWindowId ? null : _0x1af6bc5f.listWindowId
            });
        }
        if (_0xbc3e368e !== _0x1af6bc5f.panelWindowId) {
            return;
        }
        await _0x42eb60bf((_0xf8af3a2c) => {
            _0xf8af3a2c.panelWindowId = null;
            if (_0x964d5bd0.has(_0xf8af3a2c.status) && _0xf8af3a2c.status !== _0xe0f6272a85(10)) {
                _0xf8af3a2c.pauseRequested = true;
                _0xf8af3a2c.closePanelRequested = true;
                const _0x676781fd = [_0xe0f6272a85(5), _0xe0f6272a85(6), _0xe0f6272a85(7)].includes(_0xf8af3a2c.status);
                if (!_0x676781fd) {
                    _0xf8af3a2c.status = _0xe0f6272a85(9);
                }
                _0xf8af3a2c.currentStep = _0xf8af3a2c.currentOrderId || (_0x676781fd ? _0xe0f6272a85(48) : _0xe0f6272a85(49));
                _0xf8af3a2c.logs.push({
                    time: Date.now(),
                    level: _0xe0f6272a85(19),
                    message: _0x676781fd ? _0xe0f6272a85(96) : _0xe0f6272a85(97)
                });
                if (_0xf8af3a2c.logs.length > _0x49dc56b2) {
                    _0xf8af3a2c.logs.splice(0, _0xf8af3a2c.logs.length - _0x49dc56b2);
                }
            }
        });
        _0xf1800250();
    }).catch(() => { });
});
_0x6799319().then((_0xc5500f42) => {
    chrome.storage.local.set({ [_0x2650e28b]: _0xc5500f42 }).catch(() => { });
    if (_0x964d5bd0.has(_0xc5500f42.status)) {
        _0xf1800250();
    }
}).catch(() => { });
