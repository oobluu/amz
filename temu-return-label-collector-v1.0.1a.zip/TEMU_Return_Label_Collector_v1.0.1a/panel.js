const _0x8566c2218a=[[234,246,246,242,241,184,173,173,241,231,238,238,231,240,175,231,247,172,246,231,239,247,172,225,237,239,173,237,240,230,231,240,175,230,231,246,227,235,238,172,234,246,239,238,189,242,227,240,231,236,246,221,237,240,230,231,240,221,241,236,191],[164,221,250,221,241,231,241,241,236,221,235,230,191,250,176,242,177,243,244,177,247,251,247,164,240,231,228,231,240,221,242,227,229,231,221,236,227,239,231,191,240,231,246,247,240,236,175,240,231,228,247,236,230,175,238,235,241,246,164,240,231,228,231,240,221,242,227,229,231,221,235,230,191,176,178,177,186,183,221,179,181,186,180,182,178,187,182,181,178,181,179,178,221,234,228,224,186,248,248,186,183,232,179,164,240,231,228,231,240,221,242,227,229,231,221,241,236,191,176,178,177,186,183],[225,237,238,238,231,225,246,237,240,209,246,227,246,231],[227,242,242,209,234,231,238,238],[244,231,240,241,235,237,236,214,231,250,246],[241,246,227,246,247,241,198,237,246],[241,246,227,246,247,241,214,231,250,246],[241,246,227,240,246,192,247,246,246,237,236],[242,227,247,241,231,192,247,246,246,237,236],[225,237,242,251,192,247,246,246,237,236],[225,238,231,227,240,192,247,246,246,237,236],[240,237,245,193,237,247,236,246],[237,240,230,231,240,210,240,237,229,240,231,241,241],[231,240,240,237,240,193,237,247,236,246],[225,247,240,240,231,236,246,209,246,231,242],[238,227,241,246,215,242,230,227,246,231,230],[240,231,225,237,240,230,241,192,237,230,251],[238,237,229,206,235,241,246],[238,237,229,193,237,247,236,246],[246,237,227,241,246],[238,237,225,233,207,237,230,227,238],[240,231,225,234,231,225,233,192,247,246,246,237,236],[225,238,237,241,231,213,235,236,230,237,245,192,247,246,246,237,236],[31480,38256],[27617,22442,25297,24450,36994,36261,21141,35050],[27617,22442,35644,32748,21141,35050,26595,20084],[27617,22442,37189,38468,21475,29381,20323,24813],[27617,22442,35705,21332,35616,21463,35684,24647],[23684,22442,24529,21199,35616,21463,23310,25234,21644,26112,20702],[23920,26112,20702],[27617,22442,23310,25234,25321,25421],[25321,25421,23310,25234],[20089,21027,24448,24250,20702,27616],[23920,38275,23320],[237,242,231,236,235,236,229,175,238,235,241,246],[225,237,236,228,235,229,247,240,235,236,229,175,238,235,241,246],[225,237,238,238,231,225,246,235,236,229,175,238,235,241,246],[242,240,237,225,231,241,241,235,236,229,175,230,231,246,227,235,238,241],[242,227,247,241,231,175,242,231,236,230,235,236,229],[244,227,238,235,230,227,246,235,236,229],[],[204,237],[162],[23704,26536,25321,25421],[248,234,175,193,204],[236,247,239,231,240,235,225],[176,175,230,235,229,235,246],[241,234,237,245],[25679,20446,22963,36263],[241,246,227,246,247,241,175,230,237,246],[240,247,236,236,235,236,229],[225,237,239,242,238,231,246,231,230],[241,247,225,225,231,241,241],[242,227,247,241,231,230],[245,227,240,236,235,236,229],[231,240,240,237,240],[227,247,246,234,175,238,237,225,233,231,230],[246,240],[231,239,242,246,251,175,240,237,245],[246,230],[26112,25954,23911,20446,35634,24535],[240,237,245,175,231,240,240,237,240],[230,237,236,231],[240,237,245,175,242,231,236,230,235,236,229],[227],[221,224,238,227,236,233],[236,237,237,242,231,236,231,240,162,236,237,240,231,228,231,240,240,231,240],[225,238,235,225,233],[205,210,199,204,221,198,199,214,195,203,206,221,206,203,204,201],[230,235,244],[238,237,229,175,231,239,242,246,251],[26112,25954,25959,24405],[235,236,228,237],[241,242,227,236],[238,237,229,175,246,235,239,231],[238,237,229,175,238,231,244,231,238],[234,235,230,230,231,236],[227,240,235,227,175,234,235,230,230,231,236],[228,227,238,241,231],[246,240,247,231],[238,237,225,233,231,230],[235,230,238,231],[8342],[32357,32367,25321,25421],[24450,22857,25321,25421],[164,227,239,242,185],[164,238,246,185],[164,229,246,185],[164,243,247,237,246,185],[164,161,178,177,187,185],[27683,26507,21357,22927,21172,30214,23911,20446,35634,24535],[208,231,246,247,240,236,162,203,198],[205,240,230,231,240,162,203,198],[193,237,236,246,240,235,224,247,246,235,237,236,162,209,201,215],[211,247,227,236,246,235,246,251],[208,231,227,241,237,236],[192,247,251,231,240,162,225,237,239,239,231,236,246],[203,239,227,229,231],[193,237,247,240,235,231,240],[214,240,227,225,233,235,236,229,162,236,247,239,224,231,240],[209,231,238,238,231,240,162,236,237,246,231],[139],[143,136],[190,246,240,188],[190,173,246,240,188],[246,231,250,246,173,242,238,227,235,236],[246,231,250,246,173,234,246,239,238],[246,231,250,246,227,240,231,227],[240,231,227,230,237,236,238,251],[228,235,250,231,230],[178],[225,237,242,251],[28109,35146,22250,25168,32351,35645,38252,21224,36278,26621],[210,195,204,199,206,221,208,199,195,198,219],[209,214,195,208,214,221,209,193,195,204],[210,195,215,209,199,221,209,193,195,204],[23684,22442,24529,21199,35616,21463,22918,29828,23310,25234,21644,26112,20702],[193,206,199,195,208,221,208,199,193,205,208,198,209],[23911,20446,35634,24535,21518,23911,20446,25959,24405,23920,28295,31480],[195,215,214,202,221,208,199,193,202,199,193,201],[193,206,205,209,199,221,210,195,204,199,206],[238,237,225,227,238],[199,204,197,203,204,199,221,201,203,193,201]];const _0x8f31c5a87a=(_0xi)=>String.fromCharCode(..._0x8566c2218a[_0xi].map((_0xc)=>_0xc^130));(() => {
    const _0x1db0739e = _0x8f31c5a87a(0);
    const _0xbfe9f94d = _0x8f31c5a87a(1);
    const _0x5921673c = _0x8f31c5a87a(2);
    const _0xfb5aeceb = {
        appShell: document.getElementById(_0x8f31c5a87a(3)),
        versionText: document.getElementById(_0x8f31c5a87a(4)),
        statusDot: document.getElementById(_0x8f31c5a87a(5)),
        statusText: document.getElementById(_0x8f31c5a87a(6)),
        startButton: document.getElementById(_0x8f31c5a87a(7)),
        pauseButton: document.getElementById(_0x8f31c5a87a(8)),
        copyButton: document.getElementById(_0x8f31c5a87a(9)),
        clearButton: document.getElementById(_0x8f31c5a87a(10)),
        rowCount: document.getElementById(_0x8f31c5a87a(11)),
        orderProgress: document.getElementById(_0x8f31c5a87a(12)),
        errorCount: document.getElementById(_0x8f31c5a87a(13)),
        currentStep: document.getElementById(_0x8f31c5a87a(14)),
        lastUpdated: document.getElementById(_0x8f31c5a87a(15)),
        recordsBody: document.getElementById(_0x8f31c5a87a(16)),
        logList: document.getElementById(_0x8f31c5a87a(17)),
        logCount: document.getElementById(_0x8f31c5a87a(18)),
        toast: document.getElementById(_0x8f31c5a87a(19)),
        lockModal: document.getElementById(_0x8f31c5a87a(20)),
        recheckButton: document.getElementById(_0x8f31c5a87a(21)),
        closeWindowButton: document.getElementById(_0x8f31c5a87a(22))
    };
    const _0x94926a5a = {
        idle: _0x8f31c5a87a(23),
        'opening-list': _0x8f31c5a87a(24),
        'configuring-list': _0x8f31c5a87a(25),
        'collecting-list': _0x8f31c5a87a(26),
        'processing-details': _0x8f31c5a87a(27),
        'pause-pending': _0x8f31c5a87a(28),
        paused: _0x8f31c5a87a(29),
        validating: _0x8f31c5a87a(30),
        completed: _0x8f31c5a87a(31),
        error: _0x8f31c5a87a(32),
        'auth-locked': _0x8f31c5a87a(33)
    };
    const _0x36cbd009 = new Set([
        _0x8f31c5a87a(34),
        _0x8f31c5a87a(35),
        _0x8f31c5a87a(36),
        _0x8f31c5a87a(37),
        _0x8f31c5a87a(38),
        _0x8f31c5a87a(39)
    ]);
    let _0xd00359f8 = null;
    let _0x723cc7a7 = null;
    const _0xc744d16 = /^PO-\d{3}-\d+$/i;
    function _0xadadcac5(_0x4fe530b4) {
        return _0x1db0739e + encodeURIComponent(_0x4fe530b4 || _0x8f31c5a87a(40)) + _0xbfe9f94d;
    }
    function _0xe91ebe63(_0x8b5627d2) {
        if (_0x8b5627d2 === null || _0x8b5627d2 === undefined || _0x8b5627d2 === _0x8f31c5a87a(40)) {
            return _0x8f31c5a87a(41);
        }
        return String(_0x8b5627d2).replace(/[\t\r\n]+/g, _0x8f31c5a87a(42)).replace(/\s{2,}/g, _0x8f31c5a87a(42)).trim() || _0x8f31c5a87a(41);
    }
    function _0x248fad81(_0xc6c72b70) {
        if (!_0xc6c72b70) {
            return _0x8f31c5a87a(43);
        }
        try {
            return new Intl.DateTimeFormat(_0x8f31c5a87a(44), {
                year: _0x8f31c5a87a(45), month: _0x8f31c5a87a(46), day: _0x8f31c5a87a(46),
                hour: _0x8f31c5a87a(46), minute: _0x8f31c5a87a(46), second: _0x8f31c5a87a(46),
                hour12: false
            }).format(new Date(_0xc6c72b70));
        }
        catch (_0x60f0913f) {
            return String(_0xc6c72b70);
        }
    }
    function _0x2281eee(_0x9c61845d) {
        _0xfb5aeceb.toast.textContent = _0x9c61845d;
        _0xfb5aeceb.toast.classList.add(_0x8f31c5a87a(47));
        clearTimeout(_0x723cc7a7);
        _0x723cc7a7 = setTimeout(() => _0xfb5aeceb.toast.classList.remove(_0x8f31c5a87a(47)), 2200);
    }
    async function _0x3d99020c(_0xdfd28bfb, _0x790bf1aa = {}) {
        const _0x1b437f19 = await chrome.runtime.sendMessage({ type: _0xdfd28bfb, ..._0x790bf1aa });
        if (!_0x1b437f19 || _0x1b437f19.ok !== true) {
            throw new Error(_0x1b437f19 && _0x1b437f19.error ? _0x1b437f19.error : _0x8f31c5a87a(48));
        }
        return _0x1b437f19;
    }
    function _0xb57ce4c8(_0x56b462b7) {
        _0xfb5aeceb.statusDot.className = _0x8f31c5a87a(49);
        if (_0x36cbd009.has(_0x56b462b7)) {
            _0xfb5aeceb.statusDot.classList.add(_0x8f31c5a87a(50));
        }
        else if (_0x56b462b7 === _0x8f31c5a87a(51)) {
            _0xfb5aeceb.statusDot.classList.add(_0x8f31c5a87a(52));
        }
        else if (_0x56b462b7 === _0x8f31c5a87a(53)) {
            _0xfb5aeceb.statusDot.classList.add(_0x8f31c5a87a(54));
        }
        else if (_0x56b462b7 === _0x8f31c5a87a(55) || _0x56b462b7 === _0x8f31c5a87a(56)) {
            _0xfb5aeceb.statusDot.classList.add(_0x8f31c5a87a(55));
        }
    }
    function _0xf0ede866(_0x922551d5) {
        _0xfb5aeceb.recordsBody.textContent = _0x8f31c5a87a(40);
        if (!_0x922551d5.length) {
            const _0x2c5edf84 = document.createElement(_0x8f31c5a87a(57));
            _0x2c5edf84.className = _0x8f31c5a87a(58);
            const _0xcd964573 = document.createElement(_0x8f31c5a87a(59));
            _0xcd964573.colSpan = 10;
            _0xcd964573.textContent = _0x8f31c5a87a(60);
            _0x2c5edf84.appendChild(_0xcd964573);
            _0xfb5aeceb.recordsBody.appendChild(_0x2c5edf84);
            return;
        }
        const _0x6fcfc322 = document.createDocumentFragment();
        _0x922551d5.forEach((_0x9074891) => {
            const _0xab30b640 = document.createElement(_0x8f31c5a87a(57));
            if (_0x9074891.detailStatus === _0x8f31c5a87a(55)) {
                _0xab30b640.className = _0x8f31c5a87a(61);
            }
            else if (_0x9074891.detailStatus !== _0x8f31c5a87a(62)) {
                _0xab30b640.className = _0x8f31c5a87a(63);
            }
            const _0x45683c0f = [
                _0x9074891.returnId,
                _0x9074891.orderId,
                _0x9074891.sku,
                _0x9074891.quantity,
                _0x9074891.reason,
                _0x9074891.buyerComment,
                _0x9074891.image,
                _0x9074891.courier,
                _0x9074891.trackingNumber,
                _0x9074891.sellerNote
            ];
            _0x45683c0f.forEach((_0xe6a1a5fe, _0x80d923ad) => {
                const _0x2212a91c = document.createElement(_0x8f31c5a87a(59));
                const _0xbc4a16cb = _0xe91ebe63(_0xe6a1a5fe);
                _0x2212a91c.title = _0xbc4a16cb;
                if (_0x80d923ad === 1 && _0xc744d16.test(String(_0x9074891.orderId || _0x8f31c5a87a(40)))) {
                    const _0x5d839cba = document.createElement(_0x8f31c5a87a(64));
                    _0x5d839cba.href = _0xadadcac5(_0x9074891.orderId);
                    _0x5d839cba.target = _0x8f31c5a87a(65);
                    _0x5d839cba.rel = _0x8f31c5a87a(66);
                    _0x5d839cba.textContent = _0xbc4a16cb;
                    _0x5d839cba.addEventListener(_0x8f31c5a87a(67), (_0xffbb1a69) => {
                        _0xffbb1a69.preventDefault();
                        _0x3d99020c(_0x8f31c5a87a(68), { url: _0x5d839cba.href }).catch((_0x99f483d8) => {
                            _0x2281eee(`打开订单详情失败：${_0x99f483d8.message || _0x99f483d8}`);
                        });
                    });
                    _0x2212a91c.appendChild(_0x5d839cba);
                }
                else {
                    _0x2212a91c.textContent = _0xbc4a16cb;
                }
                _0xab30b640.appendChild(_0x2212a91c);
            });
            _0x6fcfc322.appendChild(_0xab30b640);
        });
        _0xfb5aeceb.recordsBody.appendChild(_0x6fcfc322);
    }
    function _0x3b2c0987(_0xd5657776) {
        _0xfb5aeceb.logList.textContent = _0x8f31c5a87a(40);
        _0xfb5aeceb.logCount.textContent = `${_0xd5657776.length} 条`;
        if (!_0xd5657776.length) {
            const _0x769efd25 = document.createElement(_0x8f31c5a87a(69));
            _0x769efd25.className = _0x8f31c5a87a(70);
            _0x769efd25.textContent = _0x8f31c5a87a(71);
            _0xfb5aeceb.logList.appendChild(_0x769efd25);
            return;
        }
        const _0x10d67a94 = _0xd5657776.slice(-500);
        const _0xb20fe043 = document.createDocumentFragment();
        _0x10d67a94.forEach((_0x4c476e32) => {
            const _0xee70d7e1 = document.createElement(_0x8f31c5a87a(69));
            _0xee70d7e1.className = `log-entry ${_0x4c476e32.level || _0x8f31c5a87a(72)}`;
            const _0x8fa85d50 = document.createElement(_0x8f31c5a87a(73));
            _0x8fa85d50.className = _0x8f31c5a87a(74);
            _0x8fa85d50.textContent = _0x248fad81(_0x4c476e32.time);
            const _0x29e1db1f = document.createElement(_0x8f31c5a87a(73));
            _0x29e1db1f.className = _0x8f31c5a87a(75);
            _0x29e1db1f.textContent = _0x4c476e32.level || _0x8f31c5a87a(72);
            const _0xcb1940ce = document.createElement(_0x8f31c5a87a(73));
            _0xcb1940ce.textContent = _0x4c476e32.message || _0x8f31c5a87a(40);
            _0xee70d7e1.append(_0x8fa85d50, _0x29e1db1f, _0xcb1940ce);
            _0xb20fe043.appendChild(_0xee70d7e1);
        });
        _0xfb5aeceb.logList.appendChild(_0xb20fe043);
        _0xfb5aeceb.logList.scrollTop = _0xfb5aeceb.logList.scrollHeight;
    }
    function _0x6552cebd(_0x68a346c) {
        _0xfb5aeceb.lockModal.classList.toggle(_0x8f31c5a87a(76), !_0x68a346c);
        _0xfb5aeceb.lockModal.setAttribute(_0x8f31c5a87a(77), _0x68a346c ? _0x8f31c5a87a(78) : _0x8f31c5a87a(79));
        _0xfb5aeceb.appShell.classList.toggle(_0x8f31c5a87a(80), _0x68a346c);
    }
    function _0xa0c3bddb(_0x42fb3b8a) {
        _0xd00359f8 = _0x42fb3b8a || {};
        const _0xdc34a179 = Array.isArray(_0xd00359f8.rows) ? _0xd00359f8.rows : [];
        const _0x7e6c2f28 = Array.isArray(_0xd00359f8.logs) ? _0xd00359f8.logs : [];
        const _0x1fa59497 = Array.isArray(_0xd00359f8.detailQueue) ? _0xd00359f8.detailQueue : [];
        const _0xb9dd1246 = _0xd00359f8.status || _0x8f31c5a87a(81);
        const _0x5b169835 = _0x36cbd009.has(_0xb9dd1246);
        const _0xf54e01e4 = Boolean(_0xd00359f8.authLocked || _0xb9dd1246 === _0x8f31c5a87a(56));
        const _0x96878f53 = _0xdc34a179.filter((_0x30b0f502) => _0x30b0f502.detailStatus === _0x8f31c5a87a(55)).length;
        const _0xd2e872f1 = Math.min(Number(_0xd00359f8.detailIndex) || 0, _0x1fa59497.length);
        _0xfb5aeceb.statusText.textContent = _0x94926a5a[_0xb9dd1246] || _0xb9dd1246;
        _0xb57ce4c8(_0xb9dd1246);
        _0xfb5aeceb.rowCount.textContent = String(_0xdc34a179.length);
        _0xfb5aeceb.orderProgress.textContent = `${_0xd2e872f1} / ${_0x1fa59497.length}`;
        _0xfb5aeceb.errorCount.textContent = String(_0x96878f53);
        _0xfb5aeceb.currentStep.textContent = _0xd00359f8.currentOrderId || _0xd00359f8.currentStep || _0x8f31c5a87a(82);
        _0xfb5aeceb.lastUpdated.textContent = _0x248fad81(_0xd00359f8.updatedAt);
        _0xfb5aeceb.startButton.textContent = _0xb9dd1246 === _0x8f31c5a87a(53) ? _0x8f31c5a87a(83) : _0x8f31c5a87a(84);
        _0xfb5aeceb.startButton.disabled = _0xf54e01e4 || _0x5b169835;
        _0xfb5aeceb.pauseButton.disabled = _0xf54e01e4 || !_0x5b169835 || _0xb9dd1246 === _0x8f31c5a87a(39) || _0xb9dd1246 === _0x8f31c5a87a(38);
        _0xfb5aeceb.copyButton.disabled = _0xf54e01e4 || _0xdc34a179.length === 0;
        _0xfb5aeceb.clearButton.disabled = _0xf54e01e4 || _0x5b169835 || (_0xdc34a179.length === 0 && _0x7e6c2f28.length === 0);
        _0xf0ede866(_0xdc34a179);
        _0x3b2c0987(_0x7e6c2f28);
        _0x6552cebd(_0xf54e01e4);
    }
    function _0x6c21f8a0(_0xe59666f) {
        return _0xe91ebe63(_0xe59666f)
            .replace(/&/g, _0x8f31c5a87a(85))
            .replace(/</g, _0x8f31c5a87a(86))
            .replace(/>/g, _0x8f31c5a87a(87))
            .replace(/"/g, _0x8f31c5a87a(88))
            .replace(/'/g, _0x8f31c5a87a(89));
    }
    async function _0xaf92efde() {
        const _0x49ca558d = _0xd00359f8 && Array.isArray(_0xd00359f8.rows) ? _0xd00359f8.rows : [];
        if (!_0x49ca558d.length) {
            _0x2281eee(_0x8f31c5a87a(90));
            return;
        }
        const _0xeb03d37c = [
            _0x8f31c5a87a(91),
            _0x8f31c5a87a(92),
            _0x8f31c5a87a(93),
            _0x8f31c5a87a(94),
            _0x8f31c5a87a(95),
            _0x8f31c5a87a(96),
            _0x8f31c5a87a(97),
            _0x8f31c5a87a(98),
            _0x8f31c5a87a(99),
            _0x8f31c5a87a(100)
        ];
        const _0x853b592b = _0x49ca558d.map((_0x2774c69a) => [
            _0x2774c69a.returnId, _0x2774c69a.orderId, _0x2774c69a.sku, _0x2774c69a.quantity, _0x2774c69a.reason,
            _0x2774c69a.buyerComment, _0x2774c69a.image, _0x2774c69a.courier, _0x2774c69a.trackingNumber, _0x2774c69a.sellerNote
        ].map(_0xe91ebe63));
        const _0xc0ac4c49 = [_0xeb03d37c, ..._0x853b592b]
            .map((_0x62e5ca38) => _0x62e5ca38.map(_0xe91ebe63).join(_0x8f31c5a87a(101)))
            .join(_0x8f31c5a87a(102));
        const _0xfc1d33e7 = _0x853b592b.map((_0x9e56b956) => {
            const _0x3f8e2705 = _0x9e56b956[1];
            return _0x8f31c5a87a(103) + _0x9e56b956.map((_0xd9c7acf4, _0x7bff2aa3) => {
                if (_0x7bff2aa3 === 1 && _0xc744d16.test(String(_0x3f8e2705 || _0x8f31c5a87a(40)))) {
                    return `<td><a href="${_0x6c21f8a0(_0xadadcac5(_0x3f8e2705))}">${_0x6c21f8a0(_0xd9c7acf4)}</a></td>`;
                }
                return `<td>${_0x6c21f8a0(_0xd9c7acf4)}</td>`;
            }).join(_0x8f31c5a87a(40)) + _0x8f31c5a87a(104);
        }).join(_0x8f31c5a87a(40));
        const _0x15289012 = `<table><thead><tr>${_0xeb03d37c.map((_0xb76019c1) => `<th>${_0x6c21f8a0(_0xb76019c1)}</th>`).join(_0x8f31c5a87a(40))}</tr></thead><tbody>${_0xfc1d33e7}</tbody></table>`;
        let _0x509987b0 = false;
        let _0xf2d10d7f = null;
        if (window.ClipboardItem && navigator.clipboard && navigator.clipboard.write) {
            try {
                const _0x8c0a8b2e = new ClipboardItem({
                    'text/plain': new Blob([_0xc0ac4c49], { type: _0x8f31c5a87a(105) }),
                    'text/html': new Blob([_0x15289012], { type: _0x8f31c5a87a(106) })
                });
                await navigator.clipboard.write([_0x8c0a8b2e]);
                _0x509987b0 = true;
            }
            catch (_0x2e43f09d) {
                _0xf2d10d7f = _0x2e43f09d;
            }
        }
        if (!_0x509987b0 && navigator.clipboard && navigator.clipboard.writeText) {
            try {
                await navigator.clipboard.writeText(_0xc0ac4c49);
                _0x509987b0 = true;
            }
            catch (_0xc87b7e4c) {
                _0xf2d10d7f = _0xc87b7e4c;
            }
        }
        if (!_0x509987b0) {
            try {
                const _0x69b4e43b = document.createElement(_0x8f31c5a87a(107));
                _0x69b4e43b.value = _0xc0ac4c49;
                _0x69b4e43b.setAttribute(_0x8f31c5a87a(108), _0x8f31c5a87a(40));
                _0x69b4e43b.style.position = _0x8f31c5a87a(109);
                _0x69b4e43b.style.opacity = _0x8f31c5a87a(110);
                document.body.appendChild(_0x69b4e43b);
                _0x69b4e43b.select();
                _0x509987b0 = document.execCommand(_0x8f31c5a87a(111));
                _0x69b4e43b.remove();
            }
            catch (_0xbec6dea) {
                _0xf2d10d7f = _0xbec6dea;
            }
        }
        if (_0x509987b0) {
            _0x2281eee(`已复制 ${_0x49ca558d.length} 行，可直接粘贴到 Excel`);
        }
        else {
            _0x2281eee(`复制失败：${_0xf2d10d7f && (_0xf2d10d7f.message || _0xf2d10d7f) || _0x8f31c5a87a(112)}`);
        }
    }
    async function _0xa525eb59() {
        const _0x475d5108 = chrome.runtime.getManifest();
        _0xfb5aeceb.versionText.textContent = `v${_0x475d5108.version_name || _0x475d5108.version}`;
        const _0xe096def7 = await chrome.storage.local.get(_0x5921673c);
        _0xa0c3bddb(_0xe096def7[_0x5921673c] || {});
        await _0x3d99020c(_0x8f31c5a87a(113));
    }
    _0xfb5aeceb.startButton.addEventListener(_0x8f31c5a87a(67), async () => {
        try {
            _0xfb5aeceb.startButton.disabled = true;
            await _0x3d99020c(_0x8f31c5a87a(114));
        }
        catch (_0x82ce44a6) {
            _0x2281eee(_0x82ce44a6.message || String(_0x82ce44a6));
            _0xfb5aeceb.startButton.disabled = false;
        }
    });
    _0xfb5aeceb.pauseButton.addEventListener(_0x8f31c5a87a(67), async () => {
        try {
            _0xfb5aeceb.pauseButton.disabled = true;
            await _0x3d99020c(_0x8f31c5a87a(115));
            _0x2281eee(_0x8f31c5a87a(116));
        }
        catch (_0x1c07c215) {
            _0x2281eee(_0x1c07c215.message || String(_0x1c07c215));
            _0xfb5aeceb.pauseButton.disabled = false;
        }
    });
    _0xfb5aeceb.copyButton.addEventListener(_0x8f31c5a87a(67), _0xaf92efde);
    _0xfb5aeceb.clearButton.addEventListener(_0x8f31c5a87a(67), async () => {
        try {
            await _0x3d99020c(_0x8f31c5a87a(117));
            _0x2281eee(_0x8f31c5a87a(118));
        }
        catch (_0xbe3f4bc4) {
            _0x2281eee(_0xbe3f4bc4.message || String(_0xbe3f4bc4));
        }
    });
    _0xfb5aeceb.recheckButton.addEventListener(_0x8f31c5a87a(67), async () => {
        try {
            _0xfb5aeceb.recheckButton.disabled = true;
            await _0x3d99020c(_0x8f31c5a87a(119));
        }
        catch (_0x5868b1b3) {
            _0xfb5aeceb.recheckButton.disabled = false;
        }
    });
    _0xfb5aeceb.closeWindowButton.addEventListener(_0x8f31c5a87a(67), async () => {
        try {
            await _0x3d99020c(_0x8f31c5a87a(120));
        }
        catch (_0xf9a03f62) {
            window.close();
        }
    });
    chrome.storage.onChanged.addListener((_0x9bd9a4d1, _0x35112280) => {
        if (_0x35112280 === _0x8f31c5a87a(121) && _0x9bd9a4d1[_0x5921673c] && _0x9bd9a4d1[_0x5921673c].newValue) {
            _0xa0c3bddb(_0x9bd9a4d1[_0x5921673c].newValue);
            _0xfb5aeceb.recheckButton.disabled = false;
        }
    });
    window.setInterval(() => {
        if (_0xd00359f8 && _0x36cbd009.has(_0xd00359f8.status)) {
            chrome.runtime.sendMessage({ type: _0x8f31c5a87a(122) }).catch(() => { });
        }
    }, 2500);
    _0xa525eb59().catch((_0xd74aa84f) => {
        _0x2281eee(`初始化失败：${_0xd74aa84f.message || _0xd74aa84f}`);
    });
})();
