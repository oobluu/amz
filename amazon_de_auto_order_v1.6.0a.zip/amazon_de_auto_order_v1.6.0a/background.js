(()=>{'use strict';const _0x496158fce0=["gY2ar5KEhZKylY6zlIGUhQ==","gY2ar5KEhZKoiZOUj5KZ","gY2atIWNla+ShIWSqY6EhZg=","gY2ao4GSlKKViYyEiY6HrI+Diw==","gY2ar5KEhZKsj4eT","gY2ar5KEhZKkkoGGlLKPl5M=","gY2ar5KEhZKzhZSUiY6Hkw==","gY2aoZWUj6+ShIWSoZWUiI+SiZqBlImPjg==","kpWOjomOhw==","kIGVk4WE","lJKBjpOJlImPjomOhw==","t6GptL+vsqSlsr+ztaOjpbOz","t6GptL+vsqSlsr+oqbO0r7K5","p7KvtbC/oaSkv7Cyr6S1o7Q=","t6GptL+nsq+1sL+hpKS/sqWztay0","p7KvtbC/sLKvo6WlpL+jqKWjq6+1tA==","t6GptL+jqKWjq6+1tA==","s6WspaO0v7Chua2lrrS/o6GypA==","t6GptL+jqKGup6W/oaSksqWzsw==","t6GptL+hpKS/oaSksqWzs7+hprSlsr+jqKGup6U=","t6GptL+hpKSypbOzv6avsq0=","t6GptL+hpKSypbOzv7Kls7WstA==","t6GptL+toa61oay/oaSksqWzsw==","t6GptL+wobmtpa60","tqWyqaa5v7Chua2lrrS/rqGtpQ==","gY2azY+ShIWSzYmOlIWSloGM2g==","iJSUkJPaz8+BjoGOzdHS1dnQ2dXY2NPOg4+TzoWVzYaSgY6LhpWSlM6NmZGDjI+VhM6Dj43P0c+BlZSPj5KEhZLOiJSNjA==","BkBBCUpsBURRCFRFD1xsCE9XCGF0B1Nbs4iBjoeBjg==","nA==","obW0qL+jr66mqae1sqG0qa+uv6mutKWnsqm0ub+moamspaQ=","0A==","gZWUiI+SiZqFhA==","obW0qK+yqbqhtKmvrr+jqKGup6Wk","hZKSj5I=","","v5Y=","v5Q=","p6W0","jo/Nk5SPkoU=","j42JlA==","hoGJjIWE","oYKPkpSlkpKPkg==","tKmtpa+1tA==","sqWxtaWztL+moamspaQ=","obW0qL+moamspaQ=","j4KKhYOU","BndABlN1BU5pBm5yBFhrBW11CXdUCXp0D1x6BFtbBWpBwKmkwARYbQVNeAV8SANgYg==","hY7Np6I=","pZWSj5CFz6KFkoyJjg==","jpWNhZKJgw==","0s2EiYeJlA==","mojNo64=","iNLT","rqarow==","wA==","hIXNpKU=","gY2Bmo+OzoSF","zoGNgZqPjs6EhQ==","gZOJjg==","obOprg==","r7KkpbKlpA==","BF9BBmFPBFhtBU5sBnVUD1xsCFdTCF9n","tIWNlcCvkoSFksCppARYWgdJWg9cbAhXUwhfZw==","BnVQCWdvBkBcBVxvCXR5CE9PD1xsCFdTCF9n","oa26wIyJjosGd0AGdWgPXGwIV1MIX2c=","BV5lBURkB3Bm","kIWOhImOhw==","koWBhJk=","k4uJkJCFhA==","BXBsBXxQBX1gB1tkBXBoBW11BU14BXxIBVxiBVhYD1xsBnVUB1tkCFdTCF9n","goyPg4uFhA==","kJKPg4WTk4mOhw==","k5WDg4WTkw==","BFhrBW11BmhwBWp/","tIWNlcCvkoSFksCppAVdcwVESQVXUgRYawhfZwVtdQ9cbAhXUwhfZw==","kIGOhYzOiJSNjA==","kI+QlZA=","gYKPlZTagoyBjos=","jo+SjYGM","BndABlN1BWh7BVtawKGNgZqPjsAFV0UEXXwGQGcHTV4JQVUDYGI=","BVdFBF18BkBnB01eCUFVBFhtBU14BXxIA2Bi","t6Grpb+htbSvraG0qa+u","goWGj5KFzYaJkpOUzYGEhA==","BU14BXxIBnxKBlhlCXlEB3pkB1tkBXBoBW11CFRNB2lJB09OBU5pBWVICXRhD1xsBFtbBWpBBnxKBXBPBWpIA2BiCE9XBWVoBFpaBVdFBkNgBn9FCFRNB2lJB09OBXJsBnxgCF9xCE5CBW11D1xsBWZtBF1fB3RIAmB8BlhlCXlEB1tkBXBoBW11CXRhAmB9BmxpCXJOA2Bi","BU14BXxIBnxKBlhlCXlEB3pkB1tkBXBoBW11CFRNB2lJB09OBU5pBWVICXRhA2BiCE9XBWVoBFpaBVdFBkNgBn9FCFRNB2lJB09OBXJsCE5CBW11D1xsBWZtBlhlCXlEB1tkBXBoBW11CXRhA2Bi","BVdSBnxpBnxKB1tzBn1/BFtbBWpBA2BiCE9XBF1fB3RIB1tHB1tNA2BhCFdTCF9nBV1zBWltCEFsBmh2BWF8Bk1CBmxpCXJOBURkB3BmB25QBnxpBFtbBWpBA2Bi","Bk9vBW11CXdUCXp0BV9lCUFbBnhPwNACYHPT1tDQwAd6ZAZ1VAZ1UANgYg==","BlJBBnxpBW9PBURkB3BmB3pkBnVQBm1OCEFsA2Bi","iY6Gjw==","CF5zBWVFCEFIBkBcBF99BmxhBW5/BUdrCUFaBVpvD1x7Bm9yBFtWBFtlBXxIBWZlCWNIBmxpBXxQBX1gA2BhBUdzBXBtBm5yBWh3BFhrBW11B1tkA2Bi","l4GSjomOhw==","sLKlo6ilo6u/o6+upqypo7Q=","g4+NkIyFlIWE","o6+tsKyltKWk","BlJBBnxpCXxgCEZhBFhrBW11B3pkBnxpBnVoBXxQBX1gB1tkD1xsBFtbBWpBB1tzBn1/A2Bi","tLKhrrOptKmvrqmupw==","BW11CEFsBXxQBX1gB1tkB1tHB1tNBF1fB3RIwKKVmcCuj5cPXHsFcGwFR3MFcG0EWHQFTmwGdVQFfFAFfWAHe1gFcGwHemQFRHoIQWwFfFAFfWAHW2QEXV8HdEjAoYSEwJSPwIKBk4uFlMAFcGgFWVYEWGsFbXUDYGI=","B1tkBXBoBW11BFx6BWVoBU5sBnVUCUJkBkNgBn9FBWVIB1tkD1x7BFtbBmRvBFhgCEFsCXxgCEZhCFdTCF9nBndWD1xsBnVUBFhKBXxQBX1gB1tkBFhtBFhrBW11A2Bi","B1tkBXBoBW11BVxgBUdrCUJkBkNgBn9FBWltA2BhBk1DBVxvBWpACFRNBWltA2BhBk9vBkxBBWpACFRNBXBuBXJswLCSj4OFhYTABWltBX1nBkBYBU9ZCFRNB2lJB09OBnVQCWdvA2Bi","BlZoBmFPBFhtBnhPBn1FCGdKBV1zBWltBVdFBF18BkBnB01eCUFVA2Bi","BFtbBWpBB2loBnxMBVdSB1tvBW94BWx2A2Bi","BFtbBWpBBV1zBWltBnxKCF9wCEFsA2Bi","CUFVCX1CB2pWBmBhBVxiBVhYA2Bi","BFtbBWpBB2pWBmBhBVdSB1tvBW94BWx2A2Bi","BmleBFhtBWhQBV1zBWltBFhrBW11B1tkA2Bi","BnxgB1toBm9wBFpEBWltB3pkBnRWBFtWBFpaBUdzBXBtBFhuBV1zBWltBXxQBX1gB1tkBFhtBFhgCGdUA2Bi","B1tkBXBoBW11BVlWCX1+BmlgBnxpCEFsCWNdBVdSBU5sBmhwCUJkBkNgBn9FBXJsBWpABWVFCFRNB2lJB09OA2Bi","B1tkBXBoBW11CFRNB2lJB09OBU5pBWVICXRhBFhtBU14BXxIBmh2BFhuBV1zBWltBXxQBX1gB1tkBFhtBFhgCGdUA2Bi","BnxgB1toBm9wBFpEBWltBlJBBnxpBnxpBnVoB3pkBXVmBXNhBXBLB0huBW11BFtXwAJiTNLO0NDABkBBCUpsCE5QBV11A2Bi","BnxgB1toBm9wBFpEBWltBlJBBnxpBnxpBnVoB3pkB1JeBWdmBnVQCWdvBkBBCUpsCE5QBV11A2Bi","Bk1DBXxIBm9wBFpEB1tkBXBoCE5CBW11D1xoB01pBV5lCG5XBW92wK+ShIWSwKmkD1xp","homOgYzNk5WCjYmU","Bk1DBXxIBm9wBFpECE5CBW11D1xoB01pBV5lCG5XBW92wK+ShIWSwKmkD1xp","BmleBFhtBWhQBWdmBURnBURkB3BmB3pkBXxQBX1gB1tkA2Bi","BWdmBURnB1tkBXBoBW11CUJkBkNgBn9F","BWdmBURnBmlzBVxgBXVmBXNhCUFVCX1C","o6ilo6u/o6GytL+ipaavsqW/sLKlo6ilo6s=","t6GptL+wsq+ktaO0","B1tkBXBoBW11CUJkBkNgBn9FBWltBk1DBXxIB0FOCE5ECFRNB2lJB09OBFhaB0la","Bk1DBXxIBmlzBVxgBXVmBXNhCUFVCX1C","BmlgBnxpBnxpBnVoBXxQBX1gB1tkBURkB3BmBU5sBmhwA2Bi","t6GptL+prrSlsrahrA==","BFhrBW11CXdUCXp0B1tzBn1/D1xsBVxgBUdrBURkB3BmBFhrBFhgBFhKBXxQBX1gB1tkA2Bi","o6ilo6u/o6GytL+ipaavsqW/orWprKQ=","BV1zBWltBFhtBnhPB1tkBXBoBW11A2Bi","p7KvtbC/sLKlo6ilo6u/sLKvpLWjtA==","B1tkBXBoBW11CUJkBkNgBn9FD1x6Bk1DBXxIBkBYBU9ZBXVmBXNh","B1tkBXBoBW11CUJkBkNgBn9FBWltB0FOCE5ECFRNB2lJB09OBnVQCWdvBFha0ANgYg==","Bk1DBVxvBWpACFRNBWltBW9xB25QBVdSBnxpB1tkBXBoBW11CFRNB2lJB09OBU5pBWVICXRhA2Bi","Bk1DBVxvBWpABWVFCFRNB2lJB09OD1x6Bk1DBXxIBURkB3BmB0xM0QhBbAV1ZgVzYQ==","Bk1DBVxvBWpABWVFCFRNB2lJB09OD1x6Bk1DBXxIBkBYBU9ZBXVmBXNh","B1tkBXBoBW11Bk1DBVxvBWpACFRNBWltBWZtBkxBB0FOCE5ECFRNB2lJB09OBnVQCWdvBFha0A9cewVXUgVbWgdLa8CjobK0v6K1qaykqa6nwAVOaQVlSAl0YQNgYg==","BmleBFhtBWhQB1tkBXBoBW11BV1zBWltCEFsA2Bi","B1tkBXBoBW11CUJkBkNgBn9FCEFsB1RCBVx1BVdSB1tvBW94BWx2A2Bi","B1tkBXBoBW11CUJkBkNgBn9FBXt+BFxAB3pkBXVmBXNhBW11BFtXBndABnVoA2Bi","B1tkBXBoBW11CUJkBkNgBn9FBXt+BFxAB3pkBnVQCWdvBndABnVoA2Bi","B1tkBXBoBW11CUJkBkNgBn9FCWB6CF9n","B1tkBXBoBW11CUJkBkNgBn9FD1x6Bk1DBXxIBmlzBVxgBXVmBXNhCUFVCX1C","B1tkBXBoBW11CUJkBkNgBn9FBU5sBmhw","B1tkBXBoBW11CUJkBkNgBn9FBU5sBmhwD1xsBk1DBVxvBWpACFRNBWltCWdtBnZQB0FOCE5ECFRNB2lJB09OBFhaB0la","B1tkBXBoBW11BWVICWNIBXVmBXNhCUJkBkNgBn9FCWB6CF9nD1xsCF90BXt+B0xMBFhgBFtWBXVmBXNhBVlWBWZtBkxBBkNgBn9FCFRNB2lJB09OBFhaB0laA2Bi","B1tkBXBoBW11BXVmBXNhCUJkBkNgBn9FBnxKCWB6CF9n","B1tkBXBoBW11CFRNB2lJB09OBU5pBWVICXRhBndABnVoA2Bi","B1tkBXBoBW11Bk1DBVxvBWpACFRNCEFsB1RCBVx1BVdSB1tvBW94BWx2A2Bi","Bk1DBVxvBWpACFRNBWltB3pkBnVQCWdvBFhuB3tOBkBnBnVQCWdvBFhtBFhgCGdUA2Bi","Bk1DBVxvBWpACFRNBWltB3pkBXVmBXNhBXBLB0huBW11BFtXBFhtBnhPwAJiTNLO0NADYGI=","gYSEiY6HzYmUhY0=","Bk1DBVxvBWpACFRNBXt+BFxAB3pkBnVQCWdvBFhuB3tOBkBnBnVQCWdvBFhtBFhgCGdUA2Bi","Bk1DBVxvBWpACFRNBXt+BFxAB3pkBXVmBXNhBXBLB0huBW11BFtXBFhtBnhPwAJiTNLO0NADYGI=","gpWJjISJjoc=","Bk1DBVxvBWpABWVFCFRNB2lJB09OD1x6Bk1DBXxIBmlzBVxgBXVmBXNhCUFVCX1C","B1tkBXBoBW11BXVmBXNhBVdSBWVICWNIBWpABWVFCFRNB2lJB09OD1xsBWdmBURnwLCSj4OFhYTAlI/Ao4iFg4uPlZQ=","koWBhJnNlI/Ng4iFg4uPlZQ=","BVdSBkBYBU9ZCFRNB2lJB09OBmBbBnVQCWdvD1xsBk1DBXxICF97BWVFBFhrBW11CUFVCX1C","g4iFg4uPlZQ=","BV1zBWltBlJBBnxpBFtbBWpBA2Bi","BmleBFhtBWhQBV1zBWltBnVQBm1OCEFsBmh2BXxQBX1gB1tkA2Bi","B1tkBXBoBW11BVdSB1tvBVxgBUdrBn5kBVtaCFRNB2lJB09OD1xsBFhtCGNdB3tUBm5FCFdTCF9nA2BiCE9XBWVoBFpaBVdFBkNgBn9FCFRNB2lJB09OBXJsBnxgCF9xCE5CBW11D1xsBWZtBlhlCXlEB1tkBXBoBW11CXRhA2Bi","BFpaBVdFCFdTCF9n","CFdTCF9n","BmleBFhtBWhQBV1zBWltBXxQBX1gB1tkA2Bi","r5KEhZLAqaTABkBcBVxvBndABnVoA2Bi","B1tkBXBoBW11BmhwBWp/CE5QBV11BWltCFRNB2lJB09OBU5pBWVICXRhBFhtBU14BXxIBmh2BFhtBWxZCWVtA2Bi","BVdSBW92BV53B1tkBXBoBW11wK+ShIWSwKmkD1xso6GytL+itamspKmup8AFTmkFZUgJdGEFV1IIZ0oFakgGWGUJeUQDYGI=","BV1zBWltBFtbBWpBBFhtBURkBFpuBW9PBnpiBWF8B2pWBmBhA2Bi","BFpaBVdFBnpiBWF8","BFtbBWpBBVdSBFpaBVdFBnpiBWF8A2Bi","BV1zBWltBlJBBnxpBVdSBnpiBWF8BFtbBWpBA2Bi","CUJkBkNgBn9FBU14BXxIwLSFjZXAr5KEhZLAqaTABXxQBX1gBmh2B01eBXBtBWZSB0phD1xsBFhtCGNdB3tUBm5FB1tHB1tNA2BiCE9XBWF8Bk1CBFtbBWpBBVlWBF9OBnRZCF5zBWVFBnVQBm1OA2Bi","B1tkBXBoBW11CFRNB2lJB09OBU5pBWVICXRhBVdSBFhtBU14BXxID1xsBFhtCGNdB1tHB1tNBV1zBWltBFtbBWpBA2BiCE9XBWF8Bk1CBXBuCWdtBnZQBVxgBUdrA2Bi","BFtbBWpBB1tHB1tNBmlHCEFsD1xsBFhrBW11CXdUCXp0CE5BBndWBmFCBURtA2Bi","oY2Bmo+OwAVXRQRdfAZAZwdNXglBVQVXUgVlUwl3TQ9cbAVdcwVpbQl4VgZOVQRYbQhjXQVOaQVlSAhnSgVqSAZhQgVEbQNgYghPVwRaWgVXRQZDYAZ/RQVwbgVhfAZNQgRbWwVqQQ9cewhrRQZ8aQdbZAVwaAVtdQl0YQ9cbAhPVwdBTghORAhUTQdpSQdPTgVybAhOQgVtdQVwbgZYZQl5RANgYg==","B1tHB1tNBmlHCEFsB1tkBXBoBW11BV1zBWltBk1FCUpE","B1tHB1tNBmlHCEFsBV1zBWltBk1FCUpE","BFtbBWpBB1tHB1tNBmlHCEFsA2Bi","BV1zBWltBlJBBnxpBW9PBWF8Bk1CB3pkBFtbBWpBA2Bi","k5SPkJCFhA==","s7SvsLClpA==","BVdSBWF8Bk1CD1xoB1tkBXBoBW11CFRNB2lJB09OCXRhBFttBF99B3V5D1xp","BVdSBWF8Bk1CD1xoCE5CBW11B1tzBn58BnxKB0FOCE5ED1xp","BVdSBWF8Bk1C","BFtbBWpBBVdSBWF8Bk1CD1x7o6GytL+itamspKmup8AFTmkFZUgJdGEEW20EX30HdXkDYGIIT1cEWloFV0UGQ2AGf0UIVE0HaUkHT04FcmwGfGAIX3EITkIFbXUFcG4FZm0GWGUJeUQHW2QFcGgFbXUJdGEDYGI=","BFtbBWpBBVdSBWF8Bk1CD1x7BV1zBWltCE5CBW11B1tzBn58BFttBnxKB0FOCE5ED1xsBFh0BFhtBFx6BWZ5BWVFBV1zBURJCXhSCWdtBURtCE5QBV11A2Bi","BFtbBWpBBVdSBWF8Bk1CA2Bi","BV1zBWltBlJBBnxpB1tkBXBoBW11CFRNB2lJB09OBU5pBWVICXRhA2Bi","BFtbBWpBBFttBXxICF9wCEFsD1xsBFhtCGNdBlhlCXlEB1tkBXBoBW11CFRNB2lJB09OCXRhA2BiCE9XBWVoBnpiBWF8Bmh2BWF8Bk1CBFtbBWpBA2Bi","B1tkBXBoBW11CXRhBVdSB3RRB3RIBmhXB0FOCE5EBXBuBlhlCXlED1xsBFtbBWpBBVdSBWF8Bk1C","BnxKB39F","BFtbBWpBCF9wCEFsBnx/CXdUBFhtCGNdBF9OBnRZCF5zBWVFBnVQBm1OA2Bi","BFtbBWpBCF9wCEFsBnx/CXdUBFhtCGNdBlhlB0laCF5zBWVFBnVQBm1OA2Bi","BU14BXxIBnxKBlhlCXlEB3pkB1tkBXBoBW11CFRNB2lJB09OCXRhD1xsBFhtCGNdBlhlB0laBFtbBWpBCE5QBV11A2Bi","BFtbBWpBCF9wCEFsBnx/CXdUBFhtCGNdBF9OBnRZBk9vBW11CXdUCXp0A2Bi","BFtbBWpBCF9wCEFsBnx/CXdUBFhtCGNdBlhlB0laBV1zBURJBFhrBW11CE5QBV11A2Bi","tY6BgoyFwJSPwI+QhY7AkIGOhYza","BW1nB1pHBXBuBFtbBWpBBVdSBWF8Bk1CD1xsCE9XBFpaBVdFBkNgBn9FBV1zBWltwKGNgZqPjsAJQVUJfUI=","BW1nB1pHBXBuBVdSBWF8Bk1CBndHB2loBnxKB1tzBn1/BFtbBWpBD1xsCE9XBFpaBVdFB0FOCE5EBnhPBXBGBVdSBFpHB3R/CE5CBW11A2Bi","BkNgBlVrBWhQBnxKBlhlCXlEB3pkB1tkBXBoBW11CFRNB2lJB09OCXRhD1x7BnZQBFtbBWpBBFx6CEJLCXhbBk1CD1xsB3tUBWhQBFpaBVdFBkNgBn9FBVlWBlhlCXlECE9FCXRhA2Bi","sqW2oayppKG0pb+htbSor7KpuqG0qa+u","o6ilo6u/obW0qK+yqbqhtKmvrg==","p6W0v6OvrrSluLQ=","p6W0v6GsrL+kobSh","s7ShsrS/srWu","s6G2pb+ksqGmtL+yr7ez","o6ylobK/pLKhprS/sq+3sw==","o6ylobK/rK+nsw==","s6G2pb+zpbS0qa6nsw==","o6ylobK/tK+kobm/r7KkpbK/sqWjr7Kksw==","o6ylobK/o6GytL+itamspKmup7+sr6Or","s6W0v7CoobOl","sKG1s6W/pbKyr7I=","oqWmr7Klv6aprqGsv7O1oq2ptA==","sKGnpb+sr6c=","s6upsL+yr7c=","p7KvtbC/o6GytL+lrbC0uQ==","p7KvtbC/sLKlo6ilo6u/sKGzsw==","p7KvtbC/sLKlo6ilo6u/pqGprA==","p7KvtbC/oqWmr7Klv6GkpA==","p7KvtbC/qbSlrb+hpKSlpA==","p7KvtbC/oqWmr7Klv7Cyr6OlpaQ=","r7KkpbK/s7Wjo6Wzsw==","sKG1s6W/srWu","o6+utKmutaW/srWu","s7SvsL+yta4=","s6upsL+jtbKypa60v62hrrWhrA==","r7Clrr+3r7Krv7Shog==","B01pBV5lCXdUCXp0Bnx/CXdUwKGNgZqPjsAFV0UEXXwGQGcHTV4JQVUIQksFZVMJd00PXHsJd1QJenQHW3MGfX8FcG4FUGYIZ0oFakgFaHsFW1oGdlAGQGcHTV4JQVUDYGI=","oY2Bmo+OwAVXRQRdfAZAZwdNXglBVQVXUgVlUwl3TQ9cewdbZAVwaAVtdQhUTQdpSQdPTgl0YQRbbQRffQd1eQ9cbAhPVwRaWgVXRQZDYAZ/RQhUTQdpSQdPTgVybAhOQgVtdQNgYg==","oY2Bmo+OwAVXRQRdfAZAZwdNXglBVQVXUghCSwVlUwl3TQNgYg=="];const _0xb24ac859b4=[];function _0x1c6cd537e4(_0xi){let _0xv=_0xb24ac859b4[_0xi];if(_0xv!==undefined)return _0xv;const _0xb=atob(_0x496158fce0[_0xi]);const _0x3fddfc35b4=new Uint8Array(_0xb.length);for(let _0xj=0;_0xj<_0xb.length;_0xj++)_0x3fddfc35b4[_0xj]=_0xb.charCodeAt(_0xj)^224;_0xv=new TextDecoder().decode(_0x3fddfc35b4);_0xb24ac859b4[_0xi]=_0xv;return _0xv;}
const _0x1a6d9 = Object.freeze({
RUN_STATE: _0x1c6cd537e4(0),
HISTORY: _0x1c6cd537e4(1),
ORDER_INDEX: _0x1c6cd537e4(2),
CART_LOCK: _0x1c6cd537e4(3),
LOGS: _0x1c6cd537e4(4),
DRAFT_ROWS: _0x1c6cd537e4(5),
SETTINGS: _0x1c6cd537e4(6),
AUTHORIZATION: _0x1c6cd537e4(7)
});
const _0x22bcb = Object.freeze({
orderIntervalSeconds: 30
});
const _0x3773d = 3000;
const _0x4f03f = 3000;
const _0x54db2 = new Set([_0x1c6cd537e4(8), _0x1c6cd537e4(9), _0x1c6cd537e4(10)]);
const _0x64371 = new Set([_0x1c6cd537e4(11), _0x1c6cd537e4(12)]);
const _0x7296d = new Set([
_0x1c6cd537e4(13),
_0x1c6cd537e4(14),
_0x1c6cd537e4(15),
_0x1c6cd537e4(16),
_0x1c6cd537e4(17),
_0x1c6cd537e4(18),
_0x1c6cd537e4(19),
_0x1c6cd537e4(20),
_0x1c6cd537e4(21),
_0x1c6cd537e4(22),
_0x1c6cd537e4(23),
_0x1c6cd537e4(24),
_0x1c6cd537e4(11),
_0x1c6cd537e4(12)
]);
const _0x80c29 = new Set([
_0x1c6cd537e4(14),
_0x1c6cd537e4(15),
_0x1c6cd537e4(16),
_0x1c6cd537e4(17),
_0x1c6cd537e4(18),
_0x1c6cd537e4(19),
_0x1c6cd537e4(20),
_0x1c6cd537e4(21),
_0x1c6cd537e4(22),
_0x1c6cd537e4(23),
_0x1c6cd537e4(24),
_0x1c6cd537e4(11),
_0x1c6cd537e4(12)
]);
const _0x95e49 = _0x1c6cd537e4(25);
const _0xa5a3c = /^\d{3}-\d{7}-\d{7}$/;
const _0xbfe83 = 7;
const _0xc4ed4 = Object.freeze({
endpoint: _0x1c6cd537e4(26),
cacheMs: 8 * 60 * 60 * 1000,
timeoutMs: 10000,
expectedStatus: 200,
failureMessage: _0x1c6cd537e4(27)
});
const _0xd2f43 = 0xa70299d5;
function _0xede51() {
const _0xfc570 = [
_0xc4ed4.endpoint,
_0xc4ed4.cacheMs,
_0xc4ed4.timeoutMs,
_0xc4ed4.failureMessage,
_0xc4ed4.expectedStatus
].join(_0x1c6cd537e4(28));
let _0x10a0a3 = 0x811c9dc5;
for (const _0x110d99 of new TextEncoder().encode(_0xfc570)) {
_0x10a0a3 ^= _0x110d99;
_0x10a0a3 = Math.imul(_0x10a0a3, 0x01000193) >>> 0;
}
return _0x10a0a3 >>> 0;
}
function _0x127b57() {
if (_0xede51() !== _0xd2f43) {
throw new Error(_0x1c6cd537e4(29));
}
}
let _0x13daea = null;
let _0x1479ad = null;
let _0x15e785 = Promise.resolve();
const _0x16a9ef = new Map();
function _0x17705a(_0x18b4d9) {
const _0x194af0 = _0x15e785.then(_0x18b4d9, _0x18b4d9);
_0x15e785 = _0x194af0.catch(() => undefined);
return _0x194af0;
}
function _0x1abf40() {
const _0x1b72d2 = chrome.runtime.getManifest();
return String(_0x1b72d2.version_name || _0x1b72d2.version || _0x1c6cd537e4(30));
}
function _0x1cb8d1(_0x1df681) {
return { authorized: _0x1df681?.status === _0x1c6cd537e4(31) };
}
function _0x1e652c(_0x1f5076, _0x20b0d1 = Date.now()) {
return Boolean(_0x1f5076 &&
_0x1f5076.status === _0x1c6cd537e4(31) &&
_0x1f5076.version === _0x1abf40() &&
Number(_0x1f5076.expiresAt) > _0x20b0d1);
}
async function _0x21854d(_0x22d378) {
if (_0x1479ad === _0x22d378) {
return;
}
_0x1479ad = _0x22d378;
try {
await chrome.runtime.sendMessage({
type: _0x1c6cd537e4(32),
authorized: Boolean(_0x22d378)
});
}
catch {
}
}
function _0x231c92(_0x247eb6, _0x25755a) {
if (!_0x247eb6 || !_0x54db2.has(_0x247eb6.mode)) {
return;
}
_0x247eb6.authorizationBlocked = true;
_0x247eb6.updatedAt = new Date().toISOString();
if (_0x64371.has(_0x247eb6.phase)) {
_0x247eb6.authorizationFailureDeferred = true;
return;
}
_0x247eb6.authorizationFailureDeferred = false;
_0x247eb6.mode = _0x1c6cd537e4(9);
_0x247eb6.pauseReason = _0xc4ed4.failureMessage;
const _0x262855 = _0x144a799(_0x247eb6);
const _0x272d4c = _0x25755a?.[_0x25755a.length - 1];
if (_0x272d4c?.message !== _0xc4ed4.failureMessage) {
_0xadb373(_0x25755a, _0x1c6cd537e4(33), _0xc4ed4.failureMessage, _0x262855?.rowNumber ?? null);
}
}
async function _0x28cbfd() {
const _0x29cf65 = await chrome.storage.local.get([_0x1a6d9.RUN_STATE, _0x1a6d9.LOGS]);
const _0x2a7db0 = _0x29cf65[_0x1a6d9.RUN_STATE] || null;
const _0x2bb6e5 = Array.isArray(_0x29cf65[_0x1a6d9.LOGS]) ? _0x29cf65[_0x1a6d9.LOGS] : [];
_0x231c92(_0x2a7db0, _0x2bb6e5);
await chrome.storage.local.set({
[_0x1a6d9.RUN_STATE]: _0x2a7db0,
[_0x1a6d9.LOGS]: _0x2bb6e5
});
await _0x21854d(false);
}
async function _0x2c0d66() {
const _0x2dfa82 = await chrome.storage.local.get(_0x1a6d9.RUN_STATE);
const _0x2ea879 = _0x2dfa82[_0x1a6d9.RUN_STATE] || null;
if (_0x2ea879?.authorizationBlocked) {
_0x2ea879.authorizationBlocked = false;
_0x2ea879.authorizationFailureDeferred = false;
if (_0x2ea879.pauseReason === _0xc4ed4.failureMessage) {
_0x2ea879.pauseReason = _0x1c6cd537e4(34);
}
_0x2ea879.updatedAt = new Date().toISOString();
await chrome.storage.local.set({ [_0x1a6d9.RUN_STATE]: _0x2ea879 });
}
await _0x21854d(true);
}
async function _0x2f88fb() {
_0x127b57();
const _0x3074a0 = new AbortController();
const _0x317e7b = setTimeout(() => _0x3074a0.abort(), _0xc4ed4.timeoutMs);
try {
const _0x323e7b = new URL(_0xc4ed4.endpoint);
_0x323e7b.searchParams.set(_0x1c6cd537e4(35), _0x1abf40());
_0x323e7b.searchParams.set(_0x1c6cd537e4(36), String(Date.now()));
const _0x332d8c = await fetch(_0x323e7b.toString(), {
method: _0x1c6cd537e4(37),
cache: _0x1c6cd537e4(38),
credentials: _0x1c6cd537e4(39),
redirect: _0x1c6cd537e4(33),
signal: _0x3074a0.signal
});
if (_0x332d8c.status !== _0xc4ed4.expectedStatus) {
throw new Error(`HTTP_${_0x332d8c.status}`);
}
try {
await _0x332d8c.body?.cancel();
}
catch {
}
const _0x34d44d = Date.now();
return {
status: _0x1c6cd537e4(31),
version: _0x1abf40(),
checkedAt: _0x34d44d,
expiresAt: _0x34d44d + _0xc4ed4.cacheMs
};
}
finally {
clearTimeout(_0x317e7b);
}
}
async function _0x35e48a(_0x3640e9 = false) {
const _0x377df6 = await chrome.storage.local.get(_0x1a6d9.AUTHORIZATION);
const _0x38f626 = _0x377df6[_0x1a6d9.AUTHORIZATION] || null;
const _0x39d021 = Date.now();
if (!_0x3640e9 && _0x1e652c(_0x38f626, _0x39d021)) {
return _0x1cb8d1(_0x38f626);
}
if (!_0x3640e9 &&
_0x38f626?.status === _0x1c6cd537e4(40) &&
_0x38f626.version === _0x1abf40()) {
await _0x28cbfd();
return _0x1cb8d1(_0x38f626);
}
if (_0x13daea) {
return _0x13daea;
}
_0x13daea = (async () => {
try {
const _0x3a1af6 = await _0x2f88fb();
await chrome.storage.local.set({ [_0x1a6d9.AUTHORIZATION]: _0x3a1af6 });
await _0x2c0d66();
return _0x1cb8d1(_0x3a1af6);
}
catch (_0x3b6663) {
const _0x3c6818 = {
status: _0x1c6cd537e4(40),
version: _0x1abf40(),
checkedAt: Date.now(),
expiresAt: 0,
reason: _0x3b6663?.name === _0x1c6cd537e4(41) ? _0x1c6cd537e4(42) : _0x1c6cd537e4(43)
};
await chrome.storage.local.set({ [_0x1a6d9.AUTHORIZATION]: _0x3c6818 });
await _0x28cbfd();
return _0x1cb8d1(_0x3c6818);
}
finally {
_0x13daea = null;
}
})();
return _0x13daea;
}
function _0x3dce6d(_0x3e2126 = null) {
return {
ok: false,
code: _0x1c6cd537e4(44),
error: _0xc4ed4.failureMessage,
authorization: _0x3e2126 || { authorized: false, status: _0x1c6cd537e4(40) }
};
}
async function _0x3f8e02(_0x40a0a7 = false) {
try {
_0x127b57();
}
catch {
await _0x28cbfd();
return _0x3dce6d({ authorized: false });
}
const _0x417118 = await _0x35e48a(_0x40a0a7);
return _0x417118.authorized
? { ok: true, authorization: _0x417118 }
: _0x3dce6d(_0x417118);
}
async function _0x422a29(_0x436b14) {
const _0x44cb8c = await _0x3f8e02(false);
if (!_0x44cb8c.ok) {
return _0x44cb8c;
}
return _0x436b14();
}
async function _0x45ab20() {
const _0x46e061 = await _0x35e48a(false);
const _0x478131 = await _0x1493fef();
return { ok: true, data: _0x478131, authorization: _0x46e061 };
}
async function _0x487a5c() {
const _0x4975d3 = await _0x35e48a(true);
return _0x4975d3.authorized
? { ok: true, authorization: _0x4975d3 }
: _0x3dce6d(_0x4975d3);
}
async function _0x4a4443(_0x4b0671) {
const _0x4c0e9a = await chrome.storage.local.get(_0x1a6d9.RUN_STATE);
const _0x4dc809 = _0x4c0e9a[_0x1a6d9.RUN_STATE] || null;
const _0x4ed299 = Boolean(_0x4dc809 &&
_0x4b0671.tab?.id === _0x4dc809.workTabId &&
_0x64371.has(_0x4dc809.phase));
if (!_0x4ed299) {
const _0x4f2dd8 = await _0x3f8e02(false);
if (!_0x4f2dd8.ok) {
return _0x4f2dd8;
}
}
const _0x50ccf3 = await _0x28e6252(_0x4b0671);
if (_0x4ed299) {
const _0x513d9f = await chrome.storage.local.get(_0x1a6d9.AUTHORIZATION);
_0x50ccf3.authorization = _0x1cb8d1(_0x513d9f[_0x1a6d9.AUTHORIZATION]);
_0x50ccf3.authorizationDeferred = !_0x50ccf3.authorization.authorized;
}
else {
_0x50ccf3.authorization = { authorized: true, status: _0x1c6cd537e4(31) };
}
return _0x50ccf3;
}
function _0x52e375(_0x53d791) {
return new Promise((_0x54fe77) => setTimeout(_0x54fe77, _0x53d791));
}
function _0x55f407(_0x56f879, _0x577793 = _0x22bcb.orderIntervalSeconds) {
const _0x58ece2 = Number(_0x56f879);
if (!Number.isInteger(_0x58ece2) || _0x58ece2 < 0 || _0x58ece2 > 3600) {
return _0x577793;
}
return _0x58ece2;
}
function _0x59440f(_0x5a9831) {
const _0x5b185a = _0x5a9831 && typeof _0x5a9831 === _0x1c6cd537e4(45) ? _0x5a9831 : {};
return {
orderIntervalSeconds: _0x55f407(_0x5b185a.orderIntervalSeconds, _0x22bcb.orderIntervalSeconds)
};
}
function _0x5c4614(_0x5dad7b) {
return _0xa5a3c.test(String(_0x5dad7b ?? _0x1c6cd537e4(34)).trim());
}
function _0x5eb9d7(_0x5f53bf) {
const _0x603e2e = String(_0x5f53bf ?? _0x1c6cd537e4(34)).trim();
if (!/^[1-9]\d*$/.test(_0x603e2e)) {
return null;
}
const _0x61c1f1 = Number(_0x603e2e);
return Number.isSafeInteger(_0x61c1f1) ? _0x61c1f1 : null;
}
function _0x628bfe(_0x631f72) {
return `${_0x95e49}${String(_0x631f72 || _0x1c6cd537e4(34))}`;
}
function _0x64162d(_0x654218) {
const _0x665ca1 = _0x16a9ef.get(_0x654218);
if (_0x665ca1 !== undefined) {
clearTimeout(_0x665ca1);
_0x16a9ef.delete(_0x654218);
}
}
async function _0x6755c1(_0x68261f) {
if (!_0x68261f) {
return false;
}
return chrome.alarms.clear(_0x628bfe(_0x68261f));
}
async function _0x69e03d(_0x6acf13) {
_0x64162d(_0x6acf13);
try {
await _0x6755c1(_0x6acf13);
}
catch {
}
}
function _0x6b5365(_0x6c2433) {
const _0x6d1fb2 = Date.parse(String(_0x6c2433?.intervalEndsAt || _0x1c6cd537e4(34)));
if (Number.isFinite(_0x6d1fb2)) {
return Math.max(0, _0x6d1fb2 - Date.now());
}
const _0x6e8690 = Number(_0x6c2433?.intervalRemainingSeconds || 0);
return Math.max(0, _0x6e8690 * 1000);
}
async function _0x6f1845(_0x70b3ba, _0x71cdbf) {
const _0x72625e = _0x70b3ba?.runId;
if (!_0x72625e) {
throw new Error(_0x1c6cd537e4(46));
}
const _0x73f2c2 = Math.max(0, Number(_0x71cdbf) || 0);
const _0x74949d = Date.now() + _0x73f2c2;
await _0x69e03d(_0x72625e);
await chrome.alarms.create(_0x628bfe(_0x72625e), { when: _0x74949d });
if (_0x73f2c2 <= 60000) {
const _0x75a985 = setTimeout(() => {
_0x16a9ef.delete(_0x72625e);
_0x17705a(() => _0x1d19389(_0x72625e)).catch((_0x76780e) => console.error(_0x76780e));
}, _0x73f2c2);
_0x16a9ef.set(_0x72625e, _0x75a985);
}
}
function _0x778307(_0x78e413 = new Date()) {
const _0x794a9f = new Intl.DateTimeFormat(_0x1c6cd537e4(47), {
timeZone: _0x1c6cd537e4(48),
year: _0x1c6cd537e4(49),
month: _0x1c6cd537e4(50),
day: _0x1c6cd537e4(50)
}).formatToParts(_0x78e413);
const _0x7a9e10 = Object.fromEntries(_0x794a9f.map((_0x7bd106) => [_0x7bd106.type, _0x7bd106.value]));
return `${_0x7a9e10.year}-${_0x7a9e10.month}-${_0x7a9e10.day}`;
}
function _0x7cfe7f(_0x7deb5b = new Date()) {
return new Intl.DateTimeFormat(_0x1c6cd537e4(51), {
timeZone: _0x1c6cd537e4(48),
year: _0x1c6cd537e4(49),
month: _0x1c6cd537e4(50),
day: _0x1c6cd537e4(50),
hour: _0x1c6cd537e4(50),
minute: _0x1c6cd537e4(50),
second: _0x1c6cd537e4(50),
hourCycle: _0x1c6cd537e4(52)
}).format(_0x7deb5b);
}
function _0x7ee5dd(_0x7fbb3b) {
return String(_0x7fbb3b ?? _0x1c6cd537e4(34))
.normalize(_0x1c6cd537e4(53))
.replace(/\s+/g, _0x1c6cd537e4(54))
.trim();
}
function _0x80cd3c(_0x813e8b) {
return String(_0x813e8b ?? _0x1c6cd537e4(34))
.normalize(_0x1c6cd537e4(53))
.replace(/[^\p{L}\p{M}\s\-'’]/gu, _0x1c6cd537e4(54))
.replace(/\s+/g, _0x1c6cd537e4(54))
.trim();
}
function _0x82279e(_0x83ed52) {
return _0x7ee5dd(_0x83ed52).toLocaleLowerCase(_0x1c6cd537e4(55));
}
function _0x842448(_0x859e3e) {
return String(_0x859e3e ?? _0x1c6cd537e4(34))
.normalize(_0x1c6cd537e4(53))
.replace(/\s+/g, _0x1c6cd537e4(34))
.trim()
.toUpperCase();
}
function _0x8637b0(_0x87a6e3) {
const _0x882c59 = String(_0x87a6e3 ?? _0x1c6cd537e4(34)).trim();
if (!_0x882c59) {
return null;
}
let _0x890b75;
try {
_0x890b75 = new URL(_0x882c59);
}
catch {
return null;
}
const _0x8a9130 = _0x890b75.hostname.toLowerCase();
if (_0x8a9130 !== _0x1c6cd537e4(56) && !_0x8a9130.endsWith(_0x1c6cd537e4(57))) {
return null;
}
const _0x8b0bc0 = [
/\/(?:dp|gp\/product|gp\/aw\/d)\/([A-Z0-9]{10})(?:[/?]|$)/i,
/\/product\/([A-Z0-9]{10})(?:[/?]|$)/i
];
for (const _0x8cc2f0 of _0x8b0bc0) {
const _0x8d34f0 = _0x890b75.pathname.match(_0x8cc2f0);
if (_0x8d34f0) {
return _0x8d34f0[1].toUpperCase();
}
}
const _0x8ec13a = _0x890b75.searchParams.get(_0x1c6cd537e4(58)) || _0x890b75.searchParams.get(_0x1c6cd537e4(59));
if (_0x8ec13a && /^[A-Z0-9]{10}$/i.test(_0x8ec13a)) {
return _0x8ec13a.toUpperCase();
}
return null;
}
function _0x8f5765(_0x90c828) {
const _0x91b950 = _0x842448(_0x90c828);
return _0x91b950 ? `temu:${_0x91b950}` : _0x1c6cd537e4(34);
}
function _0x9285d3(_0x93a12f, _0x944f43) {
const _0x95ef37 = String(_0x93a12f || _0x1c6cd537e4(34)).trim();
if (/^\d{4}-\d{2}-\d{2}$/.test(_0x95ef37)) {
return _0x95ef37;
}
const _0x963d79 = new Date(_0x944f43 || _0x1c6cd537e4(34));
return Number.isNaN(_0x963d79.getTime()) ? _0x1c6cd537e4(34) : _0x778307(_0x963d79);
}
function _0x97dc56(_0x985863) {
const _0x99aacc = [];
for (const _0x9afb21 of Array.isArray(_0x985863) ? _0x985863 : []) {
const _0x9ba47f = _0x842448(_0x9afb21?.temuOrderIdKey || _0x9afb21?.temuOrderId || _0x1c6cd537e4(34));
const _0x9ca250 = String(_0x9afb21?.orderId || _0x1c6cd537e4(34)).trim();
if (!_0x9ba47f || _0x9afb21?.status !== _0x1c6cd537e4(60) || !_0x5c4614(_0x9ca250)) {
continue;
}
_0x99aacc.push({
..._0x9afb21,
temuOrderId: _0x9ba47f,
temuOrderIdKey: _0x9ba47f,
status: _0x1c6cd537e4(60),
orderId: _0x9ca250,
dateKey: _0x9285d3(_0x9afb21?.dateKey, _0x9afb21?.updatedAt || _0x9afb21?.createdAt),
addressSignature: String(_0x9afb21?.addressSignature || _0x1c6cd537e4(34)),
itemSignature: String(_0x9afb21?.itemSignature || _0x1c6cd537e4(34)),
temuSignature: String(_0x9afb21?.temuSignature || _0x1c6cd537e4(34)),
groupSignature: String(_0x9afb21?.groupSignature || _0x1c6cd537e4(34)),
updatedAt: _0x9afb21?.updatedAt || _0x9afb21?.createdAt || new Date().toISOString()
});
}
return _0x99aacc;
}
function _0x9d4f15(_0x9e03e7, _0x9fde3f = []) {
const _0xa09844 = {};
const _0xa140f9 = [];
if (_0x9e03e7 && typeof _0x9e03e7 === _0x1c6cd537e4(45) && !Array.isArray(_0x9e03e7)) {
for (const _0xa20dcc of Object.values(_0x9e03e7)) {
const _0xa3969c = _0x842448(_0xa20dcc?.temuOrderId || _0x1c6cd537e4(34));
const _0xa4e20c = String(_0xa20dcc?.orderId || _0x1c6cd537e4(34)).trim();
if (!_0xa3969c || _0xa20dcc?.status !== _0x1c6cd537e4(60) || !_0x5c4614(_0xa4e20c)) {
continue;
}
_0xa140f9.push({
..._0xa20dcc,
temuOrderId: _0xa3969c,
orderId: _0xa4e20c,
status: _0x1c6cd537e4(60),
dateKey: _0x9285d3(_0xa20dcc?.dateKey, _0xa20dcc?.updatedAt),
addressSignature: String(_0xa20dcc?.addressSignature || _0x1c6cd537e4(34)),
itemSignature: String(_0xa20dcc?.itemSignature || _0x1c6cd537e4(34)),
temuSignature: String(_0xa20dcc?.temuSignature || _0x1c6cd537e4(34)),
groupSignature: String(_0xa20dcc?.groupSignature || _0x1c6cd537e4(34)),
updatedAt: _0xa20dcc?.updatedAt || new Date(0).toISOString()
});
}
}
for (const _0xa5aeb8 of _0x9fde3f) {
_0xa140f9.push({
temuOrderId: _0x842448(_0xa5aeb8.temuOrderIdKey || _0xa5aeb8.temuOrderId),
status: _0x1c6cd537e4(60),
orderId: _0xa5aeb8.orderId,
dateKey: _0xa5aeb8.dateKey,
addressSignature: String(_0xa5aeb8.addressSignature || _0x1c6cd537e4(34)),
itemSignature: String(_0xa5aeb8.itemSignature || _0x1c6cd537e4(34)),
temuSignature: String(_0xa5aeb8.temuSignature || _0x1c6cd537e4(34)),
groupSignature: String(_0xa5aeb8.groupSignature || _0x1c6cd537e4(34)),
updatedAt: _0xa5aeb8.updatedAt
});
}
for (const _0xa6ddf8 of _0xa140f9) {
const _0xa735f7 = _0x8f5765(_0xa6ddf8.temuOrderId);
if (!_0xa735f7) {
continue;
}
const _0xa8f734 = _0xa09844[_0xa735f7];
if (!_0xa8f734 || String(_0xa6ddf8.updatedAt) >= String(_0xa8f734.updatedAt || _0x1c6cd537e4(34))) {
_0xa09844[_0xa735f7] = _0xa6ddf8;
}
}
return _0xa09844;
}
function _0xa9e8db(_0xaab34e, _0xab6df0, _0xac48e4 = null) {
return {
id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
time: _0x7cfe7f(),
isoTime: new Date().toISOString(),
level: _0xaab34e,
rowNumber: _0xac48e4,
message: _0xab6df0
};
}
function _0xadb373(_0xaed2a3, _0xaf77e0, _0xb041cf, _0xb11f80 = null) {
const _0xb2101b = Array.isArray(_0xaed2a3) ? _0xaed2a3 : [];
_0xb2101b.push(_0xa9e8db(_0xaf77e0, _0xb041cf, _0xb11f80));
if (_0xb2101b.length > _0x3773d) {
_0xb2101b.splice(0, _0xb2101b.length - _0x3773d);
}
return _0xb2101b;
}
function _0xb360c3(_0xb433ab, _0xb5d135) {
const _0xb6c1ec = _0xb433ab && typeof _0xb433ab === _0x1c6cd537e4(45) ? _0xb433ab : {};
const _0xb788b4 = _0x7ee5dd(_0xb6c1ec.temuOrderId);
const _0xb8efef = _0x842448(_0xb788b4);
const _0xb9d911 = String(_0xb6c1ec.amzLink ?? _0x1c6cd537e4(34)).trim();
const _0xba714f = String(_0xb6c1ec.quantityToShip ?? _0x1c6cd537e4(34)).trim();
const _0xbb8bba = String(_0xb6c1ec.recipientName ?? _0x1c6cd537e4(34)).trim();
const _0xbc62c8 = String(_0xb6c1ec.phoneNumber ?? _0x1c6cd537e4(34)).trim();
const _0xbdc5d0 = _0x7ee5dd(_0xb6c1ec.shipAddress);
const _0xbe85ab = _0x7ee5dd(_0xb6c1ec.address2);
const _0xbfb0d9 = _0x7ee5dd(_0xb6c1ec.shipCity);
const _0xc01b4a = _0x7ee5dd(_0xb6c1ec.shipPostalCode);
const _0xc1d6f3 = _0x80cd3c(_0xbb8bba);
const _0xc2c3a0 = _0x82279e(_0xc1d6f3);
const _0xc34cc9 = _0x5eb9d7(_0xba714f);
const _0xc4cf8b = _0x8637b0(_0xb9d911);
const _0xc589f5 = _0xc1d6f3 && _0xbdc5d0 && _0xbfb0d9 && _0xc01b4a
? [
_0xc2c3a0,
_0x82279e(_0xbdc5d0),
_0x82279e(_0xbe85ab),
_0x82279e(_0xbfb0d9),
_0x82279e(_0xc01b4a)
].join(_0x1c6cd537e4(28))
: _0x1c6cd537e4(34);
let _0xc6f62e = _0x1c6cd537e4(34);
if (!_0xc1d6f3 || !_0xbdc5d0 || !_0xbfb0d9 || !_0xc01b4a || !_0xbc62c8) {
_0xc6f62e = _0x1c6cd537e4(61);
}
else if (!_0xb8efef) {
_0xc6f62e = _0x1c6cd537e4(62);
}
else if (_0xc34cc9 === null) {
_0xc6f62e = _0x1c6cd537e4(63);
}
else if (!_0xc4cf8b) {
_0xc6f62e = _0x1c6cd537e4(64);
}
return {
id: crypto.randomUUID(),
sourceIndex: _0xb5d135,
rowNumber: _0xb5d135 + 1,
temuOrderId: _0xb788b4,
normalizedTemuOrderId: _0xb8efef,
amzLink: _0xb9d911,
quantityToShip: _0xba714f,
recipientName: _0xbb8bba,
normalizedName: _0xc1d6f3,
normalizedNameKey: _0xc2c3a0,
requestedQuantity: _0xc34cc9,
phoneNumber: _0xbc62c8,
shipAddress: _0xbdc5d0,
address2: _0xbe85ab,
shipCity: _0xbfb0d9,
shipPostalCode: _0xc01b4a,
asin: _0xc4cf8b,
addressSignature: _0xc589f5,
groupId: _0x1c6cd537e4(34),
groupKey: _0xc589f5,
groupPosition: null,
groupSize: 0,
initialFailureReason: _0xc6f62e,
status: _0x1c6cd537e4(65),
result: _0x1c6cd537e4(66),
orderId: _0x1c6cd537e4(34),
observedUnitPrice: _0x1c6cd537e4(34),
selectedQuantity: _0x1c6cd537e4(34),
precheckPassed: false,
addedToCart: false,
updatedAt: new Date().toISOString()
};
}
function _0xc7f8b3(_0xc8ab2b) {
return [
_0xc8ab2b.temuOrderId,
_0xc8ab2b.amzLink,
_0xc8ab2b.quantityToShip,
_0xc8ab2b.recipientName,
_0xc8ab2b.phoneNumber,
_0xc8ab2b.shipAddress,
_0xc8ab2b.address2,
_0xc8ab2b.shipCity,
_0xc8ab2b.shipPostalCode
].every((_0xc906ff) => String(_0xc906ff ?? _0x1c6cd537e4(34)).trim() === _0x1c6cd537e4(34));
}
function _0xca6809(_0xcb1d39, _0xcc827a, _0xcd0fc8) {
_0xcb1d39.status = _0xcc827a;
_0xcb1d39.result = _0xcd0fc8;
_0xcb1d39.updatedAt = new Date().toISOString();
}
function _0xce0c4c(_0xcf9f06, _0xd09daf) {
const _0xd14492 = new Map();
for (const _0xd27f60 of _0xd09daf) {
const _0xd348b0 = _0xcf9f06[_0xd27f60];
if (!_0xd348b0?.asin || !Number.isSafeInteger(_0xd348b0.requestedQuantity) || _0xd348b0.requestedQuantity <= 0) {
continue;
}
_0xd14492.set(_0xd348b0.asin, (_0xd14492.get(_0xd348b0.asin) || 0) + _0xd348b0.requestedQuantity);
}
return [..._0xd14492.entries()]
.sort(([_0xd437e0], [_0xd56543]) => _0xd437e0.localeCompare(_0xd56543))
.map(([_0xd65d33, _0xd73659]) => ({ asin: _0xd65d33, quantity: _0xd73659 }));
}
function _0xd8a581(_0xd90cf4) {
return (Array.isArray(_0xd90cf4) ? _0xd90cf4 : [])
.map((_0xda198d) => `${_0xda198d.asin}x${_0xda198d.quantity}`)
.join(_0x1c6cd537e4(28));
}
function _0xdbcd11(_0xdcd005, _0xddc122, _0xdeb764) {
return _0xddc122.rowIndexes.filter((_0xdfa280) => _0xdcd005[_0xdfa280]?.normalizedTemuOrderId === _0xdeb764);
}
function _0xe0384d(_0xe17787, _0xe2c9f1, _0xe3db77) {
const _0xe4c8e9 = [..._0xe2c9f1].sort((_0xe556b8, _0xe62127) => _0xe17787[_0xe556b8].sourceIndex - _0xe17787[_0xe62127].sourceIndex);
const _0xe71631 = _0xe4c8e9[0];
const _0xe8bc0c = _0xe17787[_0xe71631];
const _0xe90003 = [...new Set(_0xe4c8e9.map((_0xea977c) => _0x7ee5dd(_0xe17787[_0xea977c].phoneNumber)).filter(Boolean))];
const _0xeb3b6d = _0xce0c4c(_0xe17787, _0xe4c8e9);
const _0xeca04b = _0xeb3b6d.reduce((_0xed92cb, _0xeee135) => _0xed92cb + _0xeee135.quantity, 0);
const _0xefa510 = [...new Set(_0xe4c8e9.map((_0xf06a9c) => _0xe17787[_0xf06a9c].normalizedTemuOrderId).filter(Boolean))];
const _0xf19ed6 = {};
const _0xf2e683 = {};
for (const _0xf3f923 of _0xefa510) {
const _0xf425e9 = _0xdbcd11(_0xe17787, { rowIndexes: _0xe4c8e9 }, _0xf3f923);
const _0xf5c517 = _0xce0c4c(_0xe17787, _0xf425e9);
const _0xf60f3f = _0xd8a581(_0xf5c517);
_0xf2e683[_0xf3f923] = _0xf60f3f;
_0xf19ed6[_0xf3f923] = `${_0xe8bc0c.addressSignature}||${_0xf60f3f}`;
}
const _0xf716cd = `group-${_0xe3db77}-${crypto.randomUUID()}`;
_0xe4c8e9.forEach((_0xf85ec6, _0xf95656) => {
_0xe17787[_0xf85ec6].groupId = _0xf716cd;
_0xe17787[_0xf85ec6].groupPosition = _0xf95656;
_0xe17787[_0xf85ec6].groupSize = _0xe4c8e9.length;
});
return {
id: _0xf716cd,
key: _0xe8bc0c.addressSignature,
sortKey: [
_0x82279e(_0xe8bc0c.shipAddress),
_0x82279e(_0xe8bc0c.address2),
_0x82279e(_0xe8bc0c.shipCity),
_0x82279e(_0xe8bc0c.shipPostalCode),
_0xe8bc0c.normalizedNameKey
].join(_0x1c6cd537e4(28)),
originalPosition: _0xe8bc0c.sourceIndex,
rowIndexes: _0xe4c8e9,
primaryRowIndex: _0xe71631,
isCombined: _0xe4c8e9.length > 1,
normalizedName: _0xe8bc0c.normalizedName,
normalizedNameKey: _0xe8bc0c.normalizedNameKey,
shipAddress: _0xe8bc0c.shipAddress,
address2: _0xe8bc0c.address2,
shipCity: _0xe8bc0c.shipCity,
shipPostalCode: _0xe8bc0c.shipPostalCode,
phoneNumber: _0xe8bc0c.phoneNumber,
phoneMismatch: _0xe90003.length > 1,
phoneNumbers: _0xe90003,
addressSignature: _0xe8bc0c.addressSignature,
expectedItems: _0xeb3b6d,
expectedItemSignature: _0xd8a581(_0xeb3b6d),
expectedTotalQuantity: _0xeca04b,
uniqueTemuOrderIds: _0xefa510,
temuSignatures: _0xf19ed6,
temuItemSignatures: _0xf2e683,
groupSignature: `${_0xe8bc0c.addressSignature}||${_0xd8a581(_0xeb3b6d)}`,
result: _0x1c6cd537e4(67),
status: _0x1c6cd537e4(65),
triggerRowIndex: null,
precheckCursor: 0,
addCursor: 0,
expectedCartCount: 0,
actualDeliveryAddress: _0x1c6cd537e4(34),
orderId: _0x1c6cd537e4(34),
updatedAt: new Date().toISOString()
};
}
function _0xfa7111(_0xfb1886, _0xfc02f8, _0xfd647f, _0xfe2b2d) {
_0xfc02f8.result = _0x1c6cd537e4(68);
_0xfc02f8.status = _0xfe2b2d;
_0xfc02f8.triggerRowIndex = _0xfd647f;
_0xfc02f8.updatedAt = new Date().toISOString();
for (const _0xff3613 of _0xfc02f8.rowIndexes) {
const _0x1009496 = _0xfb1886[_0xff3613];
const _0x1017e57 = _0xff3613 === _0xfd647f || _0xfc02f8.rowIndexes.length === 1
? _0xfe2b2d : _0x1c6cd537e4(69);
_0xca6809(_0x1009496, _0x1017e57, _0x1c6cd537e4(68));
}
}
function _0x10286f1(_0x103bf12, _0x1044e1b, _0x105569f) {
_0x1044e1b.result = _0x1c6cd537e4(70);
_0x1044e1b.status = `等待人工检查：${_0x105569f}`;
_0x1044e1b.updatedAt = new Date().toISOString();
for (const _0x106a055 of _0x1044e1b.rowIndexes) {
_0xca6809(_0x103bf12[_0x106a055], `等待人工检查：${_0x105569f}`, _0x1c6cd537e4(70));
}
}
function _0x107eadd(_0x108722d, _0x10967e0, _0x10a3a7d) {
_0x10967e0.result = _0x1c6cd537e4(71);
_0x10967e0.status = _0x10a3a7d;
_0x10967e0.updatedAt = new Date().toISOString();
for (const _0x10b714d of _0x10967e0.rowIndexes) {
const _0x10c2a43 = _0x108722d[_0x10b714d];
if (_0x10c2a43.result !== _0x1c6cd537e4(72) && _0x10c2a43.result !== _0x1c6cd537e4(68)) {
_0xca6809(_0x10c2a43, _0x10a3a7d, _0x1c6cd537e4(71));
}
}
}
function _0x10dc76a(_0x10efadd, _0x10fb751, _0x1104a92) {
_0x10fb751.result = _0x1c6cd537e4(72);
_0x10fb751.status = _0x1c6cd537e4(73);
_0x10fb751.orderId = _0x1104a92;
_0x10fb751.updatedAt = new Date().toISOString();
for (const _0x1110bbd of _0x10fb751.rowIndexes) {
const _0x11283de = _0x10efadd[_0x1110bbd];
_0x11283de.orderId = _0x1104a92;
_0xca6809(_0x11283de, _0x1c6cd537e4(73), _0x1c6cd537e4(72));
}
}
function _0x113e2e3(_0x114d53c, _0x115acdf, _0x1168cb3) {
const _0x117a886 = _0x9d4f15(_0x1168cb3, _0x115acdf);
const _0x11879a2 = _0x778307();
const _0x119c174 = (Array.isArray(_0x114d53c) ? _0x114d53c : [])
.map((_0x11a3366, _0x11b53ba) => _0xb360c3(_0x11a3366, _0x11b53ba))
.filter((_0x11c616f) => !_0xc7f8b3(_0x11c616f));
const _0x11d8816 = new Map();
for (let _0x11e3658 = 0; _0x11e3658 < _0x119c174.length; _0x11e3658 += 1) {
const _0x11f1d01 = _0x119c174[_0x11e3658];
if (!_0x11f1d01.addressSignature) {
_0xca6809(_0x11f1d01, _0x11f1d01.initialFailureReason || _0x1c6cd537e4(61), _0x1c6cd537e4(68));
continue;
}
if (!_0x11d8816.has(_0x11f1d01.addressSignature)) {
_0x11d8816.set(_0x11f1d01.addressSignature, []);
}
_0x11d8816.get(_0x11f1d01.addressSignature).push(_0x11e3658);
}
const _0x120da4e = [..._0x11d8816.values()].map((_0x12145b2, _0x1223452) => _0xe0384d(_0x119c174, _0x12145b2, _0x1223452 + 1));
_0x120da4e.sort((_0x1239889, _0x124521e) => _0x1239889.sortKey.localeCompare(_0x124521e.sortKey, _0x1c6cd537e4(55)) || _0x1239889.originalPosition - _0x124521e.originalPosition);
for (const _0x1259107 of _0x120da4e) {
const _0x126e5f5 = _0x1259107.rowIndexes.find((_0x12797a4) => _0x119c174[_0x12797a4].initialFailureReason);
if (_0x126e5f5 !== undefined) {
_0xfa7111(_0x119c174, _0x1259107, _0x126e5f5, _0x119c174[_0x126e5f5].initialFailureReason);
}
else {
_0x1259107.result = _0x1c6cd537e4(67);
_0x1259107.status = _0x1c6cd537e4(65);
for (const _0x128b923 of _0x1259107.rowIndexes) {
_0xca6809(_0x119c174[_0x128b923], _0x1c6cd537e4(65), _0x1c6cd537e4(67));
}
}
}
const _0x1298c79 = [];
const _0x12a5fb3 = new Map();
for (const _0x12be573 of _0x120da4e) {
for (const _0x12cba77 of _0x12be573.uniqueTemuOrderIds) {
if (!_0x12a5fb3.has(_0x12cba77)) {
_0x12a5fb3.set(_0x12cba77, new Set());
}
_0x12a5fb3.get(_0x12cba77).add(_0x12be573.id);
}
}
for (const [_0x12d6b2a, _0x12e206f] of _0x12a5fb3.entries()) {
if (_0x12e206f.size <= 1) {
continue;
}
const _0x12fe63d = `Temu Order ID ${_0x12d6b2a} 出现在不同收件地址组，已停止等待人工检查。`;
_0x1298c79.push(_0x12fe63d);
for (const _0x1309c3e of _0x12e206f) {
const _0x1313261 = _0x120da4e.find((_0x1325dbb) => _0x1325dbb.id === _0x1309c3e);
if (_0x1313261) {
_0x10286f1(_0x119c174, _0x1313261, _0x12fe63d);
}
}
}
for (const _0x133d643 of _0x120da4e) {
if (_0x133d643.result !== _0x1c6cd537e4(67)) {
continue;
}
let _0x134ae69 = null;
let _0x135cba7 = null;
for (const _0x1369ae4 of _0x133d643.uniqueTemuOrderIds) {
const _0x137a490 = _0x117a886[_0x8f5765(_0x1369ae4)];
if (!_0x137a490 ||
_0x137a490.status !== _0x1c6cd537e4(60) ||
_0x137a490.dateKey !== _0x11879a2 ||
!_0x5c4614(_0x137a490.orderId)) {
continue;
}
const _0x138b1e4 = _0x133d643.temuSignatures[_0x1369ae4] || _0x1c6cd537e4(34);
if (_0x137a490.temuSignature && _0x138b1e4 && _0x137a490.temuSignature !== _0x138b1e4) {
_0x135cba7 = `Temu Order ID ${_0x1369ae4} 今天已有订单，但本次地址、商品或数量签名不同，已停止等待人工检查。`;
break;
}
const _0x1394db0 = _0x133d643.rowIndexes.find((_0x13af23d) => _0x119c174[_0x13af23d].normalizedTemuOrderId === _0x1369ae4);
_0x134ae69 = {
triggerRowIndex: _0x1394db0,
reason: _0x1c6cd537e4(74)
};
break;
}
if (_0x135cba7) {
_0x1298c79.push(_0x135cba7);
_0x10286f1(_0x119c174, _0x133d643, _0x135cba7);
}
else if (_0x134ae69) {
_0xfa7111(_0x119c174, _0x133d643, _0x134ae69.triggerRowIndex, _0x134ae69.reason);
}
}
const _0x13b178b = [...new Set(Object.values(_0x117a886)
.filter((_0x13c45be) => _0x13c45be?.dateKey === _0x11879a2 && _0x5c4614(_0x13c45be?.orderId))
.map((_0x13d2573) => _0x13d2573.orderId))];
return { rows: _0x119c174, groups: _0x120da4e, orderIndex: _0x117a886, fatalConflicts: _0x1298c79, knownOrderIds: _0x13b178b };
}
function _0x13e497f(_0x13f35a3, _0x140a348 = -1) {
for (let _0x1418506 = _0x140a348 + 1; _0x1418506 < _0x13f35a3.length; _0x1418506 += 1) {
if (_0x13f35a3[_0x1418506]?.result === _0x1c6cd537e4(67)) {
return _0x1418506;
}
}
return -1;
}
function _0x1429d3b(_0x1431328) {
if (!_0x1431328 || !Array.isArray(_0x1431328.groups) || !Number.isInteger(_0x1431328.currentGroupIndex)) {
return null;
}
return _0x1431328.groups[_0x1431328.currentGroupIndex] || null;
}
function _0x144a799(_0x145a342) {
if (!_0x145a342 || !Array.isArray(_0x145a342.rows) || !Number.isInteger(_0x145a342.currentIndex)) {
return null;
}
return _0x145a342.rows[_0x145a342.currentIndex] || null;
}
function _0x146d3ad(_0x147c849) {
const _0x1486c78 = _0x1429d3b(_0x147c849);
if (!_0x1486c78 || !Array.isArray(_0x147c849?.rows)) {
return _0x144a799(_0x147c849);
}
return _0x147c849.rows[_0x1486c78.primaryRowIndex] || _0x144a799(_0x147c849);
}
async function _0x1493fef() {
return chrome.storage.local.get([
_0x1a6d9.RUN_STATE,
_0x1a6d9.HISTORY,
_0x1a6d9.ORDER_INDEX,
_0x1a6d9.CART_LOCK,
_0x1a6d9.LOGS,
_0x1a6d9.DRAFT_ROWS,
_0x1a6d9.SETTINGS
]);
}
async function _0x14a1ba1() {
const _0x14ba921 = chrome.runtime.getURL(_0x1c6cd537e4(75));
const _0x14c20f1 = await chrome.windows.getAll({ populate: true });
for (const _0x14d915e of _0x14c20f1) {
const _0x14e5332 = _0x14d915e.tabs?.find((_0x14f029f) => _0x14f029f.url === _0x14ba921);
if (_0x14e5332) {
await chrome.windows.update(_0x14d915e.id, { focused: true });
await chrome.tabs.update(_0x14e5332.id, { active: true });
return;
}
}
await chrome.windows.create({
url: _0x14ba921,
type: _0x1c6cd537e4(76),
width: 1440,
height: 920,
focused: true
});
}
async function _0x150e2ae(_0x1514ddd = null) {
if (Number.isInteger(_0x1514ddd)) {
try {
const _0x152308b = await chrome.tabs.get(_0x1514ddd);
await chrome.tabs.update(_0x152308b.id, { url: _0x1c6cd537e4(77), active: true });
await chrome.windows.update(_0x152308b.windowId, { focused: true });
await _0x52e375(120);
return _0x152308b.id;
}
catch {
}
}
const _0x153dc07 = await chrome.windows.getAll({ windowTypes: [_0x1c6cd537e4(78)] });
const _0x15457d5 = _0x153dc07.find((_0x155b2b2) => _0x155b2b2.focused) || _0x153dc07[0];
if (_0x15457d5) {
const _0x1560205 = await chrome.tabs.create({
windowId: _0x15457d5.id,
url: _0x1c6cd537e4(77),
active: true
});
await chrome.windows.update(_0x15457d5.id, { focused: true });
return _0x1560205.id;
}
const _0x1576c3b = await chrome.windows.create({
type: _0x1c6cd537e4(78),
url: _0x1c6cd537e4(77),
focused: true
});
const _0x15819e4 = _0x1576c3b.tabs?.[0]?.id;
if (!Number.isInteger(_0x15819e4)) {
throw new Error(_0x1c6cd537e4(79));
}
return _0x15819e4;
}
async function _0x159b731(_0x15a5c8e) {
if (!Number.isInteger(_0x15a5c8e)) {
throw new Error(_0x1c6cd537e4(80));
}
const _0x15b5f07 = await chrome.tabs.get(_0x15a5c8e);
await chrome.tabs.update(_0x15a5c8e, { active: true });
await chrome.windows.update(_0x15b5f07.windowId, { focused: true });
}
async function _0x15c8e36(_0x15d45d4) {
if (!Number.isInteger(_0x15d45d4)) {
return;
}
try {
await chrome.tabs.sendMessage(_0x15d45d4, { type: _0x1c6cd537e4(81) });
}
catch {
}
}
async function _0x15e5a45(_0x15f75bd, _0x1601f1e) {
if (!Number.isInteger(_0x15f75bd)) {
throw new Error(_0x1c6cd537e4(80));
}
await chrome.tabs.update(_0x15f75bd, { url: _0x1601f1e, active: true });
await _0x159b731(_0x15f75bd);
}
async function _0x1612e07(_0x162c4d1, _0x1637a0e, _0x1648d52 = {}) {
await chrome.storage.local.set({
[_0x1a6d9.RUN_STATE]: _0x162c4d1,
[_0x1a6d9.LOGS]: _0x1637a0e,
..._0x1648d52
});
}
function _0x165f524(_0x16667bb, _0x167a10a) {
return {
version: 1,
runId: _0x16667bb.runId,
groupId: _0x167a10a.id,
groupSignature: _0x167a10a.groupSignature,
rowNumbers: _0x167a10a.rowIndexes.map((_0x168e365) => _0x16667bb.rows[_0x168e365].rowNumber),
temuOrderIds: _0x167a10a.uniqueTemuOrderIds,
expectedTotalQuantity: _0x167a10a.expectedTotalQuantity,
expectedItems: _0x167a10a.expectedItems,
addedRowIndexes: [],
expectedCartCount: 0,
stage: _0x1c6cd537e4(82),
createdAt: new Date().toISOString(),
updatedAt: new Date().toISOString()
};
}
function _0x169c43a(_0x16ac2ab, _0x16b74d4, _0x16c1369) {
return Boolean(_0x16ac2ab &&
_0x16ac2ab.runId === _0x16b74d4?.runId &&
_0x16ac2ab.groupId === _0x16c1369?.id &&
_0x16ac2ab.groupSignature === _0x16c1369?.groupSignature);
}
async function _0x16dc7e1(_0x16edc09, _0x16fa91a) {
const _0x170a583 = await _0x1493fef();
const _0x171b687 = Array.isArray(_0x170a583[_0x1a6d9.LOGS]) ? _0x170a583[_0x1a6d9.LOGS] : [];
if (_0x170a583[_0x1a6d9.CART_LOCK]) {
_0xadb373(_0x171b687, _0x1c6cd537e4(33), _0x1c6cd537e4(83));
await chrome.storage.local.set({ [_0x1a6d9.LOGS]: _0x171b687 });
return {
ok: false,
error: _0x1c6cd537e4(84)
};
}
const _0x17282b5 = _0x170a583[_0x1a6d9.RUN_STATE];
if (_0x17282b5 && _0x54db2.has(_0x17282b5.mode)) {
return {
ok: false,
error: _0x1c6cd537e4(85)
};
}
if (_0x17282b5?.runId) {
await _0x69e03d(_0x17282b5.runId);
}
const _0x173dccd = _0x59440f(_0x170a583[_0x1a6d9.SETTINGS]);
const _0x1743886 = _0x16fa91a ?? _0x173dccd.orderIntervalSeconds;
const _0x175a36b = Number(_0x1743886);
if (!Number.isInteger(_0x175a36b) || _0x175a36b < 0 || _0x175a36b > 3600) {
return { ok: false, error: _0x1c6cd537e4(86) };
}
const _0x176e1db = _0x175a36b;
const _0x177d054 = { orderIntervalSeconds: _0x176e1db };
const _0x178d1b2 = _0x97dc56(_0x170a583[_0x1a6d9.HISTORY]);
const _0x17943ea = _0x113e2e3(_0x16edc09, _0x178d1b2, _0x170a583[_0x1a6d9.ORDER_INDEX]);
const { rows, groups, orderIndex, fatalConflicts, knownOrderIds } = _0x17943ea;
if (rows.length === 0) {
return { ok: false, error: _0x1c6cd537e4(87) };
}
_0xadb373(_0x171b687, _0x1c6cd537e4(88), `任务预检查开始：共 ${rows.length} 条非空数据，内部形成 ${groups.length} 个收件人地址组。`);
_0xadb373(_0x171b687, _0x1c6cd537e4(88), _0x1c6cd537e4(89));
for (const _0x17a35f8 of groups) {
if (_0x17a35f8.phoneMismatch) {
const _0x17bbc2e = rows[_0x17a35f8.primaryRowIndex];
_0xadb373(_0x171b687, _0x1c6cd537e4(90), `同地址组合单存在不同电话号码，将使用原始输入中最先出现一行的电话号码：${_0x17bbc2e.phoneNumber}。`, _0x17bbc2e.rowNumber);
}
}
const _0x17c29c4 = groups.filter((_0x17d046d) => _0x17d046d.result === _0x1c6cd537e4(67)).length;
const _0x17ebeaf = groups.filter((_0x17f82be) => _0x17f82be.result === _0x1c6cd537e4(67) && _0x17f82be.isCombined).length;
const _0x1800389 = rows.filter((_0x181ffb3) => _0x181ffb3.result === _0x1c6cd537e4(68)).length;
_0xadb373(_0x171b687, _0x1c6cd537e4(88), `预检查完成：待处理地址组 ${_0x17c29c4} 个（其中组合单 ${_0x17ebeaf} 个），预先跳过 ${_0x1800389} 行。`);
if (fatalConflicts.length > 0) {
const _0x182e0ec = groups.findIndex((_0x183b553) => _0x183b553.result === _0x1c6cd537e4(70));
const _0x184e703 = groups[_0x182e0ec] || null;
const _0x185ce61 = {
version: _0xbfe83,
runId: crypto.randomUUID(),
mode: _0x1c6cd537e4(9),
phase: _0x1c6cd537e4(91),
pauseReason: fatalConflicts[0],
currentGroupIndex: _0x182e0ec >= 0 ? _0x182e0ec : null,
currentIndex: _0x184e703?.primaryRowIndex ?? null,
rows,
groups,
workTabId: null,
orderIntervalSeconds: _0x176e1db,
intervalEndsAt: null,
intervalRemainingSeconds: 0,
knownOrderIds,
todayDateKey: _0x778307(),
startedAt: new Date().toISOString(),
updatedAt: new Date().toISOString()
};
fatalConflicts.forEach((_0x1868b42) => _0xadb373(_0x171b687, _0x1c6cd537e4(33), _0x1868b42));
await _0x1612e07(_0x185ce61, _0x171b687, {
[_0x1a6d9.DRAFT_ROWS]: Array.isArray(_0x16edc09) ? _0x16edc09 : [],
[_0x1a6d9.HISTORY]: _0x178d1b2,
[_0x1a6d9.ORDER_INDEX]: orderIndex,
[_0x1a6d9.SETTINGS]: _0x177d054
});
return { ok: true, state: _0x185ce61, paused: true };
}
const _0x187f0cc = _0x13e497f(groups);
if (_0x187f0cc === -1) {
const _0x188a243 = {
version: _0xbfe83,
runId: crypto.randomUUID(),
mode: _0x1c6cd537e4(92),
phase: _0x1c6cd537e4(93),
pauseReason: _0x1c6cd537e4(34),
currentGroupIndex: null,
currentIndex: null,
rows,
groups,
workTabId: null,
orderIntervalSeconds: _0x176e1db,
intervalEndsAt: null,
intervalRemainingSeconds: 0,
knownOrderIds,
todayDateKey: _0x778307(),
startedAt: new Date().toISOString(),
updatedAt: new Date().toISOString()
};
_0xadb373(_0x171b687, _0x1c6cd537e4(72), _0x1c6cd537e4(94));
await _0x1612e07(_0x188a243, _0x171b687, {
[_0x1a6d9.DRAFT_ROWS]: Array.isArray(_0x16edc09) ? _0x16edc09 : [],
[_0x1a6d9.HISTORY]: _0x178d1b2,
[_0x1a6d9.ORDER_INDEX]: orderIndex,
[_0x1a6d9.SETTINGS]: _0x177d054
});
return { ok: true, state: _0x188a243 };
}
const _0x1897d68 = Number.isInteger(_0x17282b5?.workTabId) ? _0x17282b5.workTabId : null;
let _0x18af882;
try {
_0x18af882 = await _0x150e2ae(_0x1897d68);
}
catch (_0x18bba74) {
return { ok: false, error: _0x18bba74.message || String(_0x18bba74) };
}
const _0x18c1e5f = {
version: _0xbfe83,
runId: crypto.randomUUID(),
mode: _0x1c6cd537e4(10),
phase: _0x1c6cd537e4(95),
pauseReason: _0x1c6cd537e4(34),
currentGroupIndex: _0x187f0cc,
currentIndex: groups[_0x187f0cc].primaryRowIndex,
rows,
groups,
workTabId: _0x18af882,
orderIntervalSeconds: _0x176e1db,
intervalEndsAt: null,
intervalRemainingSeconds: 0,
knownOrderIds,
todayDateKey: _0x778307(),
startedAt: new Date().toISOString(),
updatedAt: new Date().toISOString()
};
_0xadb373(_0x171b687, _0x1c6cd537e4(88), _0x1c6cd537e4(96));
_0xadb373(_0x171b687, _0x1c6cd537e4(88), _0x1c6cd537e4(97));
_0xadb373(_0x171b687, _0x1c6cd537e4(88), _0x1c6cd537e4(98));
_0xadb373(_0x171b687, _0x1c6cd537e4(88), `成功取得一个 Amazon Order ID 后等待 ${_0x176e1db} 秒，再处理下一个地址组。`);
await _0x1612e07(_0x18c1e5f, _0x171b687, {
[_0x1a6d9.DRAFT_ROWS]: Array.isArray(_0x16edc09) ? _0x16edc09 : [],
[_0x1a6d9.HISTORY]: _0x178d1b2,
[_0x1a6d9.ORDER_INDEX]: orderIndex,
[_0x1a6d9.SETTINGS]: _0x177d054
});
await _0x1b7061f(_0x18c1e5f, _0x171b687, false);
return { ok: true, state: _0x18c1e5f };
}
async function _0x18d56f2(_0x18e0a19, _0x18f454a) {
const _0x19003f6 = await _0x1493fef();
const _0x1912d1f = _0x19003f6[_0x1a6d9.RUN_STATE];
const _0x192cbd5 = Array.isArray(_0x19003f6[_0x1a6d9.LOGS]) ? _0x19003f6[_0x1a6d9.LOGS] : [];
if (!_0x1912d1f || _0x18f454a.tab?.id !== _0x1912d1f.workTabId) {
return { ok: false, error: _0x1c6cd537e4(99) };
}
if (_0x1912d1f.runId !== _0x18e0a19.runId) {
return { ok: false, error: _0x1c6cd537e4(100) };
}
if (_0x18e0a19.expectedPhase && _0x1912d1f.phase !== _0x18e0a19.expectedPhase) {
return { ok: false, stale: true, error: `当前阶段已变为 ${_0x1912d1f.phase}。` };
}
if (_0x1912d1f.mode !== _0x1c6cd537e4(8)) {
return { ok: false, paused: true, error: _0x1c6cd537e4(101) };
}
const _0x1939fdc = _0x144a799(_0x1912d1f);
const _0x194be13 = _0x1429d3b(_0x1912d1f);
_0x1912d1f.phase = _0x18e0a19.nextPhase;
_0x1912d1f.updatedAt = new Date().toISOString();
if (_0x1939fdc && Number.isFinite(Number(_0x18e0a19.observedUnitPrice))) {
_0x1939fdc.observedUnitPrice = Number(_0x18e0a19.observedUnitPrice).toFixed(2);
}
if (_0x1939fdc && Number.isSafeInteger(Number(_0x18e0a19.selectedQuantity)) && Number(_0x18e0a19.selectedQuantity) > 0) {
_0x1939fdc.selectedQuantity = Number(_0x18e0a19.selectedQuantity);
}
if (_0x194be13 && _0x18e0a19.observedDeliveryAddress) {
_0x194be13.actualDeliveryAddress = _0x7ee5dd(_0x18e0a19.observedDeliveryAddress);
}
if (_0x18e0a19.status) {
if (_0x194be13?.isCombined && _0x80c29.has(_0x18e0a19.nextPhase)) {
_0x107eadd(_0x1912d1f.rows, _0x194be13, _0x18e0a19.status);
}
else if (_0x1939fdc) {
_0xca6809(_0x1939fdc, _0x18e0a19.status, _0x1c6cd537e4(71));
}
}
if (_0x18e0a19.logMessage) {
_0xadb373(_0x192cbd5, _0x18e0a19.level || _0x1c6cd537e4(88), _0x18e0a19.logMessage, _0x1939fdc?.rowNumber ?? null);
}
await _0x1612e07(_0x1912d1f, _0x192cbd5);
return { ok: true, state: _0x1912d1f };
}
async function _0x1958672(_0x1964a90, _0x19781a7) {
const _0x1984c6c = await chrome.storage.local.get(_0x1a6d9.RUN_STATE);
const _0x19949e6 = _0x1984c6c[_0x1a6d9.RUN_STATE] || null;
const _0x19afdfe = Boolean(_0x19949e6 &&
_0x19781a7.tab?.id === _0x19949e6.workTabId &&
_0x19949e6.runId === _0x1964a90.runId &&
_0x64371.has(_0x19949e6.phase) &&
_0x64371.has(_0x1964a90.nextPhase));
if (!_0x19afdfe) {
const _0x19bebc3 = await _0x3f8e02(false);
if (!_0x19bebc3.ok) {
return _0x19bebc3;
}
}
return _0x18d56f2(_0x1964a90, _0x19781a7);
}
async function _0x19cce18(_0x19db4eb, _0x19e59f3) {
const _0x19fbde2 = await _0x1493fef();
const _0x1a0d965 = _0x19fbde2[_0x1a6d9.RUN_STATE];
const _0x1a16d8a = Array.isArray(_0x19fbde2[_0x1a6d9.LOGS]) ? _0x19fbde2[_0x1a6d9.LOGS] : [];
if (!_0x1a0d965 || _0x19e59f3.tab?.id !== _0x1a0d965.workTabId || _0x1a0d965.runId !== _0x19db4eb.runId) {
return { ok: false, stale: true };
}
if (_0x19db4eb.expectedPhase && _0x1a0d965.phase !== _0x19db4eb.expectedPhase) {
return { ok: false, stale: true };
}
const _0x1a26716 = _0x144a799(_0x1a0d965);
const _0x1a38665 = _0x1429d3b(_0x1a0d965);
_0x1a0d965.mode = _0x1c6cd537e4(9);
_0x1a0d965.pauseReason = _0x19db4eb.reason || _0x1c6cd537e4(102);
_0x1a0d965.updatedAt = new Date().toISOString();
if (_0x1a38665?.isCombined) {
_0x10286f1(_0x1a0d965.rows, _0x1a38665, _0x1a0d965.pauseReason);
}
else if (_0x1a26716) {
_0xca6809(_0x1a26716, `等待人工检查：${_0x1a0d965.pauseReason}`, _0x1c6cd537e4(70));
}
_0xadb373(_0x1a16d8a, _0x1c6cd537e4(33), _0x1a0d965.pauseReason, _0x1a26716?.rowNumber ?? null);
await _0x1612e07(_0x1a0d965, _0x1a16d8a);
return { ok: true, state: _0x1a0d965 };
}
async function _0x1a44b2f(_0x1a56189, _0x1a6e6f0) {
const _0x1a75c0a = await _0x1493fef();
const _0x1a8b838 = _0x1a75c0a[_0x1a6d9.RUN_STATE];
const _0x1a95472 = Array.isArray(_0x1a75c0a[_0x1a6d9.LOGS]) ? _0x1a75c0a[_0x1a6d9.LOGS] : [];
const _0x1aa459e = _0x97dc56(_0x1a75c0a[_0x1a6d9.HISTORY]);
const _0x1ab33a4 = _0x9d4f15(_0x1a75c0a[_0x1a6d9.ORDER_INDEX], _0x1aa459e);
let _0x1acaf16 = _0x1a75c0a[_0x1a6d9.CART_LOCK] || null;
if (!_0x1a8b838 || _0x1a6e6f0.tab?.id !== _0x1a8b838.workTabId || _0x1a8b838.runId !== _0x1a56189.runId) {
return { ok: false, stale: true, error: _0x1c6cd537e4(103) };
}
if (_0x1a8b838.mode !== _0x1c6cd537e4(8) || _0x1a8b838.phase !== _0x1c6cd537e4(24)) {
return { ok: false, stale: true, error: `当前阶段不是付款页姓名验证阶段：${_0x1a8b838.phase}` };
}
const _0x1ad93d1 = _0x1429d3b(_0x1a8b838);
const _0x1ae7739 = _0x146d3ad(_0x1a8b838);
if (!_0x1ad93d1 || !_0x1ae7739) {
return { ok: false, error: _0x1c6cd537e4(104) };
}
const _0x1af30e9 = _0x7ee5dd(_0x1a56189.observedRecipientName);
if (!_0x1af30e9 || _0x82279e(_0x1af30e9) !== _0x82279e(_0x1ad93d1.normalizedName)) {
return { ok: false, error: _0x1c6cd537e4(105) };
}
if (_0x1ad93d1.isCombined) {
if (!_0x1ad93d1.rowIndexes.every((_0x1b06894) => _0x1a8b838.rows[_0x1b06894].precheckPassed && _0x1a8b838.rows[_0x1b06894].addedToCart)) {
return { ok: false, error: _0x1c6cd537e4(106) };
}
if (!_0x169c43a(_0x1acaf16, _0x1a8b838, _0x1ad93d1)) {
return { ok: false, error: _0x1c6cd537e4(107) };
}
}
else {
const _0x1b1b8de = Number(_0x1ae7739.observedUnitPrice);
if (!Number.isFinite(_0x1b1b8de) || Math.abs(_0x1b1b8de - 2) > 0.0001) {
return { ok: false, error: _0x1c6cd537e4(108) };
}
const _0x1b2ef15 = Number(_0x1ae7739.selectedQuantity);
if (!Number.isSafeInteger(_0x1b2ef15) ||
_0x1b2ef15 <= 0 ||
_0x1b2ef15 !== _0x1ae7739.requestedQuantity) {
return { ok: false, error: _0x1c6cd537e4(109) };
}
}
const _0x1b330fa = _0x778307();
for (const _0x1b4fc2e of _0x1ad93d1.uniqueTemuOrderIds) {
const _0x1b5675a = _0x1ab33a4[_0x8f5765(_0x1b4fc2e)];
if (_0x1b5675a?.status === _0x1c6cd537e4(60) &&
_0x1b5675a.dateKey === _0x1b330fa &&
_0x5c4614(_0x1b5675a.orderId)) {
_0x1a8b838.mode = _0x1c6cd537e4(9);
_0x1a8b838.pauseReason = `最终付款前发现 Temu Order ID ${_0x1b4fc2e} 今天已有成功订单，已停止以避免重复下单。`;
if (_0x1ad93d1.isCombined) {
_0x10286f1(_0x1a8b838.rows, _0x1ad93d1, _0x1a8b838.pauseReason);
}
else {
_0xca6809(_0x1ae7739, `等待人工检查：${_0x1a8b838.pauseReason}`, _0x1c6cd537e4(70));
}
_0xadb373(_0x1a95472, _0x1c6cd537e4(33), _0x1a8b838.pauseReason, _0x1ae7739.rowNumber);
await _0x1612e07(_0x1a8b838, _0x1a95472, {
[_0x1a6d9.HISTORY]: _0x1aa459e,
[_0x1a6d9.ORDER_INDEX]: _0x1ab33a4
});
return { ok: false, error: _0x1a8b838.pauseReason };
}
}
_0x1ad93d1.actualDeliveryAddress = _0x7ee5dd(_0x1a56189.observedDeliveryAddress || _0x1ad93d1.actualDeliveryAddress);
if (_0x1ad93d1.isCombined) {
_0x107eadd(_0x1a8b838.rows, _0x1ad93d1, _0x1c6cd537e4(110));
_0x1acaf16 = {
..._0x1acaf16,
stage: _0x1c6cd537e4(111),
actualDeliveryAddress: _0x1ad93d1.actualDeliveryAddress,
updatedAt: new Date().toISOString()
};
}
else {
_0xca6809(_0x1ae7739, _0x1c6cd537e4(112), _0x1c6cd537e4(71));
}
_0x1a8b838.phase = _0x1c6cd537e4(11);
_0x1a8b838.updatedAt = new Date().toISOString();
_0xadb373(_0x1a95472, _0x1c6cd537e4(90), _0x1ad93d1.isCombined
? `组合单共 ${_0x1ad93d1.rowIndexes.length} 行、总数量 ${_0x1ad93d1.expectedTotalQuantity}，付款页收件人姓名已核对；购物篮安全锁将保留到取得 Order ID。`
: `商品含税单价 €2.00、精准数量 ${_0x1ae7739.requestedQuantity} 和付款页收件人姓名均已核对；只有取得 Order ID 后才计入当天下单记录。`, _0x1ae7739.rowNumber);
const _0x1b6b4d0 = {
[_0x1a6d9.HISTORY]: _0x1aa459e,
[_0x1a6d9.ORDER_INDEX]: _0x1ab33a4
};
if (_0x1ad93d1.isCombined) {
_0x1b6b4d0[_0x1a6d9.CART_LOCK] = _0x1acaf16;
}
await _0x1612e07(_0x1a8b838, _0x1a95472, _0x1b6b4d0);
return { ok: true, state: _0x1a8b838 };
}
async function _0x1b7061f(_0x1b83790, _0x1b933e7, _0x1ba64f0 = true) {
const _0x1bb4667 = await _0x35e48a(false);
if (!_0x1bb4667.authorized) {
_0x231c92(_0x1b83790, _0x1b933e7);
await _0x1612e07(_0x1b83790, _0x1b933e7);
return { completed: false, authorizationFailed: true, error: _0xc4ed4.failureMessage };
}
const _0x1bcb5b4 = _0x1429d3b(_0x1b83790);
if (!_0x1bcb5b4) {
return { completed: false, error: _0x1c6cd537e4(113) };
}
_0x1bcb5b4.precheckCursor = 0;
_0x1bcb5b4.addCursor = 0;
_0x1bcb5b4.expectedCartCount = 0;
_0x1bcb5b4.actualDeliveryAddress = _0x1c6cd537e4(34);
_0x1bcb5b4.orderId = _0x1c6cd537e4(34);
_0x1bcb5b4.result = _0x1c6cd537e4(71);
_0x1bcb5b4.updatedAt = new Date().toISOString();
for (const _0x1bd6a8f of _0x1bcb5b4.rowIndexes) {
const _0x1bec896 = _0x1b83790.rows[_0x1bd6a8f];
_0x1bec896.precheckPassed = false;
_0x1bec896.addedToCart = false;
_0x1bec896.observedUnitPrice = _0x1c6cd537e4(34);
_0x1bec896.selectedQuantity = _0x1c6cd537e4(34);
_0x1bec896.orderId = _0x1c6cd537e4(34);
}
const _0x1bf5cc7 = _0x1bcb5b4.rowIndexes[0];
const _0x1c01684 = _0x1b83790.rows[_0x1bf5cc7];
_0x1b83790.currentIndex = _0x1bf5cc7;
_0x1b83790.mode = _0x1c6cd537e4(10);
_0x1b83790.phase = _0x1c6cd537e4(95);
_0x1b83790.pauseReason = _0x1c6cd537e4(34);
_0x1b83790.intervalEndsAt = null;
_0x1b83790.intervalRemainingSeconds = 0;
_0x1b83790.updatedAt = new Date().toISOString();
if (_0x1bcb5b4.isCombined) {
_0x107eadd(_0x1b83790.rows, _0x1bcb5b4, _0x1c6cd537e4(114));
_0xadb373(_0x1b933e7, _0x1c6cd537e4(88), `开始组合单：${_0x1bcb5b4.rowIndexes.length} 行，${_0x1bcb5b4.uniqueTemuOrderIds.length} 个唯一 Temu Order ID，总数量 ${_0x1bcb5b4.expectedTotalQuantity}。`, _0x1c01684.rowNumber);
}
else {
_0xca6809(_0x1c01684, _0x1c6cd537e4(115), _0x1c6cd537e4(71));
_0xadb373(_0x1b933e7, _0x1c6cd537e4(88), `第 ${_0x1c01684.rowNumber} 行：开始单行 Buy Now 流程，Temu Order ID ${_0x1c01684.temuOrderId}，ASIN ${_0x1c01684.asin}，目标数量 ${_0x1c01684.requestedQuantity}。`, _0x1c01684.rowNumber);
}
await _0x1612e07(_0x1b83790, _0x1b933e7);
try {
let _0x1c1f0fc = false;
if (Number.isInteger(_0x1b83790.workTabId)) {
try {
await chrome.tabs.get(_0x1b83790.workTabId);
_0x1c1f0fc = true;
}
catch {
_0x1c1f0fc = false;
}
}
if (_0x1c1f0fc && _0x1ba64f0) {
await chrome.tabs.update(_0x1b83790.workTabId, { url: _0x1c6cd537e4(77), active: true });
await _0x52e375(120);
}
else if (!_0x1c1f0fc) {
_0x1b83790.workTabId = await _0x150e2ae(null);
await _0x1612e07(_0x1b83790, _0x1b933e7);
}
_0x1b83790.mode = _0x1c6cd537e4(8);
_0x1b83790.phase = _0x1bcb5b4.isCombined ? _0x1c6cd537e4(116) : _0x1c6cd537e4(117);
_0x1b83790.pauseReason = _0x1c6cd537e4(34);
if (_0x1bcb5b4.isCombined) {
_0x107eadd(_0x1b83790.rows, _0x1bcb5b4, _0x1c6cd537e4(118));
}
else {
_0xca6809(_0x1c01684, _0x1c6cd537e4(119), _0x1c6cd537e4(71));
}
_0x1b83790.updatedAt = new Date().toISOString();
await _0x1612e07(_0x1b83790, _0x1b933e7);
await _0x15e5a45(_0x1b83790.workTabId, _0x1c01684.amzLink);
return { completed: false };
}
catch (_0x1c231c0) {
_0x1b83790.mode = _0x1c6cd537e4(9);
_0x1b83790.pauseReason = `无法打开商品页面：${_0x1c231c0.message || String(_0x1c231c0)}`;
if (_0x1bcb5b4.isCombined) {
_0x10286f1(_0x1b83790.rows, _0x1bcb5b4, _0x1b83790.pauseReason);
}
else {
_0xca6809(_0x1c01684, `等待人工检查：${_0x1b83790.pauseReason}`, _0x1c6cd537e4(70));
}
_0xadb373(_0x1b933e7, _0x1c6cd537e4(33), _0x1b83790.pauseReason, _0x1c01684.rowNumber);
await _0x1612e07(_0x1b83790, _0x1b933e7);
return { completed: false, error: _0x1b83790.pauseReason };
}
}
async function _0x1c33e2d(_0x1c484e6, _0x1c555f1, _0x1c6fc46, _0x1c759ee = 0) {
const _0x1c8bd24 = await _0x35e48a(false);
if (!_0x1c8bd24.authorized) {
_0x1c484e6.authorizationBlocked = true;
_0x1c484e6.authorizationFailureDeferred = false;
_0x1c484e6.mode = _0x1c6cd537e4(9);
_0x1c484e6.pauseReason = _0xc4ed4.failureMessage;
_0x1c484e6.updatedAt = new Date().toISOString();
const _0x1c9605c = _0x144a799(_0x1c484e6);
const _0x1ca1a05 = _0x1c555f1?.[_0x1c555f1.length - 1];
if (_0x1ca1a05?.message !== _0xc4ed4.failureMessage) {
_0xadb373(_0x1c555f1, _0x1c6cd537e4(33), _0xc4ed4.failureMessage, _0x1c9605c?.rowNumber ?? null);
}
await _0x1612e07(_0x1c484e6, _0x1c555f1);
return { completed: false, authorizationFailed: true, error: _0xc4ed4.failureMessage };
}
const _0x1cb91c1 = _0x1c484e6.currentGroupIndex;
const _0x1cc4be7 = _0x13e497f(_0x1c484e6.groups, Number.isInteger(_0x1cb91c1) ? _0x1cb91c1 : -1);
if (_0x1cc4be7 === -1) {
await _0x69e03d(_0x1c484e6.runId);
_0x1c484e6.mode = _0x1c6cd537e4(92);
_0x1c484e6.phase = _0x1c6cd537e4(93);
_0x1c484e6.pauseReason = _0x1c6cd537e4(34);
_0x1c484e6.currentGroupIndex = null;
_0x1c484e6.currentIndex = null;
_0x1c484e6.intervalEndsAt = null;
_0x1c484e6.intervalRemainingSeconds = 0;
_0x1c484e6.updatedAt = new Date().toISOString();
_0xadb373(_0x1c555f1, _0x1c6cd537e4(72), _0x1c6fc46 || _0x1c6cd537e4(120));
await _0x1612e07(_0x1c484e6, _0x1c555f1);
return { completed: true };
}
_0x1c484e6.currentGroupIndex = _0x1cc4be7;
const _0x1cd993a = _0x1c484e6.groups[_0x1cc4be7];
_0x1c484e6.currentIndex = _0x1cd993a.primaryRowIndex;
const _0x1ce3997 = _0x55f407(_0x1c759ee, 0);
if (_0x1ce3997 > 0) {
_0x1c484e6.mode = _0x1c6cd537e4(10);
_0x1c484e6.phase = _0x1c6cd537e4(121);
_0x1c484e6.pauseReason = _0x1c6cd537e4(34);
_0x1c484e6.intervalEndsAt = new Date(Date.now() + _0x1ce3997 * 1000).toISOString();
_0x1c484e6.intervalRemainingSeconds = _0x1ce3997;
_0x107eadd(_0x1c484e6.rows, _0x1cd993a, `等待下单间隔（${_0x1ce3997}秒）`);
_0x1c484e6.updatedAt = new Date().toISOString();
const _0x1cf45cb = _0x1c484e6.rows[_0x1cd993a.primaryRowIndex];
_0xadb373(_0x1c555f1, _0x1c6cd537e4(88), `距离下一个地址组还有 ${_0x1ce3997} 秒；等待结束后从第 ${_0x1cf45cb.rowNumber} 行开始。`, _0x1cf45cb.rowNumber);
await _0x1612e07(_0x1c484e6, _0x1c555f1);
try {
await _0x6f1845(_0x1c484e6, _0x1ce3997 * 1000);
return { completed: false, waiting: true };
}
catch (_0x1d04837) {
_0x1c484e6.mode = _0x1c6cd537e4(9);
_0x1c484e6.pauseReason = `无法安排下一单间隔：${_0x1d04837.message || String(_0x1d04837)}`;
_0x10286f1(_0x1c484e6.rows, _0x1cd993a, _0x1c484e6.pauseReason);
_0xadb373(_0x1c555f1, _0x1c6cd537e4(33), _0x1c484e6.pauseReason, _0x1cf45cb.rowNumber);
await _0x1612e07(_0x1c484e6, _0x1c555f1);
return { completed: false, error: _0x1c484e6.pauseReason };
}
}
return _0x1b7061f(_0x1c484e6, _0x1c555f1, true);
}
async function _0x1d19389(_0x1d2b407) {
const _0x1d32c7d = await _0x1493fef();
const _0x1d40991 = _0x1d32c7d[_0x1a6d9.RUN_STATE];
const _0x1d535be = Array.isArray(_0x1d32c7d[_0x1a6d9.LOGS]) ? _0x1d32c7d[_0x1a6d9.LOGS] : [];
if (!_0x1d40991 ||
_0x1d40991.runId !== _0x1d2b407 ||
_0x1d40991.mode !== _0x1c6cd537e4(10) ||
_0x1d40991.phase !== _0x1c6cd537e4(121)) {
await _0x69e03d(_0x1d2b407);
return { ok: false, stale: true };
}
const _0x1d670be = _0x6b5365(_0x1d40991);
if (_0x1d670be > 500) {
_0x1d40991.intervalRemainingSeconds = Math.ceil(_0x1d670be / 1000);
await _0x1612e07(_0x1d40991, _0x1d535be);
await _0x6f1845(_0x1d40991, _0x1d670be);
return { ok: true, waiting: true };
}
await _0x69e03d(_0x1d2b407);
_0x1d40991.intervalEndsAt = null;
_0x1d40991.intervalRemainingSeconds = 0;
const _0x1d73999 = _0x1429d3b(_0x1d40991);
const _0x1d845b1 = _0x1d73999 ? _0x1d40991.rows[_0x1d73999.primaryRowIndex] : null;
_0xadb373(_0x1d535be, _0x1c6cd537e4(88), _0x1c6cd537e4(122), _0x1d845b1?.rowNumber ?? null);
await _0x1612e07(_0x1d40991, _0x1d535be);
await _0x1b7061f(_0x1d40991, _0x1d535be, true);
return { ok: true };
}
async function _0x1d90544(_0x1dabf21, _0x1db16e2) {
const _0x1dc4dbe = await _0x1493fef();
const _0x1dd1dce = _0x1dc4dbe[_0x1a6d9.RUN_STATE];
const _0x1ded7b9 = Array.isArray(_0x1dc4dbe[_0x1a6d9.LOGS]) ? _0x1dc4dbe[_0x1a6d9.LOGS] : [];
if (!_0x1dd1dce || _0x1db16e2.tab?.id !== _0x1dd1dce.workTabId || _0x1dd1dce.runId !== _0x1dabf21.runId) {
return { ok: false, stale: true };
}
if (![_0x1c6cd537e4(116), _0x1c6cd537e4(123)].includes(_0x1dd1dce.phase)) {
return { ok: false, stale: true, error: `当前阶段不能确认空购物篮：${_0x1dd1dce.phase}` };
}
const _0x1dfb706 = _0x1429d3b(_0x1dd1dce);
if (!_0x1dfb706?.isCombined) {
return { ok: false, error: _0x1c6cd537e4(124) };
}
if (Number(_0x1dabf21.cartCount) !== 0) {
return { ok: false, error: `购物篮数量不是0：${_0x1dabf21.cartCount}` };
}
const _0x1e091f0 = _0x1dfb706.rowIndexes[0];
const _0x1e16e87 = _0x1dd1dce.rows[_0x1e091f0];
_0x1dd1dce.currentIndex = _0x1e091f0;
if (_0x1dd1dce.phase === _0x1c6cd537e4(116)) {
_0x1dfb706.precheckCursor = 0;
_0x1dd1dce.phase = _0x1c6cd537e4(125);
_0xca6809(_0x1e16e87, _0x1c6cd537e4(126), _0x1c6cd537e4(71));
_0xadb373(_0x1ded7b9, _0x1c6cd537e4(72), _0x1c6cd537e4(127), _0x1e16e87.rowNumber);
await _0x1612e07(_0x1dd1dce, _0x1ded7b9);
await _0x15c8e36(_0x1dd1dce.workTabId);
return { ok: true, state: _0x1dd1dce };
}
if (_0x1dc4dbe[_0x1a6d9.CART_LOCK]) {
return { ok: false, error: _0x1c6cd537e4(128) };
}
_0x1dfb706.addCursor = 0;
_0x1dfb706.expectedCartCount = 0;
const _0x1e2e587 = _0x165f524(_0x1dd1dce, _0x1dfb706);
_0x1dd1dce.phase = _0x1c6cd537e4(13);
_0x107eadd(_0x1dd1dce.rows, _0x1dfb706, _0x1c6cd537e4(129));
_0xca6809(_0x1e16e87, _0x1c6cd537e4(130), _0x1c6cd537e4(71));
_0xadb373(_0x1ded7b9, _0x1c6cd537e4(72), _0x1c6cd537e4(131), _0x1e16e87.rowNumber);
await _0x1612e07(_0x1dd1dce, _0x1ded7b9, { [_0x1a6d9.CART_LOCK]: _0x1e2e587 });
await _0x15c8e36(_0x1dd1dce.workTabId);
return { ok: true, state: _0x1dd1dce };
}
async function _0x1e39cce(_0x1e480b0, _0x1e5e1bf) {
const _0x1e6d6ae = await _0x1493fef();
const _0x1e7dd24 = _0x1e6d6ae[_0x1a6d9.RUN_STATE];
const _0x1e876df = Array.isArray(_0x1e6d6ae[_0x1a6d9.LOGS]) ? _0x1e6d6ae[_0x1a6d9.LOGS] : [];
if (!_0x1e7dd24 || _0x1e5e1bf.tab?.id !== _0x1e7dd24.workTabId || _0x1e7dd24.runId !== _0x1e480b0.runId) {
return { ok: false, stale: true };
}
if (_0x1e7dd24.phase !== _0x1c6cd537e4(125)) {
return { ok: false, stale: true, error: `当前阶段不是组合单预检查：${_0x1e7dd24.phase}` };
}
const _0x1e92921 = _0x1429d3b(_0x1e7dd24);
const _0x1eaf3d2 = _0x144a799(_0x1e7dd24);
if (!_0x1e92921?.isCombined || !_0x1eaf3d2) {
return { ok: false, error: _0x1c6cd537e4(132) };
}
const _0x1eb29a9 = _0x1e92921.rowIndexes[_0x1e92921.precheckCursor];
if (_0x1e7dd24.currentIndex !== _0x1eb29a9) {
return { ok: false, stale: true, error: _0x1c6cd537e4(133) };
}
const _0x1ec3531 = Number(_0x1e480b0.observedUnitPrice);
const _0x1edf002 = Number(_0x1e480b0.selectedQuantity);
if (!Number.isFinite(_0x1ec3531) || Math.abs(_0x1ec3531 - 2) > 0.0001) {
return { ok: false, error: _0x1c6cd537e4(134) };
}
if (!Number.isSafeInteger(_0x1edf002) || _0x1edf002 !== _0x1eaf3d2.requestedQuantity) {
return { ok: false, error: _0x1c6cd537e4(135) };
}
_0x1eaf3d2.observedUnitPrice = _0x1ec3531.toFixed(2);
_0x1eaf3d2.selectedQuantity = _0x1edf002;
_0x1eaf3d2.precheckPassed = true;
_0xca6809(_0x1eaf3d2, _0x1c6cd537e4(136), _0x1c6cd537e4(71));
_0xadb373(_0x1e876df, _0x1c6cd537e4(72), `组合单预检查通过：ASIN ${_0x1eaf3d2.asin}，含税单价 €2.00，精准数量 ${_0x1edf002}。`, _0x1eaf3d2.rowNumber);
if (_0x1e92921.precheckCursor + 1 < _0x1e92921.rowIndexes.length) {
_0x1e92921.precheckCursor += 1;
const _0x1eedf26 = _0x1e92921.rowIndexes[_0x1e92921.precheckCursor];
const _0x1ef642e = _0x1e7dd24.rows[_0x1eedf26];
_0x1e7dd24.currentIndex = _0x1eedf26;
_0x1e7dd24.phase = _0x1c6cd537e4(125);
_0xca6809(_0x1ef642e, _0x1c6cd537e4(137), _0x1c6cd537e4(71));
_0x1e7dd24.updatedAt = new Date().toISOString();
await _0x1612e07(_0x1e7dd24, _0x1e876df);
await _0x15e5a45(_0x1e7dd24.workTabId, _0x1ef642e.amzLink);
return { ok: true, state: _0x1e7dd24 };
}
_0x1e92921.result = _0x1c6cd537e4(71);
_0x1e92921.status = _0x1c6cd537e4(138);
_0x1e7dd24.currentIndex = _0x1e92921.rowIndexes[0];
_0x1e7dd24.phase = _0x1c6cd537e4(123);
_0x107eadd(_0x1e7dd24.rows, _0x1e92921, _0x1c6cd537e4(139));
_0xadb373(_0x1e876df, _0x1c6cd537e4(88), _0x1c6cd537e4(140), _0x1e7dd24.rows[_0x1e92921.rowIndexes[0]].rowNumber);
_0x1e7dd24.updatedAt = new Date().toISOString();
await _0x1612e07(_0x1e7dd24, _0x1e876df);
await _0x15e5a45(_0x1e7dd24.workTabId, _0x1e7dd24.rows[_0x1e92921.rowIndexes[0]].amzLink);
return { ok: true, state: _0x1e7dd24 };
}
async function _0x1f04d3b(_0x1f1e924, _0x1f2f2f9) {
const _0x1f39173 = await _0x1493fef();
const _0x1f4f6ce = _0x1f39173[_0x1a6d9.RUN_STATE];
const _0x1f57943 = Array.isArray(_0x1f39173[_0x1a6d9.LOGS]) ? _0x1f39173[_0x1a6d9.LOGS] : [];
if (!_0x1f4f6ce || _0x1f2f2f9.tab?.id !== _0x1f4f6ce.workTabId || _0x1f4f6ce.runId !== _0x1f1e924.runId) {
return { ok: false, stale: true };
}
if (_0x1f4f6ce.phase !== _0x1c6cd537e4(125)) {
return { ok: false, stale: true };
}
const _0x1f68ee9 = _0x1429d3b(_0x1f4f6ce);
const _0x1f7d71f = _0x144a799(_0x1f4f6ce);
if (!_0x1f68ee9?.isCombined || !_0x1f7d71f) {
return { ok: false, error: _0x1c6cd537e4(132) };
}
if (Number.isFinite(Number(_0x1f1e924.observedUnitPrice))) {
_0x1f7d71f.observedUnitPrice = Number(_0x1f1e924.observedUnitPrice).toFixed(2);
}
if (Number.isSafeInteger(Number(_0x1f1e924.selectedQuantity)) && Number(_0x1f1e924.selectedQuantity) > 0) {
_0x1f7d71f.selectedQuantity = Number(_0x1f1e924.selectedQuantity);
}
const _0x1f83122 = _0x1f1e924.reason || _0x1c6cd537e4(141);
_0xfa7111(_0x1f4f6ce.rows, _0x1f68ee9, _0x1f4f6ce.currentIndex, _0x1f83122);
_0xadb373(_0x1f57943, _0x1c6cd537e4(90), `${_0x1f83122}；该收件人地址组全部不下单。`, _0x1f7d71f.rowNumber);
_0x1f4f6ce.updatedAt = new Date().toISOString();
await _0x1612e07(_0x1f4f6ce, _0x1f57943);
await _0x1c33e2d(_0x1f4f6ce, _0x1f57943, _0x1c6cd537e4(120), 0);
return { ok: true };
}
async function _0x1f9196b(_0x1fab32a, _0x1fbe7a3) {
const _0x1fc612a = await _0x1493fef();
const _0x1fd03ff = _0x1fc612a[_0x1a6d9.RUN_STATE];
const _0x1feb324 = Array.isArray(_0x1fc612a[_0x1a6d9.LOGS]) ? _0x1fc612a[_0x1a6d9.LOGS] : [];
let _0x1ff617a = _0x1fc612a[_0x1a6d9.CART_LOCK] || null;
if (!_0x1fd03ff || _0x1fbe7a3.tab?.id !== _0x1fd03ff.workTabId || _0x1fd03ff.runId !== _0x1fab32a.runId) {
return { ok: false, stale: true };
}
if (_0x1fd03ff.phase !== _0x1c6cd537e4(13)) {
return { ok: false, stale: true, error: `当前阶段不是组合单正式加购：${_0x1fd03ff.phase}` };
}
const _0x200e580 = _0x1429d3b(_0x1fd03ff);
const _0x201e24f = _0x144a799(_0x1fd03ff);
if (!_0x200e580?.isCombined || !_0x201e24f || !_0x169c43a(_0x1ff617a, _0x1fd03ff, _0x200e580)) {
return { ok: false, error: _0x1c6cd537e4(142) };
}
const _0x2028e8a = _0x200e580.rowIndexes[_0x200e580.addCursor];
if (_0x1fd03ff.currentIndex !== _0x2028e8a) {
return { ok: false, stale: true, error: _0x1c6cd537e4(143) };
}
const _0x2034e23 = Number(_0x1fab32a.selectedQuantity);
const _0x2046502 = Number(_0x1fab32a.observedUnitPrice);
if (!Number.isSafeInteger(_0x2034e23) || _0x2034e23 !== _0x201e24f.requestedQuantity) {
return { ok: false, error: _0x1c6cd537e4(144) };
}
if (!Number.isFinite(_0x2046502) || Math.abs(_0x2046502 - 2) > 0.0001) {
return { ok: false, error: _0x1c6cd537e4(145) };
}
const _0x2055d76 = _0x200e580.rowIndexes
.slice(0, _0x200e580.addCursor + 1)
.reduce((_0x206182b, _0x2075de9) => _0x206182b + _0x1fd03ff.rows[_0x2075de9].requestedQuantity, 0);
_0x201e24f.observedUnitPrice = _0x2046502.toFixed(2);
_0x201e24f.selectedQuantity = _0x2034e23;
_0xca6809(_0x201e24f, `正在加入购物篮（完成后应累计 ${_0x2055d76} 件）`, _0x1c6cd537e4(71));
_0x1fd03ff.phase = _0x1c6cd537e4(14);
_0x1fd03ff.updatedAt = new Date().toISOString();
_0x1ff617a = {
..._0x1ff617a,
stage: _0x1c6cd537e4(146),
pendingRowIndex: _0x1fd03ff.currentIndex,
expectedCartCountAfter: _0x2055d76,
updatedAt: new Date().toISOString()
};
_0xadb373(_0x1feb324, _0x1c6cd537e4(88), `正式加购前再次核对通过：ASIN ${_0x201e24f.asin} × ${_0x2034e23}；点击后购物篮应累计 ${_0x2055d76} 件。`, _0x201e24f.rowNumber);
await _0x1612e07(_0x1fd03ff, _0x1feb324, { [_0x1a6d9.CART_LOCK]: _0x1ff617a });
return { ok: true, state: _0x1fd03ff, expectedCartCountAfter: _0x2055d76 };
}
async function _0x208a402(_0x2092e68, _0x20a26e5) {
const _0x20b068d = await _0x1493fef();
const _0x20c73a1 = _0x20b068d[_0x1a6d9.RUN_STATE];
const _0x20db68e = Array.isArray(_0x20b068d[_0x1a6d9.LOGS]) ? _0x20b068d[_0x1a6d9.LOGS] : [];
let _0x20e39fc = _0x20b068d[_0x1a6d9.CART_LOCK] || null;
if (!_0x20c73a1 || _0x20a26e5.tab?.id !== _0x20c73a1.workTabId || _0x20c73a1.runId !== _0x2092e68.runId) {
return { ok: false, stale: true };
}
if (_0x20c73a1.phase !== _0x1c6cd537e4(14)) {
return { ok: false, stale: true, error: `当前阶段不是组合单加购结果确认：${_0x20c73a1.phase}` };
}
const _0x20f30dd = _0x1429d3b(_0x20c73a1);
const _0x210ad5d = _0x144a799(_0x20c73a1);
if (!_0x20f30dd?.isCombined || !_0x210ad5d || !_0x169c43a(_0x20e39fc, _0x20c73a1, _0x20f30dd)) {
return { ok: false, error: _0x1c6cd537e4(142) };
}
const _0x2110a35 = _0x20f30dd.rowIndexes[_0x20f30dd.addCursor];
if (_0x20c73a1.currentIndex !== _0x2110a35) {
return { ok: false, stale: true, error: _0x1c6cd537e4(143) };
}
const _0x212ca69 = Number(_0x2092e68.selectedQuantity);
const _0x2131bce = Number(_0x2092e68.observedUnitPrice);
if (!Number.isSafeInteger(_0x212ca69) || _0x212ca69 !== _0x210ad5d.requestedQuantity) {
return { ok: false, error: _0x1c6cd537e4(147) };
}
if (!Number.isFinite(_0x2131bce) || Math.abs(_0x2131bce - 2) > 0.0001) {
return { ok: false, error: _0x1c6cd537e4(148) };
}
const _0x2146d26 = _0x20f30dd.rowIndexes
.slice(0, _0x20f30dd.addCursor + 1)
.reduce((_0x215618a, _0x216f9cb) => _0x215618a + _0x20c73a1.rows[_0x216f9cb].requestedQuantity, 0);
const _0x217c0d1 = Number(_0x2092e68.cartCount);
if (!Number.isSafeInteger(_0x217c0d1) || _0x217c0d1 !== _0x2146d26) {
return {
ok: false,
error: `购物篮累计数量异常：应为 ${_0x2146d26}，页面为 ${_0x2092e68.cartCount}。`
};
}
_0x210ad5d.observedUnitPrice = _0x2131bce.toFixed(2);
_0x210ad5d.selectedQuantity = _0x212ca69;
_0x210ad5d.addedToCart = true;
_0x20f30dd.expectedCartCount = _0x2146d26;
_0xca6809(_0x210ad5d, `已加入购物篮（累计 ${_0x2146d26} 件）`, _0x1c6cd537e4(71));
_0xadb373(_0x20db68e, _0x1c6cd537e4(72), `已加入购物篮：ASIN ${_0x210ad5d.asin} × ${_0x212ca69}；累计购物篮数量 ${_0x2146d26}。`, _0x210ad5d.rowNumber);
_0x20e39fc = {
..._0x20e39fc,
addedRowIndexes: [...new Set([...(_0x20e39fc.addedRowIndexes || []), _0x20c73a1.currentIndex])],
expectedCartCount: _0x2146d26,
stage: _0x1c6cd537e4(149),
updatedAt: new Date().toISOString()
};
if (_0x20f30dd.addCursor + 1 < _0x20f30dd.rowIndexes.length) {
_0x20f30dd.addCursor += 1;
const _0x21889f8 = _0x20f30dd.rowIndexes[_0x20f30dd.addCursor];
const _0x2195ab0 = _0x20c73a1.rows[_0x21889f8];
_0x20c73a1.currentIndex = _0x21889f8;
_0x20c73a1.phase = _0x1c6cd537e4(13);
_0xca6809(_0x2195ab0, _0x1c6cd537e4(150), _0x1c6cd537e4(71));
_0x20c73a1.updatedAt = new Date().toISOString();
await _0x1612e07(_0x20c73a1, _0x20db68e, { [_0x1a6d9.CART_LOCK]: _0x20e39fc });
await _0x15e5a45(_0x20c73a1.workTabId, _0x2195ab0.amzLink);
return { ok: true, state: _0x20c73a1 };
}
_0x20c73a1.phase = _0x1c6cd537e4(15);
_0x107eadd(_0x20c73a1.rows, _0x20f30dd, _0x1c6cd537e4(151));
_0x20e39fc.stage = _0x1c6cd537e4(152);
_0x20e39fc.updatedAt = new Date().toISOString();
_0x20c73a1.updatedAt = new Date().toISOString();
_0xadb373(_0x20db68e, _0x1c6cd537e4(88), `组合单全部商品已加入购物篮，总数量 ${_0x20f30dd.expectedTotalQuantity}，准备交叉检查并结算。`, _0x210ad5d.rowNumber);
await _0x1612e07(_0x20c73a1, _0x20db68e, { [_0x1a6d9.CART_LOCK]: _0x20e39fc });
await _0x15c8e36(_0x20c73a1.workTabId);
return { ok: true, state: _0x20c73a1 };
}
async function _0x21af5c3(_0x21bd84f, _0x21c6449) {
const _0x21d5c02 = await _0x1493fef();
const _0x21e11ca = _0x21d5c02[_0x1a6d9.RUN_STATE];
const _0x21ff2da = Array.isArray(_0x21d5c02[_0x1a6d9.LOGS]) ? _0x21d5c02[_0x1a6d9.LOGS] : [];
let _0x220890b = _0x21d5c02[_0x1a6d9.CART_LOCK] || null;
if (!_0x21e11ca || _0x21c6449.tab?.id !== _0x21e11ca.workTabId || _0x21e11ca.runId !== _0x21bd84f.runId) {
return { ok: false, stale: true };
}
if (_0x21e11ca.phase !== _0x1c6cd537e4(15)) {
return { ok: false, stale: true, error: `当前阶段不是 Proceed to Checkout：${_0x21e11ca.phase}` };
}
const _0x2218744 = _0x1429d3b(_0x21e11ca);
if (!_0x2218744?.isCombined || !_0x169c43a(_0x220890b, _0x21e11ca, _0x2218744)) {
return { ok: false, error: _0x1c6cd537e4(142) };
}
const _0x222a91d = Number(_0x21bd84f.cartCount);
if (!Number.isSafeInteger(_0x222a91d) || _0x222a91d !== _0x2218744.expectedTotalQuantity) {
return { ok: false, error: `Proceed 前购物篮数量应为 ${_0x2218744.expectedTotalQuantity}，页面为 ${_0x21bd84f.cartCount}。` };
}
if (_0x21bd84f.proceedItemCount !== null &&
_0x21bd84f.proceedItemCount !== undefined &&
Number(_0x21bd84f.proceedItemCount) !== _0x2218744.expectedTotalQuantity) {
return { ok: false, error: `Proceed 按钮显示 ${_0x21bd84f.proceedItemCount} items，与预期 ${_0x2218744.expectedTotalQuantity} 不一致。` };
}
_0x21e11ca.currentIndex = _0x2218744.primaryRowIndex;
_0x21e11ca.phase = _0x1c6cd537e4(16);
_0x107eadd(_0x21e11ca.rows, _0x2218744, _0x1c6cd537e4(153));
_0x220890b = {
..._0x220890b,
stage: _0x1c6cd537e4(154),
expectedCartCount: _0x2218744.expectedTotalQuantity,
proceedItemCount: _0x21bd84f.proceedItemCount ?? null,
updatedAt: new Date().toISOString()
};
_0xadb373(_0x21ff2da, _0x1c6cd537e4(72), _0x21bd84f.proceedItemCount === null || _0x21bd84f.proceedItemCount === undefined
? `Proceed 前购物篮数量核对通过：${_0x222a91d} 件。`
: `Proceed 前购物篮数量与按钮 items 数均核对通过：${_0x222a91d} 件。`, _0x21e11ca.rows[_0x2218744.primaryRowIndex].rowNumber);
_0x21e11ca.updatedAt = new Date().toISOString();
await _0x1612e07(_0x21e11ca, _0x21ff2da, { [_0x1a6d9.CART_LOCK]: _0x220890b });
return { ok: true, state: _0x21e11ca };
}
async function _0x2233d8d(_0x22468e2, _0x2257302 = null, _0x226100a = false) {
const _0x227f681 = await _0x1493fef();
const _0x22820db = _0x227f681[_0x1a6d9.RUN_STATE];
const _0x22968ce = Array.isArray(_0x227f681[_0x1a6d9.LOGS]) ? _0x227f681[_0x1a6d9.LOGS] : [];
const _0x22aa80c = _0x227f681[_0x1a6d9.CART_LOCK] || null;
if (!_0x22820db) {
return { ok: false, error: _0x1c6cd537e4(155) };
}
if (_0x2257302?.tab && _0x2257302.tab.id !== _0x22820db.workTabId) {
return { ok: false, stale: true };
}
if (_0x22468e2.runId && _0x22820db.runId !== _0x22468e2.runId) {
return { ok: false, stale: true };
}
if (_0x22468e2.expectedPhase && _0x22820db.phase !== _0x22468e2.expectedPhase) {
return { ok: false, stale: true };
}
const _0x22b1bc5 = _0x144a799(_0x22820db);
const _0x22c0a23 = _0x1429d3b(_0x22820db);
if (!_0x22b1bc5 || !_0x22c0a23) {
return { ok: false, error: _0x1c6cd537e4(156) };
}
if (_0x169c43a(_0x22aa80c, _0x22820db, _0x22c0a23)) {
return {
ok: false,
error: _0x1c6cd537e4(157)
};
}
if (_0x22820db.phase === _0x1c6cd537e4(121)) {
await _0x69e03d(_0x22820db.runId);
_0x22820db.intervalEndsAt = null;
_0x22820db.intervalRemainingSeconds = 0;
}
const _0x22d06c0 = _0x22468e2.reason || (_0x226100a ? _0x1c6cd537e4(158) : _0x1c6cd537e4(159));
if (Number.isFinite(Number(_0x22468e2.observedUnitPrice))) {
_0x22b1bc5.observedUnitPrice = Number(_0x22468e2.observedUnitPrice).toFixed(2);
}
if (Number.isSafeInteger(Number(_0x22468e2.selectedQuantity)) && Number(_0x22468e2.selectedQuantity) > 0) {
_0x22b1bc5.selectedQuantity = Number(_0x22468e2.selectedQuantity);
}
const _0x22ef259 = _0x64371.has(_0x22820db.phase);
const _0x22fe5eb = _0x226100a && _0x22ef259 ? `${_0x22d06c0}（订单结果未确认）` : _0x22d06c0;
if (_0x22c0a23.isCombined) {
_0xfa7111(_0x22820db.rows, _0x22c0a23, _0x22820db.currentIndex, _0x22fe5eb);
_0xadb373(_0x22968ce, _0x1c6cd537e4(90), `${_0x22fe5eb}；该收件人地址组全部跳过。`, _0x22b1bc5.rowNumber);
}
else {
_0x22c0a23.result = _0x1c6cd537e4(68);
_0x22c0a23.status = _0x22fe5eb;
_0xca6809(_0x22b1bc5, _0x22fe5eb, _0x1c6cd537e4(68));
_0xadb373(_0x22968ce, _0x1c6cd537e4(90), _0x22fe5eb, _0x22b1bc5.rowNumber);
}
await _0x1612e07(_0x22820db, _0x22968ce);
await _0x1c33e2d(_0x22820db, _0x22968ce, _0x1c6cd537e4(120), 0);
return { ok: true };
}
async function _0x2308819(_0x23173f3, _0x2328a2c) {
const _0x2338b28 = await _0x1493fef();
const _0x2342738 = _0x2338b28[_0x1a6d9.RUN_STATE];
const _0x2350eb5 = Array.isArray(_0x2338b28[_0x1a6d9.LOGS]) ? _0x2338b28[_0x1a6d9.LOGS] : [];
const _0x236240a = _0x97dc56(_0x2338b28[_0x1a6d9.HISTORY]);
const _0x237c530 = _0x9d4f15(_0x2338b28[_0x1a6d9.ORDER_INDEX], _0x236240a);
const _0x2386688 = _0x2338b28[_0x1a6d9.CART_LOCK] || null;
if (!_0x2342738 || _0x2328a2c.tab?.id !== _0x2342738.workTabId || _0x2342738.runId !== _0x23173f3.runId) {
return { ok: false, stale: true };
}
if (_0x2342738.phase !== _0x1c6cd537e4(12)) {
return { ok: false, stale: true, error: `当前阶段不是订单核对阶段：${_0x2342738.phase}` };
}
const _0x239298e = _0x1429d3b(_0x2342738);
const _0x23a9b13 = _0x146d3ad(_0x2342738);
if (!_0x239298e || !_0x23a9b13) {
return { ok: false, error: _0x1c6cd537e4(160) };
}
const _0x23b1daa = String(_0x23173f3.orderId ?? _0x1c6cd537e4(34)).trim();
if (!_0x5c4614(_0x23b1daa)) {
return { ok: false, error: _0x1c6cd537e4(161) };
}
if (_0x239298e.isCombined && !_0x169c43a(_0x2386688, _0x2342738, _0x239298e)) {
return { ok: false, error: _0x1c6cd537e4(162) };
}
const _0x23cfa75 = new Date().toISOString();
const _0x23de62c = _0x778307();
for (const _0x23edf66 of _0x239298e.uniqueTemuOrderIds) {
const _0x23fda61 = _0xdbcd11(_0x2342738.rows, _0x239298e, _0x23edf66);
const _0x2407a3c = _0x2342738.rows[_0x23fda61[0]];
const _0x241836f = _0x239298e.temuItemSignatures[_0x23edf66] || _0x1c6cd537e4(34);
const _0x242edd8 = _0x239298e.temuSignatures[_0x23edf66] || _0x1c6cd537e4(34);
_0x236240a.push({
id: crypto.randomUUID(),
runId: _0x2342738.runId,
rowNumbers: _0x23fda61.map((_0x243f886) => _0x2342738.rows[_0x243f886].rowNumber),
dateKey: _0x23de62c,
temuOrderId: _0x2407a3c?.temuOrderId || _0x23edf66,
temuOrderIdKey: _0x23edf66,
asin: _0x2407a3c?.asin || _0x1c6cd537e4(34),
normalizedName: _0x239298e.normalizedName,
shipAddress: _0x239298e.shipAddress,
address2: _0x239298e.address2,
shipCity: _0x239298e.shipCity,
shipPostalCode: _0x239298e.shipPostalCode,
phoneNumber: _0x239298e.phoneNumber,
status: _0x1c6cd537e4(60),
orderId: _0x23b1daa,
addressSignature: _0x239298e.addressSignature,
itemSignature: _0x241836f,
temuSignature: _0x242edd8,
groupSignature: _0x239298e.groupSignature,
expectedItems: _0xce0c4c(_0x2342738.rows, _0x23fda61),
actualDeliveryAddress: _0x239298e.actualDeliveryAddress,
createdAt: _0x23cfa75,
updatedAt: _0x23cfa75
});
_0x237c530[_0x8f5765(_0x23edf66)] = {
temuOrderId: _0x23edf66,
status: _0x1c6cd537e4(60),
orderId: _0x23b1daa,
dateKey: _0x23de62c,
addressSignature: _0x239298e.addressSignature,
itemSignature: _0x241836f,
temuSignature: _0x242edd8,
groupSignature: _0x239298e.groupSignature,
updatedAt: _0x23cfa75
};
}
if (_0x236240a.length > _0x4f03f) {
_0x236240a.splice(0, _0x236240a.length - _0x4f03f);
}
_0x10dc76a(_0x2342738.rows, _0x239298e, _0x23b1daa);
_0x2342738.knownOrderIds = [...new Set([...(_0x2342738.knownOrderIds || []), _0x23b1daa])];
_0x2342738.updatedAt = _0x23cfa75;
_0xadb373(_0x2350eb5, _0x1c6cd537e4(72), _0x239298e.isCombined
? `组合单下单成功，${_0x239298e.rowIndexes.length} 行共用 Order ID：${_0x23b1daa}`
: `下单成功，Order ID：${_0x23b1daa}`, _0x23a9b13.rowNumber);
const _0x244b6a1 = {
[_0x1a6d9.RUN_STATE]: _0x2342738,
[_0x1a6d9.HISTORY]: _0x236240a,
[_0x1a6d9.ORDER_INDEX]: _0x237c530,
[_0x1a6d9.LOGS]: _0x2350eb5
};
await chrome.storage.local.set(_0x244b6a1);
if (_0x239298e.isCombined) {
await chrome.storage.local.remove(_0x1a6d9.CART_LOCK);
_0xadb373(_0x2350eb5, _0x1c6cd537e4(72), _0x1c6cd537e4(163), _0x23a9b13.rowNumber);
await chrome.storage.local.set({ [_0x1a6d9.LOGS]: _0x2350eb5 });
}
await _0x1c33e2d(_0x2342738, _0x2350eb5, _0x1c6cd537e4(120), _0x55f407(_0x2342738.orderIntervalSeconds, _0x22bcb.orderIntervalSeconds));
return { ok: true, orderId: _0x23b1daa };
}
async function _0x2451d90() {
const _0x246fdb4 = await _0x1493fef();
const _0x2477591 = _0x246fdb4[_0x1a6d9.RUN_STATE];
const _0x248b2e3 = Array.isArray(_0x246fdb4[_0x1a6d9.LOGS]) ? _0x246fdb4[_0x1a6d9.LOGS] : [];
if (!_0x2477591 || !_0x54db2.has(_0x2477591.mode) || _0x2477591.mode === _0x1c6cd537e4(9)) {
return { ok: false, error: _0x1c6cd537e4(164) };
}
const _0x249ff44 = _0x1429d3b(_0x2477591);
const _0x24a9aff = _0x144a799(_0x2477591);
if (_0x2477591.phase === _0x1c6cd537e4(121)) {
const _0x24b5e7d = _0x6b5365(_0x2477591);
await _0x69e03d(_0x2477591.runId);
_0x2477591.intervalEndsAt = null;
_0x2477591.intervalRemainingSeconds = Math.ceil(_0x24b5e7d / 1000);
}
_0x2477591.mode = _0x1c6cd537e4(9);
_0x2477591.pauseReason = _0x1c6cd537e4(165);
_0x2477591.updatedAt = new Date().toISOString();
const _0x24cd0e4 = _0x2477591.phase === _0x1c6cd537e4(121)
? `（间隔剩余约 ${_0x2477591.intervalRemainingSeconds} 秒）`
: _0x1c6cd537e4(34);
if (_0x249ff44?.isCombined) {
_0x10286f1(_0x2477591.rows, _0x249ff44, `人工暂停${_0x24cd0e4}`);
}
else if (_0x24a9aff) {
_0xca6809(_0x24a9aff, `已暂停：人工暂停${_0x24cd0e4}`, _0x1c6cd537e4(70));
}
_0xadb373(_0x248b2e3, _0x1c6cd537e4(90), _0x1c6cd537e4(166), _0x24a9aff?.rowNumber ?? null);
await _0x1612e07(_0x2477591, _0x248b2e3);
return { ok: true };
}
async function _0x24d8b03() {
const _0x24e6411 = await _0x1493fef();
const _0x24f3efc = _0x24e6411[_0x1a6d9.RUN_STATE];
const _0x25050cb = Array.isArray(_0x24e6411[_0x1a6d9.LOGS]) ? _0x24e6411[_0x1a6d9.LOGS] : [];
const _0x251feb0 = _0x24e6411[_0x1a6d9.CART_LOCK] || null;
if (!_0x24f3efc || _0x24f3efc.mode !== _0x1c6cd537e4(9)) {
return { ok: false, error: _0x1c6cd537e4(167) };
}
if (_0x24f3efc.phase === _0x1c6cd537e4(91)) {
return { ok: false, error: _0x1c6cd537e4(168) };
}
const _0x252d6de = _0x1429d3b(_0x24f3efc);
const _0x253ee62 = _0x144a799(_0x24f3efc);
if (_0x252d6de?.isCombined && _0x7296d.has(_0x24f3efc.phase) && !_0x169c43a(_0x251feb0, _0x24f3efc, _0x252d6de)) {
return { ok: false, error: _0x1c6cd537e4(169) };
}
if (_0x24f3efc.phase === _0x1c6cd537e4(121)) {
const _0x254df6e = Math.max(0, Number(_0x24f3efc.intervalRemainingSeconds || 0) * 1000);
_0x24f3efc.mode = _0x1c6cd537e4(10);
_0x24f3efc.pauseReason = _0x1c6cd537e4(34);
_0x24f3efc.intervalEndsAt = new Date(Date.now() + _0x254df6e).toISOString();
_0x24f3efc.intervalRemainingSeconds = Math.ceil(_0x254df6e / 1000);
_0x24f3efc.updatedAt = new Date().toISOString();
if (_0x252d6de) {
_0x107eadd(_0x24f3efc.rows, _0x252d6de, `等待下单间隔（${_0x24f3efc.intervalRemainingSeconds}秒）`);
}
_0xadb373(_0x25050cb, _0x1c6cd537e4(88), _0x1c6cd537e4(170), _0x253ee62?.rowNumber ?? null);
await _0x1612e07(_0x24f3efc, _0x25050cb);
if (_0x254df6e <= 0) {
await _0x1d19389(_0x24f3efc.runId);
}
else {
await _0x6f1845(_0x24f3efc, _0x254df6e);
}
return { ok: true };
}
let _0x25537c3 = false;
if (Number.isInteger(_0x24f3efc.workTabId)) {
try {
await chrome.tabs.get(_0x24f3efc.workTabId);
_0x25537c3 = true;
}
catch {
_0x25537c3 = false;
}
}
if (!_0x25537c3) {
const _0x256ccf7 = [_0x1c6cd537e4(117), _0x1c6cd537e4(116), _0x1c6cd537e4(125), _0x1c6cd537e4(123)].includes(_0x24f3efc.phase);
if (!_0x256ccf7 || !_0x253ee62?.amzLink || _0x24e6411[_0x1a6d9.CART_LOCK]) {
return {
ok: false,
error: _0x1c6cd537e4(171)
};
}
_0x24f3efc.workTabId = await _0x150e2ae(null);
}
_0x24f3efc.mode = _0x1c6cd537e4(8);
_0x24f3efc.pauseReason = _0x1c6cd537e4(34);
_0x24f3efc.updatedAt = new Date().toISOString();
if (_0x252d6de?.isCombined) {
_0x107eadd(_0x24f3efc.rows, _0x252d6de, _0x1c6cd537e4(172));
}
else if (_0x253ee62) {
_0xca6809(_0x253ee62, _0x1c6cd537e4(173), _0x1c6cd537e4(71));
}
_0xadb373(_0x25050cb, _0x1c6cd537e4(88), _0x1c6cd537e4(174), _0x253ee62?.rowNumber ?? null);
await _0x1612e07(_0x24f3efc, _0x25050cb);
if (!_0x25537c3 && _0x253ee62?.amzLink) {
await _0x15e5a45(_0x24f3efc.workTabId, _0x253ee62.amzLink);
}
else {
await _0x15c8e36(_0x24f3efc.workTabId);
}
return { ok: true };
}
async function _0x257e304() {
const _0x25814b4 = await _0x1493fef();
const _0x259febb = _0x25814b4[_0x1a6d9.RUN_STATE];
const _0x25a85ba = Array.isArray(_0x25814b4[_0x1a6d9.LOGS]) ? _0x25814b4[_0x1a6d9.LOGS] : [];
const _0x25b4cff = _0x25814b4[_0x1a6d9.CART_LOCK] || null;
if (!_0x259febb || !_0x54db2.has(_0x259febb.mode)) {
return { ok: false, error: _0x1c6cd537e4(175) };
}
const _0x25cc9d8 = _0x1429d3b(_0x259febb);
const _0x25d5d5b = _0x144a799(_0x259febb);
const _0x25e0a7d = _0x259febb.phase;
if (_0x25e0a7d === _0x1c6cd537e4(121)) {
await _0x69e03d(_0x259febb.runId);
}
_0x259febb.mode = _0x1c6cd537e4(176);
_0x259febb.phase = _0x1c6cd537e4(177);
_0x259febb.pauseReason = _0x1c6cd537e4(34);
_0x259febb.intervalEndsAt = null;
_0x259febb.intervalRemainingSeconds = 0;
_0x259febb.updatedAt = new Date().toISOString();
const _0x25f9daa = _0x169c43a(_0x25b4cff, _0x259febb, _0x25cc9d8);
const _0x2605f79 = _0x25f9daa ? _0x1c6cd537e4(178) : _0x64371.has(_0x25e0a7d)
? _0x1c6cd537e4(179) : _0x1c6cd537e4(180);
if (_0x25cc9d8?.isCombined) {
_0x10286f1(_0x259febb.rows, _0x25cc9d8, _0x2605f79);
}
else if (_0x25d5d5b && (_0x25d5d5b.result === _0x1c6cd537e4(71) || _0x25d5d5b.result === _0x1c6cd537e4(70))) {
_0xca6809(_0x25d5d5b, _0x2605f79, _0x1c6cd537e4(70));
}
_0xadb373(_0x25a85ba, _0x1c6cd537e4(90), _0x25f9daa ? _0x1c6cd537e4(181) : _0x64371.has(_0x25e0a7d)
? _0x1c6cd537e4(182) : _0x1c6cd537e4(183), _0x25d5d5b?.rowNumber ?? null);
await _0x1612e07(_0x259febb, _0x25a85ba);
return { ok: true };
}
async function _0x2613fdd() {
const _0x262c2af = await _0x1493fef();
const _0x263f731 = _0x262c2af[_0x1a6d9.RUN_STATE] || null;
const _0x2648896 = Array.isArray(_0x262c2af[_0x1a6d9.LOGS]) ? _0x262c2af[_0x1a6d9.LOGS] : [];
const _0x2652cd9 = _0x262c2af[_0x1a6d9.CART_LOCK] || null;
if (!_0x2652cd9) {
return { ok: true, cleared: false, message: _0x1c6cd537e4(184) };
}
if (_0x263f731 && [_0x1c6cd537e4(8), _0x1c6cd537e4(10)].includes(_0x263f731.mode)) {
return { ok: false, error: _0x1c6cd537e4(185) };
}
if (_0x263f731 && _0x263f731.runId === _0x2652cd9.runId) {
const _0x266d583 = _0x1429d3b(_0x263f731);
if (_0x266d583?.id === _0x2652cd9.groupId) {
_0x10286f1(_0x263f731.rows, _0x266d583, _0x1c6cd537e4(186));
}
_0x263f731.mode = _0x1c6cd537e4(176);
_0x263f731.phase = _0x1c6cd537e4(177);
_0x263f731.pauseReason = _0x1c6cd537e4(34);
_0x263f731.updatedAt = new Date().toISOString();
}
_0xadb373(_0x2648896, _0x1c6cd537e4(90), `用户确认已人工检查购物篮及最近订单，已清除组合单锁（组 ${_0x2652cd9.groupId || _0x1c6cd537e4(187)}）。`);
await chrome.storage.local.remove(_0x1a6d9.CART_LOCK);
await chrome.storage.local.set({
[_0x1a6d9.RUN_STATE]: _0x263f731,
[_0x1a6d9.LOGS]: _0x2648896
});
return { ok: true, cleared: true };
}
async function _0x267fccc(_0x268aee4, _0x26922f7) {
const _0x26a1d09 = await _0x1493fef();
const _0x26bedf1 = _0x26a1d09[_0x1a6d9.RUN_STATE];
const _0x26c4eb2 = Array.isArray(_0x26a1d09[_0x1a6d9.LOGS]) ? _0x26a1d09[_0x1a6d9.LOGS] : [];
if (!_0x26bedf1 || _0x26922f7.tab?.id !== _0x26bedf1.workTabId || _0x26bedf1.runId !== _0x268aee4.runId) {
return { ok: false, stale: true };
}
const _0x26d3db1 = _0x144a799(_0x26bedf1);
_0xadb373(_0x26c4eb2, _0x268aee4.level || _0x1c6cd537e4(88), String(_0x268aee4.message || _0x1c6cd537e4(34)), _0x26d3db1?.rowNumber ?? null);
await chrome.storage.local.set({ [_0x1a6d9.LOGS]: _0x26c4eb2 });
return { ok: true };
}
async function _0x26ed6a0(_0x26f0b7a) {
const _0x270da61 = await chrome.storage.local.get(_0x1a6d9.RUN_STATE);
const _0x2718c77 = _0x270da61[_0x1a6d9.RUN_STATE];
if (_0x2718c77 && _0x54db2.has(_0x2718c77.mode)) {
return { ok: false, error: _0x1c6cd537e4(188) };
}
await chrome.storage.local.set({
[_0x1a6d9.DRAFT_ROWS]: Array.isArray(_0x26f0b7a) ? _0x26f0b7a : []
});
return { ok: true };
}
async function _0x272f3ab() {
const _0x2735ebd = await chrome.storage.local.get([_0x1a6d9.RUN_STATE, _0x1a6d9.CART_LOCK]);
const _0x274c55c = _0x2735ebd[_0x1a6d9.RUN_STATE];
if (_0x274c55c && _0x54db2.has(_0x274c55c.mode)) {
return { ok: false, error: _0x1c6cd537e4(189) };
}
if (_0x2735ebd[_0x1a6d9.CART_LOCK]) {
return { ok: false, error: _0x1c6cd537e4(190) };
}
await chrome.storage.local.set({
[_0x1a6d9.DRAFT_ROWS]: [],
[_0x1a6d9.RUN_STATE]: null
});
return { ok: true };
}
async function _0x27589a4() {
await chrome.storage.local.set({ [_0x1a6d9.LOGS]: [] });
return { ok: true };
}
async function _0x276f958(_0x27718a8) {
const _0x278ec13 = await chrome.storage.local.get([_0x1a6d9.RUN_STATE, _0x1a6d9.SETTINGS]);
const _0x279b0e8 = _0x278ec13[_0x1a6d9.RUN_STATE];
if (_0x279b0e8 && _0x54db2.has(_0x279b0e8.mode)) {
return { ok: false, error: _0x1c6cd537e4(191) };
}
const _0x27aa802 = _0x27718a8?.orderIntervalSeconds;
const _0x27b9dfc = Number(_0x27aa802);
if (!Number.isInteger(_0x27b9dfc) || _0x27b9dfc < 0 || _0x27b9dfc > 3600) {
return { ok: false, error: _0x1c6cd537e4(86) };
}
const _0x27c5656 = { orderIntervalSeconds: _0x27b9dfc };
await chrome.storage.local.set({ [_0x1a6d9.SETTINGS]: _0x27c5656 });
return { ok: true, settings: _0x27c5656 };
}
async function _0x27dcc38() {
const _0x27ea7fe = await _0x1493fef();
const _0x27f41bd = _0x27ea7fe[_0x1a6d9.RUN_STATE];
if (_0x27f41bd && _0x54db2.has(_0x27f41bd.mode)) {
return { ok: false, error: _0x1c6cd537e4(192) };
}
const _0x2802dab = _0x778307();
const _0x2817e72 = Array.isArray(_0x27ea7fe[_0x1a6d9.LOGS]) ? _0x27ea7fe[_0x1a6d9.LOGS] : [];
const _0x282d354 = _0x97dc56(_0x27ea7fe[_0x1a6d9.HISTORY]);
const _0x283cb75 = _0x9d4f15(_0x27ea7fe[_0x1a6d9.ORDER_INDEX], _0x282d354);
const _0x284afe0 = new Set();
for (const [_0x285a5a6, _0x286df16] of Object.entries(_0x283cb75)) {
if (_0x286df16?.status === _0x1c6cd537e4(60) && _0x286df16.dateKey === _0x2802dab && _0x5c4614(_0x286df16.orderId)) {
_0x284afe0.add(_0x842448(_0x286df16.temuOrderId));
delete _0x283cb75[_0x285a5a6];
}
}
const _0x287301d = _0x282d354.filter((_0x288a69f) => {
const _0x28946ba = _0x288a69f.status === _0x1c6cd537e4(60) &&
_0x288a69f.dateKey === _0x2802dab &&
_0x5c4614(_0x288a69f.orderId);
if (_0x28946ba) {
_0x284afe0.add(_0x842448(_0x288a69f.temuOrderIdKey || _0x288a69f.temuOrderId));
}
return !_0x28946ba;
});
_0xadb373(_0x2817e72, _0x1c6cd537e4(90), `已清空 ${_0x284afe0.size} 条 ${_0x2802dab} 的成功下单防重复记录。`);
await chrome.storage.local.set({
[_0x1a6d9.HISTORY]: _0x287301d,
[_0x1a6d9.ORDER_INDEX]: _0x283cb75,
[_0x1a6d9.LOGS]: _0x2817e72
});
return { ok: true, clearedCount: _0x284afe0.size, dateKey: _0x2802dab };
}
async function _0x28abe3c() {
const _0x28b9406 = await _0x1493fef();
const _0x28ce012 = _0x28b9406[_0x1a6d9.RUN_STATE];
if (!_0x28ce012 || _0x28ce012.mode !== _0x1c6cd537e4(10) || _0x28ce012.phase !== _0x1c6cd537e4(121) || !_0x28ce012.runId) {
return { ok: false, stale: true };
}
const _0x28da308 = _0x6b5365(_0x28ce012);
if (_0x28da308 <= 0) {
return _0x1d19389(_0x28ce012.runId);
}
await _0x6f1845(_0x28ce012, _0x28da308);
return { ok: true, waiting: true };
}
async function _0x28e6252(_0x28fd473) {
const _0x290e7bd = await chrome.storage.local.get([_0x1a6d9.RUN_STATE, _0x1a6d9.CART_LOCK]);
const _0x29141ae = _0x290e7bd[_0x1a6d9.RUN_STATE] || null;
const _0x2920808 = Boolean(_0x29141ae && _0x28fd473.tab?.id === _0x29141ae.workTabId);
const _0x293d4a8 = _0x2920808 ? _0x1429d3b(_0x29141ae) : null;
return {
ok: true,
isWorkTab: _0x2920808,
state: _0x29141ae,
row: _0x2920808 ? _0x144a799(_0x29141ae) : null,
group: _0x293d4a8,
orderRow: _0x2920808 ? _0x146d3ad(_0x29141ae) : null,
cartLock: _0x2920808 ? _0x290e7bd[_0x1a6d9.CART_LOCK] || null : null
};
}
chrome.action.onClicked.addListener(() => {
_0x14a1ba1().catch((_0x2944db1) => console.error(_0x1c6cd537e4(193), _0x2944db1));
});
chrome.runtime.onInstalled.addListener(() => {
_0x17705a(async () => {
const _0x295ea74 = await _0x1493fef();
const _0x2962b05 = _0x97dc56(_0x295ea74[_0x1a6d9.HISTORY]);
const _0x297174a = _0x9d4f15(_0x295ea74[_0x1a6d9.ORDER_INDEX], _0x2962b05);
const _0x2985242 = Array.isArray(_0x295ea74[_0x1a6d9.LOGS]) ? _0x295ea74[_0x1a6d9.LOGS] : [];
const _0x299e466 = _0x59440f(_0x295ea74[_0x1a6d9.SETTINGS]);
const _0x29a1f7a = Array.isArray(_0x295ea74[_0x1a6d9.DRAFT_ROWS]) ? _0x295ea74[_0x1a6d9.DRAFT_ROWS] : [];
const _0x29b023a = _0x295ea74[_0x1a6d9.CART_LOCK] || null;
let _0x29cf6c0 = _0x295ea74[_0x1a6d9.RUN_STATE] || null;
if (_0x29cf6c0 && _0x54db2.has(_0x29cf6c0.mode) && Number(_0x29cf6c0.version || 0) < _0xbfe83) {
const _0x29dd65b = _0x144a799(_0x29cf6c0);
if (_0x29dd65b) {
_0xca6809(_0x29dd65b, _0x1c6cd537e4(194), _0x1c6cd537e4(70));
}
_0x29cf6c0 = {
..._0x29cf6c0,
version: _0xbfe83,
mode: _0x1c6cd537e4(176),
phase: _0x1c6cd537e4(177),
pauseReason: _0x1c6cd537e4(34),
intervalEndsAt: null,
intervalRemainingSeconds: 0,
updatedAt: new Date().toISOString()
};
_0xadb373(_0x2985242, _0x1c6cd537e4(90), _0x1c6cd537e4(195));
}
if (_0x29b023a) {
_0xadb373(_0x2985242, _0x1c6cd537e4(90), _0x1c6cd537e4(196));
}
await chrome.storage.local.set({
[_0x1a6d9.RUN_STATE]: _0x29cf6c0,
[_0x1a6d9.HISTORY]: _0x2962b05,
[_0x1a6d9.ORDER_INDEX]: _0x297174a,
[_0x1a6d9.LOGS]: _0x2985242,
[_0x1a6d9.DRAFT_ROWS]: _0x29a1f7a,
[_0x1a6d9.SETTINGS]: _0x299e466
});
if (_0x29cf6c0?.mode === _0x1c6cd537e4(10) && _0x29cf6c0.phase === _0x1c6cd537e4(121)) {
await _0x28abe3c();
}
}).catch((_0x29e33d3) => console.error(_0x29e33d3));
});
chrome.runtime.onStartup.addListener(() => {
_0x17705a(_0x28abe3c).catch((_0x29f03e7) => console.error(_0x29f03e7));
});
chrome.alarms.onAlarm.addListener((_0x2a03c74) => {
if (!_0x2a03c74?.name?.startsWith(_0x95e49)) {
return;
}
const _0x2a1317a = _0x2a03c74.name.slice(_0x95e49.length);
_0x17705a(() => _0x1d19389(_0x2a1317a)).catch((_0x2a2fd1f) => console.error(_0x2a2fd1f));
});
chrome.runtime.onMessage.addListener((_0x2a3e8ea, _0x2a40acc, _0x2a5f742) => {
const _0x2a63a5c = (_0x2a79662) => {
_0x2a79662.then((_0x2a85d7a) => _0x2a5f742(_0x2a85d7a))
.catch((_0x2a945a8) => {
console.error(_0x2a945a8);
_0x2a5f742({ ok: false, error: _0x2a945a8.message || String(_0x2a945a8) });
});
};
switch (_0x2a3e8ea?.type) {
case _0x1c6cd537e4(197):
_0x2a63a5c(_0x17705a(_0x487a5c));
return true;
case _0x1c6cd537e4(198):
_0x2a63a5c(_0x3f8e02(false));
return true;
case _0x1c6cd537e4(32):
_0x2a5f742({ ok: true });
return false;
case _0x1c6cd537e4(199):
_0x2a63a5c(_0x4a4443(_0x2a40acc));
return true;
case _0x1c6cd537e4(200):
_0x2a63a5c(_0x45ab20());
return true;
case _0x1c6cd537e4(201):
_0x2a63a5c(_0x17705a(() => _0x422a29(() => _0x16dc7e1(_0x2a3e8ea.rows, _0x2a3e8ea.orderIntervalSeconds))));
return true;
case _0x1c6cd537e4(202):
_0x2a63a5c(_0x17705a(() => _0x422a29(() => _0x26ed6a0(_0x2a3e8ea.rows))));
return true;
case _0x1c6cd537e4(203):
_0x2a63a5c(_0x17705a(() => _0x422a29(_0x272f3ab)));
return true;
case _0x1c6cd537e4(204):
_0x2a63a5c(_0x17705a(() => _0x422a29(_0x27589a4)));
return true;
case _0x1c6cd537e4(205):
_0x2a63a5c(_0x17705a(() => _0x422a29(() => _0x276f958(_0x2a3e8ea.settings))));
return true;
case _0x1c6cd537e4(206):
_0x2a63a5c(_0x17705a(() => _0x422a29(_0x27dcc38)));
return true;
case _0x1c6cd537e4(207):
_0x2a63a5c(_0x17705a(() => _0x422a29(_0x2613fdd)));
return true;
case _0x1c6cd537e4(208):
_0x2a63a5c(_0x17705a(() => _0x1958672(_0x2a3e8ea, _0x2a40acc)));
return true;
case _0x1c6cd537e4(209):
_0x2a63a5c(_0x17705a(() => _0x19cce18(_0x2a3e8ea, _0x2a40acc)));
return true;
case _0x1c6cd537e4(210):
_0x2a63a5c(_0x17705a(() => _0x422a29(() => _0x1a44b2f(_0x2a3e8ea, _0x2a40acc))));
return true;
case _0x1c6cd537e4(211):
_0x2a63a5c(_0x17705a(() => _0x267fccc(_0x2a3e8ea, _0x2a40acc)));
return true;
case _0x1c6cd537e4(212):
_0x2a63a5c(_0x17705a(() => _0x422a29(() => _0x2233d8d(_0x2a3e8ea, _0x2a40acc, false))));
return true;
case _0x1c6cd537e4(213):
_0x2a63a5c(_0x17705a(() => _0x422a29(() => _0x1d90544(_0x2a3e8ea, _0x2a40acc))));
return true;
case _0x1c6cd537e4(214):
_0x2a63a5c(_0x17705a(() => _0x422a29(() => _0x1e39cce(_0x2a3e8ea, _0x2a40acc))));
return true;
case _0x1c6cd537e4(215):
_0x2a63a5c(_0x17705a(() => _0x422a29(() => _0x1f04d3b(_0x2a3e8ea, _0x2a40acc))));
return true;
case _0x1c6cd537e4(216):
_0x2a63a5c(_0x17705a(() => _0x422a29(() => _0x1f9196b(_0x2a3e8ea, _0x2a40acc))));
return true;
case _0x1c6cd537e4(217):
_0x2a63a5c(_0x17705a(() => _0x422a29(() => _0x208a402(_0x2a3e8ea, _0x2a40acc))));
return true;
case _0x1c6cd537e4(218):
_0x2a63a5c(_0x17705a(() => _0x422a29(() => _0x21af5c3(_0x2a3e8ea, _0x2a40acc))));
return true;
case _0x1c6cd537e4(219):
_0x2a63a5c(_0x17705a(() => _0x2308819(_0x2a3e8ea, _0x2a40acc)));
return true;
case _0x1c6cd537e4(220):
_0x2a63a5c(_0x17705a(() => _0x422a29(_0x2451d90)));
return true;
case _0x1c6cd537e4(221):
_0x2a63a5c(_0x17705a(() => _0x422a29(_0x24d8b03)));
return true;
case _0x1c6cd537e4(222):
_0x2a63a5c(_0x17705a(() => _0x422a29(_0x257e304)));
return true;
case _0x1c6cd537e4(223):
_0x2a63a5c(_0x17705a(() => _0x422a29(() => _0x2233d8d({ reason: _0x1c6cd537e4(158) }, null, true))));
return true;
case _0x1c6cd537e4(224):
_0x2a63a5c(_0x422a29(() => chrome.storage.local
.get(_0x1a6d9.RUN_STATE)
.then((_0x2aad8e5) => _0x159b731(_0x2aad8e5[_0x1a6d9.RUN_STATE]?.workTabId))
.then(() => ({ ok: true }))));
return true;
default:
return false;
}
});
chrome.tabs.onRemoved.addListener((_0x2ab2744) => {
_0x17705a(async () => {
const _0x2ac8480 = await _0x1493fef();
const _0x2ad2562 = _0x2ac8480[_0x1a6d9.RUN_STATE];
if (!_0x2ad2562 || _0x2ab2744 !== _0x2ad2562.workTabId || !_0x54db2.has(_0x2ad2562.mode)) {
return;
}
const _0x2ae3799 = Array.isArray(_0x2ac8480[_0x1a6d9.LOGS]) ? _0x2ac8480[_0x1a6d9.LOGS] : [];
const _0x2afdbb3 = _0x1429d3b(_0x2ad2562);
const _0x2b0d3e6 = _0x144a799(_0x2ad2562);
const _0x2b19d7c = _0x2ac8480[_0x1a6d9.CART_LOCK] || null;
_0x2ad2562.workTabId = null;
_0x2ad2562.updatedAt = new Date().toISOString();
if (_0x2ad2562.phase === _0x1c6cd537e4(121) && _0x2ad2562.mode === _0x1c6cd537e4(10)) {
_0xadb373(_0x2ae3799, _0x1c6cd537e4(90), _0x1c6cd537e4(225), _0x2b0d3e6?.rowNumber ?? null);
await _0x1612e07(_0x2ad2562, _0x2ae3799);
return;
}
_0x2ad2562.mode = _0x1c6cd537e4(9);
_0x2ad2562.pauseReason = _0x169c43a(_0x2b19d7c, _0x2ad2562, _0x2afdbb3)
? _0x1c6cd537e4(226) : _0x1c6cd537e4(227);
if (_0x2afdbb3?.isCombined) {
_0x10286f1(_0x2ad2562.rows, _0x2afdbb3, _0x2ad2562.pauseReason);
}
else if (_0x2b0d3e6) {
_0xca6809(_0x2b0d3e6, `等待人工检查：${_0x2ad2562.pauseReason}`, _0x1c6cd537e4(70));
}
_0xadb373(_0x2ae3799, _0x1c6cd537e4(33), _0x2ad2562.pauseReason, _0x2b0d3e6?.rowNumber ?? null);
await _0x1612e07(_0x2ad2562, _0x2ae3799);
}).catch((_0x2b2839a) => console.error(_0x2b2839a));
});
})();
