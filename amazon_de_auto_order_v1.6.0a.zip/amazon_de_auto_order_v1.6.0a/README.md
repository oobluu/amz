# Amazon DE 自动下单助手 v1.6.0a

Chrome Manifest V3 扩展，仅用于 Amazon.de 英文界面。当前版本同时支持：

- 单行收件人地址组：沿用商品页 **Buy Now** 流程；
- 同一处理后姓名、同一完整地址的多行地址组：逐行 **Add to basket**，最后合并为一个 Amazon 订单；
- 商品含税单价必须为 €2.00；
- 购买数量必须使用页面中的精准数字选项，不使用 `4+`、`5+` 等模糊选项；
- Temu Order ID 德国自然日防重复及地址/商品签名冲突检查；
- 组合单购物篮累计数量校验和 `CART_BUILDING` 安全锁；
- `address2`、人工处理推荐地址、特殊 Amex 1009 分支；
- 七列工作记录、逐行复制 Order ID、CSV 导出和详细工作日志。

## 安装

1. 解压 ZIP 文件。
2. 在 Chrome 地址栏打开 `chrome://extensions/`。
3. 打开右上角“开发者模式”。
4. 点击“加载已解压的扩展程序”。
5. 选择目录 `amazon_de_auto_order_v1.6.0a`。
6. 禁用或删除旧版本，避免多个版本同时控制同一个 Amazon 页面。
7. 先登录 Amazon.de，并将页面语言设为 English。

## 输入表格

必须按下列顺序复制九列数据，不要复制表头：

| 顺序 | 字段 |
|---:|---|
| 1 | Temu Order ID |
| 2 | AMZ link |
| 3 | quantity to ship |
| 4 | recipient name |
| 5 | phone number |
| 6 | ship address |
| 7 | address2 |
| 8 | ship city |
| 9 | ship postal code |

`address2` 可以为空，但 Excel 中必须保留第七列的空单元格。旧八列格式不会自动推断字段位置。

姓名处理规则：保留 Unicode 字母、空格、连字符和撇号；其他符号替换为空格，再压缩连续空格。`+`、`*`、`/` 因此会变为空格，`-` 保留。

## 地址组建立规则

插件不会改变面板中原始行顺序。开始后只在内部建立并排列地址组，工作记录仍按原输入行回填。

以下五项全部相同，才属于同一个 Amazon 地址组：

1. 处理后的 recipient name；
2. ship address；
3. address2；
4. ship city；
5. ship postal code。

比较时去除首尾空格、压缩连续空格并忽略英文大小写，但不会擅自把 `Straße`、`Strasse`、`Str.` 等不同写法视为相同地址。

- 姓名相同、完整地址不同：分成不同 Amazon 订单，均可自动处理；
- 姓名和完整地址相同、只有一行：使用原 Buy Now 流程；
- 姓名和完整地址相同、有两行或更多：使用购物篮合并流程；
- 同组电话号码不同：使用原始输入中最先出现一行的电话号码，并写入警告日志。

## 单行地址组流程

1. 打开 AMZ link；
2. 检查 404、商品含税单价和精准 quantity；
3. 点击商品页 Buy Now；
4. 进入地址选择/付款页面；
5. 添加新地址并回读验证六项字段；
6. 推荐地址出现时等待人工选择；
7. 核对付款页收件人姓名；
8. 点击最终 Buy now；
9. 进入订单历史，按姓名、最终地址、当天日期和 ASIN×quantity 匹配唯一订单卡片；
10. 获取 Order ID，写入该行结果和当天防重复记录。

## 多行组合单流程

### 第一阶段：完整预检查，不加入购物篮

组合单开始时，插件先读取 Amazon 右上角 `#nav-cart-count` 与购物篮 `aria-label`。活动购物篮必须为 0。

随后逐行打开组内商品页面并检查：

- 商品页面不是 404；
- 当前 Add to basket 下单模块属于目标 ASIN；
- 含税单价为 €2.00；
- quantity 是正整数；
- 页面存在与 quantity 完全相同的数字选项；
- `4+`、`5+` 等选项不算精准匹配；
- 选择后 select、option 和页面显示数量一致；
- Add to basket 按钮存在且可用。

预检查期间不会点击 Add to basket。

如果某一行属于普通跳过情况，整个地址组不下单：

- 触发问题的行保留实际原因，例如 `金额不为2，跳过`、`限购，跳过`、`未找到商品，跳过`；
- 同组其余行记录 `同地址组合单存在异常，整组跳过`。

价格无法读取、价格来源冲突、数量回读不一致或页面结构异常属于不确定状态，任务暂停等待人工检查，不按普通跳过处理。

### 第二阶段：正式逐行加入购物篮

全组预检查通过后，插件回到第一行商品并再次确认购物篮为 0，然后建立 `CART_BUILDING` 安全锁。

对每一行重新执行价格和数量核对，再分别点击 Add to basket。即使以下信息完全相同，也会按两行分别添加并累计数量：

- Temu Order ID；
- AMZ link；
- quantity。

每次加购后必须同时满足：

- 页面出现 `Added to basket`；
- 右上角购物篮累计数量等于已处理行 quantity 的总和。

例如组内数量为 `1、5、2`，累计检查依次必须为 `1、6、8`。

最后一行添加成功后，插件再次检查：

- 右上角购物篮总数 = 该组全部 quantity 总和；
- Proceed to Checkout 按钮中的 `(n items)` 若存在，也必须等于该总和。

检查通过后点击 Proceed to Checkout。无需进入购物车详情页。

### Checkout 及付款

Proceed 后沿用原地址和付款流程：

- 页面直接出现 Add a new delivery address：按正常流程继续；
- 页面没有 Add new，但存在银行卡模块和地址 Change：选择 American Express ending in 1009，确认选中后点击 Change，再等待 Add new；
- 不修改 Amex Rewards Points；
- 返回最终付款页后不再次重新选择银行卡；
- 推荐地址由用户人工决定；
- 付款页只核对处理后收件人姓名，不检查付款页金额。

### 组合单 Order ID 匹配

订单历史页会扫描可见订单卡片，并同时匹配：

- Order placed 为德国当天；
- Dispatch to 姓名；
- 付款页实际显示的最终收货地址；
- 本组合单全部 ASIN 及其累计 quantity；
- Order ID 尚未被当前任务记录。

必须恰好找到一个包含全部预期商品数量的 Order ID。若 Amazon 将一次 Checkout 拆成多个 Order ID，插件暂停，不自动把 ID 分配到输入行。

成功后，同组所有输入行的“工作结果”都写入同一个 Amazon Order ID。

## Temu Order ID 防重复

同一地址组内允许 Temu Order ID 重复，也允许多个不同 Temu Order ID 合并为一个 Amazon 订单。

成功后，对组内每个唯一 Temu Order ID 保存：

- 德国日期；
- 标准化姓名和完整地址签名；
- 该 Temu Order ID 对应的 ASIN×quantity 签名；
- Amazon Order ID。

处理规则：

| 情况 | 结果 |
|---|---|
| 同一 Temu ID 在同一地址组多行出现 | 允许，所有行都参与组合单 |
| 同一 Temu ID 出现在不同地址组 | 暂停，等待人工检查 |
| 今天已成功，地址和商品签名相同 | 该地址组整组跳过 |
| 今天已成功，但地址、商品或数量签名不同 | 暂停，等待人工检查 |
| 昨天或更早成功 | 按现有“当天防重复”规则，今天允许重新处理 |

只有成功取得有效 Amazon Order ID 后才写入当天成功记录。普通跳过行不计入当天记录。

## CART_BUILDING 安全锁

组合单在第一次 Add to basket 前建立安全锁，并持续到成功取得唯一 Order ID。

锁会在以下阶段继续保留：

- 正在加入部分商品；
- 已加入全部商品；
- 已点击 Proceed to Checkout；
- 正在填写地址或等待人工地址选择；
- 已点击最终 Buy now 但尚未取得 Order ID；
- 任务暂停、停止、工作标签页关闭或浏览器重启。

存在锁时，新任务被阻止，也不能直接跳过当前组合单。

人工恢复步骤：

1. 检查 Amazon 活动购物篮；
2. 检查 Amazon 最近订单，确认是否已产生订单；
3. 必要时人工清理购物篮或记录订单；
4. 在控制面板点击“确认已人工检查并清除组合单锁”。

该按钮只清除插件安全锁，不会删除 Amazon 购物篮商品，也不会自动写入 Order ID。清锁后当前组合单任务保持停止状态。

## 工作记录和导出

工作记录固定为七列：

1. Temu Order ID；
2. ASIN；
3. recipient name；
4. address；
5. city；
6. postal code；
7. 工作结果。

成功时“工作结果”直接显示 Amazon Order ID。组合单多行共享同一个 ID。

“复制所有 Order ID”按工作记录行输出，不去重。因此四行共享一个 Order ID 时，复制结果也包含四行相同 ID。

CSV 继续只导出七列，不包含 phone、address2、AMZ link 或 quantity。

## 下单间隔

- 默认 30 秒；
- 可设置 0–3600 的整数；
- 只在成功取得一个 Amazon Order ID 后开始；
- 组合单内部逐行 Add to basket 不等待；
- 普通跳过组不等待；
- 最后一个成功地址组完成后直接结束。

## 清空当天下单记录

“清空当天下单记录”只删除隐藏的当天成功防重复记录，不删除：

- 输入表格；
- 工作记录；
- 工作日志；
- 页面中已显示的 Order ID。

存在组合单安全锁时，该按钮不可用。

## 运行限制与安全边界

- 仅支持 Amazon.de 英文界面；
- 首次测试新版本时只输入少量数据，并保持工作标签页可见；
- 组合单开始前必须人工清空真实活动购物篮；
- 插件不会自动删除购物篮中的原有商品；
- 验证码、登录验证、价格来源冲突、数量回读失败、银行卡切换失败、购物篮数量异常和订单拆分都会暂停；
- 页面结构发生变化时，不应反复点击最终付款按钮；
- 若最终付款后未取得 Order ID，先人工检查最近订单，再处理组合单锁。

## 文件结构

```text
amazon_de_auto_order_v1.6.0a/
├── manifest.json
├── background.js
├── content.js
├── panel.html
├── panel.css
├── panel.js
└── README.md
```
