(()=>{'use strict';const _0x910731f6ec=["rKC3gr+pqL+fuKOeuay5qA==","rKC3gr+pqL+FpL65or+0","rKC3gr+pqL+Boqq+","rKC3gr+pqL+Jv6yruZ+iur4=","rKC3gr+pqL+eqLm5pKOqvg==","rKC3jqy/uY+4pKGppKOqgaKupg==","uaiguIK/qai/hKk=","maiguO2Cv6mov+2EiQ==","rKC3gaSjpg==","jICX7aGko6Y=","vLiso7mkubSZop6lpL0=","vLiso7mkubTtuaLtvqWkvQ==","v6iupL2kqKO5g6ygqA==","v6iupL2kqKO57aOsoKg=","vaWio6iDuKCvqL8=","vaWio6jto7igr6i/","vqWkvYypqb+ovr4=","vqWkve2sqam/qL6+","rKmpv6i+vv8=","vqWkvY6kubQ=","vqWkve2upLm0","vqWkvZ2ivrmsoY6iqag=","vqWkve29or65rKHtrqKpqA==","v7ijo6Sjqg==","vay4vqip","ub+so76kuaSio6Sjqg==","K21sJGdBKGl8JXloInFBJWJ6JUxZKn52nqWso6qsow==","JXNeKEhoJG9JK25NK1JoKEt/KmdMInFBKmBEKHNIKXd3KHpoKGlJKl1L","KnZJKF1FKEBYJG9JK25NK1JoKERAKmxjJWNpJXlgKkRkKmJjKXV3KmR3","JE1dJWxBJG9JK25NK1JoKnZJKF1FKEBYKFhLKF5M","K2BuKHFCKEdtJXlgKERAKEtAK2FsKmxjJWNpJXlgKkRkKmJjKXV3KmR3","JE1dJWxBK2BuKHFCKEdtKEhoJXlgKkRkKmJj","KmxjJWNp7Yypqaip7bmi7a+svqaoue0pdUMqeWIlY2wrWH0kSkI=","K211KGJ0K012K1h9JEpCKHR77Z2/oq6oqKntuaLtjqWorqaiuLk=","K0ReKHFNKFhLKF5MJGx4KHR7JWJLKEVmKXVGKEBYK2VsKFBa","K25NK1JoKFhLKF5MKF1mKmVDKEBYKXZ67S9PYf/j/f0=","JE1EK0ZkKn9zKEpLJXlgKXR9K1h9JEpC","KFZTJWJ2KHR7K211KGJ0JXlgKXR9K1h9JEpC","KmBEKHNIKXVGKEBYK0VbKXZVK2FzJE1EK0ZkJGx4JFBv","JE1EK0Zk7YygqL+krqyj7Yi1vb+ovr7tqKOppKOq7aSj7fz9/fQ=","Kk90KEp2KFF9KFBNK2VsKFBa7Y6lrKOqqA==","KmBEKHNIKFF9KFBNJE1EK0ZkJGx4JFBvKEdtJXBw","KmBEKHNIK1t9KHZ3KFF9KFBNKmdaKEJu","KmBEKHNIKFF9KFBNJGdBJWJMKnZeK1NR","KmBEKHNIKXd3KHpoJE1EK0ZkK0NlJUBdKFF9KFBN","KmBEKHNIKXZVK2FzJGx4JFBv","K211KGJ0KXZVK2FzJGx4K1l7KXZ7KXd3KGpeKF1A","KmBEKHNIKXVGKEBYK0VdKEdSJGx4JFBv","K0FEKGpeKF1ALk1MKFF9KFBNKF9BKFhLKF5MK1h9JEpCKEF0JEhAJWNvKEBYKEBsKkRK","KEVKK0BvKEV9KXVGKXVNK1BsK1h9K0Bj","KmBEKHNIKXVGKXVNKEBYKXVGKEBYJFp5JFdZ","KXZ2KEdsKGNBK0Vd","KXZ2KEdsKHp/KExRK2Bv","JXJdJWxBKXVg","KHp/K1dPKExR","KEVKK0BvKXVg","KHp/KGNBK0Vd","KHp/KExRK2Bv","vaijqaSjqg==","7r+4o4Ciqag=","7q64v7+oo7mforo=","7q64v7+oo7mdpay+qA==","7r2suL6on6isvqKj","7qy4uaWiv6S3rLmkoqOLrKShuL+oj6y/","7r+ou6yhpKmsuaiMuLmlor+kt6y5pKKjj7mj","7q6hor6omqSjqaK6j7mj","7r65rL+5j7mj","7r2suL6oj7mj","7q6io7mko7ioj7mj","7r6mpL2PuaM=","7r65or2PuaM=","7qK9qKOZrK+PuaM=","7qK/qai/hKO5qL+7rKGeqK6io6m+","7q6hqKy/maKprLSCv6mov76PuaM=","7q6hqKy/jqy/uYGirqaPuaM=","7qypqZ+iur6PuaM=","7r+ooKK7qI+hrKOmj7mj","7q6hqKy/hKO9uLmPuaM=","7q6ivbSCv6mov4Spvo+5ow==","7qi1vaK/uZ+orqK/qb6OvruPuaM=","7q6ivbSfqK6iv6m+j7mj","7q6ivbSBoqqPuaM=","7q6hqKy/gaKqj7mj","7qSjvbi5mayvoaiPoqm0","7r+orqK/qb6ZrK+hqI+iqbQ=","7qGiqo6io7mspKOovw==","7rmirL65","","oq+nqK65","qL+/or8=","paSpqaij","rLi5paK/pLeoqQ==","q6ykoaip","jJiZhZKLjISBiIk=","ub8=","uak=","pKO9uLngv6K64KO4oK+ovw==","pKO9uLk=","uai1uQ==","oqur","rL+krOChrK+ooQ==","vay+uag=","uai1ueK9oaykow==","xA==","7w==","xw==","wA==","pKO9uLmWqay5rOCrpKihqZA=","noybiJKJn4yLmZKfgpqe","7Q==","vriurqi+vg==","v6iuor+p4L64rq6ovr4=","r6GirqaoqQ==","v6iuor+p4Ki/v6K/","vqakvb2oqQ==","v6iuor+p4Lqsv6Oko6o=","qKC9ubTgrqihoQ==","K1dPK1ptKHpoKXBRJWN9KHBY","qaS7","oaKq4Kigvbm0","K1dPK1ptK1poKHJa","oaKq4L+iug==","pKOrog==","vr2sow==","oaKq4LmkoKg=","oaKq4KGou6ih","oaKq4L+iuuCjuKCvqL8=","L01Z","oaKq4KCovr6sqqg=","K1FnKHFNKGpG","K1FnKlJo","moyEmZKEg5mIn5uMgQ==","r7i5uaKj4e2ko724uQ==","jJ6Egw==","rKmpv6i+vg==","rqS5tA==","vaK+uayh7a6iqag=","KHpoKXBRKnZeK1NR","7+8=","9g==","wMc=","qKPgio8=","iLi/or2o4o+ov6Gkow==","o7igqL+krg==","/+CppKqkuQ==","pf/+","uai1ueKuvrv2rqWsv76oufC4uavg9Q==","rA==","rqGkrqY=","n4ibjIGEiYyZiJKMmJmFgp+El4yZhIKD","K39sK1FEKEJiKGlJKl1LKldJK1h9K0BjJWxBLk1P","K2JCKEBYKXVGKEBYK1p7JFp5JFp5JFdZKHJIJGx2K1Vi7f0vTV7++/397SpXSStYeStYfSpqXy5NTw==","noybiJKeiJmZhIOKng==","npmMn5mSn5iD","JG9JK25NK1JoKEJcKkN9KEt/KmdMInFBKXZ2KEdsKHp/K1dPKExRKmBEKHNIKXd3KHpoKGlJKl1LLk1P","KXZ2KEdsKHp/KHFNKGpGLk1P","nYyYnoiSn5iD","KXZ2KEdsKHp/K1dPKExRLk1P","joKDmYSDmIiSn5iD","KXZ2KEdsKnZqKnZgK0RqJWxBLk1P","moyEmZKCn4mIn5KemI6OiJ6e","moyEmZKCn4mIn5KFhJ6Zgp+U","KHBeKERAJWNvKEBYKEJiJU5wKHp/KnZCK0JdKXdpKXBLKH1XK1FnKEJbKHNa7YK/qai/7YSJLk1PJXp+JXJKKF1DKXVAKXFXKEtUKEhoKHBeKGlkKXVGKEBYJWN9KHBYInFBJEpAK1t9JXJdJWxBKlZ1KF1B7ZmooLjtgr+pqL/thIntKEJiJU5wJE1tK0VdJEpAKGlAKXVGKEBYLk1PKmxjKGNXJXp+JXJKKHBeKERAJWxBKF1aInFS","noaEnZKOmJ+fiIOZkoCMg5iMgQ==","KHBeKERAJWxBKHp/JXp+JXJKLk1P","KHBeKERAKGBVKFFl7Y6Mn5mSj5iEgYmEg4rtKnZJKF1FKEBYKGNEKEhlJFlMLk1PKExRK2BvKXZ2KEdsKF1DJFlMKXZAKXFXKXJQKlhUInFBKHJIJGx2KEhFKXd3KHpoK25NK1JoJXlgKkRkKmJjKF9BK1FNJXJcJWNvKEBYInFBKEtAKXByKlllL01RKmxjJWNpKHp/KXd3KHpoK25NK1JoKHR7K3VIJFRpKnZJKF1FKEBYJFlML01QLk1PKmxjKGNXKExRK2BvKEhlJE5lKXZ2KEdsKF1aInFS","KHBeKERAJWNvKEBYKEJiJU5wKHp/KnZCK0JdKXdpKXBLKH1XK1FnKEJbKHNa7YK/qai/7YSJLk1PKExRK2BvKF1DKXVAKXFXKEtUKEhoKHBeKGlkKXVGKEBYJWN9KHBYInFBJEpAK1t9JXJdJWxBKEJiJU5wJE1tK0VdJEpAKGlAKXVGKEBYLk1PKmxjKGNXKExRK2BvKEhlJE5lKXZ2KEdsKF1aInFS","npmCnZKfmIM=","KXZ2KEdsKHp/KExRK2BvLk1P","gp2Ig5Kagp+GkpmMjw==","KmxjKGNXK3VIKmR3JXNeKEhoJWxlK21xKF9BKHBeKERAKHp/KnZeK1BSKXZ2KEdsKldJKHpoKXBRJWN9KHBYKF1aInFSKHBeKGlkK0VdKEdSKXVGKEBYJFV/JEpAKGlAJWN9KHBYKXVAKXFXJW9mKEVtJFRpLk1P","joGIjJ+SiZ+Mi5mSn4Kang==","JXNeKEhoK1h9K0BjKHp/K3VIKmR3InFWKHBeKGlkK0VdKEdSKXVGKEBYJFV/JEpAKGlAJWN9KHBYKXZAKXJQKlhULk1P","rqWso6qo","KXZIKFFlK09lKHp/KnZCKXd3KHpoK25NK1Jo7YygrLeio+0reXYoR2UleWAqRGQqYmMoX0ErUU0lclwlY28oQFgoXUMrREAlTnArdUgkVGkuTU/Hxyt1SCRUaShdQyJxQShwXihEQCp2SShdRShAWCl2dihHbClxVylyUCtBTChMUStgbypHeytNTCJxViViaCtBRCRfYyl1QClxVyhFbSRUaSV5YCpEZCpiYyhYSyheTCJxQSl0Uil1QClxVyhLVChIaO2Cv6mov+2EiS5NTypsYyhjVyt1SCRUae2OjJ+Zko+YhIGJhIOK7Sp2SShdRShAWCRZTChdWiJxUg==","joGIjJ+SjoyfmZKPmISBiYSDipKBgo6G","KnZJKF1FKEBYKGNEKEhlJFlMKHp/K3VIJFRpLk1P","KHBeKERAK39sK1FEKnZJKF1FKEBYKGNEKEhlJFlMLk1P","KmxjKGNXK3VIKmR3KXZHKGlkKHp/K0VdKEdSJUN6KEJb7YK/qai/7YSJ7SpXSe2ZqKC47YK/qai/7YSJ7SRVfyRKQChpQCVjfShwWChdWiJxUsfHK3VIKmR3KF1DInFBJXJUKXdW7ZmooLjtgr+pqL/thIntKXZHKGlkKEJiKXZoKEtAK2FsKXVGKEBYLk1PKHpoKXBRJWN9KHBYLk1MJXNeKEhoK1h9K0BjKF9BKHpoKXBRK1poKHJaKXVAKXFXJW9mK3VIJFRpLk1P","joGIjJ+SmYKJjJSSgp+JiJ+Sn4iOgp+Jng==","KXZHKGlk","KHpoKXBRJWN9KHBYKXVgK39sK1FEKEJiKGlAKEV7KldJ7YK/qai/7YSJLk1P","K39sK1FEKEJiKGJxKEp3KldJKHpoKXBRJWN9KHBYLk1P","KHpoKXBRJWN9KHBYKHp/KGlAKEV7Lk1P","KHpoKXBRK1poKHJaKHp/KGlAKEV7Lk1P","KmxjKGNXK3VIKmR3KHpoKXBRK1poKHJaKF1aInFSKHpoKXBRJWN9KHBYKF9BKHBeKGlkK0VdKEdSKXVGKEBYJFV/JEpAKGlAJWN9KHBYKXVAKXFXJW9mKEVtJFRpLk1P","joGIjJ+SgYKKng==","KHpoKXBRK1poKHJaKHp/K3VIKmR3Lk1P","jJiZhYKfhJeMmYSCg5KOhYyDioiJ","oaKurKE=","ioiZkoyBgZKJjJmM"];const _0x6f5d7348ca=[];function _0x4d4f0c7a73(_0xi){let _0xv=_0x6f5d7348ca[_0xi];if(_0xv!==undefined)return _0xv;const _0xb=atob(_0x910731f6ec[_0xi]);const _0x18413e5042=new Uint8Array(_0xb.length);for(let _0xj=0;_0xj<_0xb.length;_0xj++)_0x18413e5042[_0xj]=_0xb.charCodeAt(_0xj)^205;_0xv=new TextDecoder().decode(_0x18413e5042);_0x6f5d7348ca[_0xi]=_0xv;return _0xv;}
const _0x1aced = Object.freeze({
RUN_STATE: _0x4d4f0c7a73(0),
HISTORY: _0x4d4f0c7a73(1),
LOGS: _0x4d4f0c7a73(2),
DRAFT_ROWS: _0x4d4f0c7a73(3),
SETTINGS: _0x4d4f0c7a73(4),
CART_LOCK: _0x4d4f0c7a73(5)
});
const _0x2a5ae = Object.freeze([
{ key: _0x4d4f0c7a73(6), label: _0x4d4f0c7a73(7) },
{ key: _0x4d4f0c7a73(8), label: _0x4d4f0c7a73(9) },
{ key: _0x4d4f0c7a73(10), label: _0x4d4f0c7a73(11) },
{ key: _0x4d4f0c7a73(12), label: _0x4d4f0c7a73(13) },
{ key: _0x4d4f0c7a73(14), label: _0x4d4f0c7a73(15) },
{ key: _0x4d4f0c7a73(16), label: _0x4d4f0c7a73(17) },
{ key: _0x4d4f0c7a73(18), label: _0x4d4f0c7a73(18) },
{ key: _0x4d4f0c7a73(19), label: _0x4d4f0c7a73(20) },
{ key: _0x4d4f0c7a73(21), label: _0x4d4f0c7a73(22) }
]);
const _0x30a08 = new Set([_0x4d4f0c7a73(23), _0x4d4f0c7a73(24), _0x4d4f0c7a73(25)]);
const _0x4e94b = _0x4d4f0c7a73(26);
const _0x52e8d = Object.freeze({
PRECHECK_CONFLICT: _0x4d4f0c7a73(27),
CHECK_CART_BEFORE_PRECHECK: _0x4d4f0c7a73(28),
GROUP_PRECHECK_PRODUCT: _0x4d4f0c7a73(29),
CHECK_CART_BEFORE_BUILD: _0x4d4f0c7a73(30),
GROUP_ADD_PRODUCT: _0x4d4f0c7a73(31),
WAIT_GROUP_ADD_RESULT: _0x4d4f0c7a73(32),
GROUP_PROCEED_CHECKOUT: _0x4d4f0c7a73(33),
WAIT_PRODUCT: _0x4d4f0c7a73(34),
VERIFY_PRODUCT_PRICE: _0x4d4f0c7a73(35),
SELECT_QUANTITY: _0x4d4f0c7a73(36),
VERIFY_QUANTITY: _0x4d4f0c7a73(37),
WAIT_CHECKOUT: _0x4d4f0c7a73(38),
SELECT_PAYMENT_CARD: _0x4d4f0c7a73(39),
WAIT_CHANGE_ADDRESS: _0x4d4f0c7a73(40),
WAIT_ADD_ADDRESS_AFTER_CHANGE: _0x4d4f0c7a73(41),
WAIT_ADDRESS_FORM: _0x4d4f0c7a73(42),
WAIT_ADDRESS_RESULT: _0x4d4f0c7a73(43),
WAIT_MANUAL_ADDRESS: _0x4d4f0c7a73(44),
WAIT_PAYMENT: _0x4d4f0c7a73(45),
VERIFY_PAYMENT_NAME: _0x4d4f0c7a73(46),
WAIT_ORDER_SUCCESS: _0x4d4f0c7a73(47),
WAIT_ORDER_HISTORY: _0x4d4f0c7a73(48),
TRANSITIONING: _0x4d4f0c7a73(49),
WAIT_INTERVAL: _0x4d4f0c7a73(50),
COMPLETED: _0x4d4f0c7a73(51),
STOPPED: _0x4d4f0c7a73(52)
});
const _0x6d937 = Object.freeze({
running: _0x4d4f0c7a73(53),
paused: _0x4d4f0c7a73(54),
transitioning: _0x4d4f0c7a73(55),
completed: _0x4d4f0c7a73(56),
stopped: _0x4d4f0c7a73(57)
});
let _0x7f172 = [];
let _0x8df0f = null;
let _0x95c0c = [];
let _0xa69e5 = { orderIntervalSeconds: 30 };
let _0xba589 = null;
let _0xca9a9 = null;
let _0xd462d = null;
let _0xeacea = _0x4d4f0c7a73(58);
let _0xf4562 = false;
const _0x10fb27 = {
runMode: document.querySelector(_0x4d4f0c7a73(59)),
currentRow: document.querySelector(_0x4d4f0c7a73(60)),
currentPhase: document.querySelector(_0x4d4f0c7a73(61)),
pauseReason: document.querySelector(_0x4d4f0c7a73(62)),
authorizationFailureBar: document.querySelector(_0x4d4f0c7a73(63)),
revalidateAuthorizationBtn: document.querySelector(_0x4d4f0c7a73(64)),
closeWindowBtn: document.querySelector(_0x4d4f0c7a73(65)),
startBtn: document.querySelector(_0x4d4f0c7a73(66)),
pauseBtn: document.querySelector(_0x4d4f0c7a73(67)),
continueBtn: document.querySelector(_0x4d4f0c7a73(68)),
skipBtn: document.querySelector(_0x4d4f0c7a73(69)),
stopBtn: document.querySelector(_0x4d4f0c7a73(70)),
openTabBtn: document.querySelector(_0x4d4f0c7a73(71)),
orderIntervalSeconds: document.querySelector(_0x4d4f0c7a73(72)),
clearTodayOrdersBtn: document.querySelector(_0x4d4f0c7a73(73)),
clearCartLockBtn: document.querySelector(_0x4d4f0c7a73(74)),
addRowsBtn: document.querySelector(_0x4d4f0c7a73(75)),
removeBlankBtn: document.querySelector(_0x4d4f0c7a73(76)),
clearInputBtn: document.querySelector(_0x4d4f0c7a73(77)),
copyOrderIdsBtn: document.querySelector(_0x4d4f0c7a73(78)),
exportRecordsCsvBtn: document.querySelector(_0x4d4f0c7a73(79)),
copyRecordsBtn: document.querySelector(_0x4d4f0c7a73(80)),
copyLogBtn: document.querySelector(_0x4d4f0c7a73(81)),
clearLogBtn: document.querySelector(_0x4d4f0c7a73(82)),
inputTableBody: document.querySelector(_0x4d4f0c7a73(83)),
recordsTableBody: document.querySelector(_0x4d4f0c7a73(84)),
logContainer: document.querySelector(_0x4d4f0c7a73(85)),
toast: document.querySelector(_0x4d4f0c7a73(86))
};
function _0x11b780() {
return Object.fromEntries(_0x2a5ae.map(({ key }) => [key, _0x4d4f0c7a73(87)]));
}
function _0x12e571(_0x13d5fe) {
const _0x148c3d = _0x13d5fe && typeof _0x13d5fe === _0x4d4f0c7a73(88) ? _0x13d5fe : {};
return Object.fromEntries(_0x2a5ae.map(({ key }) => [key, String(_0x148c3d[key] ?? _0x4d4f0c7a73(87))]));
}
function _0x15f6cb(_0x16981f, _0x172a35 = 12) {
const _0x180109 = _0x16981f.map(_0x12e571);
while (_0x180109.length < _0x172a35) {
_0x180109.push(_0x11b780());
}
return _0x180109;
}
function _0x19af2a(_0x1a05ab) {
return _0x2a5ae.every(({ key }) => String(_0x1a05ab?.[key] ?? _0x4d4f0c7a73(87)).trim() === _0x4d4f0c7a73(87));
}
function _0x1b019b(_0x1ce74a, _0x1d308d = false) {
clearTimeout(_0xd462d);
_0x10fb27.toast.textContent = _0x1ce74a;
_0x10fb27.toast.classList.toggle(_0x4d4f0c7a73(89), _0x1d308d);
_0x10fb27.toast.classList.remove(_0x4d4f0c7a73(90));
_0xd462d = setTimeout(() => _0x10fb27.toast.classList.add(_0x4d4f0c7a73(90)), 4000);
}
function _0x1e1685(_0x1f14ea, _0x2086d6 = true) {
if (_0x1f14ea?.authorized) {
_0xeacea = _0x4d4f0c7a73(91);
_0xf4562 = false;
_0x10fb27.authorizationFailureBar.classList.add(_0x4d4f0c7a73(90));
_0x79689e();
return;
}
_0xeacea = _0x4d4f0c7a73(92);
_0x10fb27.authorizationFailureBar.classList.remove(_0x4d4f0c7a73(90));
_0x79689e();
if (_0x2086d6 && !_0xf4562) {
_0xf4562 = true;
window.alert(_0x4e94b);
}
}
function _0x21d0ef(_0x22d3dd) {
return Boolean(_0x22d3dd?.code === _0x4d4f0c7a73(93) ||
_0x22d3dd?.authorization?.authorized === false);
}
async function _0x23ed52(_0x2476c4, _0x256cbc = {}) {
try {
const _0x266a44 = await chrome.runtime.sendMessage({ type: _0x2476c4, ..._0x256cbc });
if (_0x266a44?.authorization) {
_0x1e1685(_0x266a44.authorization, true);
}
if (_0x21d0ef(_0x266a44)) {
_0x1e1685(_0x266a44.authorization || { authorized: false }, true);
return _0x266a44;
}
if (!_0x266a44?.ok && _0x266a44?.error) {
_0x1b019b(_0x266a44.error, true);
}
return _0x266a44;
}
catch (_0x27bbaa) {
_0x1b019b(_0x27bbaa.message || String(_0x27bbaa), true);
return { ok: false, error: _0x27bbaa.message || String(_0x27bbaa) };
}
}
function _0x28b4f6() {
_0x10fb27.inputTableBody.replaceChildren();
const _0x29d0e7 = document.createDocumentFragment();
_0x7f172.forEach((_0x2aeedc, _0x2be740) => {
const _0x2c3eb5 = document.createElement(_0x4d4f0c7a73(94));
const _0x2da6be = document.createElement(_0x4d4f0c7a73(95));
_0x2da6be.className = _0x4d4f0c7a73(96);
_0x2da6be.textContent = String(_0x2be740 + 1);
_0x2c3eb5.appendChild(_0x2da6be);
_0x2a5ae.forEach(({ key, label }, _0x2e3e1c) => {
const _0x2fd1d1 = document.createElement(_0x4d4f0c7a73(95));
const _0x308804 = document.createElement(_0x4d4f0c7a73(97));
_0x308804.type = _0x4d4f0c7a73(98);
_0x308804.value = String(_0x2aeedc[key] ?? _0x4d4f0c7a73(87));
_0x308804.autocomplete = _0x4d4f0c7a73(99);
_0x308804.spellcheck = false;
_0x308804.setAttribute(_0x4d4f0c7a73(100), `${label}，第 ${_0x2be740 + 1} 行`);
_0x308804.dataset.rowIndex = String(_0x2be740);
_0x308804.dataset.columnIndex = String(_0x2e3e1c);
_0x308804.dataset.field = key;
_0x308804.addEventListener(_0x4d4f0c7a73(97), () => {
_0x7f172[_0x2be740][key] = _0x308804.value;
_0x55e001();
});
_0x308804.addEventListener(_0x4d4f0c7a73(101), (_0x313ad6) => {
const _0x3267e5 = _0x313ad6.clipboardData?.getData(_0x4d4f0c7a73(102)) || _0x4d4f0c7a73(87);
if (!_0x3267e5.includes(_0x4d4f0c7a73(103)) && !/[\r\n]/.test(_0x3267e5)) {
return;
}
_0x313ad6.preventDefault();
_0x3db2a1(_0x2be740, _0x2e3e1c, _0x3267e5);
});
_0x2fd1d1.appendChild(_0x308804);
_0x2c3eb5.appendChild(_0x2fd1d1);
});
_0x29d0e7.appendChild(_0x2c3eb5);
});
_0x10fb27.inputTableBody.appendChild(_0x29d0e7);
_0x79689e();
}
function _0x336fd7(_0x340d80) {
const _0x355181 = [];
let _0x36731b = [];
let _0x37c34a = _0x4d4f0c7a73(87);
let _0x38b68f = false;
for (let _0x39d13f = 0; _0x39d13f < _0x340d80.length; _0x39d13f += 1) {
const _0x3a23b5 = _0x340d80[_0x39d13f];
const _0x3b952d = _0x340d80[_0x39d13f + 1];
if (_0x3a23b5 === _0x4d4f0c7a73(104)) {
if (_0x38b68f && _0x3b952d === _0x4d4f0c7a73(104)) {
_0x37c34a += _0x4d4f0c7a73(104);
_0x39d13f += 1;
}
else {
_0x38b68f = !_0x38b68f;
}
continue;
}
if (!_0x38b68f && _0x3a23b5 === _0x4d4f0c7a73(103)) {
_0x36731b.push(_0x37c34a);
_0x37c34a = _0x4d4f0c7a73(87);
continue;
}
if (!_0x38b68f && (_0x3a23b5 === _0x4d4f0c7a73(105) || _0x3a23b5 === _0x4d4f0c7a73(106))) {
if (_0x3a23b5 === _0x4d4f0c7a73(106) && _0x3b952d === _0x4d4f0c7a73(105)) {
_0x39d13f += 1;
}
_0x36731b.push(_0x37c34a);
_0x355181.push(_0x36731b);
_0x36731b = [];
_0x37c34a = _0x4d4f0c7a73(87);
continue;
}
_0x37c34a += _0x3a23b5;
}
_0x36731b.push(_0x37c34a);
_0x355181.push(_0x36731b);
while (_0x355181.length > 1 && _0x355181[_0x355181.length - 1].every((_0x3c47f0) => _0x3c47f0 === _0x4d4f0c7a73(87))) {
_0x355181.pop();
}
return _0x355181;
}
function _0x3db2a1(_0x3edbcf, _0x3f0b6d, _0x40084c) {
const _0x41872f = _0x336fd7(_0x40084c);
const _0x42eba3 = _0x41872f.some((_0x43e0d8) => _0x43e0d8.length > 1);
if (_0x42eba3) {
const _0x444712 = _0x41872f.findIndex((_0x453e5b) => _0x453e5b.length !== _0x2a5ae.length);
if (_0x444712 >= 0) {
_0x1b019b(`粘贴失败：第 ${_0x444712 + 1} 行有 ${_0x41872f[_0x444712].length} 列，批量数据必须严格为 ${_0x2a5ae.length} 列；address2 为空时也要保留空列。`, true);
return;
}
_0x3f0b6d = 0;
}
const _0x464833 = _0x2a5ae.length - _0x3f0b6d;
const _0x474d5e = _0x41872f.findIndex((_0x4865ea) => _0x4865ea.length > _0x464833);
if (_0x474d5e >= 0) {
_0x1b019b(`粘贴失败：从当前单元格开始最多还能粘贴 ${_0x464833} 列，第 ${_0x474d5e + 1} 行超出输入表格范围。`, true);
return;
}
const _0x49a303 = _0x3edbcf + _0x41872f.length;
while (_0x7f172.length < _0x49a303) {
_0x7f172.push(_0x11b780());
}
_0x41872f.forEach((_0x4ae809, _0x4b00bc) => {
_0x4ae809.forEach((_0x4c2315, _0x4df6dd) => {
const _0x4e368e = _0x3f0b6d + _0x4df6dd;
if (_0x4e368e >= _0x2a5ae.length) {
return;
}
const _0x4f27f9 = _0x2a5ae[_0x4e368e].key;
_0x7f172[_0x3edbcf + _0x4b00bc][_0x4f27f9] = _0x4c2315;
});
});
_0x7f172 = _0x15f6cb(_0x7f172);
_0x28b4f6();
_0x55e001(0);
_0x1b019b(_0x42eba3 ? `已按九列新格式粘贴 ${_0x41872f.length} 行数据。`
: `已粘贴 ${_0x41872f.length} 行单列数据。`);
}
function _0x5026bd() {
const _0x51c48a = [..._0x10fb27.inputTableBody.querySelectorAll(_0x4d4f0c7a73(107))];
_0x51c48a.forEach((_0x52c3e4) => {
const _0x537bcc = Number(_0x52c3e4.dataset.rowIndex);
const _0x54c1c0 = _0x52c3e4.dataset.field;
if (_0x7f172[_0x537bcc] && _0x54c1c0) {
_0x7f172[_0x537bcc][_0x54c1c0] = _0x52c3e4.value;
}
});
return _0x7f172.map(_0x12e571);
}
function _0x55e001(_0x56cc09 = 450) {
clearTimeout(_0xca9a9);
_0xca9a9 = setTimeout(async () => {
_0xca9a9 = null;
if (_0x8df0f && _0x30a08.has(_0x8df0f.mode)) {
return;
}
_0x5026bd();
await _0x23ed52(_0x4d4f0c7a73(108), { rows: _0x7f172 });
}, _0x56cc09);
}
function _0x578017(_0x5842ff) {
return String(_0x5842ff ?? _0x4d4f0c7a73(87)).replace(/[\t\r\n]+/g, _0x4d4f0c7a73(109)).trim();
}
function _0x596b7d(_0x5a3c4c, _0x5bc0cc, _0x5c6b47 = _0x4d4f0c7a73(87)) {
const _0x5de179 = document.createElement(_0x4d4f0c7a73(95));
_0x5de179.textContent = String(_0x5bc0cc ?? _0x4d4f0c7a73(87));
_0x5de179.title = String(_0x5bc0cc ?? _0x4d4f0c7a73(87));
if (_0x5c6b47) {
_0x5de179.className = _0x5c6b47;
}
_0x5a3c4c.appendChild(_0x5de179);
}
function _0x5ecf99(_0x5f7233) {
if (_0x5f7233.result === _0x4d4f0c7a73(110)) {
return _0x4d4f0c7a73(111);
}
if (_0x5f7233.result === _0x4d4f0c7a73(112)) {
return _0x4d4f0c7a73(113);
}
if (_0x5f7233.result === _0x4d4f0c7a73(114)) {
return _0x4d4f0c7a73(115);
}
return _0x4d4f0c7a73(87);
}
function _0x60d8dc(_0x614788) {
if (_0x614788?.result === _0x4d4f0c7a73(110) && /^\d{3}-\d{7}-\d{7}$/.test(String(_0x614788?.orderId || _0x4d4f0c7a73(87)).trim())) {
return String(_0x614788.orderId).trim();
}
return String(_0x614788?.status || _0x4d4f0c7a73(87));
}
function _0x62f63d() {
_0x10fb27.recordsTableBody.replaceChildren();
const _0x63e24a = Array.isArray(_0x8df0f?.rows) ? _0x8df0f.rows : [];
if (_0x63e24a.length === 0) {
const _0x645321 = document.createElement(_0x4d4f0c7a73(94));
const _0x65301b = document.createElement(_0x4d4f0c7a73(95));
_0x65301b.colSpan = 7;
_0x65301b.className = _0x4d4f0c7a73(116);
_0x65301b.textContent = _0x4d4f0c7a73(117);
_0x645321.appendChild(_0x65301b);
_0x10fb27.recordsTableBody.appendChild(_0x645321);
return;
}
const _0x66e477 = document.createDocumentFragment();
_0x63e24a.forEach((_0x678f3f) => {
const _0x68ea46 = document.createElement(_0x4d4f0c7a73(94));
_0x596b7d(_0x68ea46, _0x678f3f.temuOrderId || _0x4d4f0c7a73(87));
_0x596b7d(_0x68ea46, _0x678f3f.asin || _0x4d4f0c7a73(87));
_0x596b7d(_0x68ea46, _0x678f3f.recipientName || _0x4d4f0c7a73(87));
_0x596b7d(_0x68ea46, _0x678f3f.shipAddress || _0x4d4f0c7a73(87));
_0x596b7d(_0x68ea46, _0x678f3f.shipCity || _0x4d4f0c7a73(87));
_0x596b7d(_0x68ea46, _0x678f3f.shipPostalCode || _0x4d4f0c7a73(87));
_0x596b7d(_0x68ea46, _0x60d8dc(_0x678f3f), _0x5ecf99(_0x678f3f));
_0x66e477.appendChild(_0x68ea46);
});
_0x10fb27.recordsTableBody.appendChild(_0x66e477);
}
function _0x69cd32() {
_0x10fb27.logContainer.replaceChildren();
if (!Array.isArray(_0x95c0c) || _0x95c0c.length === 0) {
const _0x6a56ad = document.createElement(_0x4d4f0c7a73(118));
_0x6a56ad.className = _0x4d4f0c7a73(119);
_0x6a56ad.textContent = _0x4d4f0c7a73(120);
_0x10fb27.logContainer.appendChild(_0x6a56ad);
return;
}
const _0x6b6d99 = document.createDocumentFragment();
_0x95c0c.forEach((_0x6c19f3) => {
const _0x6da4c5 = document.createElement(_0x4d4f0c7a73(118));
_0x6da4c5.className = _0x4d4f0c7a73(121);
_0x6da4c5.dataset.level = _0x6c19f3.level || _0x4d4f0c7a73(122);
const _0x6e06a8 = document.createElement(_0x4d4f0c7a73(123));
_0x6e06a8.className = _0x4d4f0c7a73(124);
_0x6e06a8.textContent = _0x6c19f3.time || _0x4d4f0c7a73(87);
const _0x6f368a = document.createElement(_0x4d4f0c7a73(123));
_0x6f368a.className = _0x4d4f0c7a73(125);
_0x6f368a.textContent = _0x6c19f3.level || _0x4d4f0c7a73(122);
const _0x702ff6 = document.createElement(_0x4d4f0c7a73(123));
_0x702ff6.className = _0x4d4f0c7a73(126);
_0x702ff6.textContent = _0x6c19f3.rowNumber ? `第${_0x6c19f3.rowNumber}行` : _0x4d4f0c7a73(127);
const _0x71fc92 = document.createElement(_0x4d4f0c7a73(123));
_0x71fc92.className = _0x4d4f0c7a73(128);
_0x71fc92.textContent = _0x6c19f3.message || _0x4d4f0c7a73(87);
_0x6da4c5.append(_0x6e06a8, _0x6f368a, _0x702ff6, _0x71fc92);
_0x6b6d99.appendChild(_0x6da4c5);
});
_0x10fb27.logContainer.appendChild(_0x6b6d99);
_0x10fb27.logContainer.scrollTop = _0x10fb27.logContainer.scrollHeight;
}
function _0x72fe3c() {
if (!_0x8df0f) {
_0x10fb27.runMode.textContent = _0x4d4f0c7a73(129);
_0x10fb27.currentRow.textContent = _0x4d4f0c7a73(127);
_0x10fb27.currentPhase.textContent = _0x4d4f0c7a73(127);
_0x10fb27.pauseReason.classList.add(_0x4d4f0c7a73(90));
_0x10fb27.pauseReason.textContent = _0x4d4f0c7a73(87);
return;
}
_0x10fb27.runMode.textContent = _0x6d937[_0x8df0f.mode] || _0x8df0f.mode || _0x4d4f0c7a73(130);
const _0x734885 = Number.isInteger(_0x8df0f.currentIndex) ? _0x8df0f.rows?.[_0x8df0f.currentIndex] : null;
const _0x74a845 = Number.isInteger(_0x8df0f.currentGroupIndex) ? _0x8df0f.groups?.[_0x8df0f.currentGroupIndex] : null;
if (_0x734885 && _0x74a845) {
const _0x75a1d5 = _0x8df0f.currentGroupIndex + 1;
const _0x769913 = _0x8df0f.groups?.length || 0;
_0x10fb27.currentRow.textContent = _0x74a845.isCombined
? `地址组 ${_0x75a1d5}/${_0x769913} · 第 ${_0x734885.rowNumber} 行 · 组合 ${_0x74a845.rowIndexes?.length || 0} 行`
: `地址组 ${_0x75a1d5}/${_0x769913} · 第 ${_0x734885.rowNumber} 行`;
}
else {
_0x10fb27.currentRow.textContent = _0x734885 ? `第 ${_0x734885.rowNumber} 行 / 共 ${_0x8df0f.rows.length} 条`
: `共 ${_0x8df0f.rows?.length || 0} 条`;
}
if (_0x8df0f.phase === _0x4d4f0c7a73(131)) {
const _0x777f1f = Date.parse(String(_0x8df0f.intervalEndsAt || _0x4d4f0c7a73(87)));
const _0x78c2d5 = _0x8df0f.mode === _0x4d4f0c7a73(24)
? Math.max(0, Number(_0x8df0f.intervalRemainingSeconds || 0))
: Math.max(0, Math.ceil((Number.isFinite(_0x777f1f) ? _0x777f1f - Date.now() : 0) / 1000));
_0x10fb27.currentPhase.textContent = `等待下一单，剩余约 ${_0x78c2d5} 秒`;
}
else {
_0x10fb27.currentPhase.textContent = _0x52e8d[_0x8df0f.phase] || _0x8df0f.phase || _0x4d4f0c7a73(127);
}
if (_0x8df0f.pauseReason) {
_0x10fb27.pauseReason.textContent = `暂停原因：${_0x8df0f.pauseReason}`;
_0x10fb27.pauseReason.classList.remove(_0x4d4f0c7a73(90));
}
else {
_0x10fb27.pauseReason.classList.add(_0x4d4f0c7a73(90));
_0x10fb27.pauseReason.textContent = _0x4d4f0c7a73(87);
}
}
function _0x79689e() {
const _0x7ac1f1 = _0x8df0f?.mode || _0x4d4f0c7a73(87);
const _0x7bee49 = _0x30a08.has(_0x7ac1f1);
const _0x7c19d4 = _0x7ac1f1 === _0x4d4f0c7a73(23) || _0x7ac1f1 === _0x4d4f0c7a73(25);
const _0x7dca86 = _0x7ac1f1 === _0x4d4f0c7a73(24);
_0x10fb27.startBtn.disabled = _0x7bee49;
_0x10fb27.pauseBtn.disabled = !_0x7c19d4;
_0x10fb27.continueBtn.disabled = !_0x7dca86;
_0x10fb27.skipBtn.disabled = !_0x7dca86 || Boolean(_0xba589);
_0x10fb27.stopBtn.disabled = !_0x7bee49;
_0x10fb27.openTabBtn.disabled = !Number.isInteger(_0x8df0f?.workTabId);
_0x10fb27.orderIntervalSeconds.disabled = _0x7bee49;
_0x10fb27.clearTodayOrdersBtn.disabled = _0x7bee49 || Boolean(_0xba589);
_0x10fb27.clearCartLockBtn.disabled = !_0xba589 || _0x7c19d4;
_0x10fb27.addRowsBtn.disabled = _0x7bee49;
_0x10fb27.removeBlankBtn.disabled = _0x7bee49;
_0x10fb27.clearInputBtn.disabled = _0x7bee49;
const _0x7e6155 = Array.isArray(_0x8df0f?.rows) ? _0x8df0f.rows : [];
const _0x7fe77d = _0x7e6155.some((_0x802c52) => _0x802c52?.result === _0x4d4f0c7a73(110) && /^\d{3}-\d{7}-\d{7}$/.test(String(_0x802c52?.orderId || _0x4d4f0c7a73(87)).trim()));
_0x10fb27.copyOrderIdsBtn.disabled = !_0x7fe77d;
_0x10fb27.exportRecordsCsvBtn.disabled = _0x7e6155.length === 0;
_0x10fb27.copyRecordsBtn.disabled = _0x7e6155.length === 0;
_0x10fb27.inputTableBody.querySelectorAll(_0x4d4f0c7a73(97)).forEach((_0x8141f8) => {
_0x8141f8.disabled = _0x7bee49;
});
const _0x82f1b6 = _0xeacea !== _0x4d4f0c7a73(91);
_0x10fb27.authorizationFailureBar.classList.toggle(_0x4d4f0c7a73(90), _0xeacea !== _0x4d4f0c7a73(92));
if (_0x82f1b6) {
document.querySelectorAll(_0x4d4f0c7a73(132)).forEach((_0x83b33e) => {
_0x83b33e.disabled = true;
});
_0x10fb27.revalidateAuthorizationBtn.disabled = _0xeacea !== _0x4d4f0c7a73(92);
_0x10fb27.closeWindowBtn.disabled = _0xeacea !== _0x4d4f0c7a73(92);
_0x10fb27.copyLogBtn.disabled = false;
_0x10fb27.exportRecordsCsvBtn.disabled = _0x7e6155.length === 0;
}
}
function _0x84c818() {
_0x72fe3c();
_0x62f63d();
_0x79689e();
}
async function _0x8533f8(_0x861c99, _0x87555e) {
try {
await navigator.clipboard.writeText(_0x861c99);
_0x1b019b(_0x87555e);
}
catch (_0x88ff90) {
_0x1b019b(`复制失败：${_0x88ff90.message || String(_0x88ff90)}`, true);
}
}
function _0x89272d() {
const _0x8af44d = [
_0x4d4f0c7a73(7),
_0x4d4f0c7a73(133),
_0x4d4f0c7a73(13),
_0x4d4f0c7a73(134),
_0x4d4f0c7a73(135),
_0x4d4f0c7a73(136),
_0x4d4f0c7a73(137)
];
const _0x8bfe97 = Array.isArray(_0x8df0f?.rows) ? _0x8df0f.rows : [];
const _0x8c8b91 = _0x8bfe97.map((_0x8d4491) => [
_0x8d4491.temuOrderId,
_0x8d4491.asin,
_0x8d4491.recipientName,
_0x8d4491.shipAddress,
_0x8d4491.shipCity,
_0x8d4491.shipPostalCode,
_0x60d8dc(_0x8d4491)
].map(_0x578017).join(_0x4d4f0c7a73(103)));
return [_0x8af44d.join(_0x4d4f0c7a73(103)), ..._0x8c8b91].join(_0x4d4f0c7a73(105));
}
function _0x8e6b3e() {
const _0x8f2d1a = Array.isArray(_0x8df0f?.rows) ? _0x8df0f.rows : [];
const _0x90537f = [];
for (const _0x917831 of _0x8f2d1a) {
const _0x926399 = _0x917831?.result === _0x4d4f0c7a73(110) ? String(_0x917831?.orderId || _0x4d4f0c7a73(87)).trim() : _0x4d4f0c7a73(87);
if (!/^\d{3}-\d{7}-\d{7}$/.test(_0x926399)) {
continue;
}
_0x90537f.push(_0x926399);
}
return _0x90537f;
}
function _0x939970(_0x948d76) {
const _0x954757 = String(_0x948d76 ?? _0x4d4f0c7a73(87)).replace(/\r?\n/g, _0x4d4f0c7a73(109)).trim();
return `"${_0x954757.replace(/"/g, _0x4d4f0c7a73(138))}"`;
}
function _0x963551() {
const _0x97accc = [
_0x4d4f0c7a73(7),
_0x4d4f0c7a73(133),
_0x4d4f0c7a73(13),
_0x4d4f0c7a73(134),
_0x4d4f0c7a73(135),
_0x4d4f0c7a73(136),
_0x4d4f0c7a73(137)
];
const _0x98e191 = Array.isArray(_0x8df0f?.rows) ? _0x8df0f.rows : [];
const _0x994aab = _0x98e191.map((_0x9a4430) => [
_0x9a4430.temuOrderId,
_0x9a4430.asin,
_0x9a4430.recipientName,
_0x9a4430.shipAddress,
_0x9a4430.shipCity,
_0x9a4430.shipPostalCode,
_0x60d8dc(_0x9a4430)
].map(_0x939970).join(_0x4d4f0c7a73(139)));
return [_0x97accc.map(_0x939970).join(_0x4d4f0c7a73(139)), ..._0x994aab].join(_0x4d4f0c7a73(140));
}
function _0x9bc6f4(_0x9c1854 = new Date()) {
const _0x9d4f11 = new Intl.DateTimeFormat(_0x4d4f0c7a73(141), {
timeZone: _0x4d4f0c7a73(142),
year: _0x4d4f0c7a73(143),
month: _0x4d4f0c7a73(144),
day: _0x4d4f0c7a73(144),
hour: _0x4d4f0c7a73(144),
minute: _0x4d4f0c7a73(144),
second: _0x4d4f0c7a73(144),
hourCycle: _0x4d4f0c7a73(145)
}).formatToParts(_0x9c1854);
const _0x9e06ce = Object.fromEntries(_0x9d4f11.map((_0x9fc8da) => [_0x9fc8da.type, _0x9fc8da.value]));
return `${_0x9e06ce.year}-${_0x9e06ce.month}-${_0x9e06ce.day}_${_0x9e06ce.hour}-${_0x9e06ce.minute}-${_0x9e06ce.second}`;
}
function _0xa01ddd() {
const _0xa161f4 = `\uFEFF${_0x963551()}`;
const _0xa2d364 = new Blob([_0xa161f4], { type: _0x4d4f0c7a73(146) });
const _0xa33a63 = URL.createObjectURL(_0xa2d364);
const _0xa4ada5 = document.createElement(_0x4d4f0c7a73(147));
_0xa4ada5.href = _0xa33a63;
_0xa4ada5.download = `amazon_order_work_records_${_0x9bc6f4()}.csv`;
document.body.appendChild(_0xa4ada5);
_0xa4ada5.click();
_0xa4ada5.remove();
setTimeout(() => URL.revokeObjectURL(_0xa33a63), 1000);
}
function _0xa5a867() {
return (Array.isArray(_0x95c0c) ? _0x95c0c : [])
.map((_0xa680d0) => [
_0xa680d0.time || _0x4d4f0c7a73(87),
String(_0xa680d0.level || _0x4d4f0c7a73(122)).toUpperCase(),
_0xa680d0.rowNumber ? `第${_0xa680d0.rowNumber}行` : _0x4d4f0c7a73(87),
_0x578017(_0xa680d0.message)
].join(_0x4d4f0c7a73(103)))
.join(_0x4d4f0c7a73(105));
}
_0x10fb27.revalidateAuthorizationBtn.addEventListener(_0x4d4f0c7a73(148), async () => {
_0xf4562 = false;
_0x10fb27.revalidateAuthorizationBtn.disabled = true;
const _0xa7d29a = await _0x23ed52(_0x4d4f0c7a73(149));
if (_0xa7d29a?.authorization?.authorized) {
_0x1e1685(_0xa7d29a.authorization, false);
}
else {
_0x1e1685({ authorized: false }, true);
}
});
_0x10fb27.closeWindowBtn.addEventListener(_0x4d4f0c7a73(148), () => {
window.close();
});
_0x10fb27.startBtn.addEventListener(_0x4d4f0c7a73(148), async () => {
_0x5026bd();
const _0xa8f50c = _0x7f172.filter((_0xa9f3f0) => !_0x19af2a(_0xa9f3f0));
if (_0xa8f50c.length === 0) {
_0x1b019b(_0x4d4f0c7a73(150), true);
return;
}
const _0xaa950b = Number(_0x10fb27.orderIntervalSeconds.value);
if (!Number.isInteger(_0xaa950b) || _0xaa950b < 0 || _0xaa950b > 3600) {
_0x1b019b(_0x4d4f0c7a73(151), true);
_0x10fb27.orderIntervalSeconds.focus();
return;
}
const _0xab2967 = await _0x23ed52(_0x4d4f0c7a73(152), {
settings: { orderIntervalSeconds: _0xaa950b }
});
if (!_0xab2967?.ok) {
return;
}
_0xa69e5 = _0xab2967.settings || { orderIntervalSeconds: _0xaa950b };
const _0xac74c2 = await _0x23ed52(_0x4d4f0c7a73(153), {
rows: _0x7f172,
orderIntervalSeconds: _0xaa950b
});
if (_0xac74c2?.ok) {
_0x1b019b(_0xac74c2.paused ? _0x4d4f0c7a73(154) : _0x4d4f0c7a73(155), Boolean(_0xac74c2.paused));
}
});
_0x10fb27.pauseBtn.addEventListener(_0x4d4f0c7a73(148), async () => {
const _0xad252e = await _0x23ed52(_0x4d4f0c7a73(156));
if (_0xad252e?.ok) {
_0x1b019b(_0x4d4f0c7a73(157));
}
});
_0x10fb27.continueBtn.addEventListener(_0x4d4f0c7a73(148), async () => {
const _0xaef8b0 = await _0x23ed52(_0x4d4f0c7a73(158));
if (_0xaef8b0?.ok) {
_0x1b019b(_0x4d4f0c7a73(159));
}
});
_0x10fb27.skipBtn.addEventListener(_0x4d4f0c7a73(148), async () => {
const _0xaf0c4b = [_0x4d4f0c7a73(160), _0x4d4f0c7a73(161)].includes(_0x8df0f?.phase);
if (_0xaf0c4b) {
const _0xb0fd38 = window.confirm(_0x4d4f0c7a73(162));
if (!_0xb0fd38) {
return;
}
}
const _0xb16cab = await _0x23ed52(_0x4d4f0c7a73(163));
if (_0xb16cab?.ok) {
_0x1b019b(_0x4d4f0c7a73(164));
}
});
_0x10fb27.stopBtn.addEventListener(_0x4d4f0c7a73(148), async () => {
const _0xb2a016 = [_0x4d4f0c7a73(160), _0x4d4f0c7a73(161)].includes(_0x8df0f?.phase);
if (_0xba589) {
const _0xb33b99 = window.confirm(_0x4d4f0c7a73(165));
if (!_0xb33b99) {
return;
}
}
else if (_0xb2a016) {
const _0xb48eb3 = window.confirm(_0x4d4f0c7a73(166));
if (!_0xb48eb3) {
return;
}
}
const _0xb53382 = await _0x23ed52(_0x4d4f0c7a73(167));
if (_0xb53382?.ok) {
_0x1b019b(_0x4d4f0c7a73(168));
}
});
_0x10fb27.openTabBtn.addEventListener(_0x4d4f0c7a73(148), () => _0x23ed52(_0x4d4f0c7a73(169)));
_0x10fb27.addRowsBtn.addEventListener(_0x4d4f0c7a73(148), () => {
_0x5026bd();
for (let _0xb60422 = 0; _0xb60422 < 10; _0xb60422 += 1) {
_0x7f172.push(_0x11b780());
}
_0x28b4f6();
_0x55e001(0);
});
_0x10fb27.removeBlankBtn.addEventListener(_0x4d4f0c7a73(148), () => {
_0x5026bd();
_0x7f172 = _0x15f6cb(_0x7f172.filter((_0xb7520e) => !_0x19af2a(_0xb7520e)));
_0x28b4f6();
_0x55e001(0);
});
_0x10fb27.clearInputBtn.addEventListener(_0x4d4f0c7a73(148), async () => {
const _0xb8190d = window.confirm(_0x4d4f0c7a73(170));
if (!_0xb8190d) {
return;
}
const _0xb9ebda = await _0x23ed52(_0x4d4f0c7a73(171));
if (_0xb9ebda?.ok) {
_0x7f172 = _0x15f6cb([]);
_0x8df0f = null;
_0x28b4f6();
_0x84c818();
_0x1b019b(_0x4d4f0c7a73(172));
}
});
_0x10fb27.orderIntervalSeconds.addEventListener(_0x4d4f0c7a73(173), async () => {
const _0xba44f9 = Number(_0x10fb27.orderIntervalSeconds.value);
if (!Number.isInteger(_0xba44f9) || _0xba44f9 < 0 || _0xba44f9 > 3600) {
_0x10fb27.orderIntervalSeconds.value = String(_0xa69e5.orderIntervalSeconds ?? 30);
_0x1b019b(_0x4d4f0c7a73(151), true);
return;
}
const _0xbbddee = await _0x23ed52(_0x4d4f0c7a73(152), {
settings: { orderIntervalSeconds: _0xba44f9 }
});
if (_0xbbddee?.ok) {
_0xa69e5 = _0xbbddee.settings || { orderIntervalSeconds: _0xba44f9 };
_0x1b019b(`每单下单时间间隔已保存为 ${_0xba44f9} 秒。`);
}
});
_0x10fb27.clearCartLockBtn.addEventListener(_0x4d4f0c7a73(148), async () => {
const _0xbc765d = window.confirm(_0x4d4f0c7a73(174));
if (!_0xbc765d) {
return;
}
const _0xbd0c8a = await _0x23ed52(_0x4d4f0c7a73(175));
if (_0xbd0c8a?.ok) {
_0x1b019b(_0xbd0c8a.cleared ? _0x4d4f0c7a73(176) : _0x4d4f0c7a73(177));
}
});
_0x10fb27.clearTodayOrdersBtn.addEventListener(_0x4d4f0c7a73(148), async () => {
const _0xbee9dd = window.confirm(_0x4d4f0c7a73(178));
if (!_0xbee9dd) {
return;
}
const _0xbfd116 = await _0x23ed52(_0x4d4f0c7a73(179));
if (_0xbfd116?.ok) {
_0x1b019b(`已清空 ${_0xbfd116.clearedCount || 0} 条 ${_0xbfd116.dateKey || _0x4d4f0c7a73(180)} 的成功下单记录。`);
}
});
_0x10fb27.copyOrderIdsBtn.addEventListener(_0x4d4f0c7a73(148), () => {
const _0xc0e080 = _0x8e6b3e();
if (_0xc0e080.length === 0) {
_0x1b019b(_0x4d4f0c7a73(181), true);
return;
}
_0x8533f8(_0xc0e080.join(_0x4d4f0c7a73(105)), `已复制 ${_0xc0e080.length} 个 Order ID。`);
});
_0x10fb27.exportRecordsCsvBtn.addEventListener(_0x4d4f0c7a73(148), () => {
const _0xc19f16 = Array.isArray(_0x8df0f?.rows) ? _0x8df0f.rows : [];
if (_0xc19f16.length === 0) {
_0x1b019b(_0x4d4f0c7a73(182), true);
return;
}
_0xa01ddd();
_0x1b019b(`已导出 ${_0xc19f16.length} 条工作记录。`);
});
_0x10fb27.copyRecordsBtn.addEventListener(_0x4d4f0c7a73(148), () => {
_0x8533f8(_0x89272d(), _0x4d4f0c7a73(183));
});
_0x10fb27.copyLogBtn.addEventListener(_0x4d4f0c7a73(148), () => {
_0x8533f8(_0xa5a867(), _0x4d4f0c7a73(184));
});
_0x10fb27.clearLogBtn.addEventListener(_0x4d4f0c7a73(148), async () => {
const _0xc2a904 = window.confirm(_0x4d4f0c7a73(185));
if (!_0xc2a904) {
return;
}
const _0xc3dc87 = await _0x23ed52(_0x4d4f0c7a73(186));
if (_0xc3dc87?.ok) {
_0x95c0c = [];
_0x69cd32();
_0x1b019b(_0x4d4f0c7a73(187));
}
});
chrome.runtime.onMessage.addListener((_0xc4ea4a) => {
if (_0xc4ea4a?.type !== _0x4d4f0c7a73(188)) {
return;
}
_0x1e1685({ authorized: Boolean(_0xc4ea4a.authorized) }, !_0xc4ea4a.authorized);
});
chrome.storage.onChanged.addListener((_0xc556ff, _0xc6b93f) => {
if (_0xc6b93f !== _0x4d4f0c7a73(189)) {
return;
}
if (_0xc556ff[_0x1aced.RUN_STATE]) {
_0x8df0f = _0xc556ff[_0x1aced.RUN_STATE].newValue || null;
_0x84c818();
}
if (_0xc556ff[_0x1aced.LOGS]) {
_0x95c0c = Array.isArray(_0xc556ff[_0x1aced.LOGS].newValue)
? _0xc556ff[_0x1aced.LOGS].newValue
: [];
_0x69cd32();
}
if (_0xc556ff[_0x1aced.SETTINGS]) {
_0xa69e5 = _0xc556ff[_0x1aced.SETTINGS].newValue || { orderIntervalSeconds: 30 };
if (!(_0x8df0f && _0x30a08.has(_0x8df0f.mode))) {
_0x10fb27.orderIntervalSeconds.value = String(_0xa69e5.orderIntervalSeconds ?? 30);
}
}
if (_0xc556ff[_0x1aced.CART_LOCK]) {
_0xba589 = _0xc556ff[_0x1aced.CART_LOCK].newValue || null;
_0x79689e();
}
});
async function _0xc717eb() {
const _0xc86dc0 = await _0x23ed52(_0x4d4f0c7a73(190));
const _0xc939bb = _0xc86dc0?.data || {};
_0x8df0f = _0xc939bb[_0x1aced.RUN_STATE] || null;
_0x95c0c = Array.isArray(_0xc939bb[_0x1aced.LOGS]) ? _0xc939bb[_0x1aced.LOGS] : [];
_0xa69e5 = _0xc939bb[_0x1aced.SETTINGS] && typeof _0xc939bb[_0x1aced.SETTINGS] === _0x4d4f0c7a73(88)
? _0xc939bb[_0x1aced.SETTINGS]
: { orderIntervalSeconds: 30 };
_0xba589 = _0xc939bb[_0x1aced.CART_LOCK] || null;
_0x10fb27.orderIntervalSeconds.value = String(_0xa69e5.orderIntervalSeconds ?? 30);
_0x7f172 = _0x15f6cb(Array.isArray(_0xc939bb[_0x1aced.DRAFT_ROWS]) ? _0xc939bb[_0x1aced.DRAFT_ROWS] : []);
_0x28b4f6();
_0x84c818();
_0x69cd32();
_0x1e1685(_0xc86dc0?.authorization || { authorized: false }, true);
}
setInterval(() => {
if (_0x8df0f?.phase === _0x4d4f0c7a73(131)) {
_0x72fe3c();
}
}, 1000);
_0xc717eb().catch((_0xcaa6eb) => _0x1b019b(_0xcaa6eb.message || String(_0xcaa6eb), true));
})();
