const source = document.querySelector('#source');
const result = document.querySelector('#result');
const status = document.querySelector('#status');
const parsedInputs = Object.fromEntries(
  ['contact', 'address', 'city', 'postcode'].map((name) => [name, document.querySelector(`#${name}`)])
);

const labels = {
  contact: ['contact', 'consignee', 'recipient', 'name', '联系人', '收件人', '姓名'],
  address: ['address', 'street', 'street address', '地址', '街道'],
  city: ['city', 'town', 'locality', '城市'],
  postcode: ['postcode', 'postal code', 'zip code', 'zip', '邮编', '邮政编码']
};

function clean(value) {
  return value.replace(/^[\s:：,-]+|[\s,;]+$/g, '').trim();
}

function valueAfterLabel(line, field) {
  const escaped = labels[field].map((label) => label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
  const match = line.match(new RegExp(`^(?:${escaped})\\s*[:：-]\\s*(.+)$`, 'i'));
  return match ? clean(match[1]) : '';
}

function parseGLS(text) {
  const lines = text.split(/\r?\n/).map(clean).filter(Boolean);
  const data = { contact: '', address: '', city: '', postcode: '' };

  for (const line of lines) {
    for (const field of Object.keys(data)) {
      if (!data[field]) data[field] = valueAfterLabel(line, field);
    }
  }

  const postcodePattern = /\b\d{4,6}(?:-\d{4})?\b/;
  const cityLineIndex = lines.findIndex((line) => postcodePattern.test(line));
  if (!data.postcode && cityLineIndex >= 0) data.postcode = lines[cityLineIndex].match(postcodePattern)[0];
  if (!data.city && cityLineIndex >= 0) data.city = clean(lines[cityLineIndex].replace(postcodePattern, ''));

  const used = new Set(Object.values(data).filter(Boolean));
  const freeLines = lines.filter((line) => !used.has(line) && !Object.values(labels).flat().some((label) => line.toLowerCase().startsWith(label.toLowerCase())));
  if (!data.contact && freeLines.length) data.contact = freeLines[0];
  if (!data.address && freeLines.length > 1) data.address = freeLines[1];
  if (!data.city && freeLines.length > 2) data.city = freeLines[2];
  return data;
}

function showStatus(message, isError = false) {
  status.textContent = message;
  status.classList.toggle('error', isError);
}

document.querySelector('#parse').addEventListener('click', () => {
  if (!source.value.trim()) return showStatus('请先粘贴 GLS 信息。', true);
  const data = parseGLS(source.value);
  Object.entries(data).forEach(([field, value]) => { parsedInputs[field].value = value; });
  result.hidden = false;
  showStatus(Object.values(data).filter(Boolean).length ? '请确认解析结果后填入页面。' : '未识别到字段，请手动填写解析结果。', !Object.values(data).some(Boolean));
});

document.querySelector('#fill').addEventListener('click', async () => {
  const data = Object.fromEntries(Object.entries(parsedInputs).map(([field, input]) => [field, input.value.trim()]));
  if (!Object.values(data).some(Boolean)) return showStatus('没有可填入的信息。', true);
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const [{ result: report }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: fillForm, args: [data, labels] });
    showStatus(report.filled ? `已填入 ${report.filled} 个字段。` : '未找到匹配的表单字段。', !report.filled);
  } catch (error) {
    showStatus('无法在此页面填充。请打开可编辑的订单或地址表单。', true);
  }
});

function fillForm(data, fieldLabels) {
  const normalize = (value) => (value || '').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
  const inputs = [...document.querySelectorAll('input:not([type="hidden"]):not([type="submit"]), textarea')]
    .filter((input) => !input.disabled && !input.readOnly);
  let filled = 0;
  for (const [field, value] of Object.entries(data)) {
    if (!value) continue;
    const match = inputs.find((input) => {
      if (input.dataset.glsAutofilled) return false;
      const label = input.labels?.[0]?.innerText || '';
      const descriptor = normalize([input.name, input.id, input.autocomplete, input.placeholder, input.getAttribute('aria-label'), label].join(' '));
      return fieldLabels[field].some((keyword) => descriptor.includes(normalize(keyword)));
    });
    if (!match) continue;
    const prototype = match instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(prototype, 'value').set;
    setter.call(match, value);
    match.dataset.glsAutofilled = 'true';
    match.dispatchEvent(new Event('input', { bubbles: true }));
    match.dispatchEvent(new Event('change', { bubbles: true }));
    filled += 1;
  }
  return { filled };
}
